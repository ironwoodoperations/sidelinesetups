/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import Admin from './pages/Admin';
import AdminAnalytics from './pages/AdminAnalytics';
import AdminAutomations from './pages/AdminAutomations';
import AdminBilling from './pages/AdminBilling';
import AdminBookings from './pages/AdminBookings';
import AdminCOGS from './pages/AdminCOGS';
import AdminCRM from './pages/AdminCRM';
import AdminDashboard from './pages/AdminDashboard';
import AdminDiscountCodes from './pages/AdminDiscountCodes';
import AdminEvents from './pages/AdminEvents';
import AdminExports from './pages/AdminExports';
import AdminGoLive from './pages/AdminGoLive';
import AdminLockCleanup from './pages/AdminLockCleanup';
import AdminPackages from './pages/AdminPackages';
import AdminParks from './pages/AdminParks';
import AdminPullSheets from './pages/AdminPullSheets';
import AdminReports from './pages/AdminReports';
import AdminRunSheets from './pages/AdminRunSheets';
import AdminSeedData from './pages/AdminSeedData';
import AdminSettings from './pages/AdminSettings';
import AdminSpend from './pages/AdminSpend';
import AdminStaff from './pages/AdminStaff';
import AdminUpload from './pages/AdminUpload';
import AdminXero from './pages/AdminXero';
import AdminXeroMapping from './pages/AdminXeroMapping';
import CheckIn from './pages/CheckIn';
import EmployeeQuickActions from './pages/EmployeeQuickActions';
import Event from './pages/Event';
import Home from './pages/Home';
import Inventory from './pages/Inventory';
import Kiosk from './pages/Kiosk';
import ManagerDailyOverview from './pages/ManagerDailyOverview';
import MyBookings from './pages/MyBookings';
import PullSheets from './pages/PullSheets';
import Receipt from './pages/Receipt';
import RunAutomation from './pages/RunAutomation';
import SignIn from './pages/SignIn';
import SmsLogin from './pages/SmsLogin';
import Staff from './pages/Staff';
import StaffDashboard from './pages/StaffDashboard';
import StaffDay from './pages/StaffDay';
import StaffLogin from './pages/StaffLogin';
import StaffMobile from './pages/StaffMobile';
import StaffSms from './pages/StaffSms';
import SystemCheck from './pages/SystemCheck';
import ThankYou from './pages/ThankYou';
import app from './pages/_app';
import adminDiscountCodes from './pages/admin-discount-codes';
import adminXeroMapping from './pages/admin-xero-mapping';
import adminXero from './pages/admin-xero';
import admin from './pages/admin';
import admindashboard from './pages/admindashboard';
import adminupload from './pages/adminupload';
import book from './pages/book';
import checkin from './pages/checkin';
import customerLogin from './pages/customer-login';
import employeeQuickActions from './pages/employee-quick-actions';
import events from './pages/events';
import faq from './pages/faq';
import index from './pages/index';
import kiosk from './pages/kiosk';
import mybookings from './pages/mybookings';
import ourstory from './pages/ourstory';
import packages from './pages/packages';
import privacyPolicy from './pages/privacy-policy';
import pullsheets from './pages/pullsheets';
import smsLogin from './pages/sms-login';
import staffDashboard from './pages/staff-dashboard';
import staffLogin from './pages/staff-login';
import staffSms from './pages/staff-sms';
import staff from './pages/staff';
import termsAndConditions from './pages/terms-and-conditions';
import thankyou from './pages/thankyou';
import Events from './pages/Events';
import Packages from './pages/Packages';
import bookNew from './pages/book-new';
import AdminDocs from './pages/AdminDocs';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Admin": Admin,
    "AdminAnalytics": AdminAnalytics,
    "AdminAutomations": AdminAutomations,
    "AdminBilling": AdminBilling,
    "AdminBookings": AdminBookings,
    "AdminCOGS": AdminCOGS,
    "AdminCRM": AdminCRM,
    "AdminDashboard": AdminDashboard,
    "AdminDiscountCodes": AdminDiscountCodes,
    "AdminEvents": AdminEvents,
    "AdminExports": AdminExports,
    "AdminGoLive": AdminGoLive,
    "AdminLockCleanup": AdminLockCleanup,
    "AdminPackages": AdminPackages,
    "AdminParks": AdminParks,
    "AdminPullSheets": AdminPullSheets,
    "AdminReports": AdminReports,
    "AdminRunSheets": AdminRunSheets,
    "AdminSeedData": AdminSeedData,
    "AdminSettings": AdminSettings,
    "AdminSpend": AdminSpend,
    "AdminStaff": AdminStaff,
    "AdminUpload": AdminUpload,
    "AdminXero": AdminXero,
    "AdminXeroMapping": AdminXeroMapping,
    "CheckIn": CheckIn,
    "EmployeeQuickActions": EmployeeQuickActions,
    "Event": Event,
    "Home": Home,
    "Inventory": Inventory,
    "Kiosk": Kiosk,
    "ManagerDailyOverview": ManagerDailyOverview,
    "MyBookings": MyBookings,
    "PullSheets": PullSheets,
    "Receipt": Receipt,
    "RunAutomation": RunAutomation,
    "SignIn": SignIn,
    "SmsLogin": SmsLogin,
    "Staff": Staff,
    "StaffDashboard": StaffDashboard,
    "StaffDay": StaffDay,
    "StaffLogin": StaffLogin,
    "StaffMobile": StaffMobile,
    "StaffSms": StaffSms,
    "SystemCheck": SystemCheck,
    "ThankYou": ThankYou,
    "_app": app,
    "admin-discount-codes": adminDiscountCodes,
    "admin-xero-mapping": adminXeroMapping,
    "admin-xero": adminXero,
    "admin": admin,
    "admindashboard": admindashboard,
    "adminupload": adminupload,
    "book": book,
    "checkin": checkin,
    "customer-login": customerLogin,
    "employee-quick-actions": employeeQuickActions,
    "events": events,
    "faq": faq,
    "index": index,
    "kiosk": kiosk,
    "mybookings": mybookings,
    "ourstory": ourstory,
    "packages": packages,
    "privacy-policy": privacyPolicy,
    "pullsheets": pullsheets,
    "sms-login": smsLogin,
    "staff-dashboard": staffDashboard,
    "staff-login": staffLogin,
    "staff-sms": staffSms,
    "staff": staff,
    "terms-and-conditions": termsAndConditions,
    "thankyou": thankyou,
    "Events": Events,
    "Packages": Packages,
    "book-new": bookNew,
    "AdminDocs": AdminDocs,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};