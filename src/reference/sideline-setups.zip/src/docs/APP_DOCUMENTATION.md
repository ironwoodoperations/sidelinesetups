# Sideline Setups — Complete Application Documentation

> **Generated:** March 2026  
> **Platform:** Base44 (React + Vite + Tailwind CSS)  
> **Purpose:** This document covers every facet of the Sideline Setups web application for developers, stakeholders, and operations teams.

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [App Structure & Routes](#2-app-structure--routes)
3. [Data Models / Entities](#3-data-models--entities)
4. [Features & Functionality](#4-features--functionality)
5. [Business Logic & Workflows](#5-business-logic--workflows)
6. [Integrations](#6-integrations)
7. [User Roles & Permissions](#7-user-roles--permissions)
8. [Backend Functions](#8-backend-functions)
9. [Environment Variables / Secrets](#9-environment-variables--secrets)
10. [Known Limitations & TODOs](#10-known-limitations--todos)

---

## 1. Project Overview

**Sideline Setups** is a sports equipment rental and setup service for youth sports families in East Texas. Tournament and league weekends are long, hot, and exhausting — Sideline Setups solves this by delivering, setting up, and breaking down tents, chairs, coolers, fans, and other comfort equipment at the ballfield so families can simply show up and enjoy the game.

### Target Users
| User Type | Description |
|---|---|
| **Sports Parents / Customers** | Families attending youth baseball, softball, and soccer tournaments or leagues |
| **Staff / Field Crew** | Employees who physically set up and break down equipment at fields |
| **Managers** | Supervisors overseeing field operations and daily logistics |
| **Admins** | Back-office operators managing events, inventory, bookings, and reports |

### Core Value Proposition
- Book online in 2 minutes
- Arrive to find your setup ready
- Leave when you want — crew handles teardown

---

## 2. App Structure & Routes

### Navigation Flow (Public)
```
Home → Events → Book (book-new) → ThankYou
                    ↓
               Packages page (browse only)
```

### Public Pages
| Route | Page File | Description |
|---|---|---|
| `/` | `pages/Home` | Landing page with hero, benefits, how-it-works, testimonials, CTA |
| `/events` or `/Events` | `pages/events` / `pages/Events` | Browse active tournaments & leagues, filter by sport/type |
| `/packages` or `/Packages` | `pages/packages` / `pages/Packages` | Browse all available packages |
| `/book` | `pages/book` | Legacy booking flow |
| `/book-new` | `pages/book-new` | Current primary booking flow (full multi-step form) |
| `/thankyou` or `/ThankYou` | `pages/thankyou` | Post-payment confirmation with QR code |
| `/faq` | `pages/faq` | Frequently Asked Questions |
| `/ourstory` | `pages/ourstory` | Our Story page |
| `/privacy-policy` | `pages/privacy-policy` | Privacy Policy (legal) |
| `/terms-and-conditions` | `pages/terms-and-conditions` | Terms & Conditions (legal) |
| `/receipt` or `/Receipt` | `pages/Receipt` | Booking receipt viewer |
| `/mybookings` or `/MyBookings` | `pages/mybookings` | Customer's booking list |
| `/customer-login` | `pages/customer-login` | Customer login via SMS OTP |

### Staff Pages (requires staff session)
| Route | Page File | Description |
|---|---|---|
| `/staff-login` or `/StaffLogin` | `pages/staff-login` | Staff login (PIN or magic link) |
| `/staff-dashboard` or `/StaffDashboard` | `pages/StaffDashboard` | Main staff dashboard |
| `/staff` or `/Staff` | `pages/Staff` | Staff overview |
| `/StaffMobile` | `pages/StaffMobile` | Mobile-optimized staff UI |
| `/staff-sms` or `/StaffSms` | `pages/StaffSms` | Staff SMS communication |
| `/employee-quick-actions` or `/EmployeeQuickActions` | `pages/EmployeeQuickActions` | Quick action buttons for field crew |
| `/CheckIn` or `/checkin` | `pages/CheckIn` | Customer check-in flow |
| `/Kiosk` or `/kiosk` | `pages/Kiosk` | On-site kiosk interface |
| `/PullSheets` or `/pullsheets` | `pages/PullSheets` | Equipment pull sheets for staff |
| `/StaffDay` | `pages/StaffDay` | Day-level view for staff scheduling |
| `/Inventory` | `pages/Inventory` | Inventory management view |
| `/ManagerDailyOverview` | `pages/ManagerDailyOverview` | Manager's daily summary |

### Admin Pages (requires Base44 admin auth)
| Route | Page File | Description |
|---|---|---|
| `/Admin` or `/admin` | `pages/Admin` | Central admin dashboard hub |
| `/AdminDashboard` or `/admindashboard` | `pages/AdminDashboard` | Dashboard metrics |
| `/AdminBookings` | `pages/AdminBookings` | Manage all bookings |
| `/AdminEvents` | `pages/AdminEvents` | Manage events (tournaments/leagues) |
| `/AdminPackages` | `pages/AdminPackages` | Manage packages & pricing |
| `/AdminParks` | `pages/AdminParks` | Manage parks, fields, and spots |
| `/AdminStaff` | `pages/AdminStaff` | Manage staff/employees |
| `/AdminSettings` | `pages/AdminSettings` | Site-wide settings |
| `/AdminCRM` | `pages/AdminCRM` | CRM & marketing contacts |
| `/AdminDiscountCodes` | `pages/AdminDiscountCodes` | Discount / coupon codes |
| `/AdminAnalytics` | `pages/AdminAnalytics` | Website traffic analytics |
| `/AdminReports` | `pages/AdminReports` | Financial and operational reports |
| `/AdminCOGS` | `pages/AdminCOGS` | Cost of goods tracking |
| `/AdminSpend` | `pages/AdminSpend` | Expense / spend tracking |
| `/AdminXero` or `/admin-xero` | `pages/AdminXero` | Xero accounting integration |
| `/AdminXeroMapping` | `pages/AdminXeroMapping` | Map items to Xero account codes |
| `/AdminRunSheets` | `pages/AdminRunSheets` | Operational run sheets |
| `/AdminPullSheets` | `pages/AdminPullSheets` | Equipment pull sheets admin view |
| `/AdminGoLive` | `pages/AdminGoLive` | Pre-launch go-live checklist |
| `/AdminLockCleanup` | `pages/AdminLockCleanup` | Clean up stale booking locks |
| `/AdminBilling` | `pages/AdminBilling` | Billing management |
| `/AdminAutomations` | `pages/AdminAutomations` | Manage scheduled automations |
| `/AdminExports` | `pages/AdminExports` | Data export tools |
| `/AdminUpload` or `/adminupload` | `pages/AdminUpload` | File upload management |
| `/AdminSeedData` | `pages/AdminSeedData` | Seed demo/test data |
| `/SystemCheck` | `pages/SystemCheck` | System health check |
| `/RunAutomation` | `pages/RunAutomation` | Manually trigger automations |
| `/AdminDocs` | `pages/AdminDocs` | **This documentation** |

### Layout System
- All public and staff pages are wrapped by `Layout.jsx`
- Layout provides: navigation hamburger menu, hero section with background image, footer with contact info and links
- Admin pages render within a simplified admin shell (no public header/footer)

---

## 3. Data Models / Entities

### Bookings
The central entity — represents a paid reservation.

| Field | Type | Description |
|---|---|---|
| `fullName` | string | Customer full name |
| `contactEmail` | string | Customer email |
| `phone` | string | Customer phone |
| `teamName` | string | Sports team name |
| `coachName` | string | Coach name (optional) |
| `eventId` | string | FK → Events |
| `eventType` | enum: `tournament`, `league` | Event type |
| `sport` | enum: `softball`, `baseball`, `soccer` | Sport type |
| `date` | date | Booking date |
| `gameTimes` | array[string] | Game time slots |
| `parkId` | string | FK → Parks |
| `fieldId` | string | FK → Fields |
| `spotId` | string | FK → Spots |
| `setupSideLabel` | string | Spot label shown to customer |
| `packageId` | string | FK → Packages |
| `packageMode` | enum: `per_game`, `day`, `weekend`, `hourly` | Pricing mode |
| `addOns` | array[object] | Selected add-ons with quantity & duration |
| `lineItemsJson` | array[object] | Detailed line items: `{label, qty, unitCents, totalCents}` |
| `baseCents` | integer | Package subtotal in cents |
| `addOnCents` | integer | Add-ons subtotal in cents |
| `totalCents` | integer | Grand total after discounts |
| `discountCodeId` | string | FK → DiscountCodes |
| `discountAmountCents` | integer | Amount discounted |
| `loyaltyPointsEarned` | integer | Points earned from this booking |
| `loyaltyPointsRedeemed` | integer | Points redeemed |
| `loyaltyDiscountCents` | integer | Loyalty discount amount |
| `status` | enum | See status flow below |
| `agreedToTerms` | boolean | T&C acceptance |
| `smsConsentGiven` | boolean | SMS marketing consent |
| `smsConsentAt` | datetime | Consent timestamp |
| `consentIp` | string | IP at time of consent |
| `consentUa` | string | User agent at time of consent |
| `xeroInvoiceId` | string | Xero invoice ID |
| `idPhotoUri` | string | Private file URI for ID photo |
| `idVerifiedBy` | string | Staff email who verified ID |
| `equipmentSetupChecklist` | object | Per-item setup check tracking |
| `equipmentReturnedChecklist` | object | Per-item return check tracking |
| `archived` | boolean | Soft-delete flag |
| `notes` | string | Special requests |

**Booking Status Flow:**
```
pending → paid → photo_uploaded → setup → checked_in → leaving → picked_up → closed
                                                                           ↘ cancelled
```

---

### Events
Tournaments or leagues where Sideline Setups operates.

| Field | Type | Description |
|---|---|---|
| `name` | string | Event name |
| `eventType` | enum: `tournament`, `league` | Type |
| `sport` | enum: `softball`, `baseball`, `soccer` | Sport |
| `city` | string | City |
| `startDate` / `endDate` | date | Event dates |
| `description` | string | Description |
| `website` | string | External event website |
| `imageUrl` | string | Event logo/banner |
| `parkIds` | array[string] | FK[] → Parks |
| `fieldIds` | array[string] | FK[] → Fields |
| `packageIds` | array[string] | FK[] → Packages (restrict available packages) |
| `leagueEnabled` | boolean | Enables league-specific features |
| `leagueDates` | array[string] | Available dates (ISO strings) |
| `leagueStartTime` | string | First slot time (HH:mm) |
| `leagueEndTime` | string | Last slot time (HH:mm) |
| `leagueBufferMinutes` | number | Slot duration including buffer |
| `leagueDefaultSpotsPerSlot` | number | Default spots per time slot |
| `isActive` | boolean | Published/visible |
| `archived` | boolean | Past events auto-archived 1 day after endDate |

---

### Packages
Products customers can book (tent setups with equipment bundles).

| Field | Type | Description |
|---|---|---|
| `name` | string | Package name |
| `description` | string | Description |
| `thumbnailUrl` | string | Package image |
| `basePrice` | number | Base price (legacy) |
| `perGameUSD` | number | Per-game price |
| `perDayUSD` | number | Full-day price |
| `fullWeekendUSD` | number | Full weekend price |
| `baseItems` | array[{equipmentId, qty}] | Equipment included |
| `addOnIds` | array[string] | FK[] → AddOns (available upgrades) |
| `features` | array[string] | Feature bullet points |
| `colorTheme` | enum | UI color accent |
| `showForTournament` | boolean | Show in tournament booking |
| `showForLeague` | boolean | Show in league booking |
| `showOnPackagesPage` | boolean | Show on public Packages page |
| `isActive` | boolean | Active/available |
| `displayOrder` | number | Sort order |

---

### Parks
Physical ballpark/complex locations.

| Field | Type | Description |
|---|---|---|
| `name` | string | Park name |
| `parkType` | enum: `tournament`, `league`, `hybrid` | Usage type |
| `streetAddress`, `city`, `state`, `zip` | string | Address |
| `notes` | string | Internal notes |

---

### Fields
Fields within a park.

| Field | Type | Description |
|---|---|---|
| `parkId` | string | FK → Parks |
| `name` | string | Field name |
| `imageUrl` | string | Field map image (used for visual spot picker) |
| `maxLeagueSpots` | number | Max simultaneous league setups |

---

### Spots
Individual setup locations on a field.

| Field | Type | Description |
|---|---|---|
| `fieldId` | string | FK → Fields |
| `label` | string | Display label (e.g., "A1", "Left Side") |
| `x` / `y` | number | Percentage coordinates on field image |
| `isActive` | boolean | Available for booking |

---

### Equipment
Physical inventory items.

| Field | Type | Description |
|---|---|---|
| `type` | enum | `tent`, `chair`, `cooler`, `sidewall`, `fan`, `lighting`, `audio`, `misc` |
| `name` | string | Item name |
| `thumbnailUrl` | string | Image |
| `totalQty` | number | Total units owned |
| `availableQty` | number | Currently available |
| `rentedQty` | number | Currently rented out |
| `maintenanceQty` | number | In maintenance |
| `damagedQty` | number | Damaged units |
| `condition` | enum | `excellent`, `good`, `fair`, `needs_repair` |
| `cogsPerUseUSD` | number | Cost of goods per deployment |
| `version` | number | Optimistic concurrency control version |
| `displayOrder` | number | Sort order in admin |

---

### AddOns
Optional upsell items (e.g., extra chairs, fans, sidewalls).

> Schema in `entities/AddOns.json` — fields include: `label`, `description`, `perGameUSD`, `perDayUSD`, `fullWeekendUSD`, `equipmentId` (FK → Equipment), `thumbnailUrl`, `isActive`, `displayOrder`

---

### Customers
Customer records linked to bookings.

| Field | Type | Description |
|---|---|---|
| `fullName` | string | Full name |
| `email` | string | Email |
| `phone` | string | Phone |
| `address` | string | Address |

---

### Locks
Temporary holds on spots during checkout to prevent double-booking.

| Field | Type | Description |
|---|---|---|
| `bookingId` | string | FK → Bookings |
| `eventId` / `parkId` / `fieldId` / `spotId` | string | Location references |
| `date` | date | Lock date |
| `times` | array[string] | Locked time slots |
| `items` | array[object] | Locked equipment items |
| `status` | enum: `active`, `released`, `expired` | Lock status |
| `expiresAt` | datetime | Auto-expiry timestamp |

---

### SiteSettings
Singleton configuration record (only one row used).

| Field | Type | Description |
|---|---|---|
| `brandName` | string | Brand name |
| `defaultSport` | enum | Default sport on events page |
| `theme` | enum: `light`, `dark` | UI theme |
| `heroSoftballUrl` / `heroBaseballUrl` / `heroSoccerUrl` | string | Sport hero images |
| `heroHomePageUrl` / `heroEventsPageUrl` / etc. | string | Page-specific hero images |
| `pageBackgroundPatternUrl` | string | Background pattern for all public pages |
| `logoUrl` | string | Brand logo URL |
| `supportEmail` | string | Support email displayed in footer/receipts |
| `supportPhone` | string | Support phone number |
| `paypalMode` | enum: `sandbox`, `live` | PayPal environment |
| `twilioTestMode` | boolean | SMS test mode |
| `xeroAccountMappings` | object | Package/addon → Xero account code mapping |
| `internalIpAddresses` | array[string] | IPs excluded from analytics |

---

### LeagueSpotInventory
Per-time-slot inventory for league bookings with optimistic concurrency.

| Field | Type | Description |
|---|---|---|
| `eventId`, `fieldId`, `parkId` | string | References |
| `date` | date | Slot date |
| `time` | string | Slot time (HH:mm) |
| `availableSpots` | number | Spots available |
| `version` | number | CAS version for concurrent writes |

---

### DiscountCodes
Coupon / discount codes for checkout.

> Fields: `code`, `type` (`percentage`/`fixed_amount`), `value`, `maxUsage`, `usageCount`, `expiresAt`, `isActive`, `applicablePackageIds`, `applicableEventIds`

---

### LoyaltyCredits / LoyaltyTransactions
Customer loyalty point balance and transaction history.

---

### Employees
Staff/crew members.

> Fields include: `fullName`, `email`, `role`, `pin` (hashed), `isActive`

---

### Timeclock
Staff time tracking — punch in/out.

| Field | Type |
|---|---|
| `staffId` | string |
| `parkId` | string |
| `clockIn` / `clockOut` | datetime |

---

### Other Entities (Supporting)
| Entity | Purpose |
|---|---|
| `SetupUpdates` | Staff marks booking ready / status notes |
| `PaymentEvents` | PayPal webhook audit log |
| `WalletPasses` | Apple/Google Wallet pass URLs per booking |
| `CRMContacts` | Marketing contact list |
| `MailingListSignup` | Newsletter email capture |
| `DraftOrder` | Pre-booking draft state |
| `Campaigns` / `Templates` / `Audiences` / `Sends` | Email/SMS marketing campaign system |
| `Reminders` | Booking reminder records |
| `Invoices` / `Credits` / `Refunds` | Financial records |
| `COGS` | Cost of goods sold records |
| `Vendors` / `Purchases` / `PurchaseItems` | Vendor/spend tracking |
| `InventoryMovements` | Audit log of equipment movements |
| `GoLiveRun` / `GoLiveCheck` | Pre-launch checklist items |
| `CheckinFailures` | Log of failed check-in attempts |
| `MagicTokens` | Email magic link tokens for auth |
| `PageVisit` | Website analytics — page view records |
| `SpotTemplate` | Reusable spot layout templates for fields |
| `FAQ` | FAQ items for the public FAQ page |
| `SurveyResponse` | Post-booking survey responses |

---

## 4. Features & Functionality

### 4.1 Public Booking Flow (`/book-new`)
The primary customer-facing booking experience. Multi-step form:

1. **Event Selection** — Event pre-loaded from `?event=<id>` URL param
2. **Package Selection** — Cards showing available packages with inventory indicators; "Build Your Own" option available
3. **Duration Selection** (`PackageDurationSelector`) — Choose per-game, full-day (Sat/Sun), or full weekend pricing
4. **Add-Ons Selection** — Optional upgrades (fans, extra chairs, etc.) with per-game or weekend pricing; quantity selector with inventory limit enforcement
5. **Best Deal Check** — AI-powered analysis (`checkBestDeal` function) that compares current selection against all packages and suggests a better deal
6. **Schedule Selection** — Date + game times (or "Waiting on Schedule"); league events show inventory-aware time slot picker
7. **Location Selection** — Park dropdown → Field dropdown → Visual spot picker (interactive map with click-to-select)
8. **Customer Information** — Name, email, phone, team name, coach name, notes
9. **Consent** — Terms & Conditions + SMS consent checkboxes
10. **Discount Code** — Optional coupon code validation
11. **Order Summary** — Live-calculated line items, subtotal, tax, discount, total
12. **PayPal Payment** — PayPal SDK buttons; on success booking is created and redirected to `/thankyou`

**Key behaviors:**
- Package inventory calculated from equipment `availableQty`
- League spot inventory uses optimistic concurrency (CAS) to prevent race conditions
- Locks are created during checkout and released on cancellation/expiry
- All pricing computed client-side in cents to avoid float rounding

---

### 4.2 Events Page (`/events`)
- Grid of active, non-archived events
- Filter by sport (softball/baseball/soccer) with image-card sport tabs
- Filter by type (tournament/league)
- Sorted by start date ascending
- "Request My Event" mailto link
- Each card links to `/book?event=<id>`

---

### 4.3 Packages Page (`/packages`)
- Displays all packages where `showOnPackagesPage: true`
- Pricing breakdown (per game / per day / full weekend)
- Feature list
- "Book Now" CTA linking to events

---

### 4.4 Thank You Page (`/thankyou`)
- Fetches booking by ID from `?b=<bookingId>` param
- Shows full booking summary: package, add-ons, location, date, game times, total paid
- QR code for on-site check-in
- Map showing setup location
- "Resend confirmation email" button
- Receipt download

---

### 4.5 My Bookings (`/mybookings`)
- Customer must authenticate via SMS OTP (`/customer-login`)
- Shows all bookings for the logged-in customer email
- Filter by upcoming/past
- View receipt, contact support

---

### 4.6 Staff Dashboard
- Accessed after staff PIN login or magic link
- Shows today's bookings with status
- Quick actions: mark setup ready, check in customer, mark returning, photo capture of ID
- Pull sheets showing equipment needed per booking
- Timeclock punch in/out
- Kiosk mode for customer self-check-in

---

### 4.7 Admin Dashboard (`/Admin`)
Lazy-loaded sidebar navigation with modules:
- **Overview** — Metrics, quick actions
- **Bookings** — Full booking management, status changes, archiving, deletion
- **Events** — CRUD events, manage dates, parks/fields, league inventory generation, bulk import, archiving
- **Packages** — CRUD packages with drag-and-drop reordering, equipment linking, add-on assignment
- **Parks** — Manage parks → fields → visual spot placement
- **Equipment/Inventory** — CRUD equipment, drag-and-drop reorder, stock tracking
- **Add-Ons** — Manage upsell items with pricing tiers
- **Discount Codes** — Create/manage coupons
- **CRM** — Contact management, tagging, campaign sending
- **Staff** — Employee management, PIN assignment, shifts
- **Reports** — Revenue by day/park, package mix, add-on sales, payroll, utilization
- **COGS** — Cost of goods tracking
- **Spend** — Vendor purchases and expenses
- **Analytics** — Page visit data, device/browser breakdown, daily trends
- **Xero** — Push bookings to Xero, account mapping
- **Settings** — Site-wide configuration, images, PayPal mode, Twilio mode
- **Pull Sheets** / **Run Sheets** — Operational documents
- **Go Live Checklist** — Pre-launch verification
- **Docs** — This documentation page

---

### 4.8 Visual Spot Picker
- When a field has an `imageUrl`, spots render as clickable circular buttons overlaid on the field image
- Spot positions stored as `x`/`y` percentage coordinates
- Admin can drag spots in the park management interface
- Customer selects their preferred setup location during booking

---

## 5. Business Logic & Workflows

### 5.1 Pricing Engine
All pricing is calculated in cents to avoid floating point errors.

```
baseCents = package price × duration multiplier
addOnCents = sum of each add-on × quantity × duration
subtotalCents = baseCents + addOnCents
discountCents = from applied coupon code (% or fixed)
loyaltyDiscountCents = redeemed loyalty points × conversion rate
totalCents = subtotalCents - discountCents - loyaltyDiscountCents + tax + service fee
```

**Duration types:** `GAME`, `DAY`, `WEEKEND`, `WEEKEND_MIXED`, `NONE`

### 5.2 Inventory Management
- Each Package has `baseItems` (array of `{equipmentId, qty}`)
- Available packages = `floor(equipment.availableQty / item.qty)` across all items
- When a booking is confirmed → `inventoryAllocate` function decrements `availableQty` and increments `rentedQty`
- When equipment is returned → `inventoryRelease` reverses the allocation
- Equipment uses `version` field for optimistic concurrency control (CAS)

### 5.3 League Spot Reservation (CAS)
1. Customer selects time slot
2. Frontend shows available slots from `leagueListInventory`
3. On payment success, `leagueReserveSlotCAS` atomically decrements `availableSpots`
4. If slot was taken between display and payment → customer is shown a "slot taken" error and asked to choose again

### 5.4 Booking Locks
- A `Locks` record is created when a customer begins checkout
- Lock expires after a configurable time (typically 10-15 minutes)
- If a lock exists for a spot/time on a date, that slot appears unavailable to others
- `AdminLockCleanup` page provides manual cleanup of expired locks

### 5.5 Customer Authentication
1. Customer enters phone number at `/customer-login`
2. System sends SMS OTP via Twilio
3. Customer enters OTP → validated by `auth/verifySmsOtp`
4. Session token stored in `sessionStorage` as `customer.session`
5. Session includes `customerEmail`, `customerId`, expiry

### 5.6 Staff Authentication
- Staff log in via PIN (numeric code stored as hash on Employee record)
- `employeePinLogin` function validates PIN and returns signed JWT session
- Session stored in `sessionStorage` as `ss.session`
- Magic link login also supported via `requestMagicLink` / `verifyMagicLink`

### 5.7 ID Verification at Check-In
1. Staff captures photo of customer ID using device camera
2. Photo uploaded privately via `uploadIdPhoto` function
3. Staff verifies ID matches booking name → marks `idVerifiedBy`
4. If no ID available → supervisor can approve via `approveIdSkip`
5. Bookings checked in without ID are flagged with `needsIdReview: true`

### 5.8 Loyalty Points
- Points earned per booking: configurable rate
- Points redeemed at checkout for a dollar discount
- Balance tracked in `LoyaltyCredits` entity
- Transaction history in `LoyaltyTransactions`

### 5.9 Post-Booking Notifications
On successful payment, multiple notifications are triggered:
1. **Customer confirmation email** (Resend) with booking details and receipt
2. **Customer SMS** (Twilio) with confirmation message
3. **Admin/internal copy** email to support address
4. Xero invoice created (if enabled)
5. Loyalty points awarded

### 5.10 Event Auto-Archiving
- Events with `endDate` in the past (by more than 1 day) are automatically marked `archived: true`
- Archived events are hidden from public Events page
- Admin can view and un-archive events

### 5.11 CRM & Marketing Campaigns
- Customer data synced to `CRMContacts` via `crmUpsertContactsFromBookings`
- Tags applied based on booking history, sport, event
- Email campaigns via Resend (broadcast)
- SMS campaigns via Twilio
- Campaign analytics tracked in `Sends` entity
- Scheduled campaigns run via automations

---

## 6. Integrations

| Service | Purpose | Config |
|---|---|---|
| **PayPal** | Payment processing for bookings | `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, `PAYPAL_MODE` (sandbox/live) |
| **Twilio** | SMS notifications and OTP auth | `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_MESSAGING_SERVICE_SID` |
| **Resend** | Transactional email delivery | `RESEND_API_KEY`, `EMAIL_FROM_ADDRESS`, `EMAIL_FROM_NAME` |
| **Xero** | Accounting — invoice creation, account mapping | `XERO_CLIENT_ID`, `XERO_CLIENT_SECRET`, `XERO_ACCOUNT_CODE`, `XERO_TAX_TYPE` |
| **Base44** | Platform (auth, database, file storage, functions) | `BASE44_SERVICE_API_KEY` |

### PayPal Flow
1. Frontend calls `getPayPalClientId` function
2. PayPal JS SDK loaded with client ID
3. Customer clicks PayPal button → `paypalCreateOrder` creates order
4. PayPal handles payment UI
5. On approval → `paypalCaptureOrder` captures funds
6. Booking is created on success

### Xero Flow
- `xeroPush` function creates Xero invoices from bookings
- `xeroExportCsv` generates CSV exports
- Account codes mapped in `SiteSettings.xeroAccountMappings`

---

## 7. User Roles & Permissions

### Role Matrix

| Feature | Public | Customer | Staff | Admin |
|---|---|---|---|---|
| View Home/Events/Packages | ✅ | ✅ | ✅ | ✅ |
| Book a setup | ✅ | ✅ | ✅ | ✅ |
| View My Bookings | ❌ | ✅ | ❌ | ✅ |
| Staff Dashboard | ❌ | ❌ | ✅ | ✅ |
| Mark booking setup/ready | ❌ | ❌ | ✅ | ✅ |
| Check in customers | ❌ | ❌ | ✅ | ✅ |
| Punch in/out (timeclock) | ❌ | ❌ | ✅ | ✅ |
| Admin Dashboard | ❌ | ❌ | ❌ | ✅ |
| Manage Events/Packages | ❌ | ❌ | ❌ | ✅ |
| Manage Staff/Employees | ❌ | ❌ | ❌ | ✅ |
| View Financial Reports | ❌ | ❌ | ❌ | ✅ |
| Push to Xero | ❌ | ❌ | ❌ | ✅ |
| Send CRM Campaigns | ❌ | ❌ | ❌ | ✅ |

### Authentication Methods
| Role | Method |
|---|---|
| **Admin** | Base44 native auth (email/password) |
| **Staff** | Numeric PIN via `employeePinLogin` OR magic link email |
| **Customer** | SMS OTP via Twilio |
| **Public** | No auth required |

### Session Storage
- Admin: Base44 JWT (managed by platform)
- Staff: `sessionStorage["ss.session"]` — signed JWT with employee data
- Customer: `sessionStorage["customer.session"]` — object with `customerEmail`, `customerId`

### Layout Auth Guards
The `Layout.jsx` file enforces:
- Admin pages (`/Admin*`) → redirects to Base44 login if no `base44User`
- Employee pages (`/EmployeeQuickActions`, `/Kiosk`, `/StaffDashboard`, etc.) → redirects to `/staff-login` if no `userSession`
- Customer pages (`/mybookings`) → page handles its own auth redirect to `/customer-login`

---

## 8. Backend Functions

All functions are Deno Deploy serverless handlers in the `functions/` directory.

### Authentication
| Function | Description |
|---|---|
| `auth/requestSmsOtp` | Send OTP SMS to customer phone |
| `auth/verifySmsOtp` | Validate OTP, issue customer session token |
| `auth/consume-customer-token` | Exchange magic link token for session |
| `employeePinLogin` | Validate staff PIN, issue staff session |
| `requestMagicLink` | Send magic link email to staff |
| `verifyMagicLink` | Validate magic link token |
| `staff/login` / `staff/me` | Staff session management |
| `customer/me` / `customer/my-bookings` | Customer session data |

### Booking & Payments
| Function | Description |
|---|---|
| `paypalCreateOrder` | Create PayPal order with booking total |
| `paypalCaptureOrder` | Capture approved PayPal payment |
| `getPayPalClientId` | Return PayPal client ID to frontend |
| `validateDiscountCode` | Validate coupon + calculate discount |
| `checkBestDeal` | AI analysis of package selection vs alternatives |
| `inventoryAllocate` | Decrement equipment inventory on booking |
| `inventoryRelease` | Return equipment inventory on cancellation |
| `inventoryReconcile` | Reconcile inventory counts |
| `leagueReserveSlotCAS` | Atomic CAS league time slot reservation |
| `leagueListInventory` | Get available league slots with counts |
| `leagueAdjustInventory` | Admin: adjust slot availability |
| `leagueGenerateInventory` | Generate inventory slots for league event |

### Notifications
| Function | Description |
|---|---|
| `notifyBookingConfirmed` | Send email + SMS confirmation |
| `notifyBookingConfirmedWithAdminCopy` | Confirmation + internal admin copy |
| `notifyBookingConfirmedSms` | SMS-only confirmation |
| `notifyBookingSetupReady` | Notify customer setup is ready |
| `notifyBookingReturned` | Notify on return/pickup |
| `notifyBookingCompleted` | Booking closure notification |
| `notify` | Generic notification dispatcher |
| `emailSend` / `smsSend` | Low-level send functions |

### Staff Operations
| Function | Description |
|---|---|
| `markBookingSetup` | Mark booking as setup complete |
| `markBookingReturned` | Mark equipment as returned |
| `uploadIdPhoto` | Upload private ID photo |
| `verifyIdPhoto` | Staff verifies ID |
| `viewIdPhoto` | Get signed URL for private ID photo |
| `approveIdSkip` | Supervisor approves check-in without ID |
| `checkinRecordFailure` | Log failed check-in attempts |
| `timeClockIn` / `timeClockOut` / `timeClockStatus` | Staff timeclock |
| `listClockedInNow` | Get currently clocked-in staff |

### Reports & Admin
| Function | Description |
|---|---|
| `generateBookingReceipt` | Generate PDF receipt |
| `generateInvoice` | Generate PDF invoice |
| `generatePullSheetData` | Compile pull sheet data |
| `generateManagerOverview` | Generate manager daily overview |
| `getCalendarData` | Get calendar view data |
| `getBookingDetails` | Detailed booking info |
| `xeroPush` | Push booking to Xero as invoice |
| `xeroExportCsv` | Export data as CSV for Xero |
| `awardLoyaltyPoints` | Award points to customer |
| `redeemLoyaltyPoints` | Redeem points at checkout |
| `getLoyaltyBalance` | Get customer loyalty balance |
| `recordPageVisit` | Track page visit analytics |
| `applySpotTemplate` | Apply a spot layout template to a field |
| `bulkCreateFieldsWithTemplate` | Bulk-create fields with spot layout |

### CRM
| Function | Description |
|---|---|
| `crmUpsertContactsFromBookings` | Sync customers to CRM contacts |
| `crmListContacts` / `crmListTags` | Query CRM data |
| `crmSendEmailCampaign` / `crmSendSmsCampaign` | Broadcast campaigns |
| `crmSendScheduledCampaigns` | Run scheduled campaigns |
| `crmResendMetrics` | Campaign send metrics |
| `crmSubscribeStatus` | Check unsubscribe status |

### Reports (sub-directory)
| Function | Description |
|---|---|
| `reports/revenueByDay` | Revenue grouped by date |
| `reports/revenueByPark` | Revenue grouped by park |
| `reports/packageMix` | Package sales breakdown |
| `reports/addonSales` | Add-on sales breakdown |
| `reports/customerLtv` | Customer lifetime value |
| `reports/utilizationByParkDay` | Utilization rates |
| `reports/payrollSummary` | Staff payroll summary |
| `reports/timesheet` | Staff timesheet |
| `reports/setupPulls` | Equipment pulls per event |
| `reports/exportCsv` | Generic CSV export |

---

## 9. Environment Variables / Secrets

| Secret Name | Used By |
|---|---|
| `PAYPAL_CLIENT_ID` | PayPal order creation |
| `PAYPAL_CLIENT_SECRET` | PayPal order capture |
| `PAYPAL_MODE` | `sandbox` or `live` |
| `PAYPAL_CURRENCY` | Default `USD` |
| `TWILIO_ACCOUNT_SID` | SMS sending |
| `TWILIO_AUTH_TOKEN` | SMS sending |
| `TWILIO_MESSAGING_SERVICE_SID` | Twilio messaging service |
| `TWILIO_API_KEY` / `TWILIO_API_SECRET` | Twilio API access |
| `RESEND_API_KEY` | Email sending |
| `EMAIL_FROM_ADDRESS` | Sender email address |
| `EMAIL_FROM_NAME` | Sender display name |
| `EMAIL_PROVIDER` | Email provider selection |
| `XERO_CLIENT_ID` / `XERO_CLIENT_SECRET` | Xero OAuth |
| `XERO_ACCOUNT_CODE` | Default Xero account code |
| `XERO_TAX_TYPE` | Xero tax type |
| `CUSTOMER_SESSION_SECRET` | Sign customer session JWTs |
| `STAFF_SESSION_SECRET` | Sign staff session JWTs |
| `BASE44_SERVICE_API_KEY` | Base44 service-role access |
| `BRAND_NAME` | Brand name fallback |
| `SUPPORT_EMAIL` | Support email fallback |
| `SITE_DOMAIN` | Site domain for links |
| `SITE_THEME` | Default theme |
| `DEFAULT_SPORT` | Default sport selection |
| `LOGO_URL` / `HERO_*_URL` | Asset URLs |

---

## 10. Known Limitations & TODOs

### Known Limitations
- **Duplicate page routes:** Several pages exist in both PascalCase (`/Events`) and kebab-case (`/events`) — both are registered in `pages.config.js`. The canonical public-facing URLs use lowercase.
- **Legacy booking page:** `/book` (old flow) still exists alongside `/book-new` (current). The Events page links to `/book?event=id`. The old page should eventually redirect to `/book-new`.
- **No real-time updates on Staff Dashboard:** Staff must manually refresh to see new bookings; real-time subscription is partially implemented via Base44 entity subscriptions but not universally applied.
- **Loyalty system partially built:** Points earning/redemption code exists, but the customer-facing redemption UI at checkout may not be fully surfaced in `/book-new`.
- **Survey system:** `SurveyResponse` entity exists but the survey-sending flow and public survey page are not fully documented in the codebase.
- **Wallet passes:** `WalletPasses` entity and `lib/wallet` helper exist, but the Apple/Google Wallet pass generation is not fully implemented as a production-ready feature.
- **CRM campaigns:** Full marketing campaign engine is built but depends on Resend broadcast API access and correct audience segmentation setup.

### Suggested TODOs
- [ ] Redirect `/book` → `/book-new` to consolidate booking flows
- [ ] Remove duplicate lowercase/PascalCase page registrations from `pages.config.js`
- [ ] Add real-time booking updates on Staff Dashboard via entity subscriptions
- [ ] Surface loyalty points redemption widget in `/book-new` checkout
- [ ] Complete Apple/Google Wallet pass generation
- [ ] Add post-booking survey flow
- [ ] Implement automated event archiving via scheduled automation
- [ ] Add customer-facing receipt PDF download from `/mybookings`
- [ ] Build out refund/credit issuance admin workflow

---

*Documentation last updated: March 2026*