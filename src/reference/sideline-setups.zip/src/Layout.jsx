
import React, { useState, useEffect } from "react";
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { SessionProvider } from "./components/auth/SessionProvider";
import GlobalStyles from "./components/GlobalStyles";
import { getCtx } from "./components/lib/ctx";
import { base44 } from "./api/base44Client";
import { Phone, Facebook, Mail, Menu, X } from "lucide-react";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

// Helper to get/create visitor ID
function getVisitorId() {
  let visitorId = localStorage.getItem('_visitor_id');
  if (!visitorId) {
    visitorId = 'v_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
    localStorage.setItem('_visitor_id', visitorId);
  }
  return visitorId;
}

// Helper to get/create session ID
function getSessionId() {
  let sessionId = sessionStorage.getItem('_session_id');
  if (!sessionId) {
    sessionId = 's_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
    sessionStorage.setItem('_session_id', sessionId);
  }
  return sessionId;
}

// Track page visit
async function trackPageVisit(currentPageName, customerEmail = null) {
  try {
    // Only track if window is defined (client-side)
    if (typeof window !== 'undefined') {
      await base44.functions.invoke('recordPageVisit', {
        url: window.location.href,
        path: window.location.pathname,
        referrer: document.referrer,
        visitorId: getVisitorId(),
        sessionId: getSessionId(),
        pageName: currentPageName, // Pass currentPageName to the function
        customerEmail
      });
    }
  } catch (error) {
    console.error('Failed to track page visit:', error);
    // Don't block page load if tracking fails
  }
}

export default function Layout({ children, currentPageName }) {
  const [settings, setSettings] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false); // Overall auth status
  const [userSession, setUserSession] = useState(null); // For magic link staff session
  const [customerSession, setCustomerSession] = useState(null); // For customer session
  const [base44User, setBase44User] = useState(null); // For Base44 native admin session

  useEffect(() => {
    (async () => {
      let custSession = null; // Declare custSession outside try block to be accessible later
      try {
        const { settings: fetchedSettings } = await getCtx();
        setSettings(fetchedSettings || {});
        
        let authenticated = false;

        console.log('=== Layout: Starting auth check ===');
        console.log('Current page:', currentPageName);

        // 1. Check customer session FIRST (synchronous, fast)
        try {
          const rawSession = sessionStorage.getItem("customer.session");
          console.log('=== Layout: Raw customer session from storage ===', rawSession);
          
          custSession = JSON.parse(rawSession || "null");
          console.log('=== Layout: Parsed customer session ===', custSession);
          
          setCustomerSession(custSession);
          if (custSession) {
            authenticated = true;
            console.log('=== Layout: Customer authenticated ===');
          }
        } catch (e) {
          console.error("Error parsing customer session from sessionStorage:", e);
          setCustomerSession(null);
        }

        // 2. Check staff session from sessionStorage
        try {
          const staffSession = JSON.parse(sessionStorage.getItem("ss.session") || "null");
          setUserSession(staffSession);
          if (staffSession) {
            authenticated = true;
            console.log('=== Layout: Staff authenticated ===');
          }
        } catch (e) {
          console.error("Error parsing staff session from sessionStorage:", e);
          setUserSession(null);
        }

        // 3. Check Base44 authentication for potential admin access (this can fail with 401, that's OK)
        try {
          const user = await base44.auth.me();
          setBase44User(user);
          if (user) {
            authenticated = true;
            console.log('=== Layout: Base44 admin authenticated ===');
          }
        } catch (e) {
          // This is expected for non-admin users, don't log as error
          setBase44User(null);
        }

        console.log('=== Layout: Final auth state ===', { authenticated, hasCustomerSession: !!custSession });
        setIsAuthenticated(authenticated);
        
        // Track page visit (after auth check)
        const customerEmail = custSession?.email || null;
        await trackPageVisit(currentPageName, customerEmail);
        
      } catch (e) {
        console.error("Failed to load settings or check authentication:", e);
      } finally {
        setAuthChecked(true);
        console.log('=== Layout: Auth check complete ===');
      }
    })();
  }, [currentPageName]);

  const brandName = settings?.brandName || "Sideline Setups";
  const supportEmail = settings?.supportEmail || "support@sideline-setups.com";
  const supportNumber = settings?.supportPhone || "+19035419287";
  const logoUrl = settings?.logoUrl;

  // Hero background image - same for all pages
  const heroBackgroundImage = "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/c08b7e9db_generated-image.jpg";

  // Define page-specific hero content
  const pageHeroConfig = {
    Home: { showStandardHero: false },
    home: { showStandardHero: false },
    index: { showStandardHero: false },
    book: {
      showStandardHero: true,
      title: "Let's Get You Booked!",
      description: "Complete your setup reservation",
      height: '210px'
    },
    Book: {
      showStandardHero: true,
      title: "Let's Get You Booked!",
      description: "Complete your setup reservation",
      height: '210px'
    },
    'book-new': {
      showStandardHero: true,
      title: "Let's Get You Booked!",
      description: "Complete your setup reservation",
      height: '210px'
    },
    packages: { // New entry
      showStandardHero: true,
      title: "Our Packages",
      description: "Choose the perfect setup for your game day",
      height: '210px'
    },
    Packages: { // New entry
      showStandardHero: true,
      title: "Our Packages",
      description: "Choose the perfect setup for your game day",
      height: '210px'
    },
    thankyou: {
      showStandardHero: true,
      title: "Thank You",
      description: "Your booking has been confirmed",
      height: '210px'
    },
    ThankYou: {
      showStandardHero: true,
      title: "Thank You",
      description: "Your booking has been confirmed",
      height: '210px'
    },
    events: {
      showStandardHero: true,
      title: "Choose Your Event",
      description: "Select your sport and event",
      height: '210px'
    },
    Events: {
      showStandardHero: true,
      title: "Choose Your Event",
      description: "Select your sport and event",
      height: '210px'
    },
    ourstory: {
      showStandardHero: true,
      title: "Our Story",
      description: "How a simple idea became a game-changing service for sports families",
      height: '160px'
    },
    OurStory: {
      showStandardHero: true,
      title: "Our Story",
      description: "How a simple idea became a game-changing service for sports families",
      height: '160px'
    },
    faq: {
      showStandardHero: true,
      title: "Frequently Asked Questions",
      description: "Find answers to common questions about our services",
      height: '160px'
    },
    FAQ: {
      showStandardHero: true,
      title: "Frequently Asked Questions",
      description: "Find answers to common questions about our services",
      height: '160px'
    },
    mybookings: {
      showStandardHero: true,
      title: "My Bookings",
      description: "View your upcoming and past reservations",
      height: '160px'
    },
    MyBookings: {
      showStandardHero: true,
      title: "My Bookings",
      description: "View your upcoming and past reservations",
      height: '160px'
    },
    'staff-login': {
      showStandardHero: true,
      title: "Staff Login",
      description: "Access your staff dashboard",
      height: '160px'
    },
    StaffLogin: {
      showStandardHero: true,
      title: "Staff Login",
      description: "Access your staff dashboard",
      height: '160px'
    },
    'customer-login': {
      showStandardHero: true,
      title: "Customer Login",
      description: "Access your bookings and details",
      height: '160px'
    },
    CustomerLogin: {
      showStandardHero: true,
      title: "Customer Login",
      description: "Access your bookings and details",
      height: '160px'
    }
  };

  const currentConfig = pageHeroConfig[currentPageName] || pageHeroConfig[currentPageName?.toLowerCase()] || {
    showStandardHero: true,
    title: brandName,
    description: "Welcome",
    height: '160px'
  };

  const isHomePage = !currentPageName || currentPageName === "Home" || currentPageName === "home" || currentPageName === "index";
  const isAdminPage = currentPageName && (
    currentPageName === "Admin" || 
    currentPageName === "admin" || 
    currentPageName === "AdminDashboard" ||
    currentPageName === "admindashboard" ||
    currentPageName.toLowerCase().startsWith("admin")
  );
  
  const isEmployeePage = currentPageName && (
    currentPageName === "EmployeeQuickActions" ||
    currentPageName === "employee-quick-actions" ||
    currentPageName === "Kiosk" ||
    currentPageName === "kiosk" ||
    currentPageName === "StaffDashboard" ||
    currentPageName === "staff-dashboard" ||
    currentPageName === "PullSheets" ||
    currentPageName === "pullsheets"
  );

  const isCustomerPage = currentPageName && (
    currentPageName === "MyBookings" ||
    currentPageName === "mybookings"
  );

  // IMPORTANT: Don't protect auth pages - let them handle their own flow
  const isAuthPage = currentPageName && (
    currentPageName === "SignIn" ||
    currentPageName === "signin" ||
    currentPageName === "StaffLogin" ||
    currentPageName === "staff-login" ||
    currentPageName === "CustomerLogin" ||
    currentPageName === "customer-login"
  );

  // Handle logout for Base44 (admin), staff, and customer sessions
  const handleLogout = async () => {
    try {
      // Clear staff session if it exists
      sessionStorage.removeItem("ss.session");
      // Clear customer session if it exists
      sessionStorage.removeItem("customer.session");
      
      // Use base44 logout (will redirect if successful)
      await base44.auth.logout("/");
    } catch (e) {
      console.error("Logout error:", e);
      // If Base44 logout fails, ensure we still redirect to home
      window.location.href = "/";
    }
  };

  // Auth protection for admin pages - require Base44 authentication
  if (authChecked && isAdminPage && !isAuthPage) {
    if (!base44User) {
      // Redirect to Base44 login, then back to the admin page
      if (typeof window !== 'undefined') {
        base44.auth.redirectToLogin(window.location.pathname);
      }
      return (
        <QueryClientProvider client={queryClient}>
          <SessionProvider>
            <GlobalStyles />
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
              <div className="spinner"></div>
            </div>
          </SessionProvider>
        </QueryClientProvider>
      );
    }
  }

  // Auth protection for employee pages - require staff session
  if (authChecked && isEmployeePage && !isAuthPage) {
    if (!userSession) {
      // Redirect to staff login page, then back to the employee page
      if (typeof window !== 'undefined') {
        window.location.href = "/staff-login?redirect=" + encodeURIComponent(window.location.pathname);
      }
      return (
        <QueryClientProvider client={queryClient}>
          <SessionProvider>
            <GlobalStyles />
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
              <div className="spinner"></div>
            </div>
          </SessionProvider>
        </QueryClientProvider>
      );
    }
  }

  // Wait for auth check to complete before rendering protected pages (but NOT auth pages)
  // Removed isCustomerPage from this condition as customer pages will handle their own auth state.
  if (!authChecked && (isAdminPage || isEmployeePage) && !isAuthPage) {
    return (
      <QueryClientProvider client={queryClient}>
        <SessionProvider>
          <GlobalStyles />
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
            <div className="spinner"></div>
          </div>
        </SessionProvider>
      </QueryClientProvider>
    );
  }

  // If it's an admin page and we have a base44 user, render the admin layout
  if (isAdminPage && base44User) {
    return (
      <QueryClientProvider client={queryClient}>
        <SessionProvider value={{ session: base44User, logout: handleLogout }}>
          <GlobalStyles />
          <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
            {/* The Admin header is now expected to be part of the individual admin pages via their 'children' prop, 
                to avoid potential redirect loops or inconsistent rendering during Base44 auth redirects. */}
            <main style={{ flexGrow: 1, padding: '1rem', backgroundColor: '#f0f2f5' }}>
              {children}
            </main>
          </div>
        </SessionProvider>
      </QueryClientProvider>
    );
  }

  // Hamburger Menu Component for the public-facing site
  const HamburgerMenu = () => (
    <div style={{ position: 'relative' }}>
      <button
        onClick={() => setMenuOpen(!menuOpen)}
        className="bg-white bg-opacity-90 hover:bg-opacity-100 p-2 rounded-full shadow-lg hover:shadow-xl transition-all duration-200"
        style={{ color: '#003f5c' }}
        aria-label="Toggle menu"
      >
        {menuOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {menuOpen && (
        <>
          <div
            onClick={() => setMenuOpen(false)}
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              zIndex: 998
            }}
          />
          
          <div
            style={{
              position: 'absolute',
              top: '60px',
              left: 0,
              background: 'white',
              borderRadius: '12px',
              boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
              minWidth: '200px',
              zIndex: 999,
              overflow: 'hidden',
              animation: 'slideDown 0.2s ease-out'
            }}
          >
            <style>{`
              @keyframes slideDown {
                from {
                  opacity: 0;
                  transform: translateY(-10px);
                }
                to {
                  opacity: 1;
                  transform: translateY(0);
                }
              }
            `}</style>
            
            <a
              href="/"
              onClick={() => setMenuOpen(false)}
              style={{
                display: 'block',
                padding: '14px 20px',
                color: '#003f5c',
                textDecoration: 'none',
                fontSize: '16px',
                fontWeight: '500',
                borderBottom: '1px solid #e2e8f0',
                transition: 'background 0.2s'
              }}
              onMouseEnter={(e) => e.target.style.background = '#f8fafc'}
              onMouseLeave={(e) => e.target.style.background = 'white'}
            >
              Home
            </a>
            <a // New Packages link
              href="/packages"
              onClick={() => setMenuOpen(false)}
              style={{
                display: 'block',
                padding: '14px 20px',
                color: '#003f5c',
                textDecoration: 'none',
                fontSize: '16px',
                fontWeight: '500',
                borderBottom: '1px solid #e2e8f0',
                transition: 'background 0.2s'
              }}
              onMouseEnter={(e) => e.target.style.background = '#f8fafc'}
              onMouseLeave={(e) => e.target.style.background = 'white'}
            >
              Packages
            </a>
            <a
              href="/events"
              onClick={() => setMenuOpen(false)}
              style={{
                display: 'block',
                padding: '14px 20px',
                color: '#003f5c',
                textDecoration: 'none',
                fontSize: '16px',
                fontWeight: '500',
                borderBottom: '1px solid #e2e8f0',
                transition: 'background 0.2s'
              }}
              onMouseEnter={(e) => e.target.style.background = '#f8fafc'}
              onMouseLeave={(e) => e.target.style.background = 'white'}
            >
              Events
            </a>
            <a
              href={customerSession ? "/mybookings" : "/customer-login"}
              onClick={() => setMenuOpen(false)}
              style={{
                display: 'block',
                padding: '14px 20px',
                color: '#003f5c',
                textDecoration: 'none',
                fontSize: '16px',
                fontWeight: '500',
                borderBottom: '1px solid #e2e8f0',
                transition: 'background 0.2s'
              }}
              onMouseEnter={(e) => e.target.style.background = '#f8fafc'}
              onMouseLeave={(e) => e.target.style.background = 'white'}
            >
              My Bookings
            </a>
            <a
              href="/ourstory"
              onClick={() => setMenuOpen(false)}
              style={{
                display: 'block',
                padding: '14px 20px',
                color: '#003f5c',
                textDecoration: 'none',
                fontSize: '16px',
                fontWeight: '500',
                borderBottom: '1px solid #e2e8f0',
                transition: 'background 0.2s'
              }}
              onMouseEnter={(e) => e.target.style.background = '#f8fafc'}
              onMouseLeave={(e) => e.target.style.background = 'white'}
            >
              Our Story
            </a>
            <a
              href="/faq"
              onClick={() => setMenuOpen(false)}
              style={{
                display: 'block',
                padding: '14px 20px',
                color: '#003f5c',
                textDecoration: 'none',
                fontSize: '16px',
                fontWeight: '500',
                transition: 'background 0.2s'
              }}
              onMouseEnter={(e) => e.target.style.background = '#f8fafc'}
              onMouseLeave={(e) => e.target.style.background = 'white'}
            >
              FAQ
            </a>
          </div>
        </>
      )}
    </div>
  );

  // Navigation and Social Links Component for the public-facing site
  const OverlaidNavigation = () => (
    <div className="absolute top-0 left-0 right-0 z-20 p-4">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="flex items-center gap-3">
          <HamburgerMenu />
        </div>

        <div className="flex items-center gap-3">
          <a 
            href="https://www.facebook.com/share/1EV4PZggGf/"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-white bg-opacity-90 hover:bg-opacity-100 p-2 rounded-full shadow-lg hover:shadow-xl transition-all duration-200"
            style={{color: '#003f5c'}}
            title="Facebook"
          >
            <Facebook size={20} />
          </a>
          <a 
            href="https://www.tiktok.com/@sideline.setups?_t=ZP-90jkeK48A1v&_r=1"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-white bg-opacity-90 hover:bg-opacity-100 p-2 rounded-full shadow-lg hover:shadow-xl transition-all duration-200"
            style={{color: '#003f5c'}}
            title="TikTok"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64 2.93 2.93 0 01.88.13V9.4a6.84 6.84 0 00-1-.05A6.33 6.33 0 005 20.1a6.34 6.34 0 0010.86-4.43v-7a8.16 8.16 0 004.77 1.52v-3.4a4.85 4.85 0 01-1-.1z"/>
            </svg>
          </a>
        </div>
      </div>
    </div>
  );

  // Regular pages get the full layout
  return (
    <QueryClientProvider client={queryClient}>
      <SessionProvider value={{ session: customerSession || userSession || base44User, logout: handleLogout }}>
        <GlobalStyles />
        
        {/* Hero Section - WITH YOUR CUSTOM BACKGROUND IMAGE WITH DARK OVERLAY */}
        {isHomePage ? (
          <div style={{ position: 'relative' }}>
            <OverlaidNavigation />
          </div>
        ) : currentConfig.showStandardHero ? (
          <section 
            className="relative flex items-center justify-center"
            style={{
              minHeight: currentConfig.height,
              backgroundImage: `url('${heroBackgroundImage}')`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              backgroundRepeat: 'no-repeat',
              position: 'relative'
            }}
          >
            {/* Dark overlay */}
            <div style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              backgroundColor: 'rgba(0, 0, 0, 0.5)',
              zIndex: 1
            }}></div>

            <OverlaidNavigation />
            
            <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
              {settings?.logoUrl && (
                <img 
                  src={settings.logoUrl}
                  alt={brandName}
                  style={{
                    maxWidth: '150px',
                    height: 'auto',
                    margin: '0 auto 1rem auto',
                    display: 'block'
                  }}
                />
              )}
              <h1 
                className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold mb-4 leading-tight"
                style={{
                  color: 'white'
                }}
              >
                {isEmployeePage ? 'Staff Dashboard' : currentConfig.title}
              </h1>
              <p className="text-lg sm:text-xl md:text-2xl max-w-3xl mx-auto leading-relaxed" style={{ color: 'white' }}>
                {currentConfig.description}
              </p>
            </div>
          </section>
        ) : null}

        {/* Main Content with Background Pattern */}
        <main 
          style={!isHomePage && settings?.pageBackgroundPatternUrl ? {
            backgroundImage: `linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.92)), url('${settings.pageBackgroundPatternUrl}')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundAttachment: 'fixed',
            minHeight: '60vh'
          } : {}}
        >
          {children}
        </main>

        {/* Footer */}
        <footer className="footer">
          <div className="container" style={{textAlign: 'center'}}>
            <div style={{marginBottom: '1rem'}}>
              <a href="/packages" style={{margin: '0 1rem', color: 'var(--muted)'}}>Packages</a> {/* New Packages link */}
              <a href="/events" style={{margin: '0 1rem', color: 'var(--muted)'}}>Events</a>
              <a 
                href={customerSession ? "/mybookings" : "/customer-login"} 
                style={{margin: '0 1rem', color: 'var(--muted)'}}
              >
                My Bookings
              </a>
              <a href="/ourstory" style={{margin: '0 1rem', color: 'var(--muted)'}}>Our Story</a>
              <a href="/faq" style={{margin: '0 1rem', color: 'var(--muted)'}}>FAQ</a>
            </div>
            
            {/* Login Links */}
            <div style={{
              marginBottom: '1rem',
              padding: '12px',
              background: 'rgba(0,0,0,0.02)',
              borderRadius: '8px',
              display: 'inline-block'
            }}>
              {customerSession ? (
                <a href="/mybookings" style={{margin: '0 1rem', color: 'var(--primary)', fontSize: '0.875rem', fontWeight: '600', textDecoration: 'underline'}}>
                  👤 My Bookings ({customerSession.customerEmail})
                </a>
              ) : (
                <a href="/customer-login" style={{margin: '0 1rem', color: 'var(--muted)', fontSize: '0.875rem'}}>
                  👤 View My Bookings
                </a>
              )}
              <span style={{color: 'var(--border)'}}>|</span>
              {userSession ? (
                <a href="/StaffDashboard" style={{margin: '0 1rem', color: 'var(--primary)', fontSize: '0.875rem', fontWeight: '600', textDecoration: 'underline'}}>
                  👥 Staff Dashboard ({userSession.employee?.fullName || userSession.employee?.email || 'Staff'})
                </a>
              ) : (
                <a href="/staff-login" style={{margin: '0 1rem', color: 'var(--muted)', fontSize: '0.875rem'}}>
                  👥 Staff Login
                </a>
              )}
              <span style={{color: 'var(--border)'}}>|</span>
              {base44User ? (
                <a href="/Admin" style={{margin: '0 1rem', color: 'var(--primary)', fontSize: '0.875rem', fontWeight: '600', textDecoration: 'underline'}}>
                  🔐 Admin Dashboard ({base44User.full_name || base44User.email})
                </a>
              ) : (
                <a href="/Admin" style={{margin: '0 1rem', color: 'var(--muted)', fontSize: '0.875rem'}}>
                  🔐 Admin Dashboard
                </a>
              )}
            </div>
            
            {/* Contact Info in Footer */}
            <div style={{
              marginBottom: '1rem',
              display: 'flex',
              gap: '1.5rem',
              justifyContent: 'center',
              alignItems: 'center',
              flexWrap: 'wrap'
            }}>
              <a 
                href={`mailto:${supportEmail}`}
                style={{
                  color: 'var(--muted)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                  textDecoration: 'none'
                }}
              >
                <Mail size={16} />
                {supportEmail}
              </a>
              <a 
                href={`tel:${supportNumber}`}
                style={{
                  color: 'var(--muted)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                  textDecoration: 'none'
                }}
              >
                <Phone size={16} />
                {supportNumber}
              </a>
            </div>
            
            <p>© {new Date().getFullYear()} {brandName} — All rights reserved.</p>
          </div>
        </footer>
      </SessionProvider>
    </QueryClientProvider>
  );
}
