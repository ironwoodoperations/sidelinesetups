// components/Status.jsx
import React from "react";

export function Loading({ text = "Loading..." }) {
  return (
    <div style={{ textAlign: "center", padding: "60px 0", color: "var(--muted)" }}>
      <div className="spinner" />
      <p style={{ marginTop: 8 }}>{text}</p>
    </div>
  );
}

export function ErrorBlock({ msg, retry }) {
  return (
    <div className="card card-pad" style={{ textAlign: "center", color: "var(--danger)" }}>
      <h3>⚠️ Something went wrong</h3>
      <p className="mt-8">{msg}</p>
      {retry && (
        <button className="btn-outline mt-12" onClick={retry}>
          Try again
        </button>
      )}
    </div>
  );
}