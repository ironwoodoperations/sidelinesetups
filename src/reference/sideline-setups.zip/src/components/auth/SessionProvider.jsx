import React from "react";

const SessionCtx = React.createContext(null);

export function SessionProvider({ children }) {
  const [session, setSession] = React.useState(() => {
    try { 
      return JSON.parse(sessionStorage.getItem("ss.session") || "null"); 
    } catch { 
      return null; 
    }
  });

  const save = React.useCallback((next) => {
    setSession(next);
    if (next) {
      sessionStorage.setItem("ss.session", JSON.stringify(next));
    } else {
      sessionStorage.removeItem("ss.session");
    }
  }, []);

  const logout = React.useCallback(() => {
    save(null);
    window.location.href = "/";
  }, [save]);

  return (
    <SessionCtx.Provider value={{ session, setSession: save, logout }}>
      {children}
    </SessionCtx.Provider>
  );
}

export default function useSession() {
  const v = React.useContext(SessionCtx);
  if (!v) throw new Error("useSession must be used within <SessionProvider>");
  return v;
}