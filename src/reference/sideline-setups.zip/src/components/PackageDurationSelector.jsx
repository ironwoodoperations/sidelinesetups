
import React, { useEffect, useState, useRef } from "react";
import { DAY_GAME_THRESHOLD, MAX_GAMES_PER_DAY } from "./lib/pricing";

// Helper functions
function clampGames(v) {
  const n = Number(v ?? 0);
  return Math.max(0, Math.min(MAX_GAMES_PER_DAY, n));
}

function normBool(v) {
  return !!v;
}

// Calculate total from Sat/Sun selection
function summarizeSelection(selection, pkg) {
  const sat = {
    fullDay: normBool(selection?.sat?.fullDay),
    games: clampGames(selection?.sat?.games)
  };
  const sun = {
    fullDay: normBool(selection?.sun?.fullDay),
    games: clampGames(selection?.sun?.games)
  };

  // Safety: 3+ games => Full Day
  if (sat.games >= DAY_GAME_THRESHOLD) sat.fullDay = true;
  if (sun.games >= DAY_GAME_THRESHOLD) sun.fullDay = true;

  // Determine overall duration
  let duration = "CUSTOM";
  if (sat.fullDay && sun.fullDay) {
    duration = "WEEKEND";
  } else if (sat.fullDay || sun.fullDay) {
    duration = "CUSTOM";
  } else {
    const totalGames = sat.games + sun.games;
    if (totalGames === 0) duration = "NONE";
    else if (totalGames > 0) duration = "GAME";
  }

  // Pricing
  const pGame = Number(pkg?.perGameUSD || 0);
  const pDay = Number(pkg?.perDayUSD || 0);
  const pWknd = Number(pkg?.fullWeekendUSD || 0);

  // Calculate base package total
  let baseUSD = 0;
  if (sat.fullDay && sun.fullDay) {
    baseUSD = pWknd;
  } else {
    const satCents = sat.fullDay ? pDay : (sat.games * pGame);
    const sunCents = sun.fullDay ? pDay : (sun.games * pGame);
    baseUSD = Math.min(satCents + sunCents, pWknd);
  }

  return {
    sat,
    sun,
    duration,
    baseUSD,
    totalUSD: baseUSD
  };
}

export default function PackageDurationSelector({ pkg, onChange, initialSelection }) {
  // Track if component has been initialized to prevent initialSelection from overriding user choices
  const isInitialized = useRef(false);
  const lastPkgId = useRef(null);
  
  const [mode, setMode] = useState("GAMEDAY");
  const [sel, setSel] = useState({
    sat: { fullDay: false, games: 1 },
    sun: { fullDay: false, games: 0 }
  });

  // Only initialize from initialSelection on first mount or when package changes
  useEffect(() => {
    const pkgId = pkg?.id || pkg?.name;
    const pkgChanged = lastPkgId.current !== pkgId;
    
    if ((!isInitialized.current || pkgChanged) && initialSelection) {
      setSel({
        sat: initialSelection.sat || { fullDay: false, games: 1 },
        sun: initialSelection.sun || { fullDay: false, games: 0 }
      });
      
      // Determine mode from initial selection
      if (initialSelection.sat?.fullDay && initialSelection.sun?.fullDay) {
        setMode("WEEKEND");
      } else {
        setMode("GAMEDAY");
      }
      
      isInitialized.current = true;
      lastPkgId.current = pkgId;
    } else if (!isInitialized.current) {
      // No initial selection, use defaults
      isInitialized.current = true;
      lastPkgId.current = pkgId;
    }
  }, [pkg?.id, pkg?.name, initialSelection]); // Added initialSelection to dependency array

  // Handle Game/Day mode button click
  const handleGameDayMode = () => {
    setMode("GAMEDAY");
    // Keep current selection, just show the Game/Day UI
  };

  // Handle Full Weekend button click
  const handleWeekendMode = () => {
    setMode("WEEKEND");
    const newSel = { 
      sat: { fullDay: true, games: 0 }, 
      sun: { fullDay: true, games: 0 } 
    };
    setSel(newSel);
  };

  // Calculate summary and notify parent whenever selection changes
  useEffect(() => {
    const summary = summarizeSelection(sel, pkg);
    onChange?.(summary);
  }, [sel, pkg?.perGameUSD, pkg?.perDayUSD, pkg?.fullWeekendUSD]);

  const summary = summarizeSelection(sel, pkg);

  return (
    <div style={{ marginBottom: "16px" }}>
      {/* Quick Presets */}
      <div style={{ marginBottom: "16px" }}>
        <label className="label">Duration</label>
        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          <button
            type="button"
            onClick={handleGameDayMode}
            className={mode === "GAMEDAY" ? "btn" : "btn-outline"}
            style={{ fontSize: "14px", padding: "8px 16px" }}
          >
            Game/Day
          </button>
          <button
            type="button"
            onClick={handleWeekendMode}
            className={mode === "WEEKEND" ? "btn" : "btn-outline"}
            style={{ fontSize: "14px", padding: "8px 16px" }}
          >
            Full Weekend
          </button>
        </div>
      </div>

      {/* Custom Selection UI - Show for Game/Day mode */}
      {mode === "GAMEDAY" && (
        <div style={{
          padding: "16px",
          background: "#f8fafc",
          border: "1px solid #e2e8f0",
          borderRadius: "8px"
        }}>
          <div style={{ marginBottom: "16px" }}>
            <h4 style={{ margin: "0 0 12px 0", fontSize: "14px", fontWeight: "600" }}>Saturday</h4>
            <div style={{ display: "flex", gap: "12px", alignItems: "center", flexWrap: "wrap" }}>
              <label style={{ display: "flex", alignItems: "center", gap: "6px", cursor: "pointer" }}>
                <input
                  type="checkbox"
                  checked={sel.sat.fullDay}
                  onChange={(e) => setSel({
                    ...sel,
                    sat: { ...sel.sat, fullDay: e.target.checked, games: e.target.checked ? 0 : sel.sat.games }
                  })}
                />
                <span style={{ fontSize: "14px" }}>Full Day (more than 2 games choose this)</span>
              </label>
              
              {!sel.sat.fullDay && (
                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                  <span style={{ fontSize: "14px", color: "#64748b" }}>Games:</span>
                  <div style={{ display: "flex", gap: "4px" }}>
                    {[0, 1, 2].map(n => (
                      <button
                        key={n}
                        type="button"
                        onClick={() => setSel({ ...sel, sat: { ...sel.sat, games: n } })}
                        className={sel.sat.games === n ? "btn" : "btn-outline"}
                        style={{ fontSize: "12px", padding: "4px 12px" }}
                      >
                        {n}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div>
            <h4 style={{ margin: "0 0 12px 0", fontSize: "14px", fontWeight: "600" }}>Sunday</h4>
            <div style={{ display: "flex", gap: "12px", alignItems: "center", flexWrap: "wrap" }}>
              <label style={{ display: "flex", alignItems: "center", gap: "6px", cursor: "pointer" }}>
                <input
                  type="checkbox"
                  checked={sel.sun.fullDay}
                  onChange={(e) => setSel({
                    ...sel,
                    sun: { ...sel.sun, fullDay: e.target.checked, games: e.target.checked ? 0 : sel.sun.games }
                  })}
                />
                <span style={{ fontSize: "14px" }}>Full Day (more than 2 games choose this)</span>
              </label>
              
              {!sel.sun.fullDay && (
                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                  <span style={{ fontSize: "14px", color: "#64748b" }}>Games:</span>
                  <div style={{ display: "flex", gap: "4px" }}>
                    {[0, 1, 2].map(n => (
                      <button
                        key={n}
                        type="button"
                        onClick={() => setSel({ ...sel, sun: { ...sel.sun, games: n } })}
                        className={sel.sun.games === n ? "btn" : "btn-outline"}
                        style={{ fontSize: "12px", padding: "4px 12px" }}
                      >
                        {n}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Summary Display */}
      <div style={{
        marginTop: "12px",
        padding: "12px",
        background: "#eff6ff",
        border: "1px solid #bfdbfe",
        borderRadius: "8px",
        fontSize: "13px",
        color: "#1e40af"
      }}>
        <strong>Selected:</strong>{" "}
        {summary.sat.fullDay ? "Full Day Saturday" : summary.sat.games > 0 ? `${summary.sat.games} game${summary.sat.games > 1 ? 's' : ''} Saturday` : ""}
        {(summary.sat.fullDay || summary.sat.games > 0) && (summary.sun.fullDay || summary.sun.games > 0) ? " + " : ""}
        {summary.sun.fullDay ? "Full Day Sunday" : summary.sun.games > 0 ? `${summary.sun.games} game${summary.sun.games > 1 ? 's' : ''} Sunday` : ""}
        {!summary.sat.fullDay && summary.sat.games === 0 && !summary.sun.fullDay && summary.sun.games === 0 && "Nothing selected"}
      </div>
    </div>
  );
}
