import React from "react";
import { formatMoney } from "./lib/pricingDetails";

export default function LineItemsTable({ items, baseCents, addOnCents, totalCents }) {
  if (!items || items.length === 0) {
    return (
      <div style={{ padding: "20px", textAlign: "center", color: "#64748b" }}>
        No line items available
      </div>
    );
  }

  return (
    <div style={{ overflow: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "14px" }}>
        <thead>
          <tr style={{ 
            borderBottom: "2px solid #e2e8f0", 
            background: "#f8fafc",
            textAlign: "left"
          }}>
            <th style={{ padding: "12px", fontWeight: "600" }}>Item</th>
            <th style={{ padding: "12px", fontWeight: "600" }}>When</th>
            <th style={{ padding: "12px", fontWeight: "600" }}>Duration</th>
            <th style={{ padding: "12px", fontWeight: "600", textAlign: "center" }}>Qty</th>
            <th style={{ padding: "12px", fontWeight: "600", textAlign: "right" }}>Unit Price</th>
            <th style={{ padding: "12px", fontWeight: "600", textAlign: "right" }}>Total</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item, idx) => (
            <tr key={idx} style={{ borderBottom: "1px solid #f1f5f9" }}>
              <td style={{ padding: "12px" }}>{item.itemName || item.label || "Item"}</td>
              <td style={{ padding: "12px", color: "#64748b" }}>{item.dayLabel || "-"}</td>
              <td style={{ padding: "12px", color: "#64748b" }}>{item.durationLabel || "-"}</td>
              <td style={{ padding: "12px", textAlign: "center" }}>{item.qty || 1}</td>
              <td style={{ padding: "12px", textAlign: "right", color: "#64748b" }}>
                {formatMoney(item.unitCents)}
              </td>
              <td style={{ padding: "12px", textAlign: "right", fontWeight: "600" }}>
                {formatMoney(item.totalCents)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      
      {/* Totals Summary */}
      <div style={{
        marginTop: "16px",
        paddingTop: "16px",
        borderTop: "2px solid #e2e8f0",
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-end",
        gap: "8px"
      }}>
        {baseCents !== undefined && (
          <div style={{ display: "flex", gap: "24px", fontSize: "14px" }}>
            <span style={{ color: "#64748b" }}>Package Subtotal:</span>
            <span style={{ fontWeight: "600" }}>{formatMoney(baseCents)}</span>
          </div>
        )}
        {addOnCents !== undefined && addOnCents > 0 && (
          <div style={{ display: "flex", gap: "24px", fontSize: "14px" }}>
            <span style={{ color: "#64748b" }}>Add-Ons Subtotal:</span>
            <span style={{ fontWeight: "600" }}>{formatMoney(addOnCents)}</span>
          </div>
        )}
        {totalCents !== undefined && (
          <div style={{ display: "flex", gap: "24px", fontSize: "16px", marginTop: "8px" }}>
            <span style={{ fontWeight: "700" }}>Total:</span>
            <span style={{ fontWeight: "700", color: "#003f5c" }}>{formatMoney(totalCents)}</span>
          </div>
        )}
      </div>
    </div>
  );
}