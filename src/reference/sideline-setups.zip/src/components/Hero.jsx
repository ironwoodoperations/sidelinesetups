import React from "react";
import { getCtx } from "./lib/ctx";

export default function Hero() {
  const [sport, setSport] = React.useState("softball");
  const [settings, setSettings] = React.useState(null);

  React.useEffect(() => {
    (async () => {
      const { settings } = await getCtx();
      setSettings(settings || {});
      setSport(settings?.defaultSport || "softball");
    })();
  }, []);

  const fallbacks = {
    softball: "https://images.unsplash.com/photo-1566577739114-d8c3ece82bc0?w=1200&h=400&fit=crop",
    baseball: "https://images.unsplash.com/photo-1566577739114-d8c3ece82bc0?w=1200&h=400&fit=crop",
    soccer: "https://images.unsplash.com/photo-1566577739114-d8c3ece82bc0?w=1200&h=400&fit=crop",
  };

  const map = {
    softball: settings?.heroSoftballUrl || fallbacks.softball,
    baseball: settings?.heroBaseballUrl || fallbacks.baseball,
    soccer: settings?.heroSoccerUrl || fallbacks.soccer,
  };

  const bg = map[sport] || fallbacks.softball;

  return (
    <div className="hero" style={{ marginTop: 16 }}>
      <div className="hero-body">
        <div className="kicker" style={{color:"#fff"}}>GAMEDAY COMFORT, DELIVERED</div>
        <h1>Premium tents & seating at your field</h1>
        <p>Reserve a setup for your tournament or league. We handle delivery, setup, and teardown.</p>
        <div className="cta-row">
          <a className="btn" href="/events">Find an Event</a>
          <a className="btn-outline" href="#how-it-works">How it works</a>
        </div>
      </div>
      <style>{`.hero::before{background-image:url('${bg}');}`}</style>
    </div>
  );
}