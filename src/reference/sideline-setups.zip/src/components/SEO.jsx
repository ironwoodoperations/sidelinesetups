import { useEffect } from "react";

export default function SEO({ 
  title = "Sideline Setups | GameDay Without The Haul",
  description = "Professional tent, chair, cooler, and fan rentals for youth baseball, softball, and soccer tournaments. Skip the packing and arrive to your setup ready. Serving East Texas travel ball families.",
  keywords = "sideline setups, youth sports setup rentals, travel ball setup service, youth baseball setups, youth softball setups, sports tournament comfort gear, pop-up canopy rentals, game day setup service, sideline comfort rentals, youth sports tents and chairs, tournament tent rental, travel ball parents, game day comfort",
  ogImage = "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/eb3b03633_brandon-mowinkel-3_JwPJwq6CI-unsplash.jpg",
  pageType = "website",
  canonicalUrl
}) {
  useEffect(() => {
    // Set document title
    document.title = title;
    
    // Helper function to set or update meta tag
    const setMetaTag = (name, content, isProperty = false) => {
      if (!content) return;
      
      const attribute = isProperty ? 'property' : 'name';
      let element = document.querySelector(`meta[${attribute}="${name}"]`);
      
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attribute, name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };
    
    // Set canonical URL
    const siteUrl = window.location.origin;
    const fullUrl = canonicalUrl || window.location.href;
    
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      document.head.appendChild(canonical);
    }
    canonical.setAttribute('href', fullUrl);
    
    // Primary Meta Tags
    setMetaTag('title', title);
    setMetaTag('description', description);
    setMetaTag('keywords', keywords);
    
    // Open Graph / Facebook
    setMetaTag('og:type', pageType, true);
    setMetaTag('og:url', fullUrl, true);
    setMetaTag('og:title', title, true);
    setMetaTag('og:description', description, true);
    setMetaTag('og:image', ogImage, true);
    setMetaTag('og:site_name', 'Sideline Setups', true);
    
    // Twitter
    setMetaTag('twitter:card', 'summary_large_image', true);
    setMetaTag('twitter:url', fullUrl, true);
    setMetaTag('twitter:title', title, true);
    setMetaTag('twitter:description', description, true);
    setMetaTag('twitter:image', ogImage, true);
    
    // Additional SEO
    setMetaTag('robots', 'index, follow');
    setMetaTag('language', 'English');
    setMetaTag('author', 'Sideline Setups');
    setMetaTag('geo.region', 'US-TX');
    setMetaTag('geo.placename', 'East Texas');
    
    // Structured Data
    const businessStructuredData = {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Sideline Setups",
      "image": ogImage,
      "description": "Professional game day setup rentals for youth sports tournaments including tents, chairs, coolers, and fans. Serving travel ball families in East Texas.",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "East Texas",
        "addressRegion": "TX",
        "addressCountry": "US"
      },
      "telephone": "+1-903-541-9287",
      "email": "sidelinesetups@gmail.com",
      "url": siteUrl,
      "priceRange": "$8-$35",
      "openingHours": "Mo-Su 06:00-22:00",
      "areaServed": {
        "@type": "GeoCircle",
        "geoMidpoint": {
          "@type": "GeoCoordinates",
          "latitude": "32.7767",
          "longitude": "-96.7970"
        },
        "geoRadius": "150 miles"
      },
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "Game Day Setup Packages",
        "itemListElement": [
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Product",
              "name": "Chair Only Package",
              "description": "Premium rocker chair for game day comfort"
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Product",
              "name": "MVP Setup",
              "description": "10x10 pop-up tent, 2 rocker chairs, and wheeled cooler"
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Product",
              "name": "Tent Only Package",
              "description": "10x10 professional pop-up tent for shade and weather protection"
            }
          }
        ]
      }
    };
    
    // Add or update structured data script
    let structuredDataScript = document.querySelector('script[type="application/ld+json"]');
    if (!structuredDataScript) {
      structuredDataScript = document.createElement('script');
      structuredDataScript.setAttribute('type', 'application/ld+json');
      document.head.appendChild(structuredDataScript);
    }
    structuredDataScript.textContent = JSON.stringify(businessStructuredData);
    
  }, [title, description, keywords, ogImage, pageType, canonicalUrl]);
  
  return null;
}