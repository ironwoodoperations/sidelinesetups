
import React from "react";
import { getCtx } from "./lib/ctx";
import { t, setLang, getLang } from "./lib/i18n";

export default function NavBar(){
  const [open,setOpen]=React.useState(false);
  const [brand,setBrand]=React.useState("Sideline Setups");
  const [lang,setL]=React.useState(getLang());

  React.useEffect(()=>{ (async()=>{
    const { settings } = await getCtx();
    setBrand(settings.brandName || "Sideline Setups");
    // Apply theme tokens from settings
    if (settings.themeColor) document.documentElement.style.setProperty("--brand", settings.themeColor);
    if (settings.accentColor) document.documentElement.style.setProperty("--accent", settings.accentColor);
  })(); },[]);

  function changeLang(e){
    const v = e.target.value;
    setL(v); setLang(v);
  }

  return (
    <header style={{borderBottom:"1px solid var(--border)",background:"#fff"}}>
      <div className="container" style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:12}}>
        <a href="/" style={{display:"flex",alignItems:"center",gap:10,fontWeight:800,color:"var(--brand-ink)"}}>
          <span className="badge">SS</span> {brand}
        </a>
        <nav className="hide-mobile" style={{display:"flex",gap:18}}>
          <a href="/events">{t("nav.events")}</a>
          <a href="/book">{t("nav.book")}</a>
          <a href="/mybookings">My Bookings</a>
          <a href="/staffday">Staff</a>
          <a href="/admindashboard">{t("nav.admin")}</a>
        </nav>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <select value={lang} onChange={changeLang} className="input" style={{width:120}}>
            <option value="en">English</option>
            <option value="es">Español</option>
          </select>
          <button className="btn" onClick={()=>setOpen(!open)} aria-label="Menu" style={{display:"none"}}>Menu</button>
        </div>
      </div>
    </header>
  );
}
