import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Award, TrendingUp, Sparkles } from "lucide-react";

/**
 * Small widget to display customer's loyalty points balance
 * Can be inserted anywhere on customer-facing pages
 */
export default function LoyaltyPointsBalance({ customerEmail, showDetails = false }) {
  const [balance, setBalance] = useState(0);
  const [dollarValue, setDollarValue] = useState("0.00");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (customerEmail) {
      loadBalance();
    }
  }, [customerEmail]);

  async function loadBalance() {
    try {
      const response = await base44.functions.invoke('getLoyaltyBalance', {
        customerEmail
      });
      
      setBalance(response.data.balance);
      setDollarValue(response.data.dollarValue);
    } catch (error) {
      console.error("Failed to load loyalty balance:", error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div style={{
        padding: "12px 16px",
        background: "linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)",
        borderRadius: "10px",
        display: "inline-flex",
        alignItems: "center",
        gap: "8px"
      }}>
        <div className="spinner" style={{ width: "16px", height: "16px" }}></div>
        <span style={{ fontSize: "14px", color: "#64748b" }}>Loading points...</span>
      </div>
    );
  }

  if (!showDetails) {
    // Compact view
    return (
      <div style={{
        padding: "10px 16px",
        background: "linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)",
        borderRadius: "10px",
        display: "inline-flex",
        alignItems: "center",
        gap: "10px",
        boxShadow: "0 2px 8px rgba(251, 191, 36, 0.2)"
      }}>
        <Award size={20} style={{ color: "#f59e0b" }} />
        <div>
          <div style={{ fontSize: "18px", fontWeight: "700", color: "#92400e" }}>
            {balance.toLocaleString()} pts
          </div>
          <div style={{ fontSize: "11px", color: "#78350f" }}>
            ${dollarValue} value
          </div>
        </div>
      </div>
    );
  }

  // Detailed view (for dashboard)
  return (
    <div style={{
      padding: "20px",
      background: "linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)",
      borderRadius: "12px",
      boxShadow: "0 4px 12px rgba(251, 191, 36, 0.2)"
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "16px" }}>
        <div style={{
          width: "48px",
          height: "48px",
          borderRadius: "50%",
          background: "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: "0 4px 12px rgba(245, 158, 11, 0.3)"
        }}>
          <Award size={24} color="white" />
        </div>
        <div>
          <div style={{ fontSize: "14px", color: "#78350f", fontWeight: "600" }}>
            Your Loyalty Points
          </div>
          <div style={{ fontSize: "32px", fontWeight: "800", color: "#92400e", lineHeight: "1" }}>
            {balance.toLocaleString()}
          </div>
        </div>
      </div>

      <div style={{
        padding: "12px",
        background: "rgba(255, 255, 255, 0.6)",
        borderRadius: "8px",
        marginBottom: "12px"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
          <Sparkles size={16} style={{ color: "#d97706" }} />
          <span style={{ fontSize: "13px", fontWeight: "600", color: "#78350f" }}>
            Discount Value
          </span>
        </div>
        <div style={{ fontSize: "24px", fontWeight: "700", color: "#92400e" }}>
          ${dollarValue}
        </div>
        <div style={{ fontSize: "11px", color: "#78350f", marginTop: "4px" }}>
          100 points = $10 off your next booking
        </div>
      </div>

      <div style={{
        padding: "10px 12px",
        background: "rgba(255, 255, 255, 0.4)",
        borderRadius: "8px",
        fontSize: "12px",
        color: "#78350f",
        display: "flex",
        alignItems: "center",
        gap: "6px"
      }}>
        <TrendingUp size={14} style={{ color: "#d97706" }} />
        <span>Earn 1 point for every $1 spent</span>
      </div>
    </div>
  );
}