import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { TrendingUp, TrendingDown, Gift, Settings as SettingsIcon } from "lucide-react";

/**
 * Shows recent loyalty point transactions
 */
export default function LoyaltyTransactionHistory({ customerEmail }) {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (customerEmail) {
      loadTransactions();
    }
  }, [customerEmail]);

  async function loadTransactions() {
    try {
      const response = await base44.functions.invoke('getLoyaltyBalance', {
        customerEmail
      });
      
      setTransactions(response.data.transactions || []);
    } catch (error) {
      console.error("Failed to load transactions:", error);
    } finally {
      setLoading(false);
    }
  }

  function getIcon(type) {
    if (type === 'earned_booking' || type === 'earned_bonus') {
      return <TrendingUp size={16} style={{ color: "#10b981" }} />;
    }
    if (type === 'redeemed_discount') {
      return <TrendingDown size={16} style={{ color: "#f59e0b" }} />;
    }
    return <SettingsIcon size={16} style={{ color: "#64748b" }} />;
  }

  function getTypeLabel(type) {
    const labels = {
      'earned_booking': 'Earned',
      'earned_bonus': 'Bonus',
      'redeemed_discount': 'Redeemed',
      'manual_adjustment': 'Adjusted',
      'expired': 'Expired'
    };
    return labels[type] || type;
  }

  if (loading) {
    return (
      <div style={{ padding: "20px", textAlign: "center" }}>
        <div className="spinner" style={{ margin: "0 auto" }}></div>
      </div>
    );
  }

  if (transactions.length === 0) {
    return (
      <div style={{
        padding: "40px 20px",
        textAlign: "center",
        color: "#64748b"
      }}>
        <Gift size={48} style={{ margin: "0 auto 16px", opacity: 0.3 }} />
        <p>No transaction history yet</p>
        <p style={{ fontSize: "14px", marginTop: "8px" }}>
          Start earning points by completing bookings!
        </p>
      </div>
    );
  }

  return (
    <div style={{ padding: "20px" }}>
      <h3 style={{ margin: "0 0 16px 0", fontSize: "18px", fontWeight: "700", color: "#003f5c" }}>
        Recent Activity
      </h3>
      
      <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
        {transactions.map((txn) => (
          <div
            key={txn.id}
            style={{
              padding: "14px",
              background: "white",
              border: "1px solid #e2e8f0",
              borderRadius: "10px",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center"
            }}
          >
            <div style={{ display: "flex", alignItems: "flex-start", gap: "12px", flex: 1 }}>
              <div style={{
                width: "32px",
                height: "32px",
                borderRadius: "8px",
                background: txn.pointsChange > 0 ? "#d1fae5" : "#fef3c7",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0
              }}>
                {getIcon(txn.type)}
              </div>
              
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: "14px", fontWeight: "600", color: "#0f172a", marginBottom: "4px" }}>
                  {txn.reason}
                </div>
                <div style={{ fontSize: "12px", color: "#64748b" }}>
                  {new Date(txn.created_date).toLocaleDateString()} • {getTypeLabel(txn.type)}
                </div>
              </div>
            </div>

            <div style={{ textAlign: "right" }}>
              <div style={{
                fontSize: "18px",
                fontWeight: "700",
                color: txn.pointsChange > 0 ? "#10b981" : "#f59e0b"
              }}>
                {txn.pointsChange > 0 ? '+' : ''}{txn.pointsChange.toLocaleString()}
              </div>
              <div style={{ fontSize: "11px", color: "#64748b" }}>
                Balance: {txn.balanceAfter.toLocaleString()}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}