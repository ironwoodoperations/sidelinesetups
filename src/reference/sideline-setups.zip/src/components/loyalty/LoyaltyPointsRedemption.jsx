import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Award, Check, X, Info } from "lucide-react";

/**
 * Component for booking page - allows customers to apply loyalty points as discount
 */
export default function LoyaltyPointsRedemption({ 
  customerEmail, 
  currentTotalCents, 
  onApplyDiscount 
}) {
  const [balance, setBalance] = useState(0);
  const [pointsToRedeem, setPointsToRedeem] = useState("");
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    if (customerEmail) {
      loadBalance();
    }
  }, [customerEmail]);

  async function loadBalance() {
    try {
      const response = await base44.functions.invoke('getLoyaltyBalance', {
        customerEmail
      });
      
      setBalance(response.data.balance);
    } catch (error) {
      console.error("Failed to load loyalty balance:", error);
    } finally {
      setLoading(false);
    }
  }

  async function handleApply() {
    setApplying(true);
    setError(null);
    setSuccess(null);

    try {
      const points = parseInt(pointsToRedeem);
      
      if (isNaN(points) || points <= 0) {
        setError("Please enter a valid number of points");
        setApplying(false);
        return;
      }

      const response = await base44.functions.invoke('redeemLoyaltyPoints', {
        customerEmail,
        pointsToRedeem: points,
        currentTotalCents
      });

      if (response.data.success) {
        setSuccess(response.data.message);
        setBalance(response.data.newBalance);
        
        // Pass discount info to parent
        if (onApplyDiscount) {
          onApplyDiscount({
            pointsRedeemed: response.data.pointsRedeemed,
            discountCents: response.data.discountCents,
            newTotalCents: response.data.newTotalCents
          });
        }
        
        // Reset form after 2 seconds
        setTimeout(() => {
          setShowForm(false);
          setPointsToRedeem("");
          setSuccess(null);
        }, 2000);
      }
    } catch (err) {
      setError(err.response?.data?.error || "Failed to apply points");
    } finally {
      setApplying(false);
    }
  }

  function handleMaxPoints() {
    const maxAffordable = Math.floor((currentTotalCents / 100) * 10); // Max points that can be used
    const actualMax = Math.min(balance, maxAffordable);
    const roundedMax = Math.floor(actualMax / 100) * 100; // Round down to nearest 100
    setPointsToRedeem(roundedMax.toString());
  }

  if (loading) {
    return null;
  }

  if (balance < 100) {
    return null; // Don't show if customer doesn't have minimum points
  }

  if (!showForm) {
    return (
      <div style={{
        padding: "16px",
        background: "linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)",
        borderRadius: "10px",
        marginBottom: "16px"
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <Award size={20} style={{ color: "#d97706" }} />
            <div>
              <div style={{ fontSize: "14px", fontWeight: "600", color: "#78350f" }}>
                You have {balance.toLocaleString()} loyalty points!
              </div>
              <div style={{ fontSize: "12px", color: "#92400e" }}>
                Worth ${(balance / 10).toFixed(2)} off this booking
              </div>
            </div>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="btn"
            style={{ fontSize: "14px", padding: "8px 16px" }}
          >
            Use Points
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      padding: "20px",
      background: "linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)",
      borderRadius: "10px",
      marginBottom: "16px"
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <Award size={24} style={{ color: "#d97706" }} />
          <div>
            <div style={{ fontSize: "16px", fontWeight: "700", color: "#78350f" }}>
              Redeem Loyalty Points
            </div>
            <div style={{ fontSize: "12px", color: "#92400e" }}>
              Available: {balance.toLocaleString()} points (${(balance / 10).toFixed(2)} value)
            </div>
          </div>
        </div>
        <button
          onClick={() => {
            setShowForm(false);
            setError(null);
            setSuccess(null);
          }}
          style={{
            background: "transparent",
            border: "none",
            color: "#78350f",
            cursor: "pointer",
            padding: "4px"
          }}
        >
          <X size={20} />
        </button>
      </div>

      <div style={{
        padding: "12px",
        background: "rgba(255, 255, 255, 0.5)",
        borderRadius: "8px",
        marginBottom: "12px",
        fontSize: "12px",
        color: "#78350f",
        display: "flex",
        alignItems: "flex-start",
        gap: "8px"
      }}>
        <Info size={16} style={{ flexShrink: 0, marginTop: "2px", color: "#d97706" }} />
        <div>
          <strong>Conversion Rate:</strong> 100 points = $10 off<br />
          Minimum redemption: 100 points
        </div>
      </div>

      <div style={{ display: "flex", gap: "8px", marginBottom: "12px" }}>
        <input
          type="number"
          value={pointsToRedeem}
          onChange={(e) => setPointsToRedeem(e.target.value)}
          placeholder="Enter points (e.g., 100)"
          disabled={applying}
          style={{
            flex: 1,
            padding: "10px 12px",
            border: "2px solid #fbbf24",
            borderRadius: "8px",
            fontSize: "14px"
          }}
        />
        <button
          onClick={handleMaxPoints}
          className="btn-outline"
          disabled={applying}
          style={{ fontSize: "14px", whiteSpace: "nowrap" }}
        >
          Use Max
        </button>
      </div>

      {error && (
        <div style={{
          padding: "10px 12px",
          background: "#fee2e2",
          color: "#991b1b",
          borderRadius: "8px",
          marginBottom: "12px",
          fontSize: "13px"
        }}>
          {error}
        </div>
      )}

      {success && (
        <div style={{
          padding: "10px 12px",
          background: "#d1fae5",
          color: "#065f46",
          borderRadius: "8px",
          marginBottom: "12px",
          fontSize: "13px",
          display: "flex",
          alignItems: "center",
          gap: "8px"
        }}>
          <Check size={16} />
          {success}
        </div>
      )}

      <button
        onClick={handleApply}
        disabled={applying || !pointsToRedeem}
        className="btn"
        style={{ width: "100%", fontSize: "14px" }}
      >
        {applying ? "Applying..." : "Apply Points"}
      </button>
    </div>
  );
}