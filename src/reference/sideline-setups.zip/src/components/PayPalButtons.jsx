import React from "react";

/**
 * props:
 *  clientId   - PayPal client ID (sandbox or live)
 *  amount     - total numeric amount
 *  currency   - currency code (default: USD)
 *  onSuccess  - callback({status, id})
 *  onError    - callback(error)
 */
export default function PayPalButtons({ clientId, amount = 0, currency = "USD", onSuccess, onError }) {
  const [ready, setReady] = React.useState(false);
  const [error, setError] = React.useState(null);
  const [loadAttempts, setLoadAttempts] = React.useState(0);

  React.useEffect(() => {
    if (!clientId) {
      const err = "Missing PayPal client ID";
      console.warn("[PayPalButtons]", err);
      setError(err);
      return;
    }

    // Clean and validate clientId
    const cleanClientId = clientId.trim();
    if (!cleanClientId) {
      const err = "Invalid PayPal client ID (empty after trim)";
      console.error("[PayPalButtons]", err);
      setError(err);
      onError?.(new Error(err));
      return;
    }

    // Check if PayPal SDK is already loaded
    if (window.paypal) {
      console.log("[PayPalButtons] PayPal SDK already loaded");
      setReady(true);
      return;
    }

    // Check if script is already being loaded
    const existingScript = document.querySelector('script[src*="paypal.com/sdk/js"]');
    if (existingScript) {
      console.log("[PayPalButtons] PayPal SDK script already exists, waiting for load...");
      existingScript.addEventListener('load', () => {
        console.log("[PayPalButtons] Existing script loaded");
        setReady(true);
      });
      existingScript.addEventListener('error', (e) => {
        console.error("[PayPalButtons] Existing script failed to load:", e);
        setError("Failed to load PayPal SDK");
      });
      return;
    }

    // Load PayPal SDK script
    const sdkUrl = `https://www.paypal.com/sdk/js?client-id=${cleanClientId}&currency=${currency}`;
    console.log("[PayPalButtons] Loading PayPal SDK...");
    console.log("[PayPalButtons] Client ID:", cleanClientId.substring(0, 15) + "...");
    console.log("[PayPalButtons] SDK URL:", sdkUrl);
    
    const script = document.createElement("script");
    script.src = sdkUrl;
    script.async = true;
    script.setAttribute('data-sdk-integration-source', 'button-factory');
    
    script.onload = () => {
      console.log("[PayPalButtons] PayPal SDK loaded successfully");
      if (window.paypal) {
        console.log("[PayPalButtons] window.paypal is available");
        setReady(true);
      } else {
        console.error("[PayPalButtons] window.paypal is NOT available after script load");
        setError("PayPal SDK loaded but not initialized");
      }
    };
    
    script.onerror = (e) => {
      console.error("[PayPalButtons] Script error event:", e);
      console.error("[PayPalButtons] Error type:", e.type);
      console.error("[PayPalButtons] Error target:", e.target);
      
      const err = "Failed to load PayPal SDK. This could be due to:\n" +
                  "- Network/firewall blocking PayPal\n" +
                  "- Browser extensions blocking scripts\n" +
                  "- Invalid client ID\n" +
                  "- PayPal service temporarily unavailable";
      
      console.error("[PayPalButtons]", err);
      setError(err);
      setLoadAttempts(prev => prev + 1);
      
      onError?.(new Error(err));
    };
    
    console.log("[PayPalButtons] Appending script to document.body");
    document.body.appendChild(script);

    return () => {
      // Cleanup script on unmount
      if (script.parentNode) {
        console.log("[PayPalButtons] Removing script from document");
        script.parentNode.removeChild(script);
      }
    };
  }, [clientId, currency, onError, loadAttempts]);

  React.useEffect(() => {
    if (!ready || !window.paypal) {
      console.log("[PayPalButtons] Not ready. ready:", ready, "window.paypal:", !!window.paypal);
      return;
    }

    console.log("[PayPalButtons] Rendering PayPal buttons for amount:", amount);

    // Clear any existing button containers
    const container = document.getElementById("paypal-btns");
    if (container) {
      container.innerHTML = '';
    }

    try {
      // Render PayPal button
      window.paypal.Buttons({
        style: { 
          layout: "vertical", 
          color: "gold", 
          shape: "pill", 
          label: "paypal",
          height: 45
        },
        createOrder: (data, actions) => {
          console.log("[PayPal] Creating order for amount:", amount);
          return actions.order.create({
            purchase_units: [{
              amount: {
                currency_code: currency,
                value: amount.toFixed(2)
              }
            }]
          });
        },
        onApprove: (data, actions) => {
          console.log("[PayPal] Payment approved, capturing order...");
          return actions.order.capture().then((details) => {
            console.log("[PayPal] Order captured successfully:", details);
            onSuccess?.({ status: details.status, id: details.id });
          });
        },
        onError: (err) => {
          console.error("[PayPal] Button error:", err);
          onError?.(err);
        }
      }).render("#paypal-btns");

      console.log("[PayPal] Button rendered successfully");
    } catch (err) {
      console.error("[PayPalButtons] Error rendering buttons:", err);
      setError(err.message);
      onError?.(err);
    }
  }, [ready, amount, currency, onSuccess, onError]);

  if (error) {
    return (
      <div style={{ 
        textAlign: "left", 
        color: "#ef4444", 
        padding: "20px",
        background: "#fef2f2",
        borderRadius: "8px",
        border: "1px solid #fecaca"
      }}>
        <strong style={{ display: "block", marginBottom: "8px" }}>Payment System Error</strong>
        <div style={{ fontSize: "14px", whiteSpace: "pre-wrap", marginBottom: "12px" }}>{error}</div>
        <div style={{ fontSize: "12px", color: "#991b1b" }}>
          <strong>Troubleshooting steps:</strong>
          <ol style={{ marginTop: "8px", paddingLeft: "20px" }}>
            <li>Check your browser's console for detailed error messages</li>
            <li>Disable browser extensions (especially ad blockers)</li>
            <li>Try a different browser or incognito mode</li>
            <li>Verify your network connection</li>
            <li>Contact support if the issue persists</li>
          </ol>
        </div>
      </div>
    );
  }

  if (!clientId) {
    return (
      <div style={{ textAlign: "center", color: "#64748b", padding: "20px" }}>
        PayPal Client ID not configured
      </div>
    );
  }

  if (!ready) {
    return (
      <div style={{ textAlign: "center", padding: "20px" }}>
        <div className="spinner"></div>
        <p style={{ marginTop: "8px", color: "#64748b" }}>Loading payment options...</p>
        <p style={{ marginTop: "4px", fontSize: "12px", color: "#94a3b8" }}>
          Connecting to PayPal...
        </p>
      </div>
    );
  }

  return (
    <div style={{ textAlign: "center" }}>
      <div id="paypal-btns" style={{ marginBottom: 12 }} />
      <p style={{ fontSize: 13, color: "#64748b", marginTop: 8 }}>
        Pay securely with PayPal or credit card
      </p>
    </div>
  );
}