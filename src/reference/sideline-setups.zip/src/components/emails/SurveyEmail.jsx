// components/emails/SurveyEmail.js
import { htmlEscape } from "./_util";

export default function SurveyEmail({ brand = "Sideline Setups", booking }) {
  const name = htmlEscape(booking?.fullName || "there");
  const id   = htmlEscape(booking?.id || "");
  const link = `/survey?booking=${encodeURIComponent(id)}`;
  return `
    <div style="font-family: system-ui, -apple-system, Segoe UI, Roboto">
      <h2>${brand} — How did we do?</h2>
      <p>Hi ${name}, we'd love quick feedback on your rental experience.</p>
      <p><a href="${link}">Tap here to leave a 10-second rating.</a></p>
      <p>Thank you!</p>
    </div>
  `;
}