// components/emails/ReadyEmail.js
import { htmlEscape } from "./_util";

export default function ReadyEmail({ brand = "Sideline Setups", booking }) {
  const name = htmlEscape(booking?.fullName || booking?.teamName || "Customer");
  const id   = htmlEscape(booking?.id || "");
  const field = htmlEscape(booking?.fieldName || "");
  const spot  = htmlEscape(booking?.spotLabel || "");
  return `
    <div style="font-family: system-ui, -apple-system, Segoe UI, Roboto">
      <h2>${brand} — Your Setup is Ready!</h2>
      <p>Hi ${name}, we've completed your setup.</p>
      <p><b>Field:</b> ${field} &nbsp; <b>Spot:</b> ${spot}</p>
      <p>Have a great game!</p>
      <p style="font-size:12px;color:#64748b;margin-top:16px">Booking: ${id}</p>
    </div>
  `;
}