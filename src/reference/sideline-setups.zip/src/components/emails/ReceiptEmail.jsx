// components/emails/ReceiptEmail.js
import { htmlEscape } from "./_util";

export default function ReceiptEmail({ brand = "Sideline Setups", booking, totalUSD }) {
  const name = htmlEscape(booking?.fullName || booking?.teamName || "Customer");
  const pack = htmlEscape(booking?.packageName || "Rental Package");
  const id   = htmlEscape(booking?.id || "");
  const date = htmlEscape(booking?.date || "");
  const times = (booking?.gameTimes || []).join(", ");

  return `
    <div style="font-family: system-ui, -apple-system, Segoe UI, Roboto">
      <h2>${brand} — Booking Confirmed</h2>
      <p>Hi ${name}, thanks for your booking!</p>
      <table style="margin-top:12px">
        <tr><td><b>Booking ID:</b></td><td>${id}</td></tr>
        <tr><td><b>Date:</b></td><td>${date}</td></tr>
        <tr><td><b>Times:</b></td><td>${times || "—"}</td></tr>
        <tr><td><b>Package:</b></td><td>${pack}</td></tr>
        <tr><td><b>Total Paid:</b></td><td>$${Number(totalUSD||0).toFixed(2)}</td></tr>
      </table>
      <p style="margin-top:12px">You'll receive a text when your setup is ready.</p>
      <p style="font-size:12px;color:#64748b;margin-top:16px">Questions? Reply to this email.</p>
    </div>
  `;
}