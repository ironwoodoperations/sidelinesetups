// components/emails/ReminderEmail.js
import { htmlEscape } from "./_util";

export default function ReminderEmail({ brand = "Sideline Setups", booking }) {
  const name = htmlEscape(booking?.fullName || "there");
  const date = htmlEscape(booking?.date || "");
  const times = (booking?.gameTimes || []).join(", ");
  return `
    <div style="font-family: system-ui, -apple-system, Segoe UI, Roboto">
      <h2>${brand} — Reminder for Tomorrow</h2>
      <p>Hi ${name}, just a friendly reminder for your rental tomorrow:</p>
      <ul>
        <li><b>Date:</b> ${date}</li>
        <li><b>Times:</b> ${times || "—"}</li>
      </ul>
      <p>We'll text you when your setup is ready. Good luck!</p>
    </div>
  `;
}