import React, { useState } from 'react';
import { MessageSquare, Send } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function SmsContactBox({ bookingId, customerName, customerPhone }) {
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  async function handleSend() {
    if (!message.trim()) {
      setError('Please enter a message');
      return;
    }

    setSending(true);
    setError('');

    try {
      const businessPhone = '+19035419287';
      const fullMessage = `Customer Message:
From: ${customerName || 'Customer'}
Phone: ${customerPhone || 'Not provided'}
Booking: ${bookingId || 'N/A'}

Message: ${message}`;

      await base44.functions.invoke('smsSend', {
        to: businessPhone,
        body: fullMessage
      });

      setSent(true);
      setMessage('');
      setTimeout(() => setSent(false), 5000);
    } catch (err) {
      console.error('Failed to send SMS:', err);
      setError('Failed to send message. Please call us instead.');
    } finally {
      setSending(false);
    }
  }

  return (
    <div style={{
      marginTop: '32px',
      padding: '24px',
      background: 'white',
      borderRadius: '12px',
      boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
    }}>
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        marginBottom: '16px'
      }}>
        <MessageSquare size={24} style={{ color: '#003f5c' }} />
        <h2 style={{ margin: 0, fontSize: '20px', fontWeight: '700', color: '#003f5c' }}>
          Text Us
        </h2>
      </div>
      
      <p style={{ color: '#64748b', marginBottom: '16px', fontSize: '14px' }}>
        Send us a message and we'll respond as soon as possible. Or call us directly at{' '}
        <a href="tel:9035419287" style={{ color: '#003f5c', fontWeight: '600' }}>903-541-9287</a>
      </p>

      {sent ? (
        <div style={{
          padding: '16px',
          background: '#d1fae5',
          border: '1px solid #6ee7b7',
          borderRadius: '8px',
          color: '#065f46',
          textAlign: 'center',
          fontWeight: '600'
        }}>
          ✓ Message sent! We'll get back to you soon.
        </div>
      ) : (
        <>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type your message here..."
            rows={4}
            style={{
              width: '100%',
              padding: '12px',
              border: '1px solid #e2e8f0',
              borderRadius: '8px',
              fontSize: '14px',
              fontFamily: 'inherit',
              resize: 'vertical',
              marginBottom: '12px'
            }}
          />

          {error && (
            <div style={{
              padding: '12px',
              background: '#fee2e2',
              border: '1px solid #fecaca',
              borderRadius: '8px',
              color: '#991b1b',
              fontSize: '14px',
              marginBottom: '12px'
            }}>
              {error}
            </div>
          )}

          <button
            onClick={handleSend}
            disabled={sending || !message.trim()}
            style={{
              width: '100%',
              padding: '12px 24px',
              background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '16px',
              fontWeight: '600',
              cursor: sending ? 'not-allowed' : 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
              opacity: sending ? 0.6 : 1
            }}
          >
            {sending ? (
              <>
                <div className="spinner" style={{ width: '20px', height: '20px' }}></div>
                Sending...
              </>
            ) : (
              <>
                <Send size={18} />
                Send Message
              </>
            )}
          </button>
        </>
      )}
    </div>
  );
}