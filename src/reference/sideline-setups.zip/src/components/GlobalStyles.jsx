
import React from "react";

export default function GlobalStyles() {
  return (
    <style>{`
      /* Global theme styles */
      :root {
        --brand: #003f5c;
        --brand-600: #002a42;
        --brand-700: #001f31;
        --ink: #0f172a;
        --ink-600: #334155;
        --muted: #64748b;
        --bg: #ffffff;
        --bg-2: #f8fafc;
        --border: #e2e8f0;
        --success: #10b981;
        --warn: #f59e0b;
        --danger: #ef4444;
        --card-shadow: 0 6px 18px rgba(2,8,23,.06);
      }

      * {
        box-sizing: border-box;
      }

      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }

      body {
        font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Inter, Arial, sans-serif;
        color: var(--ink);
        background: var(--bg);
      }

      h1, h2, h3, h4, h5 {
        font-weight: 700;
        color: var(--ink);
        margin: 0;
      }

      h1 {
        font-size: 2rem;
        line-height: 1.1;
      }

      h2 {
        font-size: 1.5rem;
        line-height: 1.2;
      }

      h3 {
        font-size: 1.125rem;
      }

      a {
        color: var(--brand);
        text-decoration: none;
      }

      a:hover {
        text-decoration: underline;
      }

      img {
        max-width: 100%;
        display: block;
      }

      .container {
        max-width: 1100px;
        margin: 0 auto;
        padding: 0 16px;
      }

      .section {
        padding: 32px 0;
      }

      .grid {
        display: grid;
        gap: 16px;
      }

      .grid-2 {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }

      .grid-3 {
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      }

      @media (max-width: 900px) {
        .grid-2 {
          grid-template-columns: 1fr;
        }
        .grid-3 {
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        }
      }

      .card {
        background: white;
        border: 1px solid var(--border);
        border-radius: 14px;
        box-shadow: var(--card-shadow);
      }

      .card-pad {
        padding: 16px;
      }

      .card .img {
        width: 100%;
        height: 200px;
        overflow: hidden;
        background: #0b1220;
        position: relative;
      }

      .card .img img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        object-position: center;
      }

      .card-event {
        display: flex;
        flex-direction: column;
        overflow: hidden;
        transition: transform 0.2s, box-shadow 0.2s;
      }

      .card-event:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(2,8,23,.12);
      }

      .card-event .img {
        width: 100%;
        height: 140px;
        background: white;
        overflow: hidden;
        position: relative;
        flex-shrink: 0;
      }

      .card-event .img img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        object-position: center;
        display: block;
      }

      .card-event .body {
        padding: 12px;
        flex: 1;
      }

      .btn {
        appearance: none;
        border: 1px solid #002a42;
        background: linear-gradient(135deg, #003f5c 0%, #005a7d 100%);
        color: white;
        font-weight: 600;
        padding: 10px 16px;
        border-radius: 10px;
        cursor: pointer;
        display: inline-block;
        font-size: 14px;
        transition: all 0.2s;
      }

      .btn:hover {
        background: linear-gradient(135deg, #002a42 0%, #004461 100%);
        text-decoration: none;
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0, 63, 92, 0.3);
      }

      .btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }

      .btn-outline {
        background: white;
        color: #003f5c;
        border: 1px solid #003f5c;
        display: inline-block;
        padding: 10px 16px;
        border-radius: 10px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
      }

      .btn-outline:hover {
        background: var(--bg-2);
        text-decoration: none;
      }

      .btn-ghost {
        background: transparent;
        border: none;
        color: var(--ink-600);
        padding: 10px 16px;
        border-radius: 10px;
        font-weight: 600;
        display: inline-block;
        cursor: pointer;
      }

      .btn-ghost:hover {
        background: var(--bg-2);
        text-decoration: none;
      }

      .btn-danger {
        background: var(--danger);
        border-color: var(--danger);
      }

      .btn-success {
        background: var(--success);
        border-color: var(--success);
      }

      .btn.secondary {
        background: white;
        color: var(--brand);
        border-color: var(--brand);
      }

      .btn.secondary:hover {
        background: var(--bg-2);
      }

      .input, .select, .textarea {
        width: 100%;
        padding: 10px 12px;
        border-radius: 10px;
        border: 1px solid var(--border);
        background: white;
        color: var(--ink);
        font-size: 14px;
      }

      .label {
        font-size: 12px;
        color: var(--muted);
        margin-bottom: 6px;
        display: block;
      }

      .row {
        display: grid;
        gap: 12px;
        grid-template-columns: 1fr 1fr;
      }

      @media (max-width: 700px) {
        .row {
          grid-template-columns: 1fr;
        }
      }

      .table {
        width: 100%;
        border-collapse: collapse;
      }

      .table th, .table td {
        border-bottom: 1px solid var(--border);
        padding: 10px;
        text-align: left;
      }

      .table th {
        font-size: 12px;
        color: var(--muted);
        text-transform: uppercase;
        letter-spacing: 0.04em;
      }

      .badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 10px;
        border-radius: 999px;
        font-size: 12px;
        border: 1px solid var(--border);
        background: var(--bg-2);
      }

      .badge-success {
        border-color: #c7f9e9;
        background: #ecfdf5;
        color: #065f46;
      }

      .badge-warn {
        border-color: #fde68a;
        background: #fffbeb;
        color: #92400e;
      }

      .nav {
        position: sticky;
        top: 0;
        z-index: 50;
        backdrop-filter: saturate(1.2) blur(6px);
        background: rgba(255, 255, 255, 0.85);
        border-bottom: 1px solid var(--border);
      }

      .nav-inner {
        display: flex;
        align-items: center;
        justify-content: space-between;
        height: 64px;
      }

      .brand {
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 800;
        color: var(--ink);
      }

      .brand img {
        height: 30px;
        width: auto;
      }

      .brand:hover {
        text-decoration: none;
      }

      .nav-links {
        display: flex;
        align-items: center;
        gap: 12px;
      }

      .footer {
        border-top: 1px solid var(--border);
        padding: 28px 0;
        color: var(--muted);
        background: var(--bg-2);
        text-align: center;
      }

      .hero {
        border-radius: 18px;
        overflow: hidden;
        position: relative;
        min-height: 420px;
        background: #111;
        color: white;
        display: flex;
        align-items: end;
      }

      .hero::before {
        content: "";
        position: absolute;
        inset: 0;
        background-size: cover;
        background-position: center;
        filter: brightness(0.75);
      }

      .hero .hero-body {
        position: relative;
        padding: 28px;
        z-index: 1;
      }

      .hero h1 {
        margin: 0 0 6px 0;
        font-size: 40px;
        line-height: 1.1;
        color: white;
      }

      .hero p {
        margin: 0;
        color: #e5e7eb;
      }

      .cta-row {
        margin-top: 14px;
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
      }

      .kicker {
        color: var(--muted);
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        font-weight: 700;
      }

      .mt-8 {
        margin-top: 8px;
      }

      .mt-12 {
        margin-top: 12px;
      }

      .mt-16 {
        margin-top: 16px;
      }

      .mt-24 {
        margin-top: 24px;
      }

      .fade-in {
        animation: fadeIn 0.4s ease-out both;
      }

      @keyframes fadeIn {
        from {
          opacity: 0;
          transform: translateY(8px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      .card, .btn, .hero, .section {
        transition: all 0.25s ease-out;
      }

      .spinner {
        border: 3px solid var(--border);
        border-top-color: var(--brand);
        border-radius: 50%;
        width: 36px;
        height: 36px;
        margin: 0 auto;
        animation: spin 0.8s linear infinite;
      }

      @keyframes spin {
        to {
          transform: rotate(360deg);
        }
      }
    `}</style>
  );
}
