import React, { useState, useRef, useEffect } from "react";
import useSession from "./auth/SessionProvider";
import { User, LogOut, ChevronDown } from "lucide-react";

export default function UserMenu() {
  const { session, logout } = useSession();
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef(null);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  if (!session) return null;

  const label = session.type === "employee"
    ? `${session.fullName || "Staff"} (${session.role || "role"})`
    : (session.customerEmail || session.customerPhone || "My Account");

  return (
    <div ref={menuRef} style={{ position: "relative" }}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="btn-ghost"
        style={{
          display: "flex",
          alignItems: "center",
          gap: "8px",
          padding: "8px 12px",
          cursor: "pointer",
          border: "1px solid #e2e8f0",
          borderRadius: "8px",
          background: "white"
        }}
      >
        <User size={18} style={{ color: "#003f5c" }} />
        <span style={{ color: "#0f172a", fontSize: "14px" }}>{label}</span>
        <ChevronDown 
          size={16} 
          style={{ 
            color: "#64748b",
            transform: isOpen ? "rotate(180deg)" : "rotate(0deg)",
            transition: "transform 0.2s"
          }} 
        />
      </button>

      {isOpen && (
        <div
          className="card"
          style={{
            position: "absolute",
            right: 0,
            top: "calc(100% + 8px)",
            minWidth: "200px",
            padding: "8px",
            boxShadow: "0 10px 25px rgba(0, 63, 92, 0.15)",
            zIndex: 1000
          }}
        >
          {session.type === "employee" ? (
            <a
              href="/staff#today"
              className="btn-ghost"
              style={{
                display: "block",
                width: "100%",
                textAlign: "left",
                padding: "10px 12px",
                borderRadius: "6px",
                color: "#0f172a",
                textDecoration: "none"
              }}
              onMouseEnter={(e) => e.target.style.background = "#f8fafc"}
              onMouseLeave={(e) => e.target.style.background = "transparent"}
            >
              Staff Dashboard
            </a>
          ) : (
            <a
              href="/mybookings"
              className="btn-ghost"
              style={{
                display: "block",
                width: "100%",
                textAlign: "left",
                padding: "10px 12px",
                borderRadius: "6px",
                color: "#0f172a",
                textDecoration: "none"
              }}
              onMouseEnter={(e) => e.target.style.background = "#f8fafc"}
              onMouseLeave={(e) => e.target.style.background = "transparent"}
            >
              My Bookings
            </a>
          )}

          <button
            onClick={() => {
              logout();
              window.location.href = "/";
            }}
            className="btn-ghost"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              width: "100%",
              textAlign: "left",
              padding: "10px 12px",
              marginTop: "4px",
              borderRadius: "6px",
              color: "#ef4444",
              border: "none",
              cursor: "pointer"
            }}
            onMouseEnter={(e) => e.target.style.background = "#fef2f2"}
            onMouseLeave={(e) => e.target.style.background = "transparent"}
          >
            <LogOut size={16} />
            Sign Out
          </button>
        </div>
      )}
    </div>
  );
}