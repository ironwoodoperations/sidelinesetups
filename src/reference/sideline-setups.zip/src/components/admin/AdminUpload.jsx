
import React, { useState, useEffect } from "react";
import { base44 } from "../../api/base44Client";
import { getCtx } from "../lib/ctx"; // Fixed import path
import { Upload, Copy, Check, Trash2 } from "lucide-react";

export default function AdminUpload() {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadedUrl, setUploadedUrl] = useState("");
  const [allUploads, setAllUploads] = useState([]);
  const [copiedUrl, setCopiedUrl] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAllUploads();
  }, []);

  const loadAllUploads = async () => {
    try {
      const { entities } = await getCtx();
      const uploads = await entities.UploadedFiles.list("-created_date");
      setAllUploads(uploads || []);
    } catch (error) {
      console.error("Failed to load uploads:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e) => {
    const selected = e.target.files?.[0];
    if (selected) {
      setFile(selected);
    }
  };

  const handleUpload = async () => {
    if (!file) {
      alert("Please select a file first");
      return;
    }

    setUploading(true);
    try {
      // Get current user
      const user = await base44.auth.me().catch(() => null);
      
      // Upload file
      const result = await base44.integrations.Core.UploadFile({ file });
      const url = result?.file_url || result?.url;
      
      if (url) {
        setUploadedUrl(url);
        
        // Save to database
        const { entities } = await getCtx();
        await entities.UploadedFiles.create({
          fileName: file.name,
          fileUrl: url,
          fileSize: file.size,
          fileType: file.type,
          uploadedBy: user?.email || "unknown"
        });
        
        // Reload uploads
        await loadAllUploads();
        
        // Reset form
        setFile(null);
        const fileInput = document.getElementById("file-input");
        if (fileInput) fileInput.value = "";
      } else {
        alert("Upload succeeded but no URL returned");
      }
    } catch (error) {
      console.error("Upload error:", error);
      alert("Upload failed: " + (error.message || "Unknown error"));
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (uploadId) => {
    if (!confirm("Delete this upload record? (Note: This won't delete the actual file from storage)")) {
      return;
    }
    
    try {
      const { entities } = await getCtx();
      await entities.UploadedFiles.delete(uploadId);
      await loadAllUploads();
    } catch (error) {
      console.error("Delete error:", error);
      alert("Failed to delete: " + error.message);
    }
  };

  const copyToClipboard = (url) => {
    navigator.clipboard.writeText(url);
    setCopiedUrl(url);
    setTimeout(() => setCopiedUrl(""), 2000);
  };

  const isImageUrl = (url) => {
    return /\.(jpg|jpeg|png|gif|webp|svg)$/i.test(url);
  };

  return (
    <div>
      <h1>Image Library</h1>
      <p style={{ color: "var(--muted)", marginTop: 8 }}>
        Upload and manage images for events, logos, hero banners, and more.
      </p>

      <div className="card card-pad" style={{ marginTop: 24, maxWidth: 600 }}>
        <h3 style={{ marginBottom: 16 }}>Upload New Image</h3>
        
        <div style={{ marginBottom: 16 }}>
          <label className="label">Select Image File</label>
          <input
            id="file-input"
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="input"
            style={{ padding: "8px" }}
          />
        </div>

        {file && (
          <div style={{ marginBottom: 16, padding: 12, background: "var(--bg-2)", borderRadius: 8 }}>
            <div style={{ fontSize: 14, color: "var(--muted)" }}>Selected:</div>
            <div style={{ fontWeight: 600 }}>{file.name}</div>
            <div style={{ fontSize: 12, color: "var(--muted)" }}>
              {(file.size / 1024).toFixed(1)} KB
            </div>
          </div>
        )}

        <button
          className="btn"
          onClick={handleUpload}
          disabled={!file || uploading}
          style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
        >
          <Upload size={18} />
          {uploading ? "Uploading..." : "Upload Image"}
        </button>

        {uploadedUrl && (
          <div style={{ marginTop: 16, padding: 12, background: "#ecfdf5", border: "1px solid #c7f9e9", borderRadius: 8 }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: "#065f46", marginBottom: 8 }}>
              ✓ Upload Successful!
            </div>
          </div>
        )}
      </div>

      <div style={{ marginTop: 32 }}>
        <h2 style={{ marginBottom: 16 }}>All Uploaded Images ({allUploads.length})</h2>
        
        {loading ? (
          <div className="spinner" style={{ margin: "40px auto" }}></div>
        ) : allUploads.length === 0 ? (
          <div className="card card-pad" style={{ textAlign: "center", color: "var(--muted)" }}>
            No images uploaded yet. Upload your first image above!
          </div>
        ) : (
          <div className="grid grid-3" style={{ gap: 16 }}>
            {allUploads.map((upload) => (
              <div key={upload.id} className="card" style={{ overflow: "hidden" }}>
                {isImageUrl(upload.fileUrl) && (
                  <div style={{ 
                    height: 200, 
                    background: "#f8fafc", 
                    display: "flex", 
                    alignItems: "center", 
                    justifyContent: "center",
                    overflow: "hidden"
                  }}>
                    <img 
                      src={upload.fileUrl} 
                      alt={upload.fileName}
                      style={{ 
                        maxWidth: "100%", 
                        maxHeight: "100%",
                        objectFit: "contain"
                      }} 
                    />
                  </div>
                )}
                
                <div className="card-pad">
                  <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 4, wordBreak: "break-word" }}>
                    {upload.fileName}
                  </div>
                  <div style={{ fontSize: 12, color: "var(--muted)", marginBottom: 8 }}>
                    {upload.fileSize ? `${(upload.fileSize / 1024).toFixed(1)} KB` : ""}
                    {upload.created_date && ` • ${new Date(upload.created_date).toLocaleDateString()}`}
                  </div>
                  
                  <div style={{ 
                    fontSize: 11, 
                    color: "var(--muted)", 
                    wordBreak: "break-all", 
                    background: "var(--bg-2)", 
                    padding: 8, 
                    borderRadius: 6,
                    marginBottom: 12,
                    fontFamily: "monospace"
                  }}>
                    {upload.fileUrl}
                  </div>
                  
                  <div style={{ display: "flex", gap: 8 }}>
                    <button
                      className="btn-outline"
                      onClick={() => copyToClipboard(upload.fileUrl)}
                      style={{ 
                        flex: 1, 
                        display: "flex", 
                        alignItems: "center", 
                        justifyContent: "center", 
                        gap: 6,
                        fontSize: 13
                      }}
                    >
                      {copiedUrl === upload.fileUrl ? (
                        <>
                          <Check size={14} />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy size={14} />
                          Copy URL
                        </>
                      )}
                    </button>
                    
                    <button
                      className="btn-outline"
                      onClick={() => handleDelete(upload.id)}
                      style={{ 
                        padding: "10px 12px",
                        color: "var(--danger)",
                        borderColor: "var(--danger)"
                      }}
                      title="Delete record"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
