
// components/admin/AdminFinance.js
import React from "react";
import buildEntities from "../lib/entities";

export default function AdminFinance() {
  const entities = buildEntities();
  const [revenue, setRevenue] = React.useState(0);
  const [cogs, setCogs] = React.useState(0);
  const [bookings, setBookings] = React.useState([]);

  React.useEffect(() => {
    (async () => {
      const [allBookings, allCOGS] = await Promise.all([
        entities.Bookings.list(),
        entities.COGS.list(),
      ]);
      
      const totalRev = (allBookings || []).reduce((sum, b) => sum + Number(b?.totals?.amount || 0), 0);
      const totalCogs = (allCOGS || []).reduce((sum, c) => sum + Number(c?.totalUSD || 0), 0);
      
      setRevenue(totalRev);
      setCogs(totalCogs);
      setBookings(allBookings || []);
    })();
  }, []);

  const profit = revenue - cogs;
  const margin = revenue > 0 ? ((profit / revenue) * 100).toFixed(1) : 0;

  return (
    <div>
      <h2>Finance Overview</h2>
      
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginTop: 16 }}>
        <div className="card card-pad">
          <div className="kicker">Total Revenue</div>
          <div style={{ fontSize: 28, fontWeight: 700, marginTop: 8 }}>${revenue.toFixed(2)}</div>
        </div>
        <div className="card card-pad">
          <div className="kicker">Total COGS</div>
          <div style={{ fontSize: 28, fontWeight: 700, marginTop: 8 }}>${cogs.toFixed(2)}</div>
        </div>
        <div className="card card-pad">
          <div className="kicker">Net Profit</div>
          <div style={{ fontSize: 28, fontWeight: 700, marginTop: 8, color: profit >= 0 ? "green" : "red" }}>
            ${profit.toFixed(2)}
          </div>
        </div>
        <div className="card card-pad">
          <div className="kicker">Margin</div>
          <div style={{ fontSize: 28, fontWeight: 700, marginTop: 8 }}>{margin}%</div>
        </div>
      </div>

      <div className="card card-pad" style={{ marginTop: 24 }}>
        <h3>Recent Bookings</h3>
        {bookings.length === 0 && <p style={{ color: "#6b7280" }}>No bookings yet.</p>}
        {bookings.length > 0 && (
          <table className="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Date</th>
                <th>Status</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody>
              {bookings.slice(0, 10).map((b) => (
                <tr key={b.id}>
                  <td>{b.id}</td>
                  <td>{b.fullName}</td>
                  <td>{b.date}</td>
                  <td><span className={`badge badge-${b.status === "confirmed" ? "success" : ""}`}>{b.status}</span></td>
                  <td>${Number(b?.totals?.amount || 0).toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
