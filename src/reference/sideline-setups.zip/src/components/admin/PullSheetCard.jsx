import React, { useState, useEffect } from "react";
import { MapPin, User, Phone, Mail, Package, Clock } from "lucide-react";

export default function PullSheetCard({ pullSheet, onMarkSetup, onMarkReturned, isStaffView = false }) {
  const [setupChecklist, setSetupChecklist] = useState({});
  const [returnChecklist, setReturnChecklist] = useState({});

  useEffect(() => {
    // Load existing checklists from booking
    if (pullSheet.equipmentSetupChecklist) {
      setSetupChecklist(pullSheet.equipmentSetupChecklist);
    }
    if (pullSheet.equipmentReturnedChecklist) {
      setReturnChecklist(pullSheet.equipmentReturnedChecklist);
    }
  }, [pullSheet]);

  const formatTime = (timeStr) => {
    if (!timeStr) return '';
    const [hh, mm] = timeStr.split(':').map(n => parseInt(n, 10));
    const ampm = hh >= 12 ? 'PM' : 'AM';
    const hour = ((hh + 11) % 12) + 1;
    return `${hour}:${mm.toString().padStart(2, '0')} ${ampm}`;
  };

  const gameTimesStr = pullSheet.gameTimes && pullSheet.gameTimes.length > 0
    ? pullSheet.gameTimes.map(t => formatTime(t)).join(', ')
    : 'TBD';

  const handleSetupCheckboxChange = (idx) => {
    const newChecked = { ...setupChecklist, [idx]: !setupChecklist[idx] };
    setSetupChecklist(newChecked);

    // Check if all items are now checked
    const totalItems = pullSheet.equipmentList?.length || 0;
    const checkedCount = Object.values(newChecked).filter(Boolean).length;

    if (totalItems > 0 && checkedCount === totalItems && onMarkSetup && isStaffView) {
      // All items checked - automatically mark as setup
      onMarkSetup(pullSheet.bookingId, newChecked);
    }
  };

  const handleReturnCheckboxChange = (idx) => {
    const newChecked = { ...returnChecklist, [idx]: !returnChecklist[idx] };
    setReturnChecklist(newChecked);

    // Check if all items are now checked
    const totalItems = pullSheet.equipmentList?.length || 0;
    const checkedCount = Object.values(newChecked).filter(Boolean).length;

    if (totalItems > 0 && checkedCount === totalItems && onMarkReturned && isStaffView) {
      // All items checked - automatically mark as returned
      onMarkReturned(pullSheet.bookingId, newChecked);
    }
  };

  const isReturned = pullSheet.currentStatus === 'returned' || pullSheet.currentStatus === 'closed';

  return (
    <div style={{
      background: 'white',
      border: '2px solid #003f5c',
      borderRadius: '12px',
      overflow: 'hidden',
      marginBottom: '24px',
      pageBreakInside: 'avoid',
      pageBreakAfter: 'auto'
    }}>
      {/* Header - WHITE Background with NAVY Text (Printer Friendly) */}
      <div style={{
        background: 'white',
        color: '#003f5c',
        padding: '16px 20px',
        borderBottom: '2px solid #003f5c'
      }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr 1fr',
          gap: '16px',
          marginBottom: '12px'
        }}>
          <div>
            <div style={{ fontSize: '11px', opacity: 0.6, marginBottom: '4px', fontWeight: '600' }}>EVENT</div>
            <div style={{ fontSize: '16px', fontWeight: '700' }}>{pullSheet.eventName}</div>
          </div>
          <div>
            <div style={{ fontSize: '11px', opacity: 0.6, marginBottom: '4px', fontWeight: '600' }}>PARK</div>
            <div style={{ fontSize: '16px', fontWeight: '700' }}>{pullSheet.parkName}</div>
          </div>
          <div>
            <div style={{ fontSize: '11px', opacity: 0.6, marginBottom: '4px', fontWeight: '600' }}>FIELD</div>
            <div style={{ fontSize: '16px', fontWeight: '700' }}>{pullSheet.fieldName}</div>
          </div>
        </div>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          paddingTop: '12px',
          borderTop: '1px solid #e2e8f0'
        }}>
          <Package size={18} />
          <span style={{ fontSize: '18px', fontWeight: '700' }}>{pullSheet.packageName}</span>
        </div>
      </div>

      {/* Body - Two Column Layout */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '20px',
        padding: '20px'
      }}>
        {/* Left Column - Equipment Checklist */}
        <div>
          <h3 style={{
            margin: '0 0 16px 0',
            fontSize: '16px',
            fontWeight: '700',
            color: '#003f5c',
            borderBottom: '2px solid #003f5c',
            paddingBottom: '8px'
          }}>
            Equipment Checklist
          </h3>
          
          {isReturned ? (
            <div style={{
              padding: '20px',
              background: '#f0fdf4',
              border: '2px solid #10b981',
              borderRadius: '8px',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '48px', marginBottom: '8px' }}>✓</div>
              <div style={{ fontSize: '18px', fontWeight: '700', color: '#065f46', marginBottom: '4px' }}>
                Completed & Returned
              </div>
              <div style={{ fontSize: '14px', color: '#047857' }}>
                All equipment has been checked in
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              {pullSheet.equipmentList && pullSheet.equipmentList.length > 0 ? (
                pullSheet.equipmentList.map((item, idx) => (
                  <div key={idx} style={{
                    padding: '12px',
                    background: '#f8fafc',
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px'
                  }}>
                    {/* Equipment Item Name */}
                    <div style={{ 
                      fontWeight: '600', 
                      color: '#0f172a', 
                      fontSize: '15px',
                      marginBottom: '8px'
                    }}>
                      {item.name} <span style={{ color: '#64748b', fontSize: '13px' }}>(Qty: {item.qty})</span>
                    </div>

                    {/* Setup Row */}
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      padding: '6px 0',
                      borderBottom: '1px solid #e2e8f0'
                    }}>
                      <input
                        type="checkbox"
                        checked={setupChecklist[idx] || false}
                        onChange={() => handleSetupCheckboxChange(idx)}
                        disabled={!isStaffView}
                        style={{
                          width: '18px',
                          height: '18px',
                          cursor: isStaffView ? 'pointer' : 'default',
                          accentColor: '#10b981',
                          flexShrink: 0
                        }}
                      />
                      <span style={{
                        fontSize: '13px',
                        color: '#0f172a',
                        fontWeight: '500',
                        textDecoration: setupChecklist[idx] ? 'line-through' : 'none'
                      }}>
                        Setup
                      </span>
                    </div>

                    {/* Teardown Row */}
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      padding: '6px 0'
                    }}>
                      <input
                        type="checkbox"
                        checked={returnChecklist[idx] || false}
                        onChange={() => handleReturnCheckboxChange(idx)}
                        disabled={!isStaffView}
                        style={{
                          width: '18px',
                          height: '18px',
                          cursor: isStaffView ? 'pointer' : 'default',
                          accentColor: '#ef4444',
                          flexShrink: 0
                        }}
                      />
                      <span style={{
                        fontSize: '13px',
                        color: '#0f172a',
                        fontWeight: '500',
                        textDecoration: returnChecklist[idx] ? 'line-through' : 'none'
                      }}>
                        Teardown
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <div style={{ color: '#64748b', fontSize: '14px', padding: '12px' }}>
                  No equipment specified
                </div>
              )}
            </div>
          )}

          {/* Customer Info */}
          <div style={{ marginTop: '20px', paddingTop: '20px', borderTop: '1px solid #e2e8f0' }}>
            <h3 style={{
              margin: '0 0 12px 0',
              fontSize: '14px',
              fontWeight: '700',
              color: '#003f5c'
            }}>
              Customer Information
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '13px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <User size={14} style={{ color: '#64748b' }} />
                <span style={{ fontWeight: '600' }}>{pullSheet.customerName}</span>
              </div>
              {pullSheet.teamName && (
                <div style={{ paddingLeft: '22px', color: '#64748b' }}>
                  Team: {pullSheet.teamName}
                </div>
              )}
              {pullSheet.contactPhone && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Phone size={14} style={{ color: '#64748b' }} />
                  <span>{pullSheet.contactPhone}</span>
                </div>
              )}
              {pullSheet.contactEmail && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Mail size={14} style={{ color: '#64748b' }} />
                  <span style={{ wordBreak: 'break-all' }}>{pullSheet.contactEmail}</span>
                </div>
              )}
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Clock size={14} style={{ color: '#64748b' }} />
                <span>Games: {gameTimesStr}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Field Map with Spot */}
        <div>
          <h3 style={{
            margin: '0 0 16px 0',
            fontSize: '16px',
            fontWeight: '700',
            color: '#003f5c',
            borderBottom: '2px solid #003f5c',
            paddingBottom: '8px'
          }}>
            Setup Location
          </h3>
          
          {pullSheet.spotDetails && pullSheet.spotDetails.imageUrl ? (
            <div style={{
              position: 'relative',
              border: '2px solid #e2e8f0',
              borderRadius: '8px',
              overflow: 'hidden',
              background: '#f8fafc'
            }}>
              <img
                src={pullSheet.spotDetails.imageUrl}
                alt={pullSheet.fieldName}
                style={{
                  width: '100%',
                  height: 'auto',
                  display: 'block'
                }}
              />
              {/* Yellow Highlight for Spot */}
              <div style={{
                position: 'absolute',
                left: `${pullSheet.spotDetails.x}%`,
                top: `${pullSheet.spotDetails.y}%`,
                transform: 'translate(-50%, -50%)',
                width: '40px',
                height: '40px',
                background: 'rgba(250, 204, 21, 0.8)',
                border: '3px solid #eab308',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontWeight: '700',
                fontSize: '12px',
                color: '#713f12',
                boxShadow: '0 4px 12px rgba(0,0,0,0.3)'
              }}>
                {pullSheet.spotDetails.label}
              </div>
            </div>
          ) : (
            <div style={{
              padding: '40px',
              textAlign: 'center',
              background: '#f8fafc',
              border: '2px dashed #e2e8f0',
              borderRadius: '8px',
              color: '#64748b'
            }}>
              <MapPin size={48} style={{ margin: '0 auto 12px', opacity: 0.5 }} />
              <div>No field map available</div>
            </div>
          )}

          {pullSheet.spotDetails && (
            <div style={{
              marginTop: '16px',
              padding: '16px',
              background: '#fef3c7',
              border: '2px solid #fbbf24',
              borderRadius: '8px',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '18px', fontWeight: '700', color: '#92400e', marginBottom: '4px' }}>
                Setup Spot: {pullSheet.spotDetails.label}
              </div>
              <div style={{ fontSize: '13px', color: '#78350f' }}>
                Marked in yellow on field map above
              </div>
            </div>
          )}

          {/* Booking ID Reference */}
          <div style={{
            marginTop: '16px',
            padding: '12px',
            background: '#f1f5f9',
            borderRadius: '8px',
            fontSize: '12px',
            color: '#475569',
            fontFamily: 'monospace',
            textAlign: 'center'
          }}>
            <strong>Booking ID:</strong> {pullSheet.bookingId}
          </div>
        </div>
      </div>
    </div>
  );
}