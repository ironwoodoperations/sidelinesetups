
import React, { useState, useEffect, useCallback } from "react"; // Added useCallback for potential optimization, though not strictly required by changes
import { base44 } from "../../api/base44Client";
import buildEntities from "../lib/entities";
import { Plus, Minus } from "lucide-react";

export default function AdminLeagueInventory() {
  const entities = buildEntities();

  const [events, setEvents] = useState([]);
  // Renamed selectedEventId, selectedDate, selectedParkId to filterEventId, filterDate, filterParkId
  const [filterEventId, setFilterEventId] = useState("");
  const [filterDate, setFilterDate] = useState("");
  const [filterParkId, setFilterParkId] = useState("");

  const [inventory, setInventory] = useState([]);
  const [parks, setParks] = useState([]);
  const [fields, setFields] = useState([]);
  const [times, setTimes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [adjusting, setAdjusting] = useState(false);

  // New loadData function from the outline.
  // This function is intended for initial loading of metadata (events, parks, fields).
  // The 'allInv' part from the outline was omitted to align with the existing `loadInventory`
  // function which fetches filtered inventory on demand via a button click.
  const loadData = async () => {
    try {
      const evts = await entities.Events.filter({ leagueEnabled: true });
      setEvents(evts || []);

      const parksData = await entities.Parks.list();
      setParks(parksData || []);

      const fieldsData = await entities.Fields.list();
      setFields(fieldsData || []);
      return evts; // Return events to be used for defaulting filterEventId
    } catch (error) {
      console.error("Error loading initial data:", error);
      return [];
    }
  };

  // loadInventory function updated to use the new filter state variables
  // Wrapped in useCallback to prevent re-creation on every render, and for use in useEffect dependencies
  const loadInventory = useCallback(async () => {
    if (!filterEventId) { // Check if an event is selected. This is crucial as the UI no longer provides an explicit selector for it.
      // With the new useEffect logic, filterEventId should usually be set to a default.
      // This alert serves as a fallback or if there are no events at all.
      console.warn("No event selected for inventory load. Please ensure events are loaded and a default is set.");
      return;
    }

    setLoading(true);
    try {
      const result = await base44.functions.invoke('leagueListInventory', {
        eventId: filterEventId, // Changed from selectedEventId
        date: filterDate || undefined, // Changed from selectedDate
        parkId: filterParkId || undefined // Changed from selectedParkId
      });

      setInventory(result.data.rows || []);
      // If backend sends updated parks/fields, apply them. Otherwise, use what was loaded initially.
      if (result.data.parks) setParks(result.data.parks);
      if (result.data.fields) setFields(result.data.fields);
      setTimes(result.data.times || []);
    } catch (error) {
      console.error("Failed to load inventory:", error);
      // Removed the alert here, as automatic loading should ideally be less intrusive.
      // alert("Failed to load inventory: " + error.message);
    } finally {
      setLoading(false);
    }
  }, [filterEventId, filterDate, filterParkId]); // Dependencies for useCallback


  useEffect(() => {
    const initializeData = async () => {
      const evts = await loadData(); // Load initial data including events
      // Set a default event ID if events are available and no event is currently selected
      if (evts && evts.length > 0 && !filterEventId) {
        setFilterEventId(evts[0].id);
      }
    };
    initializeData();
  }, []); // Runs only once on component mount to load metadata and set default event

  // useEffect to automatically load inventory when filter parameters change
  useEffect(() => {
    if (filterEventId) { // Only attempt to load if an event is selected (either default or user-selected)
      loadInventory();
    }
  }, [filterEventId, filterDate, filterParkId, loadInventory]); // Dependencies: re-run when filters change or loadInventory function changes


  // Renamed handleAdjust to adjustInventory as per outline, body is kept as existing code
  const adjustInventory = async (row, delta) => {
    setAdjusting(true);
    try {
      await base44.functions.invoke('leagueAdjustInventory', {
        id: row.id,
        delta,
        expectVersion: row.version
      });

      // Reload inventory after adjustment
      await loadInventory();
    } catch (error) {
      console.error("Failed to adjust inventory:", error);
      if (error.response?.data?.error === "VersionConflict") {
        alert("Someone else just modified this slot. Please refresh and try again.");
      } else {
        alert("Failed to adjust inventory: " + error.message);
      }
    } finally {
      setAdjusting(false);
    }
  };

  // The original handleDateChange function is removed as the new input uses an inline setter.
  // const handleDateChange = (e) => {
  //   const val = e.target.value;
  //   setFilterDate(val);
  // };

  // The 'generate()' function mentioned in the outline was not present in the original code,
  // and no implementation was provided. It has been omitted to avoid errors.

  // Use filterEventId for selected event logic (though the UI for selecting an event is now removed)
  const selectedEvent = events.find(e => e.id === filterEventId);
  const availableDates = selectedEvent?.leagueDates || []; // Still available if needed for other logic, though filter input is type="date"

  // Group inventory by date and field for display
  const groupedInventory = {};
  inventory.forEach(row => {
    const key = `${row.date}:${row.fieldId}`;
    if (!groupedInventory[key]) {
      groupedInventory[key] = [];
    }
    groupedInventory[key].push(row);
  });

  return (
    <div style={{ padding: "20px" }}>
      <h1 style={{ marginBottom: "24px" }}>League Spot Inventory</h1>

      {/* Date Filter */}
      <div style={{ marginBottom: "24px", display: "flex", gap: "12px", alignItems: "center", flexWrap: "wrap" }}>
        <div>
          <label className="label">Filter by Date</label>
          <input
            type="date"
            className="input"
            value={filterDate}
            onChange={(e) => setFilterDate(e.target.value)}
            style={{ maxWidth: "200px" }}
          />
        </div>
        <button
          className="btn-outline"
          onClick={() => setFilterDate("")}
          style={{ marginTop: "24px" }}
        >
          Clear Filter
        </button>
      </div>

      {/* Inventory Grid */}
      {inventory.length > 0 && (
        <div className="space-y-6">
          {Object.keys(groupedInventory).map(key => {
            const [date, fieldId] = key.split(':');
            const field = fields.find(f => f.id === fieldId);
            const park = parks.find(p => p.id === field?.parkId);
            const rows = groupedInventory[key];

            return (
              <div key={key} className="card card-pad">
                <h3 style={{ margin: '0 0 16px 0', color: '#003f5c' }}>
                  {new Date(date).toLocaleDateString()} • {field?.name || fieldId} ({park?.name || "Unknown Park"})
                </h3>

                <div style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))',
                  gap: '12px'
                }}>
                  {rows.map(row => {
                    const spotsLeft = row.availableSpots || 0;
                    const isLow = spotsLeft <= 0;
                    const isWarning = spotsLeft === 1;

                    return (
                      <div
                        key={row.id}
                        style={{
                          border: `2px solid ${isLow ? '#ef4444' : isWarning ? '#f59e0b' : '#10b981'}`,
                          borderRadius: '8px',
                          padding: '12px',
                          background: isLow ? '#fee2e2' : isWarning ? '#fef3c7' : '#ecfdf5'
                        }}
                      >
                        <div style={{
                          fontSize: '14px',
                          fontWeight: 'bold',
                          marginBottom: '8px',
                          color: '#0f172a'
                        }}>
                          {row.time}
                        </div>
                        <div style={{
                          fontSize: '24px',
                          fontWeight: 'bold',
                          marginBottom: '12px',
                          color: isLow ? '#dc2626' : isWarning ? '#d97706' : '#059669'
                        }}>
                          {spotsLeft} {spotsLeft === 1 ? 'spot' : 'spots'}
                        </div>
                        <div style={{
                          display: 'flex',
                          gap: '6px'
                        }}>
                          <button
                            onClick={() => adjustInventory(row, -1)} // Changed to adjustInventory
                            disabled={adjusting || spotsLeft <= 0}
                            className="btn-outline"
                            style={{
                              flex: 1,
                              padding: '6px',
                              fontSize: '14px',
                              opacity: spotsLeft <= 0 ? 0.5 : 1
                            }}
                          >
                            <Minus size={14} />
                          </button>
                          <button
                            onClick={() => adjustInventory(row, 1)} // Changed to adjustInventory
                            disabled={adjusting}
                            className="btn-outline"
                            style={{
                              flex: 1,
                              padding: '6px',
                              fontSize: '14px'
                            }}
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {inventory.length === 0 && filterEventId && !loading && ( // Changed to filterEventId
        <div className="card card-pad" style={{ textAlign: 'center', color: 'var(--muted)' }}>
          <p>No inventory found for the selected event and date filters.</p>
        </div>
      )}

      {!filterEventId && !loading && events.length === 0 && ( // Changed to filterEventId logic, and added events.length check
        <div className="card card-pad" style={{ textAlign: 'center', color: 'var(--muted)' }}>
          <p>Loading events or no league events are configured.</p>
        </div>
      )}
      {!filterEventId && !loading && events.length > 0 && (
        <div className="card card-pad" style={{ textAlign: 'center', color: 'var(--muted)' }}>
          <p>No default league event could be selected. Please ensure events are available.</p>
        </div>
      )}
    </div>
  );
}
