
import React, { useState, useEffect } from "react";
import { getCtx } from "../lib/ctx";
import { 
  Calendar, 
  Package, 
  Users, 
  FileText,
  Clock,
  BarChart3
} from "lucide-react";

export default function AdminHome({ onNavigate }) {
  const [stats, setStats] = useState({
    upcomingBookings: 0,
    totalPackages: 0,
    totalParks: 0,
    activeEmployees: 0,
    todayBookings: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  async function loadStats() {
    try {
      const { entities } = await getCtx();
      
      const [bookings, packages, parks, employees] = await Promise.all([
        entities.Bookings.list(),
        entities.Packages.list(),
        entities.Parks.list(),
        entities.Employees.filter({ status: "active" })
      ]);

      const today = new Date().toISOString().split('T')[0];
      const upcoming = bookings.filter(b => 
        b.date >= today && ['pending', 'confirmed', 'setup'].includes(b.status)
      );
      const todayBookings = bookings.filter(b => b.date === today);

      setStats({
        upcomingBookings: upcoming.length,
        totalPackages: packages.length,
        totalParks: parks.length,
        activeEmployees: employees.length,
        todayBookings: todayBookings.length
      });
    } catch (error) {
      console.error("Failed to load stats:", error);
    } finally {
      setLoading(false);
    }
  }

  const cards = [
    {
      title: "Today's Bookings",
      value: stats.todayBookings,
      icon: Calendar,
      color: "#003f5c",
      onClick: () => onNavigate("bookings")
    },
    {
      title: "Upcoming Bookings",
      value: stats.upcomingBookings,
      icon: FileText,
      color: "#005a7d",
      onClick: () => onNavigate("bookings")
    },
    {
      title: "Reports",
      value: "View All",
      icon: BarChart3,
      color: "#8b5cf6",
      onClick: () => window.location.href = "/AdminReports"
    },
    {
      title: "Active Packages",
      value: stats.totalPackages,
      icon: Package,
      color: "#10b981",
      onClick: () => onNavigate("packages")
    },
    {
      title: "Active Staff",
      value: stats.activeEmployees,
      icon: Users,
      color: "#ef4444",
      onClick: () => onNavigate("employees")
    }
  ];

  if (loading) {
    return (
      <div style={{ display: "flex", justifyContent: "center", padding: "60px" }}>
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div>
      <div style={{ marginBottom: "32px" }}>
        <h1 style={{ fontSize: "28px", fontWeight: "700", color: "#003f5c", marginBottom: "8px" }}>
          Dashboard
        </h1>
        <p style={{ color: "#64748b", fontSize: "14px" }}>
          Welcome back! Here's what's happening today.
        </p>
      </div>

      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
        gap: "24px"
      }}>
        {cards.map((card, idx) => {
          const Icon = card.icon;
          return (
            <button
              key={idx}
              onClick={card.onClick}
              style={{
                background: "white",
                border: "1px solid #e2e8f0",
                borderRadius: "12px",
                padding: "24px",
                textAlign: "left",
                cursor: "pointer",
                transition: "all 0.2s",
                boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = "translateY(-4px)";
                e.currentTarget.style.boxShadow = "0 4px 12px rgba(0,0,0,0.15)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "translateY(0)";
                e.currentTarget.style.boxShadow = "0 1px 3px rgba(0,0,0,0.1)";
              }}
            >
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px" }}>
                <div style={{
                  width: "48px",
                  height: "48px",
                  borderRadius: "12px",
                  background: `${card.color}15`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center"
                }}>
                  <Icon size={24} style={{ color: card.color }} />
                </div>
              </div>
              
              <div style={{ fontSize: "32px", fontWeight: "700", color: "#0f172a", marginBottom: "4px" }}>
                {card.value}
              </div>
              
              <div style={{ fontSize: "14px", color: "#64748b", fontWeight: "500" }}>
                {card.title}
              </div>
            </button>
          );
        })}
      </div>

      {/* Quick Actions Section */}
      <div style={{ marginTop: "48px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: "600", color: "#003f5c", marginBottom: "20px" }}>
          Quick Actions
        </h2>
        
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "16px" }}>
          <button
            onClick={() => onNavigate("events")}
            className="btn"
            style={{
              background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
              color: "white",
              padding: "16px",
              display: "flex",
              alignItems: "center",
              gap: "12px",
              justifyContent: "center"
            }}
          >
            <Calendar size={20} />
            Manage Events
          </button>
          
          <button
            onClick={() => onNavigate("bookings")}
            className="btn"
            style={{
              background: "linear-gradient(135deg, #10b981 0%, #059669 100%)",
              color: "white",
              padding: "16px",
              display: "flex",
              alignItems: "center",
              gap: "12px",
              justifyContent: "center"
            }}
          >
            <FileText size={20} />
            View Bookings
          </button>
          
          <button
            onClick={() => window.location.href = "/AdminPullSheets"}
            className="btn"
            style={{
              background: "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)",
              color: "white",
              padding: "16px",
              display: "flex",
              alignItems: "center",
              gap: "12px",
              justifyContent: "center"
            }}
          >
            <Clock size={20} />
            Pull Sheets
          </button>

          <button
            onClick={() => window.location.href = "/AdminManagerOverview"}
            className="btn"
            style={{
              background: "linear-gradient(135deg, #06b6d4 0%, #0891b2 100%)",
              color: "white",
              padding: "16px",
              display: "flex",
              alignItems: "center",
              gap: "12px",
              justifyContent: "center"
            }}
          >
            <FileText size={20} />
            Daily Overview
          </button>
          
          <button
            onClick={() => window.location.href = "/employee-quick-actions"}
            className="btn"
            style={{
              background: "linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)",
              color: "white",
              padding: "16px",
              display: "flex",
              alignItems: "center",
              gap: "12px",
              justifyContent: "center"
            }}
          >
            <Users size={20} />
            Staff Hub
          </button>
        </div>
      </div>
    </div>
  );
}
