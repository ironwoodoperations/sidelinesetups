
import React, { useState, useEffect } from "react";
import { getCtx } from "../lib/ctx";
import { X, MapPin } from "lucide-react";

export default function AdminSpots() {
  const [spots, setSpots] = useState([]);
  const [fields, setFields] = useState([]);
  const [parks, setParks] = useState([]);
  const [selectedPark, setSelectedPark] = useState("");
  const [selectedField, setSelectedField] = useState("");
  const [fieldImage, setFieldImage] = useState("");
  const [clickedPosition, setClickedPosition] = useState(null);
  const [spotLabel, setSpotLabel] = useState("");
  const [editingSpot, setEditingSpot] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (selectedPark) {
      loadFields();
    }
  }, [selectedPark]);

  useEffect(() => {
    if (selectedField) {
      loadFieldImage();
      loadSpots();
    }
  }, [selectedField]);

  const loadData = async () => {
    const { entities } = await getCtx();
    const parksList = await entities.Parks.list();
    setParks(parksList || []);
  };

  const loadFields = async () => {
    const { entities } = await getCtx();
    const fieldsList = await entities.Fields.filter({ parkId: selectedPark });
    setFields(fieldsList || []);
    setSelectedField("");
    setFieldImage("");
    setSpots([]);
  };

  const loadFieldImage = async () => {
    const { entities } = await getCtx();
    const field = await entities.Fields.get(selectedField);
    setFieldImage(field?.imageUrl || "");
  };

  const loadSpots = async () => {
    const { entities } = await getCtx();
    const spotsList = await entities.Spots.filter({ fieldId: selectedField });
    setSpots(spotsList || []);
  };

  const handleImageClick = (e) => {
    const rect = e.target.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    setClickedPosition({ x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10 });
  };

  const handleSaveSpot = async () => {
    if (!clickedPosition) {
      alert("Please click on the image to select a spot location");
      return;
    }
    if (!spotLabel.trim()) {
      alert("Please enter a spot label");
      return;
    }

    const { entities } = await getCtx();
    
    try {
      if (editingSpot) {
        await entities.Spots.update(editingSpot.id, {
          fieldId: selectedField,
          label: spotLabel,
          x: clickedPosition.x,
          y: clickedPosition.y,
          isActive: true
        });
      } else {
        await entities.Spots.create({
          fieldId: selectedField,
          label: spotLabel,
          x: clickedPosition.x,
          y: clickedPosition.y,
          isActive: true
        });
      }
      
      // Reset form
      setClickedPosition(null);
      setSpotLabel("");
      setEditingSpot(null);
      
      // Reload spots
      await loadSpots();
    } catch (error) {
      console.error("Failed to save spot:", error);
      alert("Failed to save spot: " + error.message);
    }
  };

  const handleEditSpot = (spot) => {
    setEditingSpot(spot);
    setSpotLabel(spot.label);
    setClickedPosition({ x: spot.x, y: spot.y });
  };

  const handleDeleteSpot = async (spotId) => {
    if (!confirm("Delete this spot?")) return;
    
    const { entities } = await getCtx();
    await entities.Spots.delete(spotId);
    await loadSpots();
  };

  const handleCancel = () => {
    setClickedPosition(null);
    setSpotLabel("");
    setEditingSpot(null);
  };

  return (
    <div>
      <h1>Manage Spots</h1>
      <p style={{ color: "var(--muted)", marginTop: 8 }}>
        Select a field, click on the image to place spots, then name them.
      </p>

      {/* Park & Field Selection */}
      <div className="card card-pad" style={{ marginTop: 24, maxWidth: 600 }}>
        <h3 style={{ marginBottom: 16 }}>Select Field</h3>
        
        <div className="row">
          <div>
            <label className="label">Park</label>
            <select 
              className="select" 
              value={selectedPark}
              onChange={(e) => setSelectedPark(e.target.value)}
            >
              <option value="">Select a park...</option>
              {parks.map((park) => (
                <option key={park.id} value={park.id}>{park.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="label">Field</label>
            <select 
              className="select" 
              value={selectedField}
              onChange={(e) => setSelectedField(e.target.value)}
              disabled={!selectedPark}
            >
              <option value="">Select a field...</option>
              {fields.map((field) => (
                <option key={field.id} value={field.id}>{field.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Field Image with Spot Placement */}
      {selectedField && (
        <div className="card card-pad" style={{ marginTop: 24 }}>
          <h3 style={{ marginBottom: 16 }}>
            {editingSpot ? `Edit Spot: ${editingSpot.label}` : "Add New Spot"}
          </h3>
          
          {!fieldImage ? (
            <div style={{ 
              padding: 40, 
              background: "var(--bg-2)", 
              borderRadius: 8, 
              textAlign: "center",
              color: "var(--muted)"
            }}>
              This field doesn't have an image yet. Add one in the Fields section.
            </div>
          ) : (
            <>
              <p style={{ color: "var(--muted)", fontSize: 14, marginBottom: 16 }}>
                Click on the image where you want to place the spot:
              </p>
              
              <div style={{ position: "relative", display: "inline-block", maxWidth: "100%" }}>
                <img 
                  src={fieldImage}
                  alt="Field"
                  onClick={handleImageClick}
                  style={{ 
                    maxWidth: "100%", 
                    height: "auto",
                    cursor: "crosshair",
                    border: "2px solid var(--border)",
                    borderRadius: 8,
                    display: "block"
                  }}
                />
                
                {/* Show clicked position */}
                {clickedPosition && (
                  <div style={{
                    position: "absolute",
                    left: `${clickedPosition.x}%`,
                    top: `${clickedPosition.y}%`,
                    transform: "translate(-50%, -50%)",
                    color: "#ef4444",
                    filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.5))"
                  }}>
                    <MapPin size={32} fill="#ef4444" />
                  </div>
                )}
                
                {/* Show existing spots */}
                {spots.map((spot) => (
                  <div
                    key={spot.id}
                    style={{
                      position: "absolute",
                      left: `${spot.x}%`,
                      top: `${spot.y}%`,
                      transform: "translate(-50%, -50%)",
                      cursor: "pointer"
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleEditSpot(spot);
                    }}
                    title={`${spot.label} - Click to edit`}
                  >
                    <MapPin size={24} fill="#0ea5e9" style={{ filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.5))" }} />
                    <div style={{
                      position: "absolute",
                      top: "100%",
                      left: "50%",
                      transform: "translateX(-50%)",
                      background: "rgba(0,0,0,0.8)",
                      color: "white",
                      padding: "4px 8px",
                      borderRadius: 4,
                      fontSize: 11,
                      fontWeight: 600,
                      whiteSpace: "nowrap",
                      marginTop: 4
                    }}>
                      {spot.label}
                    </div>
                  </div>
                ))}
              </div>

              {clickedPosition && (
                <div style={{ marginTop: 24 }}>
                  <div style={{ 
                    padding: 12, 
                    background: "#ecfdf5", 
                    border: "1px solid #c7f9e9",
                    borderRadius: 8,
                    marginBottom: 16,
                    fontSize: 14
                  }}>
                    <b>Position selected:</b> {clickedPosition.x.toFixed(1)}%, {clickedPosition.y.toFixed(1)}%
                  </div>

                  <div style={{ marginBottom: 16 }}>
                    <label className="label">Spot Name/Label</label>
                    <input
                      type="text"
                      className="input"
                      placeholder="e.g., Home Side A, Visitor 1, etc."
                      value={spotLabel}
                      onChange={(e) => setSpotLabel(e.target.value)}
                    />
                  </div>

                  <div style={{ display: "flex", gap: 12 }}>
                    <button className="btn" onClick={handleSaveSpot}>
                      {editingSpot ? "Update Spot" : "Save Spot"}
                    </button>
                    <button className="btn-outline" onClick={handleCancel}>
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* Existing Spots List */}
      {selectedField && spots.length > 0 && (
        <div style={{ marginTop: 24 }}>
          <h3 style={{ marginBottom: 16 }}>Existing Spots ({spots.length})</h3>
          <div className="grid grid-3">
            {spots.map((spot) => (
              <div key={spot.id} className="card card-pad">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start" }}>
                  <div>
                    <h4 style={{ margin: "0 0 8px 0" }}>{spot.label}</h4>
                    <div style={{ fontSize: 12, color: "var(--muted)" }}>
                      Position: {spot.x?.toFixed(1)}%, {spot.y?.toFixed(1)}%
                    </div>
                  </div>
                  <button
                    className="btn-ghost"
                    onClick={() => handleDeleteSpot(spot.id)}
                    style={{ padding: 8 }}
                  >
                    <X size={16} />
                  </button>
                </div>
                <button
                  className="btn-outline"
                  onClick={() => handleEditSpot(spot)}
                  style={{ marginTop: 12, width: "100%" }}
                >
                  Edit Position
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
