
import React, { useState, useEffect } from "react";
import { getCtx } from "../lib/ctx";
import { Plus, Edit2, Trash2, Calendar, Clock, MapPin, User } from "lucide-react";

export default function AdminShifts() {
  const [shifts, setShifts] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [events, setEvents] = useState([]);
  const [parks, setParks] = useState([]);
  const [fields, setFields] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);

  const [form, setForm] = useState({
    employeeId: "",
    eventId: "",
    eventSpecificDate: "",
    date: "",
    parkId: "",
    fieldIds: [],
    startTime: "06:00",
    endTime: "22:00",
    role: "",
    notes: ""
  });

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    try {
      const { entities } = await getCtx();
      const [shiftsData, employeesData, eventsData, parksData, fieldsData] = await Promise.all([
        entities.Shifts.list("-date"),
        entities.Employees.list(),
        entities.Events.list(),
        entities.Parks.list(),
        entities.Fields.list()
      ]);
      
      setShifts(shiftsData || []);
      setEmployees(employeesData || []);
      setEvents(eventsData || []);
      setParks(parksData || []);
      setFields(fieldsData || []);
    } catch (error) {
      console.error("Failed to load data:", error);
    } finally {
      setLoading(false);
    }
  }

  // Get available dates from selected event
  const availableDates = React.useMemo(() => {
    if (!form.eventId) return [];
    
    const event = events.find(e => e.id === form.eventId);
    if (!event) return [];
    
    if (event.leagueDates && event.leagueDates.length > 0) {
      return event.leagueDates;
    }
    
    if (event.startDate) {
      const dates = [];
      // FIX: Parse date string manually to avoid timezone issues
      const [startYear, startMonth, startDay] = event.startDate.split('-').map(Number);
      const start = new Date(startYear, startMonth - 1, startDay);
      
      let end = start;
      if (event.endDate) {
        const [endYear, endMonth, endDay] = event.endDate.split('-').map(Number);
        end = new Date(endYear, endMonth - 1, endDay);
      }
      
      for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        dates.push(`${year}-${month}-${day}`);
      }
      
      return dates;
    }
    
    return [];
  }, [form.eventId, events]);

  // Get parks and fields from selected event
  const eventParks = React.useMemo(() => {
    if (!form.eventId) return [];
    const event = events.find(e => e.id === form.eventId);
    if (!event || !event.parkIds) return [];
    return parks.filter(p => event.parkIds.includes(p.id));
  }, [form.eventId, events, parks]);

  const eventFields = React.useMemo(() => {
    if (!form.eventId) return [];
    const event = events.find(e => e.id === form.eventId);
    if (!event || !event.fieldIds) return [];
    return fields.filter(f => event.fieldIds.includes(f.id));
  }, [form.eventId, events, fields]);

  // When event changes, auto-populate park if only one
  useEffect(() => {
    if (eventParks.length === 1) {
      setForm(prev => ({ ...prev, parkId: eventParks[0].id }));
    }
  }, [eventParks]);

  async function handleSubmit(e) {
    e.preventDefault();
    
    try {
      const { entities } = await getCtx();
      
      const shiftData = {
        ...form,
        date: form.eventSpecificDate || form.date
      };
      
      if (editing) {
        await entities.Shifts.update(editing.id, shiftData);
      } else {
        await entities.Shifts.create(shiftData);
      }
      
      resetForm();
      await loadData();
    } catch (error) {
      console.error("Failed to save shift:", error);
      alert("Failed to save shift");
    }
  }

  function handleEdit(shift) {
    setEditing(shift);
    setForm({
      employeeId: shift.employeeId || "",
      eventId: shift.eventId || "",
      eventSpecificDate: shift.eventSpecificDate || "",
      date: shift.date || "",
      parkId: shift.parkId || "",
      fieldIds: shift.fieldIds || [],
      startTime: shift.startTime || "06:00",
      endTime: shift.endTime || "22:00",
      role: shift.role || "",
      notes: shift.notes || ""
    });
    setShowForm(true);
  }

  async function handleDelete(shift) {
    if (!confirm(`Delete this shift?`)) return;
    
    try {
      const { entities } = await getCtx();
      await entities.Shifts.delete(shift.id);
      await loadData();
    } catch (error) {
      console.error("Failed to delete shift:", error);
      alert("Failed to delete shift");
    }
  }

  function resetForm() {
    setForm({
      employeeId: "",
      eventId: "",
      eventSpecificDate: "",
      date: "",
      parkId: "",
      fieldIds: [],
      startTime: "06:00",
      endTime: "22:00",
      role: "",
      notes: ""
    });
    setEditing(null);
    setShowForm(false);
  }

  const toggleField = (fieldId) => {
    setForm(prev => ({
      ...prev,
      fieldIds: prev.fieldIds.includes(fieldId)
        ? prev.fieldIds.filter(id => id !== fieldId)
        : [...prev.fieldIds, fieldId]
    }));
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold" style={{ color: '#003f5c' }}>Shifts</h2>
        <button
          onClick={() => setShowForm(true)}
          className="btn"
          style={{
            background: 'linear-gradient(to right, #003f5c, #00507a)',
            color: 'white',
            border: 'none'
          }}
        >
          <Plus size={20} className="inline mr-2" />
          New Shift
        </button>
      </div>

      {loading && <div className="spinner"></div>}

      {!loading && shifts.length === 0 && (
        <div className="card card-pad" style={{ textAlign: 'center', padding: '40px' }}>
          <p style={{ color: 'var(--muted)' }}>No shifts scheduled yet</p>
        </div>
      )}

      {!loading && shifts.length > 0 && (
        <div className="grid gap-4">
          {shifts.map(shift => {
            const employee = employees.find(e => e.id === shift.employeeId);
            const event = events.find(e => e.id === shift.eventId);
            const park = parks.find(p => p.id === shift.parkId);
            const shiftFields = fields.filter(f => (shift.fieldIds || []).includes(f.id));
            
            return (
              <div key={shift.id} className="card card-pad">
                <div className="flex justify-between items-start">
                  <div style={{ flex: 1 }}>
                    <div className="flex items-center gap-2 mb-2">
                      <User size={18} style={{ color: '#003f5c' }} />
                      <h3 className="text-lg font-bold" style={{ margin: 0 }}>
                        {employee?.fullName || "Unknown Employee"}
                      </h3>
                      {shift.role && (
                        <span className="badge">{shift.role}</span>
                      )}
                    </div>
                    
                    <div style={{ fontSize: 14, color: 'var(--muted)', display: 'grid', gap: '4px' }}>
                      {event && (
                        <div className="flex items-center gap-2">
                          <Calendar size={14} />
                          <span><strong>Event:</strong> {event.name}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2">
                        <Calendar size={14} />
                        <span>{shift.date}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock size={14} />
                        <span>{shift.startTime} - {shift.endTime}</span>
                      </div>
                      {park && (
                        <div className="flex items-center gap-2">
                          <MapPin size={14} />
                          <span>{park.name}</span>
                        </div>
                      )}
                      {shiftFields.length > 0 && (
                        <div style={{ marginLeft: '24px' }}>
                          <span>Fields: {shiftFields.map(f => f.name).join(", ")}</span>
                        </div>
                      )}
                      {shift.notes && (
                        <div style={{ marginTop: '8px', fontStyle: 'italic' }}>
                          {shift.notes}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <button onClick={() => handleEdit(shift)} className="btn-outline">
                      <Edit2 size={16} />
                    </button>
                    <button onClick={() => handleDelete(shift)} className="btn-danger">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Form Modal */}
      {showForm && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          padding: '20px'
        }}>
          <div style={{
            background: 'white',
            borderRadius: '12px',
            maxWidth: '600px',
            width: '100%',
            maxHeight: '90vh',
            overflow: 'auto',
            padding: '24px'
          }}>
            <h3 style={{ marginBottom: '20px' }}>
              {editing ? "Edit Shift" : "New Shift"}
            </h3>

            <form onSubmit={handleSubmit}>
              <div style={{ display: 'grid', gap: '16px' }}>
                {/* Employee */}
                <div>
                  <label className="label">Employee *</label>
                  <select
                    className="select"
                    value={form.employeeId}
                    onChange={(e) => setForm({ ...form, employeeId: e.target.value })}
                    required
                  >
                    <option value="">Select employee</option>
                    {employees.filter(e => e.status === "active").map(emp => (
                      <option key={emp.id} value={emp.id}>
                        {emp.fullName} ({emp.role})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Event */}
                <div>
                  <label className="label">Event *</label>
                  <select
                    className="select"
                    value={form.eventId}
                    onChange={(e) => setForm({ 
                      ...form, 
                      eventId: e.target.value,
                      eventSpecificDate: "",
                      date: "",
                      parkId: "",
                      fieldIds: []
                    })}
                    required
                  >
                    <option value="">Select event</option>
                    {events.filter(e => e.isActive !== false).map(evt => (
                      <option key={evt.id} value={evt.id}>
                        {evt.name} ({evt.eventType})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Date Selection */}
                {form.eventId && (
                  <div>
                    <label className="label">Date *</label>
                    {availableDates.length > 0 ? (
                      <select
                        className="select"
                        value={form.eventSpecificDate}
                        onChange={(e) => setForm({ ...form, eventSpecificDate: e.target.value, date: e.target.value })}
                        required
                      >
                        <option value="">Select date</option>
                        {availableDates.map(date => (
                          <option key={date} value={date}>
                            {new Date(date + 'T00:00:00').toLocaleDateString('en-US', { 
                              weekday: 'short', 
                              month: 'short', 
                              day: 'numeric', 
                              year: 'numeric' 
                            })}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input
                        type="date"
                        className="input"
                        value={form.date}
                        onChange={(e) => setForm({ ...form, date: e.target.value })}
                        required
                      />
                    )}
                  </div>
                )}

                {/* Park */}
                {form.eventId && (
                  <div>
                    <label className="label">Park *</label>
                    <select
                      className="select"
                      value={form.parkId}
                      onChange={(e) => setForm({ ...form, parkId: e.target.value })}
                      required
                    >
                      <option value="">Select park</option>
                      {eventParks.map(park => (
                        <option key={park.id} value={park.id}>
                          {park.name}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Fields */}
                {form.eventId && eventFields.length > 0 && (
                  <div>
                    <label className="label">Fields</label>
                    <div style={{
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px',
                      padding: '12px',
                      maxHeight: '120px',
                      overflow: 'auto'
                    }}>
                      {eventFields.map(field => (
                        <label key={field.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0' }}>
                          <input
                            type="checkbox"
                            checked={form.fieldIds.includes(field.id)}
                            onChange={() => toggleField(field.id)}
                          />
                          <span>{field.name}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                {/* Time */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="label">Start Time *</label>
                    <input
                      type="time"
                      className="input"
                      value={form.startTime}
                      onChange={(e) => setForm({ ...form, startTime: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <label className="label">End Time *</label>
                    <input
                      type="time"
                      className="input"
                      value={form.endTime}
                      onChange={(e) => setForm({ ...form, endTime: e.target.value })}
                      required
                    />
                  </div>
                </div>

                {/* Role */}
                <div>
                  <label className="label">Role</label>
                  <input
                    className="input"
                    value={form.role}
                    onChange={(e) => setForm({ ...form, role: e.target.value })}
                    placeholder="e.g., Setup Lead, Field Attendant"
                  />
                </div>

                {/* Notes */}
                <div>
                  <label className="label">Notes</label>
                  <textarea
                    className="textarea"
                    rows={3}
                    value={form.notes}
                    onChange={(e) => setForm({ ...form, notes: e.target.value })}
                    placeholder="Any special instructions..."
                  />
                </div>
              </div>

              <div className="flex gap-2 mt-6">
                <button type="submit" className="btn">
                  {editing ? "Update" : "Create"} Shift
                </button>
                <button type="button" onClick={resetForm} className="btn-outline">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
