
// components/admin/AdminStaff.js
import React from "react";
import buildEntities from "../lib/entities";

export default function AdminStaff() {
  const entities = buildEntities();
  const [timeclocks, setTimeclocks] = React.useState([]);
  const [updates, setUpdates] = React.useState([]);

  React.useEffect(() => {
    (async () => {
      const [tc, upd] = await Promise.all([
        entities.Timeclock.list(),
        entities.SetupUpdates.list(),
      ]);
      setTimeclocks(tc || []);
      setUpdates(upd || []);
    })();
  }, []);

  return (
    <div>
      <h2>Staff & Operations</h2>
      
      <div className="card card-pad" style={{ marginTop: 16 }}>
        <h3>Timeclock Entries</h3>
        {timeclocks.length === 0 && <p style={{ color: "#6b7280" }}>No timeclock entries yet.</p>}
        {timeclocks.length > 0 && (
          <table className="table">
            <thead>
              <tr>
                <th>Staff ID</th>
                <th>Park ID</th>
                <th>Clock In</th>
                <th>Clock Out</th>
              </tr>
            </thead>
            <tbody>
              {timeclocks.map((tc) => (
                <tr key={tc.id}>
                  <td>{tc.staffId}</td>
                  <td>{tc.parkId || "—"}</td>
                  <td>{tc.clockIn ? new Date(tc.clockIn).toLocaleString() : "—"}</td>
                  <td>{tc.clockOut ? new Date(tc.clockOut).toLocaleString() : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card card-pad" style={{ marginTop: 16 }}>
        <h3>Setup Updates</h3>
        {updates.length === 0 && <p style={{ color: "#6b7280" }}>No setup updates yet.</p>}
        {updates.length > 0 && (
          <table className="table">
            <thead>
              <tr>
                <th>Booking ID</th>
                <th>Staff ID</th>
                <th>Status</th>
                <th>Message</th>
                <th>Time</th>
              </tr>
            </thead>
            <tbody>
              {updates.map((upd) => (
                <tr key={upd.id}>
                  <td>{upd.bookingId}</td>
                  <td>{upd.staffId || "—"}</td>
                  <td>{upd.status}</td>
                  <td>{upd.message}</td>
                  <td>{upd.created_date ? new Date(upd.created_date).toLocaleString() : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
