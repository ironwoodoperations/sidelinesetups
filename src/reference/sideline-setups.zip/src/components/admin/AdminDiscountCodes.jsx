import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Edit2, Trash2, Check, X, Tag, TrendingUp } from "lucide-react";

export default function AdminDiscountCodes() {
  const [codes, setCodes] = useState([]);
  const [packages, setPackages] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingCode, setEditingCode] = useState(null);
  
  const [formData, setFormData] = useState({
    code: "",
    type: "percentage",
    value: 0,
    minimumPurchaseUSD: 0,
    expiryDate: "",
    usageLimit: null,
    perCustomerLimit: null,
    applicableTo: "all",
    applicableIds: [],
    isActive: true,
    description: ""
  });

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const [codesData, packagesData, eventsData] = await Promise.all([
        base44.entities.DiscountCodes.list('-created_date'),
        base44.entities.Packages.list(),
        base44.entities.Events.list()
      ]);
      
      setCodes(codesData);
      setPackages(packagesData);
      setEvents(eventsData);
    } catch (error) {
      console.error("Failed to load data:", error);
      alert("Failed to load discount codes");
    } finally {
      setLoading(false);
    }
  }

  function handleEdit(code) {
    setEditingCode(code);
    setFormData({
      code: code.code,
      type: code.type,
      value: code.value,
      minimumPurchaseUSD: code.minimumPurchaseUSD || 0,
      expiryDate: code.expiryDate || "",
      usageLimit: code.usageLimit || null,
      perCustomerLimit: code.perCustomerLimit || null,
      applicableTo: code.applicableTo || "all",
      applicableIds: code.applicableIds || [],
      isActive: code.isActive,
      description: code.description || ""
    });
    setShowForm(true);
  }

  async function handleDelete(codeId) {
    if (!confirm("Are you sure you want to delete this discount code?")) return;
    
    try {
      await base44.entities.DiscountCodes.delete(codeId);
      await loadData();
    } catch (error) {
      console.error("Failed to delete code:", error);
      alert("Failed to delete discount code");
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    
    if (!formData.code.trim()) {
      alert("Please enter a discount code");
      return;
    }

    try {
      const data = {
        ...formData,
        code: formData.code.toUpperCase().trim(),
        value: Number(formData.value),
        minimumPurchaseUSD: Number(formData.minimumPurchaseUSD) || 0,
        usageLimit: formData.usageLimit ? Number(formData.usageLimit) : null,
        perCustomerLimit: formData.perCustomerLimit ? Number(formData.perCustomerLimit) : null,
      };

      if (editingCode) {
        await base44.entities.DiscountCodes.update(editingCode.id, data);
      } else {
        await base44.entities.DiscountCodes.create({ ...data, usageCount: 0 });
      }

      setShowForm(false);
      setEditingCode(null);
      setFormData({
        code: "",
        type: "percentage",
        value: 0,
        minimumPurchaseUSD: 0,
        expiryDate: "",
        usageLimit: null,
        perCustomerLimit: null,
        applicableTo: "all",
        applicableIds: [],
        isActive: true,
        description: ""
      });
      
      await loadData();
    } catch (error) {
      console.error("Failed to save code:", error);
      alert("Failed to save discount code");
    }
  }

  function handleCancel() {
    setShowForm(false);
    setEditingCode(null);
    setFormData({
      code: "",
      type: "percentage",
      value: 0,
      minimumPurchaseUSD: 0,
      expiryDate: "",
      usageLimit: null,
      perCustomerLimit: null,
      applicableTo: "all",
      applicableIds: [],
      isActive: true,
      description: ""
    });
  }

  if (loading) {
    return (
      <div style={{ padding: "40px", textAlign: "center" }}>
        <div className="spinner" style={{ margin: "0 auto" }}></div>
      </div>
    );
  }

  return (
    <div style={{ padding: "24px" }}>
      <div style={{ 
        display: "flex", 
        justifyContent: "space-between", 
        alignItems: "center", 
        marginBottom: "24px" 
      }}>
        <div>
          <h1 style={{ margin: "0 0 8px 0", fontSize: "28px", fontWeight: "700", color: "#003f5c" }}>
            Discount Codes
          </h1>
          <p style={{ margin: 0, color: "#64748b" }}>
            Create and manage coupon codes for your customers
          </p>
        </div>
        
        {!showForm && (
          <button
            onClick={() => setShowForm(true)}
            className="btn"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)"
            }}
          >
            <Plus size={20} />
            New Discount Code
          </button>
        )}
      </div>

      {/* Form */}
      {showForm && (
        <div style={{
          background: "white",
          borderRadius: "12px",
          padding: "24px",
          marginBottom: "24px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.1)"
        }}>
          <h2 style={{ margin: "0 0 20px 0", fontSize: "20px", fontWeight: "600", color: "#003f5c" }}>
            {editingCode ? "Edit Discount Code" : "New Discount Code"}
          </h2>
          
          <form onSubmit={handleSubmit}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
              {/* Code */}
              <div className="form-group">
                <label className="label">Code *</label>
                <input
                  type="text"
                  value={formData.code}
                  onChange={(e) => setFormData({...formData, code: e.target.value.toUpperCase()})}
                  placeholder="e.g., SAVE10"
                  required
                  style={{ textTransform: "uppercase" }}
                />
              </div>

              {/* Type */}
              <div className="form-group">
                <label className="label">Type *</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({...formData, type: e.target.value})}
                >
                  <option value="percentage">Percentage Off</option>
                  <option value="fixed_amount">Fixed Amount Off</option>
                </select>
              </div>

              {/* Value */}
              <div className="form-group">
                <label className="label">
                  Value * {formData.type === 'percentage' ? '(%)' : '($)'}
                </label>
                <input
                  type="number"
                  value={formData.value}
                  onChange={(e) => setFormData({...formData, value: e.target.value})}
                  min="0"
                  step={formData.type === 'percentage' ? '1' : '0.01'}
                  required
                />
              </div>

              {/* Minimum Purchase */}
              <div className="form-group">
                <label className="label">Minimum Purchase ($)</label>
                <input
                  type="number"
                  value={formData.minimumPurchaseUSD}
                  onChange={(e) => setFormData({...formData, minimumPurchaseUSD: e.target.value})}
                  min="0"
                  step="0.01"
                  placeholder="0 = no minimum"
                />
              </div>

              {/* Expiry Date */}
              <div className="form-group">
                <label className="label">Expiry Date</label>
                <input
                  type="date"
                  value={formData.expiryDate}
                  onChange={(e) => setFormData({...formData, expiryDate: e.target.value})}
                />
              </div>

              {/* Usage Limit */}
              <div className="form-group">
                <label className="label">Total Usage Limit</label>
                <input
                  type="number"
                  value={formData.usageLimit || ""}
                  onChange={(e) => setFormData({...formData, usageLimit: e.target.value || null})}
                  min="1"
                  placeholder="Unlimited"
                />
              </div>

              {/* Per Customer Limit */}
              <div className="form-group">
                <label className="label">Per Customer Limit</label>
                <input
                  type="number"
                  value={formData.perCustomerLimit || ""}
                  onChange={(e) => setFormData({...formData, perCustomerLimit: e.target.value || null})}
                  min="1"
                  placeholder="Unlimited"
                />
              </div>

              {/* Applicable To */}
              <div className="form-group">
                <label className="label">Applicable To</label>
                <select
                  value={formData.applicableTo}
                  onChange={(e) => setFormData({...formData, applicableTo: e.target.value, applicableIds: []})}
                >
                  <option value="all">All Bookings</option>
                  <option value="packages">Specific Packages</option>
                  <option value="events">Specific Events</option>
                </select>
              </div>

              {/* Is Active */}
              <div className="form-group" style={{ display: "flex", alignItems: "center", marginTop: "28px" }}>
                <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
                  <input
                    type="checkbox"
                    checked={formData.isActive}
                    onChange={(e) => setFormData({...formData, isActive: e.target.checked})}
                  />
                  <span>Active</span>
                </label>
              </div>
            </div>

            {/* Applicable IDs (if packages or events selected) */}
            {formData.applicableTo === 'packages' && (
              <div className="form-group" style={{ marginTop: "16px" }}>
                <label className="label">Select Packages</label>
                <div style={{ 
                  display: "grid", 
                  gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", 
                  gap: "8px",
                  padding: "12px",
                  background: "#f8fafc",
                  borderRadius: "8px",
                  maxHeight: "200px",
                  overflowY: "auto"
                }}>
                  {packages.map(pkg => (
                    <label key={pkg.id} style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
                      <input
                        type="checkbox"
                        checked={formData.applicableIds.includes(pkg.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setFormData({...formData, applicableIds: [...formData.applicableIds, pkg.id]});
                          } else {
                            setFormData({...formData, applicableIds: formData.applicableIds.filter(id => id !== pkg.id)});
                          }
                        }}
                      />
                      <span style={{ fontSize: "14px" }}>{pkg.name}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {formData.applicableTo === 'events' && (
              <div className="form-group" style={{ marginTop: "16px" }}>
                <label className="label">Select Events</label>
                <div style={{ 
                  display: "grid", 
                  gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", 
                  gap: "8px",
                  padding: "12px",
                  background: "#f8fafc",
                  borderRadius: "8px",
                  maxHeight: "200px",
                  overflowY: "auto"
                }}>
                  {events.map(event => (
                    <label key={event.id} style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
                      <input
                        type="checkbox"
                        checked={formData.applicableIds.includes(event.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setFormData({...formData, applicableIds: [...formData.applicableIds, event.id]});
                          } else {
                            setFormData({...formData, applicableIds: formData.applicableIds.filter(id => id !== event.id)});
                          }
                        }}
                      />
                      <span style={{ fontSize: "14px" }}>{event.name}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* Description */}
            <div className="form-group" style={{ marginTop: "16px" }}>
              <label className="label">Description (Admin Notes)</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                rows={3}
                placeholder="Internal notes about this code..."
              />
            </div>

            {/* Buttons */}
            <div style={{ display: "flex", gap: "12px", marginTop: "24px" }}>
              <button type="submit" className="btn">
                <Check size={18} style={{ marginRight: "8px" }} />
                {editingCode ? "Update Code" : "Create Code"}
              </button>
              <button type="button" onClick={handleCancel} className="btn-outline">
                <X size={18} style={{ marginRight: "8px" }} />
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Codes List */}
      <div style={{
        background: "white",
        borderRadius: "12px",
        overflow: "hidden",
        boxShadow: "0 2px 8px rgba(0,0,0,0.1)"
      }}>
        {codes.length === 0 ? (
          <div style={{ padding: "60px", textAlign: "center", color: "#64748b" }}>
            <Tag size={48} style={{ margin: "0 auto 16px auto", opacity: 0.3 }} />
            <p style={{ margin: 0, fontSize: "18px" }}>No discount codes yet</p>
            <p style={{ margin: "8px 0 0 0", fontSize: "14px" }}>Create your first code to get started</p>
          </div>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "#f8fafc", borderBottom: "2px solid #e2e8f0" }}>
                <th style={{ padding: "16px", textAlign: "left", fontWeight: "600", color: "#003f5c" }}>Code</th>
                <th style={{ padding: "16px", textAlign: "left", fontWeight: "600", color: "#003f5c" }}>Discount</th>
                <th style={{ padding: "16px", textAlign: "left", fontWeight: "600", color: "#003f5c" }}>Usage</th>
                <th style={{ padding: "16px", textAlign: "left", fontWeight: "600", color: "#003f5c" }}>Expires</th>
                <th style={{ padding: "16px", textAlign: "left", fontWeight: "600", color: "#003f5c" }}>Status</th>
                <th style={{ padding: "16px", textAlign: "right", fontWeight: "600", color: "#003f5c" }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {codes.map(code => (
                <tr key={code.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                  <td style={{ padding: "16px" }}>
                    <div style={{ fontWeight: "600", color: "#003f5c", fontSize: "16px", fontFamily: "monospace" }}>
                      {code.code}
                    </div>
                    {code.description && (
                      <div style={{ fontSize: "12px", color: "#64748b", marginTop: "4px" }}>
                        {code.description}
                      </div>
                    )}
                  </td>
                  <td style={{ padding: "16px" }}>
                    <div style={{ fontWeight: "600", color: "#0f172a" }}>
                      {code.type === 'percentage' ? `${code.value}% off` : `$${code.value} off`}
                    </div>
                    {code.minimumPurchaseUSD > 0 && (
                      <div style={{ fontSize: "12px", color: "#64748b", marginTop: "4px" }}>
                        Min: ${code.minimumPurchaseUSD}
                      </div>
                    )}
                  </td>
                  <td style={{ padding: "16px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                      <TrendingUp size={14} color="#64748b" />
                      <span style={{ fontWeight: "600", color: "#0f172a" }}>
                        {code.usageCount || 0}
                      </span>
                      {code.usageLimit && (
                        <span style={{ color: "#64748b", fontSize: "14px" }}>
                          / {code.usageLimit}
                        </span>
                      )}
                    </div>
                    {code.perCustomerLimit && (
                      <div style={{ fontSize: "12px", color: "#64748b", marginTop: "4px" }}>
                        {code.perCustomerLimit} per customer
                      </div>
                    )}
                  </td>
                  <td style={{ padding: "16px", color: "#64748b", fontSize: "14px" }}>
                    {code.expiryDate ? new Date(code.expiryDate).toLocaleDateString() : "No expiry"}
                  </td>
                  <td style={{ padding: "16px" }}>
                    <span style={{
                      padding: "4px 12px",
                      borderRadius: "12px",
                      fontSize: "12px",
                      fontWeight: "600",
                      background: code.isActive ? "#d1fae5" : "#fee2e2",
                      color: code.isActive ? "#065f46" : "#991b1b"
                    }}>
                      {code.isActive ? "Active" : "Inactive"}
                    </span>
                  </td>
                  <td style={{ padding: "16px", textAlign: "right" }}>
                    <div style={{ display: "flex", gap: "8px", justifyContent: "flex-end" }}>
                      <button
                        onClick={() => handleEdit(code)}
                        className="btn-outline"
                        style={{ padding: "8px 12px", fontSize: "14px" }}
                      >
                        <Edit2 size={14} />
                      </button>
                      <button
                        onClick={() => handleDelete(code.id)}
                        className="btn-danger"
                        style={{ padding: "8px 12px", fontSize: "14px" }}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}