
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getCtx } from "../lib/ctx";
import { ArrowLeft, Plus, Trash2, Edit2, MapPin, Image, Save, X, Zap } from "lucide-react";
import ImageUrlPicker from "./ImageUrlPicker";

export default function AdminParksIntegrated() {
  const [view, setView] = useState("parks");
  const [parks, setParks] = useState([]);
  const [allFields, setAllFields] = useState([]); // Holds all fields from DB
  const [parkFields, setParkFields] = useState([]); // Fields for the currently selected park
  const [allSpots, setAllSpots] = useState([]); // Holds all spots from DB
  const [fieldSpots, setFieldSpots] = useState([]); // Spots for the currently selected field

  const [spotTemplates, setSpotTemplates] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState("");

  const [loading, setLoading] = useState(true);

  const [selectedPark, setSelectedPark] = useState(null);
  const [selectedField, setSelectedField] = useState(null);

  const [parkForm, setParkForm] = useState({ name: "", parkType: "tournament", streetAddress: "", city: "", state: "", zip: "", notes: "" });
  const [fieldForm, setFieldForm] = useState({ name: "", imageUrl: "", maxLeagueSpots: 2 });
  const [spotForm, setSpotForm] = useState({ label: "", x: 50, y: 50 });

  const [editingPark, setEditingPark] = useState(null);
  const [editingField, setEditingField] = useState(null);
  const [editingSpot, setEditingSpot] = useState(null);

  // New states for quick edit
  const [quickEditField, setQuickEditField] = useState(null);
  const [quickEditForm, setQuickEditForm] = useState({ name: "", maxLeagueSpots: 2 });

  // New states for bulk field creation modal
  const [showBulkFieldModal, setShowBulkFieldModal] = useState(false);
  const [bulkFieldForm, setBulkFieldForm] = useState({
    templateId: "",
    parkId: "",
    count: 1,
    baseName: "Field",
    imageUrl: "" // Added imageUrl
  });
  const [bulkCreating, setBulkCreating] = useState(false);

  useEffect(() => {
    loadData(); // This already loads spotTemplates
  }, []);

  // Effect to update parkFields when selectedPark or allFields changes
  useEffect(() => {
    if (selectedPark && allFields.length > 0) {
      setParkFields(allFields.filter(f => f.parkId === selectedPark.id));
    } else {
      setParkFields([]);
    }
  }, [selectedPark, allFields]);

  // Effect to update fieldSpots when selectedField or allSpots changes
  useEffect(() => {
    if (selectedField && allSpots.length > 0) {
      setFieldSpots(allSpots.filter(s => s.fieldId === selectedField.id));
    } else {
      setFieldSpots([]);
    }
  }, [selectedField, allSpots]);

  async function loadData() {
    setLoading(true);
    try {
      const { entities } = await getCtx();
      const [parksData, fieldsData, spotsData, templatesData] = await Promise.all([
        entities.Parks.list(),
        entities.Fields.list(),
        entities.Spots.list(),
        entities.SpotTemplate.list()
      ]);

      setParks(parksData || []);
      setAllFields(fieldsData || []);
      setAllSpots(spotsData || []);
      setSpotTemplates(templatesData || []); // This populates `spotTemplates`
    } catch (error) {
      console.error("Failed to load data:", error);
    } finally {
      setLoading(false);
    }
  }

  // New function to handle bulk field creation
  async function handleBulkCreateFields() {
    console.log('[AdminParksIntegrated] Starting bulk create with form:', bulkFieldForm);
    
    if (!bulkFieldForm.parkId || bulkFieldForm.count < 1) {
      alert("Please select a park and specify a valid number of fields.");
      return;
    }

    if (!bulkFieldForm.imageUrl) {
      alert("Please select a field image so customers can see the field on the booking page.");
      return;
    }

    setBulkCreating(true);
    try {
      console.log('[AdminParksIntegrated] Calling bulkCreateFieldsWithTemplate function');
      
      const payload = {
        parkId: bulkFieldForm.parkId,
        count: parseInt(bulkFieldForm.count),
        baseName: bulkFieldForm.baseName || "Field",
        imageUrl: bulkFieldForm.imageUrl
      };
      
      // Only include templateId if one is selected
      if (bulkFieldForm.templateId) {
        payload.templateId = bulkFieldForm.templateId;
      }
      
      console.log('[AdminParksIntegrated] Payload:', payload);
      
      const response = await base44.functions.invoke('bulkCreateFieldsWithTemplate', payload);
      
      console.log('[AdminParksIntegrated] Response:', response);

      if (response.data?.success) {
        alert(response.data.message || `Successfully created ${response.data.fieldsCreated} fields!`);
        setShowBulkFieldModal(false);
        setBulkFieldForm({ templateId: "", parkId: "", count: 1, baseName: "Field", imageUrl: "" }); // Reset imageUrl
        await loadData(); // Reload all data to reflect new fields and spots
      } else {
        const errorMsg = response.data?.error || "Unknown error";
        console.error('[AdminParksIntegrated] Failed to create fields:', errorMsg);
        alert("Failed to create fields: " + errorMsg);
      }
    } catch (error) {
      console.error('[AdminParksIntegrated] Error during bulk create:', error);
      alert("Failed to create fields: " + error.message);
    } finally {
      setBulkCreating(false);
    }
  }

  // New helper function for the "Add Park" button
  function startNewPark() {
    setParkForm({ name: "", parkType: "tournament", streetAddress: "", city: "", state: "", zip: "", notes: "" });
    setEditingPark(null); // Ensure we are in "add new" mode
    setView("parks"); // Navigate to the parks view if not already there
    // Optional: Add logic to scroll to the park form if needed
  }

  async function handleSavePark() {
    try {
      const { entities } = await getCtx();
      if (editingPark) {
        await entities.Parks.update(editingPark.id, parkForm);
      } else {
        await entities.Parks.create(parkForm);
      }
      setParkForm({ name: "", parkType: "tournament", streetAddress: "", city: "", state: "", zip: "", notes: "" });
      setEditingPark(null);
      await loadData(); // Reload all data
    } catch (error) {
      console.error("Failed to save park:", error);
      alert("Failed to save park");
    }
  }

  async function handleDeletePark(park) {
    if (!confirm(`Delete park "${park.name}"? This will also delete all its fields and spots.`)) return;
    try {
      const { entities } = await getCtx();
      // Explicitly delete related fields and spots (assuming no cascade delete from DB schema)
      const parkFieldsToDelete = allFields.filter(f => f.parkId === park.id);
      for (const field of parkFieldsToDelete) {
        const fieldSpotsToDelete = allSpots.filter(s => s.fieldId === field.id);
        for (const spot of fieldSpotsToDelete) {
          await entities.Spots.delete(spot.id);
        }
        await entities.Fields.delete(field.id);
      }
      await entities.Parks.delete(park.id);
      await loadData(); // Reload all data
    } catch (error) {
      console.error("Failed to delete park:", error);
      alert("Failed to delete park");
    }
  }

  async function handleSaveField() {
    try {
      const { entities } = await getCtx();
      const fieldData = { ...fieldForm, parkId: selectedPark.id };

      if (editingField) {
        await entities.Fields.update(editingField.id, fieldData);
      } else {
        await entities.Fields.create(fieldData);
      }

      setFieldForm({ name: "", imageUrl: "", maxLeagueSpots: 2 });
      setEditingField(null);
      await loadData(); // Reload all data
    } catch (error) {
      console.error("Failed to save field:", error);
      alert("Failed to save field");
    }
  }

  // New quick edit handlers
  function startQuickEdit(field) {
    setQuickEditField(field);
    setQuickEditForm({
      name: field.name || "",
      maxLeagueSpots: field.maxLeagueSpots || 2
    });
  }

  async function handleQuickSave() {
    try {
      const { entities } = await getCtx();
      await entities.Fields.update(quickEditField.id, quickEditForm);
      setQuickEditField(null);
      await loadData();
    } catch (error) {
      console.error("Failed to quick save field:", error);
      alert("Failed to save field");
    }
  }

  async function handleDeleteField(field) {
    if (!confirm(`Delete field "${field.name}"? This will also delete all its spots.`)) return;
    try {
      const { entities } = await getCtx();
      const fieldSpotsToDelete = allSpots.filter(s => s.fieldId === field.id);
      for (const spot of fieldSpotsToDelete) {
        await entities.Spots.delete(spot.id);
      }
      await entities.Fields.delete(field.id);
      await loadData(); // Reload all data
    } catch (error) {
      console.error("Failed to delete field:", error);
      alert("Failed to delete field");
    }
  }

  async function handleSaveSpot() {
    try {
      const { entities } = await getCtx();
      const spotData = { ...spotForm, fieldId: selectedField.id };

      if (editingSpot) {
        await entities.Spots.update(editingSpot.id, spotData);
      } else {
        await entities.Spots.create(spotData);
      }

      setSpotForm({ label: "", x: 50, y: 50 });
      setEditingSpot(null);
      await loadData(); // Reload all data
    } catch (error) {
      console.error("Failed to save spot:", error);
      alert("Failed to save spot");
    }
  }

  async function handleDeleteSpot(spot) {
    if (!confirm(`Delete spot "${spot.label}"?`)) return;
    try {
      const { entities } = await getCtx();
      await entities.Spots.delete(spot.id);
      await loadData(); // Reload all data
    } catch (error) {
      console.error("Failed to delete spot:", error);
      alert("Failed to delete spot");
    }
  }

  async function applyTemplateToField(fieldId) {
    if (!selectedTemplate) {
      alert("Please select a template first");
      return;
    }

    if (!confirm("This will replace ALL existing spots on this field with the template spots. Continue?")) {
      return;
    }

    try {
      const response = await base44.functions.invoke('applySpotTemplate', {
        templateId: selectedTemplate,
        fieldId: fieldId
      });

      if (response.data?.success) {
        alert(`Template applied successfully! Created ${response.data.spotsCreated} spots.`);
        await loadData(); // Reload all data to reflect changes
        setSelectedTemplate(""); // Reset selected template
      } else {
        alert("Failed to apply template: " + (response.data?.error || "Unknown error"));
      }
    } catch (error) {
      console.error("Failed to apply template:", error);
      alert("Failed to apply template: " + error.message);
    }
  }

  function handleImageClick(e) {
    if (editingSpot) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    setSpotForm({ label: `Spot ${fieldSpots.length + 1}`, x: Math.round(x), y: Math.round(y) });
  }

  return (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
        <h2 style={{ margin: 0 }}>Parks & Fields Management</h2>
        <div style={{ display: "flex", gap: "8px" }}>
          <button
            className="btn"
            onClick={() => {
              setShowBulkFieldModal(true);
              // Pre-fill parkId if currently in a park-detail view, or if only one park exists
              if (selectedPark) {
                setBulkFieldForm(prev => ({ ...prev, parkId: selectedPark.id }));
              } else if (parks.length === 1) {
                setBulkFieldForm(prev => ({ ...prev, parkId: parks[0].id }));
              }
            }}
            style={{ background: "#8b5cf6", borderColor: "#8b5cf6" }}
          >
            <Plus size={16} style={{ marginRight: "6px" }} />
            Bulk Add Fields
          </button>
          <button className="btn" onClick={startNewPark}>
            <Plus size={16} style={{ marginRight: "6px" }} />
            Add Park
          </button>
        </div>
      </div>

      {/* Quick Edit Modal */}
      {quickEditField && (
        <div style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: "rgba(0,0,0,0.5)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 1000
        }}>
          <div className="card card-pad" style={{
            width: "90%",
            maxWidth: "400px"
          }}>
            <h3 style={{ marginTop: 0 }}>Quick Edit Field: {quickEditField.name}</h3>

            <div style={{ marginBottom: "16px" }}>
              <label className="label">Field Name *</label>
              <input
                className="input"
                value={quickEditForm.name}
                onChange={(e) => setQuickEditForm({ ...quickEditForm, name: e.target.value })}
                placeholder="e.g. Field 1, Diamond A"
                autoFocus
              />
            </div>

            <div style={{ marginBottom: "24px" }}>
              <label className="label">Max League Spots</label>
              <input
                className="input"
                type="number"
                min="1"
                value={quickEditForm.maxLeagueSpots}
                onChange={(e) => setQuickEditForm({ ...quickEditForm, maxLeagueSpots: parseInt(e.target.value) || 2 })}
              />
            </div>

            <div style={{ display: "flex", gap: "8px", justifyContent: "flex-end" }}>
              <button
                className="btn-outline"
                onClick={() => setQuickEditField(null)}
              >
                Cancel
              </button>
              <button
                className="btn"
                onClick={handleQuickSave}
                disabled={!quickEditForm.name}
              >
                <Save size={16} style={{ marginRight: "6px" }} />
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Field Creation Modal */}
      {showBulkFieldModal && (
        <div style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: "rgba(0,0,0,0.5)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 1000
        }}>
          <div className="card card-pad" style={{
            width: "90%",
            maxWidth: "500px",
            maxHeight: "90vh",
            overflow: "auto"
          }}>
            <h3 style={{ marginTop: 0 }}>Bulk Create Fields{bulkFieldForm.templateId ? " with Template" : ""}</h3>

            <div style={{ marginBottom: "16px" }}>
              <label className="label">Select Park *</label>
              <select
                className="input"
                value={bulkFieldForm.parkId}
                onChange={(e) => setBulkFieldForm({ ...bulkFieldForm, parkId: e.target.value })}
              >
                <option value="">Choose a park...</option>
                {parks.map(park => (
                  <option key={park.id} value={park.id}>{park.name}</option>
                ))}
              </select>
            </div>

            <div style={{ marginBottom: "16px" }}>
              <label className="label">Select Spot Template (Optional)</label>
              <select
                className="input"
                value={bulkFieldForm.templateId}
                onChange={(e) => setBulkFieldForm({ ...bulkFieldForm, templateId: e.target.value })}
              >
                <option value="">No template - create fields only</option>
                {spotTemplates.map(template => (
                  <option key={template.id} value={template.id}>
                    {template.name} ({template.spots?.length || 0} spots)
                  </option>
                ))}
              </select>
              <div style={{ fontSize: "12px", color: "#64748b", marginTop: "4px" }}>
                Optional: Apply spots from a template to all new fields
              </div>
            </div>

            <div style={{ marginBottom: "16px" }}>
              <ImageUrlPicker
                value={bulkFieldForm.imageUrl}
                onChange={(url) => setBulkFieldForm({ ...bulkFieldForm, imageUrl: url })}
                label="Field Image *"
              />
              <div style={{ fontSize: "12px", color: "#64748b", marginTop: "4px" }}>
                This image will be used for all fields and shown to customers during booking
              </div>
            </div>

            <div style={{ marginBottom: "16px" }}>
              <label className="label">Number of Fields *</label>
              <input
                type="number"
                className="input"
                min="1"
                max="50"
                value={bulkFieldForm.count}
                onChange={(e) => setBulkFieldForm({ ...bulkFieldForm, count: parseInt(e.target.value) || 1 })}
              />
              <div style={{ fontSize: "12px", color: "#64748b", marginTop: "4px" }}>
                Maximum 50 fields at once
              </div>
            </div>

            <div style={{ marginBottom: "24px" }}>
              <label className="label">Base Name (optional)</label>
              <input
                type="text"
                className="input"
                value={bulkFieldForm.baseName}
                onChange={(e) => setBulkFieldForm({ ...bulkFieldForm, baseName: e.target.value })}
                placeholder="Field"
              />
              <div style={{ fontSize: "12px", color: "#64748b", marginTop: "4px" }}>
                Fields will be named: {bulkFieldForm.baseName || "Field"} 1, {bulkFieldForm.baseName || "Field"} 2, etc.
              </div>
            </div>

            <div style={{ display: "flex", gap: "8px", justifyContent: "flex-end" }}>
              <button
                className="btn-outline"
                onClick={() => {
                  setShowBulkFieldModal(false);
                  setBulkFieldForm({ templateId: "", parkId: "", count: 1, baseName: "Field", imageUrl: "" }); // Reset imageUrl
                }}
                disabled={bulkCreating}
              >
                Cancel
              </button>
              <button
                className="btn"
                onClick={handleBulkCreateFields}
                disabled={bulkCreating || !bulkFieldForm.parkId || !bulkFieldForm.imageUrl || bulkFieldForm.count < 1} // Removed templateId from disabled condition
              >
                {bulkCreating ? (
                  <>
                    <div className="spinner" style={{ width: 14, height: 14, borderWidth: 2, marginRight: 6 }}></div>
                    Creating...
                  </>
                ) : (
                  <>Create {bulkFieldForm.count} Field{bulkFieldForm.count !== 1 ? 's' : ''}</>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {loading ? (
        <div style={{ padding: "40px", textAlign: "center" }}>
          <div className="spinner"></div>
        </div>
      ) : (
        <>
          {/* Parks List View */}
          {view === "parks" && (
            <div style={{ maxWidth: "1400px", margin: "0 auto" }}>
              <p style={{ color: "var(--muted)", marginBottom: "24px", fontSize: "14px" }}>
                Manage parks, fields, and spot placements in one integrated interface.
              </p>

              {/* Add/Edit Park Form */}
              <div className="card card-pad" style={{ marginBottom: "32px" }}>
                <h3 style={{ fontSize: "18px", marginBottom: "16px" }}>
                  {editingPark ? "Edit Park" : "Add New Park"}
                </h3>

                <div style={{ display: "grid", gap: "16px" }}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
                    <div>
                      <label className="label">Park Name *</label>
                      <input
                        className="input"
                        value={parkForm.name}
                        onChange={(e) => setParkForm({...parkForm, name: e.target.value})}
                        placeholder="e.g. Veterans Memorial Park"
                      />
                    </div>

                    <div>
                      <label className="label">Park Type</label>
                      <select
                        className="input"
                        value={parkForm.parkType}
                        onChange={(e) => setParkForm({...parkForm, parkType: e.target.value})}
                      >
                        <option value="tournament">Tournament</option>
                        <option value="league">League</option>
                        <option value="hybrid">Hybrid</option>
                      </select>
                    </div>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: "12px" }}>
                    <div>
                      <label className="label">Street Address</label>
                      <input
                        className="input"
                        value={parkForm.streetAddress}
                        onChange={(e) => setParkForm({...parkForm, streetAddress: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="label">City</label>
                      <input
                        className="input"
                        value={parkForm.city}
                        onChange={(e) => setParkForm({...parkForm, city: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="label">State</label>
                      <input
                        className="input"
                        value={parkForm.state}
                        onChange={(e) => setParkForm({...parkForm, state: e.target.value})}
                        maxLength={2}
                        placeholder="TX"
                      />
                    </div>
                    <div>
                      <label className="label">Zip</label>
                      <input
                        className="input"
                        value={parkForm.zip}
                        onChange={(e) => setParkForm({...parkForm, zip: e.target.value})}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="label">Notes</label>
                    <textarea
                      className="input"
                      value={parkForm.notes}
                      onChange={(e) => setParkForm({...parkForm, notes: e.target.value})}
                      rows={2}
                    />
                  </div>
                </div>

                <div style={{ display: "flex", gap: "12px", marginTop: "16px" }}>
                  <button className="btn" onClick={handleSavePark}>
                    <Save size={16} style={{ marginRight: "8px" }} />
                    {editingPark ? "Update Park" : "Create Park"}
                  </button>
                  {editingPark && (
                    <button
                      className="btn-outline"
                      onClick={() => {
                        setEditingPark(null);
                        setParkForm({ name: "", parkType: "tournament", streetAddress: "", city: "", state: "", zip: "", notes: "" });
                      }}
                    >
                      Cancel
                    </button>
                  )}
                </div>
              </div>

              {/* Parks List */}
              <h2 style={{ fontSize: "20px", marginBottom: "16px" }}>All Parks ({parks.length})</h2>
              {parks.length === 0 ? (
                <div className="card card-pad" style={{ textAlign: "center" }}>
                  <p style={{ color: "var(--muted)" }}>No parks yet. Create your first park above!</p>
                </div>
              ) : (
                <div style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
                  gap: "16px"
                }}>
                  {parks.map(park => (
                    <div key={park.id} className="card card-pad">
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", marginBottom: "12px" }}>
                        <div style={{ flex: 1 }}>
                          <h3 style={{ margin: "0 0 4px 0", fontSize: "16px" }}>{park.name}</h3>
                          <div style={{ fontSize: "12px", color: "var(--muted)" }}>
                            {park.city}, {park.state}
                          </div>
                        </div>
                        <span className="badge" style={{ fontSize: "11px" }}>{park.parkType}</span>
                      </div>

                      <div style={{ display: "flex", gap: "8px", marginTop: "12px" }}>
                        <button
                          className="btn"
                          onClick={() => {
                            setSelectedPark(park);
                            setView("park-detail");
                          }}
                          style={{ flex: 1, fontSize: "13px", padding: "8px 12px" }}
                        >
                          <MapPin size={14} style={{ marginRight: "6px" }} />
                          Manage Fields
                        </button>
                        <button
                          className="btn-outline"
                          onClick={() => {
                            setEditingPark(park);
                            setParkForm({
                              name: park.name || "",
                              parkType: park.parkType || "tournament",
                              streetAddress: park.streetAddress || "",
                              city: park.city || "",
                              state: park.state || "",
                              zip: park.zip || "",
                              notes: park.notes || ""
                            });
                          }}
                          style={{ padding: "8px 12px" }}
                        >
                          <Edit2 size={14} />
                        </button>
                        <button
                          className="btn-outline"
                          onClick={() => handleDeletePark(park)}
                          style={{ color: "var(--danger)", borderColor: "var(--danger)", padding: "8px 12px" }}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Park Detail View (Fields) */}
          {view === "park-detail" && selectedPark && (
            <div style={{ maxWidth: "1400px", margin: "0 auto" }}>
              <button
                className="btn-outline"
                onClick={() => {
                  setView("parks");
                  setSelectedPark(null);
                }}
                style={{ marginBottom: "16px", display: "inline-flex", alignItems: "center", gap: "8px", fontSize: "14px", padding: "8px 16px" }}
              >
                <ArrowLeft size={16} />
                Back to Parks
              </button>

              <h1 style={{ fontSize: "24px", marginBottom: "4px" }}>{selectedPark.name} - Fields</h1>
              <p style={{ color: "var(--muted)", marginBottom: "24px", fontSize: "14px" }}>
                {selectedPark.city}, {selectedPark.state}
              </p>

              {/* Spot Template Selector - Show when not editing a field */}
              {!editingField && spotTemplates.length > 0 && (
                <div style={{
                  background: "#f8fafc",
                  border: "1px solid #e2e8f0",
                  borderRadius: "8px",
                  padding: "16px",
                  marginBottom: "32px"
                }}>
                  <label className="label">Apply Spot Template to a Field:</label>
                  <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
                    <select
                      className="input"
                      value={selectedTemplate}
                      onChange={(e) => setSelectedTemplate(e.target.value)}
                      style={{ flex: 1 }}
                    >
                      <option value="">Select a template...</option>
                      {spotTemplates.map(t => (
                        <option key={t.id} value={t.id}>
                          {t.name} ({t.spots?.length || 0} spots)
                        </option>
                      ))}
                    </select>
                    {selectedTemplate && (
                      <span style={{ color: "var(--muted)", fontSize: "14px", whiteSpace: "nowrap" }}>
                        Then click "Apply Template" next to a field below
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* Add/Edit Field Form */}
              <div className="card card-pad" style={{ marginBottom: "32px" }}>
                <h3 style={{ fontSize: "18px", marginBottom: "16px" }}>
                  {editingField ? "Edit Field" : "Add New Field"}
                </h3>

                <div style={{ display: "grid", gap: "16px" }}>
                  <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "16px" }}>
                    <div>
                      <label className="label">Field Name *</label>
                      <input
                        className="input"
                        value={fieldForm.name}
                        onChange={(e) => setFieldForm({...fieldForm, name: e.target.value})}
                        placeholder="e.g. Field 1, Diamond A"
                      />
                    </div>

                    <div>
                      <label className="label">Max League Spots</label>
                      <input
                        className="input"
                        type="number"
                        min="1"
                        value={fieldForm.maxLeagueSpots}
                        onChange={(e) => setFieldForm({...fieldForm, maxLeagueSpots: parseInt(e.target.value) || 2})}
                      />
                    </div>
                  </div>

                  <div>
                    <ImageUrlPicker
                      value={fieldForm.imageUrl}
                      onChange={(url) => setFieldForm({...fieldForm, imageUrl: url})}
                      label="Field Diagram Image"
                    />
                  </div>
                </div>

                <div style={{ display: "flex", gap: "12px", marginTop: "16px" }}>
                  <button className="btn" onClick={handleSaveField}>
                    <Save size={16} style={{ marginRight: "8px" }} />
                    {editingField ? "Update Field" : "Create Field"}
                  </button>
                  {editingField && (
                    <button
                      className="btn-outline"
                      onClick={() => {
                        setEditingField(null);
                        setFieldForm({ name: "", imageUrl: "", maxLeagueSpots: 2 });
                      }}
                    >
                      Cancel
                    </button>
                  )}
                </div>
              </div>

              {/* Fields List */}
              <h2 style={{ fontSize: "20px", marginBottom: "16px" }}>Fields ({parkFields.length})</h2>
              {parkFields.length === 0 ? (
                <div className="card card-pad" style={{ textAlign: "center" }}>
                  <p style={{ color: "var(--muted)" }}>No fields yet. Create your first field above!</p>
                </div>
              ) : (
                <div style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
                  gap: "16px"
                }}>
                  {parkFields.map(field => (
                    <div key={field.id} className="card" style={{ overflow: "hidden" }}>
                      {field.imageUrl && (
                        <div style={{ height: "150px", background: "#f8fafc", overflow: "hidden" }}>
                          <img
                            src={field.imageUrl}
                            alt={field.name}
                            style={{
                              width: "100%",
                              height: "100%",
                              objectFit: "cover"
                            }}
                          />
                        </div>
                      )}
                      <div className="card-pad">
                        <h3 style={{ margin: "0 0 6px 0", fontSize: "16px" }}>{field.name}</h3>
                        <div style={{ fontSize: "12px", color: "var(--muted)", marginBottom: "6px" }}>
                          Max League Spots: {field.maxLeagueSpots || 2}
                        </div>
                        <div style={{ fontSize: "12px", color: "var(--muted)", marginBottom: "12px" }}>
                          Spots Configured: {allSpots.filter(s => s.fieldId === field.id).length}
                        </div>

                        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", justifyContent: "flex-end" }}>
                          {selectedTemplate && !editingField && (
                            <button
                              className="btn"
                              onClick={() => applyTemplateToField(field.id)}
                              style={{ flexShrink: 0, fontSize: "13px", padding: "8px 12px" }}
                              title="Apply selected template to this field (overwrites existing spots)"
                            >
                              Apply Template
                            </button>
                          )}
                          <button
                            className="btn"
                            onClick={() => startQuickEdit(field)}
                            style={{ fontSize: "13px", padding: "8px 12px", background: "#10b981", borderColor: "#10b981" }}
                            title="Quick edit name and max league spots"
                          >
                            <Zap size={14} style={{ marginRight: "4px" }} />
                            Quick Edit
                          </button>
                          <button
                            className="btn"
                            onClick={() => {
                              setSelectedField(field);
                              setView("field-detail");
                            }}
                            style={{ fontSize: "13px", padding: "8px 12px" }}
                          >
                            <MapPin size={14} style={{ marginRight: "6px" }} />
                            Spots
                          </button>
                          <button
                            className="btn-outline"
                            onClick={() => {
                              setEditingField(field);
                              setFieldForm({
                                name: field.name || "",
                                imageUrl: field.imageUrl || "",
                                maxLeagueSpots: field.maxLeagueSpots || 2
                              });
                            }}
                            style={{ padding: "8px 12px" }}
                            title="Edit all field details including image"
                          >
                            <Edit2 size={14} />
                          </button>
                          <button
                            className="btn-outline"
                            onClick={() => handleDeleteField(field)}
                            style={{ color: "var(--danger)", borderColor: "var(--danger)", padding: "8px 12px" }}
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Field Detail View (Spots) */}
          {view === "field-detail" && selectedField && (
            <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
              <button
                className="btn-outline"
                onClick={() => {
                  setView("park-detail");
                  setSelectedField(null);
                  setEditingSpot(null);
                }}
                style={{ marginBottom: "16px", display: "inline-flex", alignItems: "center", gap: "8px", fontSize: "14px", padding: "8px 16px" }}
              >
                <ArrowLeft size={16} />
                Back to {selectedPark.name}
              </button>

              <h2 style={{ fontSize: "24px", marginBottom: "4px" }}>{selectedField.name}</h2>
              <p style={{ color: "var(--muted)", marginBottom: "24px", fontSize: "14px" }}>
                {selectedPark.name} • Click on the field image to add spots
              </p>

              {/* Spot Form */}
              <div className="card card-pad" style={{ marginBottom: "24px" }}>
                <h3 style={{ fontSize: "18px", marginBottom: "16px" }}>
                  {editingSpot ? "Edit Spot" : "Add New Spot"}
                </h3>
                <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr", gap: "12px", marginBottom: "16px" }}>
                  <div>
                    <label className="label">Spot Label *</label>
                    <input
                      className="input"
                      value={spotForm.label}
                      onChange={(e) => setSpotForm({ ...spotForm, label: e.target.value })}
                      placeholder="e.g. Home Dugout"
                    />
                  </div>
                  <div>
                    <label className="label">X Position (%)</label>
                    <input
                      className="input"
                      type="number"
                      min="0"
                      max="100"
                      value={spotForm.x}
                      onChange={(e) => setSpotForm({ ...spotForm, x: parseFloat(e.target.value) || 0 })}
                    />
                  </div>
                  <div>
                    <label className="label">Y Position (%)</label>
                    <input
                      className="input"
                      type="number"
                      min="0"
                      max="100"
                      value={spotForm.y}
                      onChange={(e) => setSpotForm({ ...spotForm, y: parseFloat(e.target.value) || 0 })}
                    />
                  </div>
                </div>
                <div style={{ display: "flex", gap: "8px" }}>
                  <button className="btn" onClick={handleSaveSpot} style={{ fontSize: "14px" }}>
                    <Save size={16} style={{ marginRight: "8px" }} />
                    {editingSpot ? "Update Spot" : "Create Spot"}
                  </button>
                  {editingSpot && (
                    <button
                      className="btn-outline"
                      onClick={() => {
                        setEditingSpot(null);
                        setSpotForm({ label: "", x: 50, y: 50 });
                      }}
                      style={{ fontSize: "14px" }}
                    >
                      <X size={16} style={{ marginRight: "8px" }} />
                      Cancel
                    </button>
                  )}
                </div>
              </div>

              {/* Visual Spot Placement */}
              {selectedField.imageUrl ? (
                <div className="card card-pad" style={{ marginBottom: "24px" }}>
                  <h3 style={{ fontSize: "18px", marginBottom: "12px" }}>Field Map</h3>
                  <div style={{ fontSize: "13px", color: "var(--muted)", marginBottom: "12px" }}>
                    Click on the image to place a new spot, or click existing spots to edit
                  </div>
                  <div style={{
                    position: "relative",
                    maxWidth: "700px",
                    margin: "0 auto",
                    border: "2px solid #e2e8f0",
                    borderRadius: "8px",
                    overflow: "hidden"
                  }}>
                    <img
                      src={selectedField.imageUrl}
                      alt={selectedField.name}
                      onClick={handleImageClick}
                      style={{
                        width: "100%",
                        height: "auto",
                        display: "block",
                        cursor: editingSpot ? "default" : "crosshair"
                      }}
                    />
                    {fieldSpots.map(spot => (
                      <button
                        key={spot.id}
                        onClick={() => {
                          setEditingSpot(spot);
                          setSpotForm({ label: spot.label, x: spot.x || 50, y: spot.y || 50 });
                        }}
                        style={{
                          position: "absolute",
                          left: `${spot.x || 50}%`,
                          top: `${spot.y || 50}%`,
                          transform: "translate(-50%, -50%)",
                          minWidth: "36px",
                          height: "36px",
                          padding: "4px 8px",
                          borderRadius: "18px",
                          border: editingSpot?.id === spot.id ? "3px solid #ef4444" : "2px solid #003f5c",
                          background: editingSpot?.id === spot.id ? "#fef2f2" : "rgba(255, 255, 255, 0.95)",
                          color: "#003f5c",
                          fontWeight: "bold",
                          fontSize: "11px",
                          cursor: "pointer",
                          boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
                          transition: "all 0.2s",
                          whiteSpace: "nowrap"
                        }}
                        title={`Edit ${spot.label}`}
                      >
                        {spot.label}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="card card-pad" style={{ textAlign: "center", marginBottom: "24px" }}>
                  <Image size={48} style={{ margin: "0 auto 16px", opacity: 0.5, color: "var(--muted)" }} />
                  <p style={{ marginBottom: "8px", fontWeight: "600" }}>No field image set</p>
                  <p style={{ fontSize: "14px", color: "var(--muted)" }}>
                    Add a field image above to visually place spots on the field
                  </p>
                </div>
              )}

              {/* Spots List */}
              <div className="card card-pad">
                <h3 style={{ fontSize: "18px", marginBottom: "16px" }}>Spots ({fieldSpots.length})</h3>
                <div style={{ display: "grid", gap: "8px" }}>
                  {fieldSpots.map(spot => (
                    <div
                      key={spot.id}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        padding: "12px",
                        background: editingSpot?.id === spot.id ? "#fef2f2" : "#f8fafc",
                        border: editingSpot?.id === spot.id ? "1px solid #fecaca" : "1px solid #e2e8f0",
                        borderRadius: "8px"
                      }}
                    >
                      <div>
                        <div style={{ fontWeight: "600", fontSize: "14px" }}>{spot.label}</div>
                        <div style={{ fontSize: "12px", color: "var(--muted)" }}>
                          Position: ({Math.round(spot.x || 0)}%, {Math.round(spot.y || 0)}%)
                        </div>
                      </div>
                      <div style={{ display: "flex", gap: "8px" }}>
                        <button
                          className="btn-outline"
                          onClick={() => {
                            setEditingSpot(spot);
                            setSpotForm({ label: spot.label, x: spot.x || 50, y: spot.y || 50 });
                          }}
                          style={{ fontSize: "12px", padding: "6px 12px" }}
                        >
                          <Edit2 size={12} />
                        </button>
                        <button
                          className="btn-outline"
                          onClick={() => handleDeleteSpot(spot)}
                          style={{
                            fontSize: "12px",
                            padding: "6px 12px",
                            color: "#ef4444",
                            borderColor: "#ef4444"
                          }}
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  ))}
                  {fieldSpots.length === 0 && (
                    <div style={{
                      padding: "20px",
                      textAlign: "center",
                      color: "var(--muted)",
                      fontSize: "14px"
                    }}>
                      No spots yet. {selectedField.imageUrl ? "Click on the field image above to add spots." : "Add a field image first, then place spots on it."}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
