import React, { useState, useEffect } from "react";
import { getCtx } from "../lib/ctx";
import { Plus, Trash2, Edit2, Save, X, Upload, Move } from "lucide-react";

export default function AdminSpotTemplates() {
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null);
  const [showBuilder, setShowBuilder] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    spots: [],
    previewImageUrl: ""
  });
  const [selectedSpotIndex, setSelectedSpotIndex] = useState(null);
  const [nextSpotNumber, setNextSpotNumber] = useState(1);
  const [uploadedImages, setUploadedImages] = useState([]);

  useEffect(() => {
    loadTemplates();
    loadUploadedImages();
  }, []);

  async function loadTemplates() {
    try {
      const { entities } = await getCtx();
      const data = await entities.SpotTemplate.list();
      setTemplates(data || []);
    } catch (error) {
      console.error("Failed to load templates:", error);
    } finally {
      setLoading(false);
    }
  }

  async function loadUploadedImages() {
    try {
      const { entities } = await getCtx();
      const files = await entities.UploadedFiles.list();
      // Filter for image files only
      const images = (files || []).filter(f => 
        f.fileType && f.fileType.startsWith('image/')
      );
      setUploadedImages(images);
    } catch (error) {
      console.error("Failed to load uploaded images:", error);
    }
  }

  function startNew() {
    setFormData({
      name: "",
      description: "",
      spots: [],
      previewImageUrl: ""
    });
    setEditingId(null);
    setShowBuilder(true);
    setNextSpotNumber(1);
  }

  function startEdit(template) {
    setFormData({
      name: template.name || "",
      description: template.description || "",
      spots: template.spots || [],
      previewImageUrl: template.previewImageUrl || ""
    });
    setEditingId(template.id);
    setShowBuilder(true);
    
    // Calculate next spot number based on existing spots
    const maxNumber = (template.spots || []).reduce((max, spot) => {
      const match = spot.label.match(/Spot (\d+)/);
      return match ? Math.max(max, parseInt(match[1])) : max;
    }, 0);
    setNextSpotNumber(maxNumber + 1);
  }

  async function handleSave() {
    try {
      const { entities } = await getCtx();
      
      const saveData = {
        name: formData.name,
        description: formData.description,
        spots: formData.spots,
        previewImageUrl: formData.previewImageUrl,
        isActive: true
      };
      
      if (editingId) {
        await entities.SpotTemplate.update(editingId, saveData);
      } else {
        await entities.SpotTemplate.create(saveData);
      }
      
      await loadTemplates();
      setShowBuilder(false);
      setEditingId(null);
    } catch (error) {
      console.error("Failed to save template:", error);
      alert("Failed to save template: " + error.message);
    }
  }

  async function handleDelete(id) {
    if (!confirm("Delete this template? This cannot be undone.")) return;
    
    try {
      const { entities } = await getCtx();
      await entities.SpotTemplate.delete(id);
      await loadTemplates();
    } catch (error) {
      console.error("Failed to delete template:", error);
      alert("Failed to delete template: " + error.message);
    }
  }

  function handleImageClick(e) {
    if (!formData.previewImageUrl) return;
    
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    const newSpot = {
      label: `Spot ${nextSpotNumber}`,
      x: Math.round(x * 10) / 10,
      y: Math.round(y * 10) / 10
    };
    
    setFormData(prev => ({
      ...prev,
      spots: [...prev.spots, newSpot]
    }));
    setNextSpotNumber(nextSpotNumber + 1);
  }

  function handleSpotDrag(index, e) {
    if (!formData.previewImageUrl) return;
    
    const rect = e.currentTarget.parentElement.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    setFormData(prev => ({
      ...prev,
      spots: prev.spots.map((spot, i) => 
        i === index 
          ? { ...spot, x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10 }
          : spot
      )
    }));
  }

  function removeSpot(index) {
    setFormData(prev => ({
      ...prev,
      spots: prev.spots.filter((_, i) => i !== index)
    }));
  }

  function updateSpotLabel(index, newLabel) {
    setFormData(prev => ({
      ...prev,
      spots: prev.spots.map((spot, i) => 
        i === index ? { ...spot, label: newLabel } : spot
      )
    }));
  }

  if (loading) {
    return (
      <div style={{ padding: "20px", textAlign: "center" }}>
        <div className="spinner"></div>
      </div>
    );
  }

  if (showBuilder) {
    return (
      <div style={{ padding: "20px", maxWidth: "1200px", margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
          <h2 style={{ margin: 0 }}>
            {editingId ? "Edit" : "Create"} Spot Template
          </h2>
          <div style={{ display: "flex", gap: "8px" }}>
            <button className="btn" onClick={handleSave} disabled={!formData.name || formData.spots.length === 0}>
              <Save size={16} style={{ marginRight: "6px" }} />
              Save Template
            </button>
            <button className="btn-outline" onClick={() => setShowBuilder(false)}>
              <X size={16} style={{ marginRight: "6px" }} />
              Cancel
            </button>
          </div>
        </div>

        <div className="card card-pad" style={{ marginBottom: "20px" }}>
          <div style={{ marginBottom: "16px" }}>
            <label className="label">Template Name *</label>
            <input
              type="text"
              className="input"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g., Standard Baseball Field"
            />
          </div>

          <div style={{ marginBottom: "16px" }}>
            <label className="label">Description</label>
            <textarea
              className="textarea"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Optional description of this template"
              rows={2}
            />
          </div>

          <div>
            <label className="label">Field Image</label>
            <select
              className="select"
              value={formData.previewImageUrl}
              onChange={(e) => setFormData({ ...formData, previewImageUrl: e.target.value })}
            >
              <option value="">Select an image</option>
              {uploadedImages.map(img => (
                <option key={img.id} value={img.fileUrl}>
                  {img.fileName}
                </option>
              ))}
            </select>
            <div style={{ fontSize: "12px", color: "#64748b", marginTop: "4px" }}>
              Don't see your image? <a href="/AdminUpload" style={{ color: "#003f5c" }}>Upload one here</a>
            </div>
          </div>
        </div>

        {formData.previewImageUrl && (
          <div className="card card-pad">
            <h3 style={{ marginBottom: "12px" }}>
              <Move size={18} style={{ verticalAlign: "middle", marginRight: "6px" }} />
              Click to Add Spots • Drag to Reposition
            </h3>
            
            <div style={{
              position: "relative",
              width: "100%",
              maxWidth: "800px",
              margin: "0 auto",
              border: "2px solid #e2e8f0",
              borderRadius: "12px",
              overflow: "hidden",
              backgroundColor: "#f8fafc",
              cursor: "crosshair"
            }}>
              <img 
                src={formData.previewImageUrl} 
                alt="Field preview"
                onClick={handleImageClick}
                style={{
                  width: "100%",
                  height: "auto",
                  display: "block",
                  pointerEvents: "auto"
                }}
              />
              
              {formData.spots.map((spot, index) => (
                <div
                  key={index}
                  draggable
                  onDragEnd={(e) => handleSpotDrag(index, e)}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedSpotIndex(index);
                  }}
                  style={{
                    position: "absolute",
                    left: `${spot.x}%`,
                    top: `${spot.y}%`,
                    transform: "translate(-50%, -50%)",
                    width: "50px",
                    height: "50px",
                    borderRadius: "50%",
                    border: selectedSpotIndex === index ? "3px solid #003f5c" : "2px solid white",
                    background: selectedSpotIndex === index 
                      ? "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)"
                      : "rgba(255, 255, 255, 0.9)",
                    color: selectedSpotIndex === index ? "white" : "#003f5c",
                    fontWeight: "bold",
                    fontSize: "14px",
                    cursor: "move",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    transition: "all 0.2s",
                    userSelect: "none"
                  }}
                  onMouseEnter={(e) => {
                    if (selectedSpotIndex !== index) {
                      e.currentTarget.style.transform = "translate(-50%, -50%) scale(1.1)";
                      e.currentTarget.style.boxShadow = "0 4px 12px rgba(0,0,0,0.3)";
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (selectedSpotIndex !== index) {
                      e.currentTarget.style.transform = "translate(-50%, -50%) scale(1)";
                      e.currentTarget.style.boxShadow = "0 2px 8px rgba(0,0,0,0.2)";
                    }
                  }}
                >
                  {index + 1}
                </div>
              ))}
            </div>

            <div style={{ textAlign: "center", marginTop: "12px", color: "#64748b", fontSize: "14px" }}>
              {formData.spots.length} spot{formData.spots.length !== 1 ? 's' : ''} added
              {selectedSpotIndex !== null && ` • Spot ${selectedSpotIndex + 1} selected`}
            </div>
          </div>
        )}

        {formData.spots.length > 0 && (
          <div className="card card-pad" style={{ marginTop: "20px" }}>
            <h3 style={{ marginBottom: "12px" }}>Spot List</h3>
            <div style={{ display: "grid", gap: "8px" }}>
              {formData.spots.map((spot, index) => (
                <div 
                  key={index}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "12px",
                    padding: "12px",
                    border: selectedSpotIndex === index ? "2px solid #003f5c" : "1px solid #e2e8f0",
                    borderRadius: "8px",
                    background: selectedSpotIndex === index ? "#f8fafc" : "white"
                  }}
                  onClick={() => setSelectedSpotIndex(index)}
                >
                  <div style={{ 
                    minWidth: "30px",
                    height: "30px",
                    borderRadius: "50%",
                    background: "#003f5c",
                    color: "white",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "12px",
                    fontWeight: "bold"
                  }}>
                    {index + 1}
                  </div>
                  
                  <input
                    type="text"
                    className="input"
                    value={spot.label}
                    onChange={(e) => updateSpotLabel(index, e.target.value)}
                    onClick={(e) => e.stopPropagation()}
                    style={{ flex: 1 }}
                  />
                  
                  <div style={{ fontSize: "12px", color: "#64748b", minWidth: "100px" }}>
                    X: {spot.x}% Y: {spot.y}%
                  </div>
                  
                  <button
                    className="btn-outline"
                    onClick={(e) => {
                      e.stopPropagation();
                      removeSpot(index);
                      setSelectedSpotIndex(null);
                    }}
                    style={{ padding: "6px 12px" }}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {!formData.previewImageUrl && (
          <div className="card card-pad" style={{ textAlign: "center", padding: "40px" }}>
            <Upload size={48} style={{ color: "#94a3b8", margin: "0 auto 16px" }} />
            <h3 style={{ color: "#64748b", marginBottom: "8px" }}>No Field Image Selected</h3>
            <p style={{ color: "#94a3b8", fontSize: "14px", marginBottom: "16px" }}>
              Select a field image from the dropdown above to start placing spots visually
            </p>
            <a href="/AdminUpload" className="btn-outline">
              Upload New Image
            </a>
          </div>
        )}
      </div>
    );
  }

  return (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
        <h2 style={{ margin: 0 }}>Spot Templates</h2>
        <button className="btn" onClick={startNew}>
          <Plus size={16} style={{ marginRight: "6px" }} />
          Create Template
        </button>
      </div>

      {templates.length === 0 ? (
        <div className="card card-pad" style={{ textAlign: "center", padding: "40px" }}>
          <h3 style={{ color: "#64748b", marginBottom: "8px" }}>No Templates Yet</h3>
          <p style={{ color: "#94a3b8", fontSize: "14px", marginBottom: "16px" }}>
            Create your first spot template to reuse across multiple fields
          </p>
          <button className="btn" onClick={startNew}>
            <Plus size={16} style={{ marginRight: "6px" }} />
            Create Your First Template
          </button>
        </div>
      ) : (
        <div style={{ display: "grid", gap: "16px" }}>
          {templates.map(template => (
            <div key={template.id} className="card card-pad">
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start" }}>
                <div style={{ flex: 1 }}>
                  <h3 style={{ margin: "0 0 8px 0" }}>{template.name}</h3>
                  {template.description && (
                    <p style={{ color: "#64748b", fontSize: "14px", margin: "0 0 8px 0" }}>
                      {template.description}
                    </p>
                  )}
                  <div style={{ fontSize: "12px", color: "#94a3b8" }}>
                    {(template.spots || []).length} spot{(template.spots || []).length !== 1 ? 's' : ''} defined
                  </div>
                </div>
                <div style={{ display: "flex", gap: "8px" }}>
                  <button className="btn-outline" onClick={() => startEdit(template)}>
                    <Edit2 size={14} />
                  </button>
                  <button 
                    className="btn-outline" 
                    onClick={() => handleDelete(template.id)}
                    style={{ color: "#ef4444", borderColor: "#ef4444" }}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}