import React, { useState, useEffect } from "react";
import { base44 } from "../../api/base44Client";
import { RefreshCw } from "lucide-react";

export default function AdminStaffNow() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    try {
      setLoading(true);
      const result = await base44.functions.invoke('listClockedInNow');
      setRows(result.data || []);
    } catch (error) {
      console.error("Failed to load clocked in staff:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <div className="card card-pad">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h3 style={{ margin: 0, color: "#003f5c" }}>Who's Clocked In Now</h3>
        <button 
          onClick={loadData} 
          className="btn-outline"
          disabled={loading}
        >
          <RefreshCw size={16} className={loading ? "animate-spin" : ""} />
        </button>
      </div>

      {loading && <div className="spinner"></div>}

      {!loading && rows.length === 0 && (
        <div style={{ color: "var(--muted)", textAlign: "center", padding: 20 }}>
          No one is currently clocked in.
        </div>
      )}

      {!loading && rows.length > 0 && (
        <div style={{ overflowX: "auto" }}>
          <table className="table">
            <thead>
              <tr>
                <th>Employee</th>
                <th>Role</th>
                <th>Clocked In At</th>
                <th>Park</th>
                <th>Notes</th>
                <th>Source</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(r => (
                <tr key={r.id}>
                  <td style={{ fontWeight: 600 }}>{r.employee}</td>
                  <td><span className="badge">{r.role}</span></td>
                  <td>{new Date(r.clockInAt).toLocaleString()}</td>
                  <td>{r.parkId || "-"}</td>
                  <td>{r.notes || "-"}</td>
                  <td><span className="badge">{r.source}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}