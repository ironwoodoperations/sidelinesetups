
import React, { useState, useEffect } from "react";
import { getCtx } from "../lib/ctx";
import { ChevronDown, ChevronUp, ExternalLink, Trash2, Archive, ArchiveRestore } from "lucide-react";
import { formatMoney } from "../lib/pricingDetails";
import LineItemsTable from "../LineItemsTable";
import { base44 } from "@/api/base44Client";

export default function AdminBookings() {
  const [bookings, setBookings] = useState([]);
  const [events, setEvents] = useState([]);
  const [parks, setParks] = useState([]);
  const [fields, setFields] = useState([]);
  const [packages, setPackages] = useState([]);
  const [equipment, setEquipment] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedBooking, setExpandedBooking] = useState(null);
  
  // Filters
  const [selectedEvent, setSelectedEvent] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [showArchived, setShowArchived] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      setLoading(true);
      const { entities } = await getCtx();
      
      const [bookingsData, eventsData, parksData, fieldsData, packagesData, equipmentData] = await Promise.all([
        entities.Bookings.list("-created_date"),
        entities.Events.list(),
        entities.Parks.list(),
        entities.Fields.list(),
        entities.Packages.list(),
        entities.Equipment.list()
      ]);
      
      setBookings(bookingsData || []);
      setEvents(eventsData || []);
      setParks(parksData || []);
      setFields(fieldsData || []);
      setPackages(packagesData || []);
      setEquipment(equipmentData || []);
    } catch (error) {
      console.error("Failed to load bookings:", error);
      alert("Failed to load bookings");
    } finally {
      setLoading(false);
    }
  }

  async function handleStatusChange(bookingId, newStatus) {
    try {
      const { entities } = await getCtx();
      
      // Get current booking to check previous status
      const booking = await entities.Bookings.get(bookingId);
      
      // Prepare update object
      const updateData = { status: newStatus };
      
      // Automatically archive when moving to closed status
      if (newStatus === 'closed') {
        updateData.archived = true;
      }
      
      await entities.Bookings.update(bookingId, updateData);
      
      // Release inventory when status changes to "picked_up", "closed", OR "cancelled"
      if (newStatus === 'picked_up' || newStatus === 'closed' || (newStatus === 'cancelled' && booking.status !== 'cancelled')) {
        try {
          console.log(`[AdminBookings] Releasing inventory for booking ${bookingId} (status: ${booking.status} → ${newStatus})`);
          const releaseResponse = await base44.functions.invoke('inventoryRelease', {
            bookingId
          });
          console.log(`[AdminBookings] Inventory released:`, releaseResponse.data);
          
          if (releaseResponse.data && !releaseResponse.data.success) {
            console.warn(`[AdminBookings] Inventory release warning:`, releaseResponse.data.error);
            alert(`Warning: ${releaseResponse.data.error || 'Inventory release returned unsuccessful'}`);
          }
        } catch (invError) {
          console.error(`[AdminBookings] Failed to release inventory:`, invError);
          alert(`Warning: Status updated but inventory release failed: ${invError.message}`);
        }
      }
      
      loadData();
    } catch (error) {
      console.error("Failed to update status:", error);
      alert("Failed to update booking status");
    }
  }

  async function handleArchiveToggle(bookingId, currentlyArchived) {
    try {
      const { entities } = await getCtx();
      await entities.Bookings.update(bookingId, { archived: !currentlyArchived });
      loadData();
    } catch (error) {
      console.error("Failed to toggle archive:", error);
      alert("Failed to archive/unarchive booking");
    }
  }

  async function handleDeleteBooking(booking) {
    if (!confirm(
      `⚠️ PERMANENT DELETION WARNING ⚠️\n\n` +
      `This will COMPLETELY DELETE booking ${booking.id} and ALL related records:\n\n` +
      `• Booking details\n` +
      `• Payment events\n` +
      `• Invoices\n` +
      `• Credits & refunds\n` +
      `• COGS records\n` +
      `• Survey responses\n` +
      `• Wallet passes\n` +
      `• Locks\n` +
      `• Inventory movements\n\n` +
      `This action CANNOT be undone.\n\n` +
      `Type the booking ID to confirm: ${booking.id}`
    )) {
      return;
    }

    const confirmId = prompt(`Type the booking ID (${booking.id}) to confirm deletion:`);
    if (confirmId !== booking.id) {
      alert("Booking ID doesn't match. Deletion cancelled.");
      return;
    }

    try {
      const { entities } = await getCtx();
      
      console.log(`[AdminBookings] Starting deletion of booking ${booking.id} with status: ${booking.status}`);

      // 1. Release inventory if booking was in any status that allocated inventory
      // This includes: paid, photo_uploaded, setup, checked_in, leaving, picked_up, closed, cancelled
      const statusesThatAllocateInventory = ['paid', 'photo_uploaded', 'setup', 'checked_in', 'leaving', 'picked_up', 'closed', 'cancelled'];
      
      if (statusesThatAllocateInventory.includes(booking.status)) {
        try {
          console.log(`[AdminBookings] Releasing inventory for booking ${booking.id} (status: ${booking.status})`);
          const releaseResponse = await base44.functions.invoke('inventoryRelease', {
            bookingId: booking.id
          });
          console.log(`[AdminBookings] Inventory released:`, releaseResponse.data);
          
          if (releaseResponse.data && !releaseResponse.data.success && releaseResponse.data.releases?.length === 0) {
            console.log(`[AdminBookings] No inventory to release (expected if already released)`);
          }
        } catch (invError) {
          console.error(`[AdminBookings] Failed to release inventory:`, invError);
          // Continue with deletion even if inventory release fails
          alert(`Warning: Inventory release failed - ${invError.message}. Continuing with deletion...`);
        }
      } else {
        console.log(`[AdminBookings] Skipping inventory release for status: ${booking.status}`);
      }

      // 2. Delete all related records
      console.log(`[AdminBookings] Deleting related records...`);

      // Delete payment events
      const paymentEvents = await entities.PaymentEvents.filter({ 
        event: { bookingId: booking.id } 
      });
      for (const pe of paymentEvents) {
        await entities.PaymentEvents.delete(pe.id);
      }
      console.log(`[AdminBookings] Deleted ${paymentEvents.length} payment events`);

      // Delete invoices
      const invoices = await entities.Invoices.filter({ bookingId: booking.id });
      for (const inv of invoices) {
        await entities.Invoices.delete(inv.id);
      }
      console.log(`[AdminBookings] Deleted ${invoices.length} invoices`);

      // Delete credits
      const credits = await entities.Credits.filter({ bookingId: booking.id });
      for (const credit of credits) {
        await entities.Credits.delete(credit.id);
      }
      console.log(`[AdminBookings] Deleted ${credits.length} credits`);

      // Delete refunds
      const refunds = await entities.Refunds.filter({ bookingId: booking.id });
      for (const refund of refunds) {
        await entities.Refunds.delete(refund.id);
      }
      console.log(`[AdminBookings] Deleted ${refunds.length} refunds`);

      // Delete COGS records
      const cogsRecords = await entities.COGS.filter({ bookingId: booking.id });
      for (const cogs of cogsRecords) {
        await entities.COGS.delete(cogs.id);
      }
      console.log(`[AdminBookings] Deleted ${cogsRecords.length} COGS records`);

      // Delete survey responses
      const surveys = await entities.SurveyResponse.filter({ bookingId: booking.id });
      for (const survey of surveys) {
        await entities.SurveyResponse.delete(survey.id);
      }
      console.log(`[AdminBookings] Deleted ${surveys.length} survey responses`);

      // Delete wallet passes
      const walletPasses = await entities.WalletPasses.filter({ bookingId: booking.id });
      for (const pass of walletPasses) {
        await entities.WalletPasses.delete(pass.id);
      }
      console.log(`[AdminBookings] Deleted ${walletPasses.length} wallet passes`);

      // Delete locks
      const locks = await entities.Locks.filter({ bookingId: booking.id });
      for (const lock of locks) {
        await entities.Locks.delete(lock.id);
      }
      console.log(`[AdminBookings] Deleted ${locks.length} locks`);

      // Delete inventory movements
      const movements = await entities.InventoryMovements.filter({ bookingId: booking.id });
      for (const movement of movements) {
        await entities.InventoryMovements.delete(movement.id);
      }
      console.log(`[AdminBookings] Deleted ${movements.length} inventory movements`);

      // Delete setup updates
      const setupUpdates = await entities.SetupUpdates.filter({ bookingId: booking.id });
      for (const update of setupUpdates) {
        await entities.SetupUpdates.delete(update.id);
      }
      console.log(`[AdminBookings] Deleted ${setupUpdates.length} setup updates`);

      // 3. Finally, delete the booking itself
      await entities.Bookings.delete(booking.id);
      console.log(`[AdminBookings] Deleted booking ${booking.id}`);

      alert(`✅ Booking ${booking.id} and all related records have been permanently deleted.`);
      
      // Reload the data
      await loadData();
      
    } catch (error) {
      console.error("Failed to delete booking:", error);
      alert(`❌ Failed to delete booking: ${error.message || 'Unknown error'}\n\nSome records may have been deleted. Please check the data.`);
      // Reload to show current state
      await loadData();
    }
  }

  async function handleViewIdPhoto(bookingId) {
    try {
      const response = await base44.functions.invoke('viewIdPhoto', { bookingId });
      window.open(response.data.signed_url, '_blank');
    } catch (error) {
      console.error('Failed to view ID photo:', error);
      alert('Failed to load ID photo: ' + error.message);
    }
  }

  async function handleApproveIdSkip(bookingId) {
    if (!confirm('Approve this booking to continue without ID verification?')) {
      return;
    }
    
    try {
      await base44.functions.invoke('approveIdSkip', { bookingId });
      alert('✅ ID requirement waived for this booking');
      loadData();
    } catch (error) {
      console.error('Failed to approve ID skip:', error);
      alert('Failed to approve: ' + error.message);
    }
  }

  function getEventName(eventId) {
    const event = events.find(e => e.id === eventId);
    return event?.name || eventId;
  }

  function getParkName(parkId) {
    const park = parks.find(p => p.id === parkId);
    return park?.name || parkId;
  }

  function getFieldName(fieldId) {
    const field = fields.find(f => f.id === fieldId);
    return field?.name || fieldId;
  }

  function getPackageName(packageId) {
    const pkg = packages.find(p => p.id === packageId);
    return pkg?.name || packageId;
  }

  function getPackageEquipment(packageId) {
    const pkg = packages.find(p => p.id === packageId);
    if (!pkg?.baseItems) return [];
    
    return pkg.baseItems.map(item => {
      const equip = equipment.find(e => e.id === item.equipmentId);
      return {
        name: equip?.name || item.equipmentId,
        qty: item.qty || 1
      };
    }).filter(Boolean);
  }

  function toggleExpand(bookingId) {
    setExpandedBooking(expandedBooking === bookingId ? null : bookingId);
  }

  // Filter bookings by archive status first
  const activeBookings = showArchived 
    ? bookings 
    : bookings.filter(b => !b.archived);

  // Then apply event and status filters
  const filteredBookings = activeBookings.filter(booking => {
    const eventMatch = selectedEvent === "all" || booking.eventId === selectedEvent;
    const statusMatch = selectedStatus === "all" || booking.status === selectedStatus;
    return eventMatch && statusMatch;
  });

  // Get counts for each filter option (only from non-archived bookings)
  const nonArchivedBookings = bookings.filter(b => !b.archived);
  const statusCounts = {
    all: nonArchivedBookings.length,
    pending: nonArchivedBookings.filter(b => b.status === 'pending').length,
    paid: nonArchivedBookings.filter(b => b.status === 'paid').length,
    photo_uploaded: nonArchivedBookings.filter(b => b.status === 'photo_uploaded').length,
    setup: nonArchivedBookings.filter(b => b.status === 'setup').length,
    checked_in: nonArchivedBookings.filter(b => b.status === 'checked_in').length,
    leaving: nonArchivedBookings.filter(b => b.status === 'leaving').length,
    picked_up: nonArchivedBookings.filter(b => b.status === 'picked_up').length,
    closed: nonArchivedBookings.filter(b => b.status === 'closed').length,
    cancelled: nonArchivedBookings.filter(b => b.status === 'cancelled').length
  };

  const eventCounts = {};
  eventCounts.all = nonArchivedBookings.length;
  events.forEach(event => {
    eventCounts[event.id] = nonArchivedBookings.filter(b => b.eventId === event.id).length;
  });

  const archivedCount = bookings.filter(b => b.archived).length;

  const statusColors = {
    pending: "bg-yellow-100 text-yellow-800",
    paid: "bg-green-100 text-green-800",
    photo_uploaded: "bg-blue-100 text-blue-800",
    setup: "bg-blue-100 text-blue-800",
    checked_in: "bg-indigo-100 text-indigo-800",
    leaving: "bg-gray-100 text-gray-800",
    picked_up: "bg-purple-100 text-purple-800",
    closed: "bg-purple-100 text-purple-800",
    cancelled: "bg-red-100 text-red-800"
  };

  if (loading) {
    return (
      <div style={{ padding: "40px", textAlign: "center" }}>
        <div className="spinner"></div>
        <p style={{ marginTop: "16px", color: "#64748b" }}>Loading bookings...</p>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: "24px" }}>
        <h2 style={{ margin: 0, fontSize: "24px", fontWeight: "700", color: "#003f5c" }}>
          Bookings
        </h2>
        <p style={{ margin: "4px 0 0 0", color: "#64748b", fontSize: "14px" }}>
          View and manage all customer bookings
        </p>
      </div>

      {/* Filters */}
      <div style={{ 
        display: "flex", 
        gap: "12px", 
        marginBottom: "24px",
        flexWrap: "wrap",
        alignItems: "center"
      }}>
        {/* Event Filter */}
        <div style={{ flex: "1", minWidth: "200px" }}>
          <label style={{ 
            display: "block", 
            fontSize: "12px", 
            fontWeight: "600", 
            color: "#64748b",
            marginBottom: "4px",
            textTransform: "uppercase",
            letterSpacing: "0.5px"
          }}>
            Filter by Event
          </label>
          <select
            value={selectedEvent}
            onChange={(e) => setSelectedEvent(e.target.value)}
            style={{
              width: "100%",
              padding: "8px 12px",
              border: "1px solid #e2e8f0",
              borderRadius: "6px",
              fontSize: "14px",
              cursor: "pointer"
            }}
          >
            <option value="all">All Events ({eventCounts.all})</option>
            {events.map(event => (
              <option key={event.id} value={event.id}>
                {event.name} ({eventCounts[event.id] || 0})
              </option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div style={{ flex: "1", minWidth: "200px" }}>
          <label style={{ 
            display: "block", 
            fontSize: "12px", 
            fontWeight: "600", 
            color: "#64748b",
            marginBottom: "4px",
            textTransform: "uppercase",
            letterSpacing: "0.5px"
          }}>
            Filter by Status
          </label>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            style={{
              width: "100%",
              padding: "8px 12px",
              border: "1px solid #e2e8f0",
              borderRadius: "6px",
              fontSize: "14px",
              cursor: "pointer"
            }}
          >
            <option value="all">All Status ({statusCounts.all})</option>
            <option value="pending">Pending ({statusCounts.pending})</option>
            <option value="paid">Paid ({statusCounts.paid})</option>
            <option value="photo_uploaded">Photo Uploaded ({statusCounts.photo_uploaded})</option>
            <option value="setup">Setup ({statusCounts.setup})</option>
            <option value="checked_in">Checked In ({statusCounts.checked_in})</option>
            <option value="leaving">Leaving ({statusCounts.leaving})</option>
            <option value="picked_up">Picked Up ({statusCounts.picked_up})</option>
            <option value="closed">Closed ({statusCounts.closed})</option>
            <option value="cancelled">Cancelled ({statusCounts.cancelled})</option>
          </select>
        </div>

        {/* Archive Toggle */}
        <div style={{ 
          padding: "8px 16px",
          background: showArchived ? "#8b5cf6" : "#f8fafc",
          color: showArchived ? "white" : "#64748b",
          borderRadius: "6px",
          fontSize: "14px",
          fontWeight: "600",
          alignSelf: "flex-end",
          cursor: "pointer",
          border: "1px solid " + (showArchived ? "#8b5cf6" : "#e2e8f0"),
          display: "flex",
          alignItems: "center",
          gap: "8px"
        }}
        onClick={() => setShowArchived(!showArchived)}
        >
          <Archive size={16} />
          {showArchived ? `Showing Archived (${archivedCount})` : `Show Archived (${archivedCount})`}
        </div>

        {/* Results Count */}
        <div style={{ 
          padding: "8px 16px",
          background: "#f8fafc",
          borderRadius: "6px",
          fontSize: "14px",
          color: "#64748b",
          fontWeight: "600",
          alignSelf: "flex-end"
        }}>
          Showing {filteredBookings.length} of {activeBookings.length} bookings
        </div>
      </div>

      {/* Bookings List */}
      {filteredBookings.length === 0 ? (
        <div className="card" style={{ padding: "40px", textAlign: "center" }}>
          <h3 style={{ margin: "0 0 8px 0", color: "#64748b" }}>
            {bookings.length === 0 ? "No Bookings Yet" : "No Matching Bookings"}
          </h3>
          <p style={{ margin: "0", color: "#94a3b8", fontSize: "14px" }}>
            {bookings.length === 0 
              ? "Bookings will appear here once customers make reservations"
              : "Try adjusting your filters to see more results"
            }
          </p>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
          {filteredBookings.map(booking => {
            const isExpanded = expandedBooking === booking.id;
            const packageEquipment = getPackageEquipment(booking.packageId);
            const total = booking.totalCents 
              ? formatMoney(booking.totalCents)
              : `$${Number(booking.totals?.amount || booking.total || 0).toFixed(2)}`;

            return (
              <div
                key={booking.id}
                className="card"
                style={{
                  overflow: "hidden",
                  border: "1px solid #e2e8f0",
                  opacity: booking.archived ? 0.6 : 1
                }}
              >
                {/* Main Booking Row */}
                <div
                  style={{
                    padding: "16px",
                    display: "grid",
                    gridTemplateColumns: "1fr auto",
                    gap: "16px",
                    alignItems: "start",
                    cursor: "pointer",
                    background: isExpanded ? "#f8fafc" : "white"
                  }}
                  onClick={() => toggleExpand(booking.id)}
                >
                  <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                    {/* Booking ID & Status */}
                    <div style={{ display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap" }}>
                      <span style={{ fontSize: "12px", color: "#64748b", fontFamily: "monospace" }}>
                        {booking.id}
                      </span>
                      <span className={`badge ${statusColors[booking.status] || statusColors.pending}`}>
                        {booking.status || "pending"}
                      </span>
                      {booking.archived && (
                        <span className="badge" style={{ background: "#8b5cf6", color: "white" }}>
                          <Archive size={12} style={{ marginRight: "4px", display: "inline" }} />
                          Archived
                        </span>
                      )}
                      {booking.idPhotoUri && (
                        <span className="badge badge-success">
                          ✓ ID
                        </span>
                      )}
                      {!booking.idPhotoUri && !booking.idSkipApprovedBy && (
                        <span className="badge badge-warn">
                          No ID
                        </span>
                      )}
                      {booking.idSkipApprovedBy && (
                        <span className="badge" style={{ background: "#94a3b8", color: "white" }}>
                          ID Waived
                        </span>
                      )}
                    </div>

                    {/* Customer Name */}
                    <div style={{ fontSize: "18px", fontWeight: "600", color: "#0f172a" }}>
                      {booking.fullName || "Unknown Customer"}
                    </div>

                    {/* Event & Package */}
                    <div style={{ display: "flex", flexWrap: "wrap", gap: "16px", fontSize: "14px", color: "#64748b" }}>
                      <div>
                        <strong>Event:</strong> {getEventName(booking.eventId)}
                      </div>
                      <div>
                        <strong>Package:</strong> {getPackageName(booking.packageId)}
                      </div>
                      <div>
                        <strong>Date:</strong> {booking.date || "TBD"}
                      </div>
                    </div>

                    {/* Location */}
                    {booking.parkId && (
                      <div style={{ fontSize: "14px", color: "#64748b" }}>
                        <strong>Location:</strong> {getParkName(booking.parkId)}
                        {booking.fieldId && ` • ${getFieldName(booking.fieldId)}`}
                        {booking.spotLabel && ` • Spot ${booking.spotLabel}`}
                      </div>
                    )}
                  </div>

                  {/* Right Side: Total & Expand Button */}
                  <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: "12px", color: "#64748b" }}>Total</div>
                      <div style={{ fontSize: "20px", fontWeight: "700", color: "#003f5c" }}>
                        {total}
                      </div>
                    </div>
                    <button
                      style={{
                        padding: "8px",
                        background: "white",
                        border: "1px solid #e2e8f0",
                        borderRadius: "6px",
                        cursor: "pointer",
                        color: "#64748b"
                      }}
                    >
                      {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                    </button>
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div style={{
                    padding: "20px",
                    borderTop: "1px solid #e2e8f0",
                    background: "white"
                  }}>
                    {/* Contact Info */}
                    <div style={{
                      marginBottom: "20px",
                      padding: "16px",
                      background: "#f8fafc",
                      borderRadius: "8px"
                    }}>
                      <h4 style={{ margin: "0 0 12px 0", fontSize: "14px", fontWeight: "600", color: "#003f5c" }}>
                        Contact Information
                      </h4>
                      <div style={{ display: "grid", gap: "8px", fontSize: "14px", color: "#475569" }}>
                        <div><strong>Email:</strong> {booking.contactEmail || "-"}</div>
                        <div><strong>Phone:</strong> {booking.phone || "-"}</div>
                        {booking.teamName && <div><strong>Team:</strong> {booking.teamName}</div>}
                        {booking.coachName && <div><strong>Coach:</strong> {booking.coachName}</div>}
                      </div>
                    </div>

                    {/* ID Verification Section */}
                    <div style={{
                      marginBottom: "20px",
                      padding: "16px",
                      background: booking.idPhotoUri ? "#f0fdf4" : (booking.idSkipApprovedBy ? "#f8fafc" : "#fffbeb"),
                      border: `1px solid ${booking.idPhotoUri ? "#bbf7d0" : (booking.idSkipApprovedBy ? "#e2e8f0" : "#fde68a")}`,
                      borderRadius: "8px"
                    }}>
                      <h4 style={{ margin: "0 0 12px 0", fontSize: "14px", fontWeight: "600", color: "#003f5c" }}>
                        ID Verification
                      </h4>
                      {booking.idPhotoUri ? (
                        <div>
                          <span className="badge badge-success" style={{ marginBottom: "8px" }}>ID Uploaded ✓</span>
                          <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "12px" }}>
                            Uploaded: {new Date(booking.idPhotoUploadedAt).toLocaleString()}
                          </div>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleViewIdPhoto(booking.id);
                            }}
                            className="btn-outline"
                            style={{ fontSize: "14px", padding: "8px 16px" }}
                          >
                            View ID Photo
                          </button>
                        </div>
                      ) : booking.idSkipApprovedBy ? (
                        <div>
                          <span className="badge" style={{ background: "#94a3b8", color: "white", marginBottom: "8px" }}>
                            ID Requirement Waived
                          </span>
                          <div style={{ fontSize: "12px", color: "#64748b" }}>
                            Approved by: {booking.idSkipApprovedBy}<br />
                            {booking.idSkipApprovedAt && `On: ${new Date(booking.idSkipApprovedAt).toLocaleString()}`}
                          </div>
                        </div>
                      ) : (
                        <div>
                          <span className="badge badge-warn" style={{ marginBottom: "8px" }}>No ID Uploaded</span>
                          <div style={{ fontSize: "12px", color: "#92400e", marginBottom: "12px" }}>
                            Customer has not uploaded their ID yet
                          </div>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleApproveIdSkip(booking.id);
                            }}
                            className="btn-outline"
                            style={{ fontSize: "14px", padding: "8px 16px" }}
                          >
                            Approve Without ID
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Package Contents */}
                    {packageEquipment.length > 0 && (
                      <div style={{
                        marginBottom: "20px",
                        padding: "16px",
                        background: "#f0fdf4",
                        border: "1px solid #bbf7d0",
                        borderRadius: "8px"
                      }}>
                        <h4 style={{
                          margin: "0 0 12px 0",
                          fontSize: "14px",
                          fontWeight: "600",
                          color: "#15803d",
                          display: "flex",
                          alignItems: "center",
                          gap: "8px"
                        }}>
                          📦 Included in Package: {getPackageName(booking.packageId)}
                        </h4>
                        <ul style={{
                          margin: 0,
                          paddingLeft: "24px",
                          fontSize: "14px",
                          color: "#166534",
                          lineHeight: "1.8"
                        }}>
                          {packageEquipment.map((equip, idx) => (
                            <li key={idx}>
                              <strong>{equip.qty}x</strong> {equip.name}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Line Items Table */}
                    {booking.lineItemsJson && booking.lineItemsJson.length > 0 ? (
                      <div style={{ marginBottom: "20px" }}>
                        <h4 style={{ margin: "0 0 12px 0", fontSize: "14px", fontWeight: "600", color: "#003f5c" }}>
                          Order Summary
                        </h4>
                        <LineItemsTable
                          items={booking.lineItemsJson}
                          baseCents={booking.baseCents}
                          addOnCents={booking.addOnCents}
                          totalCents={booking.totalCents}
                        />
                      </div>
                    ) : (
                      /* Fallback for old bookings */
                      <div style={{ marginBottom: "20px" }}>
                        <h4 style={{ margin: "0 0 12px 0", fontSize: "14px", fontWeight: "600", color: "#003f5c" }}>
                          Booking Details
                        </h4>
                        <div style={{
                          padding: "16px",
                          background: "#f8fafc",
                          borderRadius: "8px",
                          fontSize: "14px",
                          color: "#475569"
                        }}>
                          <div><strong>Package:</strong> {getPackageName(booking.packageId)}</div>
                          {booking.addOns && booking.addOns.length > 0 && (
                            <div style={{ marginTop: "8px" }}>
                              <strong>Add-ons:</strong>
                              <ul style={{ margin: "4px 0 0 0", paddingLeft: "20px" }}>
                                {booking.addOns.map((addon, idx) => (
                                  <li key={idx}>{addon.label || "Add-on"}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Notes */}
                    {booking.notes && (
                      <div style={{
                        marginBottom: "20px",
                        padding: "12px",
                        background: "#fffbeb",
                        border: "1px solid #fef3c7",
                        borderRadius: "8px",
                        fontSize: "13px",
                        color: "#92400e"
                      }}>
                        <strong>Notes:</strong> {booking.notes}
                      </div>
                    )}

                    {/* Actions */}
                    <div style={{
                      display: "flex",
                      gap: "12px",
                      paddingTop: "16px",
                      borderTop: "1px solid #e2e8f0",
                      flexWrap: "wrap"
                    }}>
                      <select
                        value={booking.status || "pending"}
                        onChange={(e) => handleStatusChange(booking.id, e.target.value)}
                        className="select"
                        style={{ width: "150px" }}
                      >
                        <option value="pending">Pending</option>
                        <option value="paid">Paid</option>
                        <option value="photo_uploaded">Photo Uploaded</option>
                        <option value="setup">Setup</option>
                        <option value="checked_in">Checked In</option>
                        <option value="leaving">Leaving</option>
                        <option value="picked_up">Picked Up</option>
                        <option value="closed">Closed</option>
                        <option value="cancelled">Cancelled</option>
                      </select>

                      <a
                        href={`/thankyou?b=${encodeURIComponent(booking.id)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn-outline"
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                          color: "#003f5c",
                          borderColor: "#003f5c",
                          textDecoration: "none"
                        }}
                      >
                        <ExternalLink size={16} />
                        View Receipt
                      </a>

                      {booking.status === "closed" && (
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleArchiveToggle(booking.id, booking.archived);
                          }}
                          style={{
                            padding: "8px 16px",
                            background: booking.archived ? "#10b981" : "#8b5cf6",
                            color: "white",
                            border: "none",
                            borderRadius: "6px",
                            cursor: "pointer",
                            fontSize: "14px",
                            fontWeight: "500",
                            transition: "background-color 0.2s ease-in-out",
                            whiteSpace: "nowrap",
                            display: "flex",
                            alignItems: "center",
                            gap: "8px"
                          }}
                        >
                          {booking.archived ? (
                            <>
                              <ArchiveRestore size={16} />
                              Unarchive
                            </>
                          ) : (
                            <>
                              <Archive size={16} />
                              Archive
                            </>
                          )}
                        </button>
                      )}

                      {booking.status === "cancelled" && (
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteBooking(booking);
                          }}
                          style={{
                            padding: "8px 16px",
                            background: "#dc2626",
                            color: "white",
                            border: "1px solid #dc2626",
                            borderRadius: "6px",
                            cursor: "pointer",
                            fontSize: "14px",
                            fontWeight: "500",
                            transition: "background-color 0.2s ease-in-out, border-color 0.2s ease-in-out",
                            whiteSpace: "nowrap",
                            display: "flex",
                            alignItems: "center",
                            gap: "8px"
                          }}
                        >
                          <Trash2 size={16} />
                          Delete Permanently
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
