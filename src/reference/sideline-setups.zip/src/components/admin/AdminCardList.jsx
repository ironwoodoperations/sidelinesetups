import React from "react";

/**
 * Generic card list for admin entities.
 * Props:
 *  - title: string
 *  - items: array of rows
 *  - keyField: primary key, e.g. "id"
 *  - getHeader: (row) => { title, subtitle?, badgeText?, badgeClass? }
 *  - getLines: (row) => array of {label, value}
 *  - onEdit: (row) => void
 *  - onDelete: (id) => void
 *  - emptyText?: string
 *  - cols?: 2|3 (default 2)
 */
export default function AdminCardList({
  title,
  items,
  keyField = "id",
  getHeader,
  getLines,
  onEdit,
  onDelete,
  emptyText = "No items yet.",
  cols = 2
}) {
  const gridClass = cols === 3 ? "grid grid-3" : "grid grid-2";

  return (
    <div>
      {title && (
        <div className="section-head">
          <h2>{title}</h2>
        </div>
      )}

      {(!items || items.length === 0) ? (
        <div className="card card-pad" style={{ textAlign: "center", color: "var(--muted)" }}>
          <p>{emptyText}</p>
        </div>
      ) : (
        <div className={gridClass}>
          {items.map((row) => {
            const k = row[keyField];
            const header = getHeader?.(row) || {};
            const lines = getLines?.(row) || [];
            return (
              <div key={k} className="card card-pad">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start" }}>
                  <div>
                    <h3 style={{ margin: "0 0 8px 0" }}>{header.title}</h3>
                    {header.subtitle && (
                      <p style={{ color: "var(--muted)", fontSize: 14, margin: "0 0 12px 0" }}>
                        {header.subtitle}
                      </p>
                    )}
                  </div>
                  {header.badgeText && (
                    <span className={`badge ${header.badgeClass || ""}`}>{header.badgeText}</span>
                  )}
                </div>

                <div style={{ marginTop: 12, fontSize: 14 }}>
                  {lines.map((ln, i) => (
                    <div key={i} style={{ marginBottom: 4 }}>
                      <b>{ln.label}:</b> {ln.value}
                    </div>
                  ))}
                </div>

                <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
                  {onEdit && <button className="btn-outline" onClick={() => onEdit(row)}>Edit</button>}
                  {onDelete && <button className="btn-ghost" onClick={() => onDelete(row[keyField])}>Delete</button>}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}