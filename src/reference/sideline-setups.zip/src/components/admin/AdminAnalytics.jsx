import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { BarChart3, Users, Eye, TrendingUp, Globe, Smartphone, Calendar } from "lucide-react";

export default function AdminAnalytics() {
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState('7days');
  const [stats, setStats] = useState({
    totalVisits: 0,
    uniqueVisitors: 0,
    topPages: [],
    deviceBreakdown: { mobile: 0, tablet: 0, desktop: 0 },
    browserBreakdown: {},
    visitsOverTime: []
  });

  useEffect(() => {
    loadAnalytics();
  }, [dateRange]);

  async function loadAnalytics() {
    setLoading(true);
    try {
      // Calculate date range
      const now = new Date();
      const daysAgo = dateRange === '7days' ? 7 : dateRange === '30days' ? 30 : 90;
      const startDate = new Date(now.getTime() - (daysAgo * 24 * 60 * 60 * 1000));
      
      // Fetch all non-internal visits in range
      const allVisits = await base44.entities.PageVisit.list('-created_date');
      const visits = allVisits.filter(v => {
        if (v.isInternal) return false;
        const visitDate = new Date(v.created_date);
        return visitDate >= startDate;
      });

      // Calculate stats
      const totalVisits = visits.length;
      const uniqueVisitors = new Set(visits.map(v => v.visitorId).filter(Boolean)).size;

      // Top pages
      const pageCounts = {};
      visits.forEach(v => {
        pageCounts[v.path] = (pageCounts[v.path] || 0) + 1;
      });
      const topPages = Object.entries(pageCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([path, count]) => ({ path, count }));

      // Device breakdown
      const deviceBreakdown = { mobile: 0, tablet: 0, desktop: 0 };
      visits.forEach(v => {
        if (v.device) deviceBreakdown[v.device]++;
      });

      // Browser breakdown
      const browserBreakdown = {};
      visits.forEach(v => {
        if (v.browser) {
          browserBreakdown[v.browser] = (browserBreakdown[v.browser] || 0) + 1;
        }
      });

      // Visits over time (daily)
      const dailyCounts = {};
      visits.forEach(v => {
        const date = new Date(v.created_date).toISOString().split('T')[0];
        dailyCounts[date] = (dailyCounts[date] || 0) + 1;
      });
      const visitsOverTime = Object.entries(dailyCounts)
        .sort((a, b) => a[0].localeCompare(b[0]))
        .map(([date, count]) => ({ date, count }));

      setStats({
        totalVisits,
        uniqueVisitors,
        topPages,
        deviceBreakdown,
        browserBreakdown,
        visitsOverTime
      });
    } catch (error) {
      console.error('Failed to load analytics:', error);
    } finally {
      setLoading(false);
    }
  }

  const StatCard = ({ icon: Icon, label, value, color = "#003f5c" }) => (
    <div style={{
      background: "white",
      borderRadius: "12px",
      padding: "20px",
      boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
      border: "1px solid #e2e8f0"
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "12px" }}>
        <div style={{
          width: "40px",
          height: "40px",
          borderRadius: "8px",
          background: `${color}15`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center"
        }}>
          <Icon size={20} style={{ color }} />
        </div>
        <div style={{ fontSize: "14px", color: "#64748b", fontWeight: "600" }}>
          {label}
        </div>
      </div>
      <div style={{ fontSize: "32px", fontWeight: "800", color: "#0f172a" }}>
        {value?.toLocaleString() || 0}
      </div>
    </div>
  );

  return (
    <div style={{ padding: "24px" }}>
      <div style={{ marginBottom: "24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h1 style={{ margin: "0 0 8px 0", fontSize: "28px", fontWeight: "700", color: "#003f5c" }}>
            Website Analytics
          </h1>
          <p style={{ margin: 0, color: "#64748b", fontSize: "14px" }}>
            Traffic insights (excluding internal visits)
          </p>
        </div>
        
        <select 
          value={dateRange} 
          onChange={(e) => setDateRange(e.target.value)}
          style={{
            padding: "8px 16px",
            border: "1px solid #e2e8f0",
            borderRadius: "8px",
            fontSize: "14px",
            fontWeight: "600"
          }}
        >
          <option value="7days">Last 7 Days</option>
          <option value="30days">Last 30 Days</option>
          <option value="90days">Last 90 Days</option>
        </select>
      </div>

      {loading ? (
        <div style={{ textAlign: "center", padding: "60px" }}>
          <div className="spinner"></div>
          <p style={{ marginTop: "16px", color: "#64748b" }}>Loading analytics...</p>
        </div>
      ) : (
        <>
          {/* Top Stats */}
          <div style={{ 
            display: "grid", 
            gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", 
            gap: "20px",
            marginBottom: "32px"
          }}>
            <StatCard 
              icon={Eye} 
              label="Total Page Views" 
              value={stats.totalVisits} 
              color="#3b82f6"
            />
            <StatCard 
              icon={Users} 
              label="Unique Visitors" 
              value={stats.uniqueVisitors} 
              color="#10b981"
            />
            <StatCard 
              icon={TrendingUp} 
              label="Avg. Daily Views" 
              value={Math.round(stats.totalVisits / (dateRange === '7days' ? 7 : dateRange === '30days' ? 30 : 90))} 
              color="#f59e0b"
            />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "24px", marginBottom: "32px" }}>
            {/* Device Breakdown */}
            <div style={{
              background: "white",
              borderRadius: "12px",
              padding: "24px",
              boxShadow: "0 2px 8px rgba(0,0,0,0.1)"
            }}>
              <h3 style={{ margin: "0 0 20px 0", fontSize: "18px", fontWeight: "700", display: "flex", alignItems: "center", gap: "8px" }}>
                <Smartphone size={20} style={{ color: "#003f5c" }} />
                Device Breakdown
              </h3>
              <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                {Object.entries(stats.deviceBreakdown).map(([device, count]) => {
                  const total = stats.totalVisits;
                  const percentage = total > 0 ? Math.round((count / total) * 100) : 0;
                  return (
                    <div key={device}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
                        <span style={{ fontSize: "14px", fontWeight: "600", textTransform: "capitalize" }}>
                          {device}
                        </span>
                        <span style={{ fontSize: "14px", color: "#64748b" }}>
                          {count} ({percentage}%)
                        </span>
                      </div>
                      <div style={{
                        height: "8px",
                        background: "#f1f5f9",
                        borderRadius: "4px",
                        overflow: "hidden"
                      }}>
                        <div style={{
                          height: "100%",
                          background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
                          width: `${percentage}%`,
                          transition: "width 0.3s"
                        }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Browser Breakdown */}
            <div style={{
              background: "white",
              borderRadius: "12px",
              padding: "24px",
              boxShadow: "0 2px 8px rgba(0,0,0,0.1)"
            }}>
              <h3 style={{ margin: "0 0 20px 0", fontSize: "18px", fontWeight: "700", display: "flex", alignItems: "center", gap: "8px" }}>
                <Globe size={20} style={{ color: "#003f5c" }} />
                Browser Breakdown
              </h3>
              <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                {Object.entries(stats.browserBreakdown)
                  .sort((a, b) => b[1] - a[1])
                  .slice(0, 5)
                  .map(([browser, count]) => {
                    const total = stats.totalVisits;
                    const percentage = total > 0 ? Math.round((count / total) * 100) : 0;
                    return (
                      <div key={browser}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
                          <span style={{ fontSize: "14px", fontWeight: "600" }}>
                            {browser}
                          </span>
                          <span style={{ fontSize: "14px", color: "#64748b" }}>
                            {count} ({percentage}%)
                          </span>
                        </div>
                        <div style={{
                          height: "8px",
                          background: "#f1f5f9",
                          borderRadius: "4px",
                          overflow: "hidden"
                        }}>
                          <div style={{
                            height: "100%",
                            background: "linear-gradient(135deg, #10b981 0%, #059669 100%)",
                            width: `${percentage}%`,
                            transition: "width 0.3s"
                          }} />
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          </div>

          {/* Top Pages */}
          <div style={{
            background: "white",
            borderRadius: "12px",
            padding: "24px",
            boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
            marginBottom: "32px"
          }}>
            <h3 style={{ margin: "0 0 20px 0", fontSize: "18px", fontWeight: "700", display: "flex", alignItems: "center", gap: "8px" }}>
              <BarChart3 size={20} style={{ color: "#003f5c" }} />
              Top Pages
            </h3>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ borderBottom: "2px solid #e2e8f0" }}>
                  <th style={{ textAlign: "left", padding: "10px", fontSize: "12px", color: "#64748b", fontWeight: "600" }}>
                    Page
                  </th>
                  <th style={{ textAlign: "right", padding: "10px", fontSize: "12px", color: "#64748b", fontWeight: "600" }}>
                    Views
                  </th>
                </tr>
              </thead>
              <tbody>
                {stats.topPages.map((page, idx) => (
                  <tr key={idx} style={{ borderBottom: "1px solid #f1f5f9" }}>
                    <td style={{ padding: "12px", fontSize: "14px", fontWeight: "600" }}>
                      {page.path}
                    </td>
                    <td style={{ padding: "12px", fontSize: "14px", textAlign: "right", color: "#64748b" }}>
                      {page.count.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Visits Over Time Chart */}
          {stats.visitsOverTime.length > 0 && (
            <div style={{
              background: "white",
              borderRadius: "12px",
              padding: "24px",
              boxShadow: "0 2px 8px rgba(0,0,0,0.1)"
            }}>
              <h3 style={{ margin: "0 0 20px 0", fontSize: "18px", fontWeight: "700", display: "flex", alignItems: "center", gap: "8px" }}>
                <Calendar size={20} style={{ color: "#003f5c" }} />
                Daily Traffic
              </h3>
              <div style={{ height: "200px", display: "flex", alignItems: "flex-end", gap: "4px" }}>
                {stats.visitsOverTime.map((day, idx) => {
                  const maxCount = Math.max(...stats.visitsOverTime.map(d => d.count));
                  const heightPercent = (day.count / maxCount) * 100;
                  return (
                    <div 
                      key={idx} 
                      style={{ 
                        flex: 1, 
                        background: "linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)",
                        height: `${heightPercent}%`,
                        borderRadius: "4px 4px 0 0",
                        minHeight: "4px",
                        position: "relative",
                        cursor: "pointer"
                      }}
                      title={`${day.date}: ${day.count} visits`}
                    />
                  );
                })}
              </div>
              <div style={{ 
                marginTop: "12px", 
                display: "flex", 
                justifyContent: "space-between",
                fontSize: "11px",
                color: "#94a3b8"
              }}>
                <span>{stats.visitsOverTime[0]?.date}</span>
                <span>{stats.visitsOverTime[stats.visitsOverTime.length - 1]?.date}</span>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}