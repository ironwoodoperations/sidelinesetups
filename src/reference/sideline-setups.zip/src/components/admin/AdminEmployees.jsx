import React, { useState, useEffect } from "react";
import buildEntities from "../lib/entities";
import { Plus, Edit2, Trash2, X } from "lucide-react";

export default function AdminEmployees() {
  const entities = buildEntities();
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    role: "attendant",
    status: "active",
    pin: "",
    meta: {}
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const data = await entities.Employees.list();
      setEmployees(data || []);
    } catch (error) {
      console.error("Failed to load employees:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editing) {
        await entities.Employees.update(editing.id, form);
      } else {
        await entities.Employees.create(form);
      }
      await loadData();
      resetForm();
    } catch (error) {
      console.error("Failed to save employee:", error);
      alert("Failed to save employee: " + error.message);
    }
  };

  const handleEdit = (emp) => {
    setEditing(emp);
    setForm({
      fullName: emp.fullName || "",
      email: emp.email || "",
      phone: emp.phone || "",
      role: emp.role || "attendant",
      status: emp.status || "active",
      pin: emp.pin || "",
      meta: emp.meta || {}
    });
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this employee?")) return;
    try {
      await entities.Employees.delete(id);
      await loadData();
    } catch (error) {
      console.error("Failed to delete employee:", error);
      alert("Failed to delete employee: " + error.message);
    }
  };

  const resetForm = () => {
    setForm({
      fullName: "",
      email: "",
      phone: "",
      role: "attendant",
      status: "active",
      pin: "",
      meta: {}
    });
    setEditing(null);
    setShowForm(false);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold" style={{ color: '#003f5c' }}>Employees</h2>
        <button
          onClick={() => setShowForm(true)}
          className="btn"
          style={{
            background: 'linear-gradient(to right, #003f5c, #00507a)',
            color: 'white',
            border: 'none'
          }}
        >
          <Plus size={20} className="inline mr-2" />
          New Employee
        </button>
      </div>

      {loading && <div className="spinner"></div>}

      {!loading && (
        <div className="grid gap-4">
          {employees.map(emp => (
            <div key={emp.id} className="card card-pad">
              <div className="flex justify-between items-start">
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                    <h3 style={{ margin: 0, fontSize: "1.125rem" }}>{emp.fullName}</h3>
                    <span className="badge">{emp.role}</span>
                    {emp.status === "inactive" && (
                      <span className="badge" style={{ background: "#fee2e2", color: "#991b1b" }}>
                        Inactive
                      </span>
                    )}
                  </div>
                  <div style={{ fontSize: 14, color: "var(--muted)" }}>
                    <div>📧 {emp.email}</div>
                    {emp.phone && <div>📱 {emp.phone}</div>}
                    {emp.pin && <div>🔐 PIN: {emp.pin}</div>}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => handleEdit(emp)} className="btn-outline">
                    <Edit2 size={16} />
                  </button>
                  <button 
                    onClick={() => handleDelete(emp.id)} 
                    className="btn-outline" 
                    style={{ color: "var(--danger)" }}
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Form Modal */}
      {showForm && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          padding: '20px'
        }}>
          <div style={{
            background: 'white',
            borderRadius: '12px',
            maxWidth: '600px',
            width: '100%',
            maxHeight: '90vh',
            overflow: 'auto',
            padding: '24px'
          }}>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold" style={{ color: '#003f5c' }}>
                {editing ? 'Edit Employee' : 'New Employee'}
              </h3>
              <button onClick={resetForm} className="text-gray-500 hover:text-gray-700">
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="label">Full Name *</label>
                <input
                  className="input"
                  value={form.fullName}
                  onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label">Email *</label>
                  <input
                    className="input"
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="label">Phone</label>
                  <input
                    className="input"
                    type="tel"
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label">Role *</label>
                  <select
                    className="select"
                    value={form.role}
                    onChange={(e) => setForm({ ...form, role: e.target.value })}
                    required
                  >
                    <option value="attendant">Attendant</option>
                    <option value="asset_mgr">Asset Manager</option>
                    <option value="manager">Manager</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>

                <div>
                  <label className="label">Status *</label>
                  <select
                    className="select"
                    value={form.status}
                    onChange={(e) => setForm({ ...form, status: e.target.value })}
                    required
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="label">PIN (4-6 digits for kiosk)</label>
                <input
                  className="input"
                  type="text"
                  maxLength="6"
                  value={form.pin}
                  onChange={(e) => setForm({ ...form, pin: e.target.value.replace(/\D/g, '') })}
                  placeholder="Optional"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button type="button" onClick={resetForm} className="btn-outline">
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn"
                  style={{
                    background: 'linear-gradient(to right, #003f5c, #00507a)',
                    color: 'white',
                    border: 'none'
                  }}
                >
                  {editing ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}