
import React, { useState, useEffect } from "react";
import buildEntities from "../lib/entities";
import { Plus, Edit2, Trash2, X, RefreshCw, Archive, ArchiveRestore, Upload } from "lucide-react";
import { base44 } from "../../api/base44Client";
import ImageUrlPicker from "./ImageUrlPicker";

// Safe date formatter helper - FIX: Parse manually to avoid timezone shifts
function formatDate(dateStr) {
  if (!dateStr) return "";
  try {
    // Parse YYYY-MM-DD manually to avoid timezone issues.
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10);
    const day = parseInt(parts[2], 10);

    if (isNaN(year) || isNaN(month) || isNaN(day)) return dateStr;
    
    const d = new Date(year, month - 1, day);
    
    if (d.getFullYear() !== year || d.getMonth() !== month - 1 || d.getDate() !== day) {
      return dateStr;
    }

    return d.toLocaleDateString();
  } catch (e) {
    return dateStr;
  }
}

export default function AdminEvents() {
  const entities = buildEntities();
  const [events, setEvents] = useState([]);
  const [parks, setParks] = useState([]);
  const [fields, setFields] = useState([]);
  const [packages, setPackages] = useState([]);
  const [spotTemplates, setSpotTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);
  const [generatingInventory, setGeneratingInventory] = useState(false);
  const [showArchived, setShowArchived] = useState(false);
  const [archiving, setArchiving] = useState(false);
  
  // New states for inline creation
  const [showNewParkForm, setShowNewParkForm] = useState(false);
  const [showNewFieldForm, setShowNewFieldForm] = useState(false);
  const [showBulkFieldForm, setShowBulkFieldForm] = useState(false);
  const [newParkForm, setNewParkForm] = useState({ name: "", parkType: "tournament", city: "", state: "" });
  const [newFieldForm, setNewFieldForm] = useState({ name: "", imageUrl: "", templateId: "" });
  const [bulkFieldForm, setBulkFieldForm] = useState({ baseName: "Field", count: 5, imageUrl: "", templateId: "" });
  const [creatingPark, setCreatingPark] = useState(false);
  const [creatingField, setCreatingField] = useState(false);
  const [creatingBulkFields, setCreatingBulkFields] = useState(false);
  
  // New states for image upload
  const [uploadingImage, setUploadingImage] = useState(false);
  const [showImageUpload, setShowImageUpload] = useState(false);
  
  // New states for bulk import
  const [showBulkImport, setShowBulkImport] = useState(false);
  const [bulkImportFile, setBulkImportFile] = useState(null);
  const [importingEvents, setImportingEvents] = useState(false);
  const [importPreview, setImportPreview] = useState([]);
  
  const [form, setForm] = useState({
    name: "",
    eventType: "tournament",
    sport: "softball",
    city: "",
    startDate: "",
    endDate: "",
    description: "",
    website: "",
    imageUrl: "",
    parkIds: [],
    fieldIds: [],
    packageIds: [],
    leagueEnabled: false,
    leagueDates: "",
    leagueStartTime: "09:00",
    leagueEndTime: "17:00",
    leagueBufferMinutes: 90,
    leagueDefaultSpotsPerSlot: 2,
    isActive: true
  });

  useEffect(() => {
    loadData();
  }, []);

  const autoArchiveOldEvents = async () => {
    try {
      const allEvents = await entities.Events.list();
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const oneDayAgo = new Date(today);
      oneDayAgo.setDate(oneDayAgo.getDate() - 1);
      
      for (const event of allEvents) {
        if (event.archived) continue;
        if (!event.endDate) continue;
        
        const endDate = new Date(event.endDate);
        endDate.setHours(0, 0, 0, 0);
        
        if (endDate < oneDayAgo) {
          await entities.Events.update(event.id, { archived: true });
          console.log(`Auto-archived event: ${event.name}`);
        }
      }
    } catch (error) {
      console.error("Failed to auto-archive events:", error);
    }
  };

  const loadData = async () => {
    try {
      setLoading(true);
      
      await autoArchiveOldEvents();
      
      const [eventsData, parksData, fieldsData, packagesData, templatesData] = await Promise.all([
        entities.Events.list(),
        entities.Parks.list(),
        entities.Fields.list(),
        entities.Packages.list(),
        entities.SpotTemplate.list()
      ]);
      
      // Sort events by start date (earliest first), with events without dates at the end
      const sortedEvents = (eventsData || []).sort((a, b) => {
        if (!a.startDate && !b.startDate) return 0;
        if (!a.startDate) return 1;
        if (!b.startDate) return -1;
        return new Date(a.startDate) - new Date(b.startDate);
      });
      
      setEvents(sortedEvents);
      setParks(parksData || []);
      setFields(fieldsData || []);
      setPackages(packagesData || []);
      setSpotTemplates(templatesData || []);
    } catch (error) {
      console.error("Failed to load data:", error);
    } finally {
      setLoading(false);
    }
  };

  const filteredFieldsForEvent = React.useMemo(() => {
    if (!form.parkIds || form.parkIds.length === 0) {
      return [];
    }
    return fields.filter(field => form.parkIds.includes(field.parkId));
  }, [fields, form.parkIds]);

  const handleArchiveAllPast = async () => {
    if (!confirm("Archive all events that ended more than 1 day ago?")) return;
    
    setArchiving(true);
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const oneDayAgo = new Date(today);
      oneDayAgo.setDate(oneDayAgo.getDate() - 1);
      
      let count = 0;
      const eventsToConsider = events.filter(event => !event.archived && event.endDate);

      for (const event of eventsToConsider) {
        const endDate = new Date(event.endDate);
        endDate.setHours(0, 0, 0, 0);
        
        if (endDate < oneDayAgo) {
          await entities.Events.update(event.id, { archived: true });
          count++;
        }
      }
      
      alert(`Archived ${count} past event(s).`);
      await loadData();
    } catch (error) {
      console.error("Failed to archive events:", error);
      alert("Failed to archive events: " + error.message);
    } finally {
      setArchiving(false);
    }
  };

  const handleUnarchive = async (eventId) => {
    if (!confirm("Unarchive this event? It will become active again.")) return;
    
    try {
      await entities.Events.update(eventId, { archived: false });
      await loadData();
    } catch (error) {
      console.error("Failed to unarchive event:", error);
      alert("Failed to unarchive event: " + error.message);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if ((form.parkIds || []).length === 0) {
      alert("Please select at least one park for the event.");
      return;
    }

    try {
      const leagueDatesArray = form.leagueDates
        ? form.leagueDates.split(",").map(d => d.trim()).filter(Boolean)
        : [];
      
      const invalidDates = [];
      const validDates = [];
      
      for (const dateStr of leagueDatesArray) {
        try {
          if (!dateStr.match(/^\d{4}-\d{2}-\d{2}$/)) {
            invalidDates.push(dateStr);
            continue;
          }
          const parts = dateStr.split('-').map(Number);
          const year = parts[0];
          const month = parts[1];
          const day = parts[2];

          const d = new Date(year, month - 1, day);
          
          if (isNaN(d.getTime()) || d.getFullYear() !== year || d.getMonth() !== month - 1 || d.getDate() !== day) {
            invalidDates.push(dateStr);
          } else {
            validDates.push(dateStr);
          }
        } catch (e) {
          invalidDates.push(dateStr);
        }
      }
      
      if (invalidDates.length > 0) {
        alert(`Invalid dates found (please use YYYY-MM-DD format, e.g., 2025-10-25):\n\n${invalidDates.join(', ')}\n\nPlease correct these dates and try again.`);
        return;
      }
      
      const eventData = {
        ...form,
        leagueDates: validDates,
        leagueEnabled: form.eventType === "league" ? true : form.leagueEnabled
      };

      if (editingEvent) {
        await entities.Events.update(editingEvent.id, eventData);
      } else {
        await entities.Events.create(eventData);
      }
      await loadData();
      resetForm();
    } catch (error) {
      console.error("Failed to save event:", error);
      alert("Failed to save event: " + error.message);
    }
  };

  const handleEdit = (event) => {
    if (event.archived) {
      alert("Archived events cannot be edited directly. Please unarchive the event first if you need to make changes.");
      return;
    }

    setEditingEvent(event);
    setForm({
      name: event.name || "",
      eventType: event.eventType || "tournament",
      sport: event.sport || "softball",
      city: event.city || "",
      startDate: event.startDate || "",
      endDate: event.endDate || "",
      description: event.description || "",
      website: event.website || "",
      imageUrl: event.imageUrl || "",
      parkIds: event.parkIds || [],
      fieldIds: event.fieldIds || [],
      packageIds: event.packageIds || [],
      leagueEnabled: event.leagueEnabled || false,
      leagueDates: Array.isArray(event.leagueDates) ? event.leagueDates.join(", ") : "",
      leagueStartTime: event.leagueStartTime || "09:00",
      leagueEndTime: event.leagueEndTime || "17:00",
      leagueBufferMinutes: event.leagueBufferMinutes || 90,
      leagueDefaultSpotsPerSlot: event.leagueDefaultSpotsPerSlot || 2,
      isActive: event.isActive !== false
    });
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this event? This action cannot be undone.")) return;
    try {
      await entities.Events.delete(id);
      await loadData();
    } catch (error) {
      console.error("Failed to delete event:", error);
      alert("Failed to delete event: " + error.message);
    }
  };

  const resetForm = () => {
    setForm({
      name: "",
      eventType: "tournament",
      sport: "softball",
      city: "",
      startDate: "",
      endDate: "",
      description: "",
      website: "",
      imageUrl: "",
      parkIds: [],
      fieldIds: [],
      packageIds: [],
      leagueEnabled: false,
      leagueDates: "",
      leagueStartTime: "09:00",
      leagueEndTime: "17:00",
      leagueBufferMinutes: 90,
      leagueDefaultSpotsPerSlot: 2,
      isActive: true
    });
    setEditingEvent(null);
    setShowForm(false);
    setShowNewParkForm(false);
    setShowNewFieldForm(false);
    setShowBulkFieldForm(false);
    setNewFieldForm({ name: "", imageUrl: "", templateId: "" });
    setBulkFieldForm({ baseName: "Field", count: 5, imageUrl: "", templateId: "" });
    setShowImageUpload(false);
  };

  const toggleField = (fieldId) => {
    const currentFieldIds = form.fieldIds || [];
    if (currentFieldIds.includes(fieldId)) {
      setForm({ ...form, fieldIds: currentFieldIds.filter(id => id !== fieldId) });
    } else {
      setForm({ ...form, fieldIds: [...currentFieldIds, fieldId] });
    }
  };

  const togglePackage = (packageId) => {
    const currentPackageIds = form.packageIds || [];
    if (currentPackageIds.includes(packageId)) {
      setForm({ ...form, packageIds: currentPackageIds.filter(id => id !== packageId) });
    } else {
      setForm({ ...form, packageIds: [...currentPackageIds, packageId] });
    }
  };

  const handleGenerateInventory = async (eventId) => {
    if (!confirm("Generate/refresh league inventory for all dates × times × fields? This will create or update inventory records.")) {
      return;
    }
    
    setGeneratingInventory(true);
    try {
      const result = await base44.functions.invoke('leagueGenerateInventory', { eventId });
      alert(`Success! Generated/refreshed ${result.data.upserts} inventory slots.`);
    } catch (error) {
      console.error("Failed to generate inventory:", error);
      const errorMessage = error.response?.data?.error || error.message || 'Unknown error';
      alert("Failed to generate inventory:\n\n" + errorMessage);
    } finally {
      setGeneratingInventory(false);
    }
  };

  // NEW: Inline park creation
  const handleCreatePark = async () => {
    if (!newParkForm.name.trim()) {
      alert("Park name is required");
      return;
    }
    
    setCreatingPark(true);
    try {
      const newPark = await entities.Parks.create(newParkForm);
      setParks([...parks, newPark]);
      setForm({ ...form, parkIds: [...(form.parkIds || []), newPark.id] });
      setNewParkForm({ name: "", parkType: "tournament", city: "", state: "" });
      setShowNewParkForm(false);
      alert(`✅ Park "${newPark.name}" created and added to event!`);
    } catch (error) {
      console.error("Failed to create park:", error);
      alert("Failed to create park: " + error.message);
    } finally {
      setCreatingPark(false);
    }
  };

  // NEW: Inline field creation with optional template
  const handleCreateField = async () => {
    if (!newFieldForm.name.trim()) {
      alert("Field name is required");
      return;
    }
    
    if ((form.parkIds || []).length === 0) {
      alert("Please select a park first");
      return;
    }
    
    setCreatingField(true);
    try {
      const newField = await entities.Fields.create({
        name: newFieldForm.name,
        imageUrl: newFieldForm.imageUrl,
        parkId: form.parkIds[0] 
      });
      
      // If a template was selected, apply it to the new field
      if (newFieldForm.templateId) {
        try {
          await base44.functions.invoke('applySpotTemplate', {
            templateId: newFieldForm.templateId,
            fieldId: newField.id
          });
        } catch (templateError) {
          console.error("Failed to apply template:", templateError);
          alert(`Field "${newField.name}" created, but failed to apply template: ${templateError.message}`);
        }
      }
      
      setFields([...fields, newField]);
      setForm({ ...form, fieldIds: [...(form.fieldIds || []), newField.id] });
      setNewFieldForm({ name: "", imageUrl: "", templateId: "" });
      setShowNewFieldForm(false);
      
      if (newFieldForm.templateId) {
        alert(`✅ Field "${newField.name}" created with spots from template!`);
      } else {
        alert(`✅ Field "${newField.name}" created and added to event!`);
      }
    } catch (error) {
      console.error("Failed to create field:", error);
      alert("Failed to create field: " + error.message);
    } finally {
      setCreatingField(false);
    }
  };

  // NEW: Bulk field creation
  const handleCreateBulkFields = async () => {
    if (!bulkFieldForm.baseName.trim()) {
      alert("Base name is required");
      return;
    }
    
    if (bulkFieldForm.count < 1 || bulkFieldForm.count > 50) {
      alert("Count must be between 1 and 50");
      return;
    }
    
    if ((form.parkIds || []).length === 0) {
      alert("Please select a park first");
      return;
    }
    
    setCreatingBulkFields(true);
    try {
      const response = await base44.functions.invoke('bulkCreateFieldsWithTemplate', {
        templateId: bulkFieldForm.templateId || null,
        parkId: form.parkIds[0],
        count: bulkFieldForm.count,
        baseName: bulkFieldForm.baseName,
        imageUrl: bulkFieldForm.imageUrl
      });
      
      // Reload fields
      const fieldsData = await entities.Fields.list();
      setFields(fieldsData || []);
      
      // Add newly created fields to event
      const newFieldIds = response.data.fields.map(f => f.field.id);
      setForm({ ...form, fieldIds: [...(form.fieldIds || []), ...newFieldIds] });
      
      setBulkFieldForm({ baseName: "Field", count: 5, imageUrl: "", templateId: "" });
      setShowBulkFieldForm(false);
      
      alert(`✅ ${response.data.message}`);
    } catch (error) {
      console.error("Failed to create bulk fields:", error);
      alert("Failed to create fields: " + error.message);
    } finally {
      setCreatingBulkFields(false);
    }
  };

  // NEW: Inline image upload
  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setUploadingImage(true);
    try {
      const result = await base44.integrations.Core.UploadFile({ file });
      const url = result?.file_url || result?.url;
      
      if (url) {
        setForm({ ...form, imageUrl: url });
        setShowImageUpload(false);
        alert("✅ Image uploaded successfully!");
      }
    } catch (error) {
      console.error("Failed to upload image:", error);
      alert("Failed to upload image: " + error.message);
    } finally {
      setUploadingImage(false);
    }
  };

  // NEW: Bulk import functionality
  const handleBulkImportFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (!file.name.endsWith('.csv')) {
      alert("Please upload a CSV file");
      return;
    }
    
    setBulkImportFile(file);
    
    // Read and preview the CSV
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target.result;
        const rows = text.split('\n').filter(row => row.trim());
        
        if (rows.length < 2) {
          alert("CSV file must contain a header row and at least one data row");
          return;
        }
        
        const headers = rows[0].split(',').map(h => h.trim().toLowerCase());
        const preview = rows.slice(1, 6).map((row, idx) => {
          const values = row.split(',').map(v => v.trim());
          const obj = {};
          headers.forEach((header, i) => {
            obj[header] = values[i] || "";
          });
          return { rowNum: idx + 2, ...obj };
        });
        
        setImportPreview(preview);
      } catch (error) {
        console.error("Failed to parse CSV:", error);
        alert("Failed to parse CSV file: " + error.message);
      }
    };
    reader.readAsText(file);
  };

  const handleBulkImport = async () => {
    if (!bulkImportFile) {
      alert("Please select a CSV file first");
      return;
    }
    
    setImportingEvents(true);
    try {
      const reader = new FileReader();
      reader.onload = async (event) => {
        try {
          const text = event.target.result;
          const rows = text.split('\n').filter(row => row.trim());
          
          if (rows.length < 2) {
            alert("CSV file must contain a header row and at least one data row");
            setImportingEvents(false);
            return;
          }
          
          const headers = rows[0].split(',').map(h => h.trim().toLowerCase());
          
          // Validate required columns
          const requiredColumns = ['name', 'eventtype', 'sport'];
          const missingColumns = requiredColumns.filter(col => !headers.includes(col));
          
          if (missingColumns.length > 0) {
            alert(`Missing required columns: ${missingColumns.join(', ')}\n\nRequired columns: name, eventType, sport\nOptional columns: city, startDate, endDate, description, website, imageUrl, isActive`);
            setImportingEvents(false);
            return;
          }
          
          const dataRows = rows.slice(1);
          const eventsToCreate = [];
          const errors = [];
          
          for (let i = 0; i < dataRows.length; i++) {
            const row = dataRows[i];
            const values = row.split(',').map(v => v.trim());
            const rowNum = i + 2;
            
            const eventData = {};
            headers.forEach((header, idx) => {
              eventData[header] = values[idx] || "";
            });
            
            // Validate event data
            if (!eventData.name) {
              errors.push(`Row ${rowNum}: Name is required`);
              continue;
            }
            
            if (!['tournament', 'league'].includes(eventData.eventtype?.toLowerCase())) {
              errors.push(`Row ${rowNum}: eventType must be "tournament" or "league"`);
              continue;
            }
            
            if (!['softball', 'baseball', 'soccer'].includes(eventData.sport?.toLowerCase())) {
              errors.push(`Row ${rowNum}: sport must be "softball", "baseball", or "soccer"`);
              continue;
            }
            
            eventsToCreate.push({
              name: eventData.name,
              eventType: eventData.eventtype.toLowerCase(),
              sport: eventData.sport.toLowerCase(),
              city: eventData.city || "",
              startDate: eventData.startdate || "",
              endDate: eventData.enddate || "",
              description: eventData.description || "",
              website: eventData.website || "",
              imageUrl: eventData.imageurl || "",
              parkIds: [],
              fieldIds: [],
              packageIds: [],
              isActive: eventData.isactive?.toLowerCase() !== 'false'
            });
          }
          
          if (errors.length > 0) {
            alert(`Found ${errors.length} error(s):\n\n${errors.slice(0, 10).join('\n')}${errors.length > 10 ? '\n\n...and more' : ''}`);
            setImportingEvents(false);
            return;
          }
          
          if (eventsToCreate.length === 0) {
            alert("No valid events found in CSV file");
            setImportingEvents(false);
            return;
          }
          
          // Create events
          let created = 0;
          for (const eventData of eventsToCreate) {
            try {
              await entities.Events.create(eventData);
              created++;
            } catch (error) {
              console.error(`Failed to create event "${eventData.name}":`, error);
              errors.push(`Failed to create "${eventData.name}": ${error.message}`);
            }
          }
          
          await loadData();
          setShowBulkImport(false);
          setBulkImportFile(null);
          setImportPreview([]);
          
          if (errors.length > 0) {
            alert(`✅ Imported ${created} of ${eventsToCreate.length} events.\n\n${errors.length} error(s):\n${errors.slice(0, 5).join('\n')}${errors.length > 5 ? '\n...and more' : ''}`);
          } else {
            alert(`✅ Successfully imported ${created} events!`);
          }
          
        } catch (error) {
          console.error("Failed to import events:", error);
          alert("Failed to import events: " + error.message);
        } finally {
          setImportingEvents(false);
        }
      };
      reader.readAsText(bulkImportFile);
    } catch (error) {
      console.error("Failed to read file:", error);
      alert("Failed to read file: " + error.message);
      setImportingEvents(false);
    }
  };

  const displayedEvents = events.filter(e => showArchived ? e.archived : !e.archived);
  const archivedCount = events.filter(e => e.archived).length;
  const activeCount = events.filter(e => !e.archived).length;

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold" style={{ color: '#003f5c' }}>Events</h2>
          <p style={{ fontSize: '14px', color: '#64748b', marginTop: '4px' }}>
            {showArchived ? `Viewing ${archivedCount} archived events` : `Viewing ${activeCount} active events`}
          </p>
        </div>
        <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
          <button
            onClick={() => setShowBulkImport(true)}
            className="btn-outline"
            style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
          >
            <Upload size={16} />
            Bulk Import CSV
          </button>
          <button
            onClick={handleArchiveAllPast}
            disabled={archiving}
            className="btn-outline"
            style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
          >
            <Archive size={16} />
            {archiving ? 'Archiving...' : 'Archive Past Events'}
          </button>
          <button
            onClick={() => setShowArchived(!showArchived)}
            className="btn-outline"
            style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
          >
            {showArchived ? <ArchiveRestore size={16} /> : <Archive size={16} />}
            {showArchived ? 'View Active' : `View Archived (${archivedCount})`}
          </button>
          {!showArchived && (
            <button
              onClick={() => setShowForm(true)}
              className="btn"
              style={{
                background: 'linear-gradient(to right, #003f5c, #00507a)',
                color: 'white',
                border: 'none'
              }}
            >
              <Plus size={20} className="inline mr-2" />
              New Event
            </button>
          )}
        </div>
      </div>

      {/* Bulk Import Modal */}
      {showBulkImport && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          padding: '20px'
        }}>
          <div style={{
            background: 'white',
            borderRadius: '12px',
            maxWidth: '700px',
            width: '100%',
            maxHeight: '90vh',
            overflow: 'auto',
            padding: '24px'
          }}>
            <div className="flex justify-between items-center mb-6">
              <h3 style={{ margin: 0 }}>Bulk Import Events from CSV</h3>
              <button onClick={() => {
                setShowBulkImport(false);
                setBulkImportFile(null);
                setImportPreview([]);
              }} className="btn-outline" style={{ padding: '4px 8px' }}>
                <X size={20} />
              </button>
            </div>

            <div style={{ marginBottom: '20px', padding: '16px', background: '#f8fafc', borderRadius: '8px' }}>
              <h4 style={{ margin: '0 0 8px 0', fontSize: '14px', fontWeight: '600' }}>CSV Format Required:</h4>
              <p style={{ margin: '0 0 12px 0', fontSize: '13px', color: '#64748b' }}>
                Your CSV file must have these columns (case-insensitive):
              </p>
              <ul style={{ margin: 0, paddingLeft: '20px', fontSize: '13px', color: '#64748b' }}>
                <li><strong>name</strong> - Event name (required)</li>
                <li><strong>eventType</strong> - "tournament" or "league" (required)</li>
                <li><strong>sport</strong> - "softball", "baseball", or "soccer" (required)</li>
                <li><strong>city</strong> - City name (optional)</li>
                <li><strong>startDate</strong> - YYYY-MM-DD format (optional)</li>
                <li><strong>endDate</strong> - YYYY-MM-DD format (optional)</li>
                <li><strong>description</strong> - Event description (optional)</li>
                <li><strong>website</strong> - Event website URL (optional)</li>
                <li><strong>imageUrl</strong> - Image URL (optional)</li>
                <li><strong>isActive</strong> - "true" or "false" (optional, default: true)</li>
              </ul>
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label className="label">Select CSV File</label>
              <input
                type="file"
                accept=".csv"
                onChange={handleBulkImportFile}
                className="input"
                style={{ padding: '8px' }}
              />
            </div>

            {importPreview.length > 0 && (
              <div style={{ marginBottom: '20px' }}>
                <h4 style={{ margin: '0 0 8px 0', fontSize: '14px', fontWeight: '600' }}>Preview (first 5 rows):</h4>
                <div style={{ overflow: 'auto', maxHeight: '200px', border: '1px solid #e2e8f0', borderRadius: '8px' }}>
                  <table style={{ width: '100%', fontSize: '12px', borderCollapse: 'collapse' }}>
                    <thead style={{ background: '#f8fafc', position: 'sticky', top: 0 }}>
                      <tr>
                        <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #e2e8f0' }}>Row</th>
                        <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #e2e8f0' }}>Name</th>
                        <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #e2e8f0' }}>Type</th>
                        <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #e2e8f0' }}>Sport</th>
                      </tr>
                    </thead>
                    <tbody>
                      {importPreview.map((row) => (
                        <tr key={row.rowNum}>
                          <td style={{ padding: '8px', borderBottom: '1px solid #f1f5f9' }}>{row.rowNum}</td>
                          <td style={{ padding: '8px', borderBottom: '1px solid #f1f5f9' }}>{row.name}</td>
                          <td style={{ padding: '8px', borderBottom: '1px solid #f1f5f9' }}>{row.eventtype}</td>
                          <td style={{ padding: '8px', borderBottom: '1px solid #f1f5f9' }}>{row.sport}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => {
                  setShowBulkImport(false);
                  setBulkImportFile(null);
                  setImportPreview([]);
                }}
                className="btn-outline"
              >
                Cancel
              </button>
              <button
                onClick={handleBulkImport}
                disabled={!bulkImportFile || importingEvents}
                className="btn"
                style={{
                  background: 'linear-gradient(to right, #003f5c, #00507a)',
                  color: 'white',
                  border: 'none',
                  opacity: (!bulkImportFile || importingEvents) ? 0.5 : 1
                }}
              >
                {importingEvents ? 'Importing...' : 'Import Events'}
              </button>
            </div>
          </div>
        </div>
      )}

      {loading && <div className="spinner"></div>}
      {!loading && displayedEvents.length === 0 && (
        <div className="text-center text-gray-500 mt-8">
          {showArchived ? "No archived events found." : "No active events found. Create one!"}
        </div>
      )}
      {!loading && displayedEvents.length > 0 && (
        <div className="grid gap-4">
          {displayedEvents.map(event => (
            <div key={event.id} className="card card-pad">
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="text-lg font-bold" style={{ margin: 0 }}>{event.name}</h3>
                    <span className="badge">
                      {event.eventType === "tournament" ? "🏆 Tournament" : "🏅 League"}
                    </span>
                    <span className="badge">{event.sport}</span>
                    {event.archived && (
                      <span className="badge" style={{ background: '#8b5cf6', color: 'white' }}>
                        <Archive size={12} style={{ marginRight: '4px', display: 'inline' }} />
                        Archived
                      </span>
                    )}
                    {event.leagueEnabled && (
                      <span className="badge badge-success">League Mode</span>
                    )}
                  </div>
                  <div style={{ fontSize: 14, color: 'var(--muted)' }}>
                    {event.city && <div>📍 {event.city}</div>}
                    {event.startDate && (
                      <div>📅 {formatDate(event.startDate)} {event.endDate && `- ${formatDate(event.endDate)}`}</div>
                    )}
                    {event.leagueEnabled && event.leagueDates && (
                      <div>🗓️ {Array.isArray(event.leagueDates) ? event.leagueDates.length : 0} game dates configured</div>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  {event.archived ? (
                    <button
                      onClick={() => handleUnarchive(event.id)}
                      className="btn-outline"
                      style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
                      title="Unarchive this event to make it active again"
                    >
                      <ArchiveRestore size={16} />
                      Unarchive
                    </button>
                  ) : (
                    <>
                      {event.leagueEnabled && (
                        <button
                          onClick={() => handleGenerateInventory(event.id)}
                          className="btn-outline"
                          disabled={generatingInventory}
                          title="Generate/Refresh League Inventory"
                        >
                          <RefreshCw size={16} className={generatingInventory ? "animate-spin" : ""} />
                        </button>
                      )}
                      <button onClick={() => handleEdit(event)} className="btn-outline">
                        <Edit2 size={16} />
                      </button>
                      <button onClick={() => handleDelete(event.id)} className="btn-outline" style={{ color: 'var(--danger)' }}>
                        <Trash2 size={16} />
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Form Modal */}
      {showForm && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          padding: '20px'
        }}>
          <div style={{
            background: 'white',
            borderRadius: '12px',
            maxWidth: '800px',
            width: '100%',
            maxHeight: '90vh',
            overflow: 'auto',
            padding: '24px'
          }}>
            <div className="flex justify-between items-center mb-6">
              <h3 style={{ margin: 0 }}>{editingEvent ? "Edit Event" : "New Event"}</h3>
              <button onClick={resetForm} className="btn-outline" style={{ padding: '4px 8px' }}>
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="grid gap-4">
                {/* Basic Info */}
                <div>
                  <label className="label">Event Name *</label>
                  <input
                    className="input"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="label">Type *</label>
                    <select
                      className="select"
                      value={form.eventType}
                      onChange={(e) => setForm({ ...form, eventType: e.target.value })}
                      required
                    >
                      <option value="tournament">Tournament</option>
                      <option value="league">League</option>
                    </select>
                  </div>

                  <div>
                    <label className="label">Sport *</label>
                    <select
                      className="select"
                      value={form.sport}
                      onChange={(e) => setForm({ ...form, sport: e.target.value })}
                      required
                    >
                      <option value="softball">Softball</option>
                      <option value="baseball">Baseball</option>
                      <option value="soccer">Soccer</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="label">City</label>
                  <input
                    className="input"
                    value={form.city}
                    onChange={(e) => setForm({ ...form, city: e.target.value })}
                    placeholder="e.g. Dallas, Houston"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="label">Start Date</label>
                    <input
                      type="date"
                      className="input"
                      value={form.startDate}
                      onChange={(e) => setForm({ ...form, startDate: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="label">End Date</label>
                    <input
                      type="date"
                      className="input"
                      value={form.endDate}
                      onChange={(e) => setForm({ ...form, endDate: e.target.value })}
                    />
                  </div>
                </div>

                <div>
                  <label className="label">Description</label>
                  <textarea
                    className="textarea"
                    rows={3}
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                  />
                </div>

                <div>
                  <label className="label">Website URL</label>
                  <input
                    type="url"
                    className="input"
                    value={form.website}
                    onChange={(e) => setForm({ ...form, website: e.target.value })}
                    placeholder="https://..."
                  />
                </div>

                {/* Image Upload Section */}
                <div>
                  <label className="label">Event Image</label>
                  <div style={{ display: 'flex', gap: '8px', alignItems: 'start' }}>
                    <div style={{ flex: 1 }}>
                      <ImageUrlPicker
                        value={form.imageUrl}
                        onChange={(url) => setForm({ ...form, imageUrl: url })}
                        label=""
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowImageUpload(!showImageUpload)}
                      className="btn-outline"
                      style={{ marginTop: '0px', display: 'flex', alignItems: 'center', gap: '8px', whiteSpace: 'nowrap' }}
                    >
                      <Upload size={16} />
                      Upload New
                    </button>
                  </div>
                  
                  {showImageUpload && (
                    <div style={{ marginTop: '12px', padding: '12px', background: '#f8fafc', borderRadius: '8px' }}>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        disabled={uploadingImage}
                        className="input"
                        style={{ padding: '8px' }}
                      />
                      {uploadingImage && (
                        <div style={{ marginTop: '8px', fontSize: '13px', color: '#64748b' }}>
                          Uploading image...
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Parks Selection with Add New Button */}
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <label className="label" style={{ margin: 0 }}>Parks *</label>
                    <button
                      type="button"
                      onClick={() => setShowNewParkForm(!showNewParkForm)}
                      className="btn-outline"
                      style={{ padding: '4px 12px', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '6px' }}
                    >
                      <Plus size={14} />
                      New Park
                    </button>
                  </div>
                  
                  {showNewParkForm && (
                    <div style={{ marginBottom: '12px', padding: '12px', background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: '8px' }}>
                      <h4 style={{ margin: '0 0 8px 0', fontSize: '14px', fontWeight: '600', color: '#15803d' }}>Create New Park</h4>
                      <div style={{ display: 'grid', gap: '8px' }}>
                        <input
                          className="input"
                          placeholder="Park Name *"
                          value={newParkForm.name}
                          onChange={(e) => setNewParkForm({ ...newParkForm, name: e.target.value })}
                          style={{ fontSize: '13px' }}
                        />
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
                          <select
                            className="select"
                            value={newParkForm.parkType}
                            onChange={(e) => setNewParkForm({ ...newParkForm, parkType: e.target.value })}
                            style={{ fontSize: '13px' }}
                          >
                            <option value="tournament">Tournament</option>
                            <option value="league">League</option>
                            <option value="hybrid">Hybrid</option>
                          </select>
                          <input
                            className="input"
                            placeholder="City"
                            value={newParkForm.city}
                            onChange={(e) => setNewParkForm({ ...newParkForm, city: e.target.value })}
                            style={{ fontSize: '13px' }}
                          />
                          <input
                            className="input"
                            placeholder="State"
                            maxLength={2}
                            value={newParkForm.state}
                            onChange={(e) => setNewParkForm({ ...newParkForm, state: e.target.value })}
                            style={{ fontSize: '13px' }}
                          />
                        </div>
                        <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
                          <button
                            type="button"
                            onClick={() => {
                              setShowNewParkForm(false);
                              setNewParkForm({ name: "", parkType: "tournament", city: "", state: "" });
                            }}
                            className="btn-outline"
                            style={{ fontSize: '13px', padding: '6px 12px' }}
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={handleCreatePark}
                            disabled={creatingPark}
                            className="btn"
                            style={{ fontSize: '13px', padding: '6px 12px', background: '#10b981', borderColor: '#10b981' }}
                          >
                            {creatingPark ? 'Creating...' : 'Create Park'}
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div style={{ 
                    border: '1px solid #e2e8f0', 
                    borderRadius: '8px', 
                    padding: '12px',
                    maxHeight: '150px',
                    overflow: 'auto'
                  }}>
                    {parks.length === 0 && (
                      <div style={{ color: 'var(--muted)', fontSize: 14 }}>
                        No parks available. Create one using the button above.
                      </div>
                    )}
                    {parks.map(park => (
                      <label key={park.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0' }}>
                        <input
                          type="checkbox"
                          checked={(form.parkIds || []).includes(park.id)}
                          onChange={() => {
                            const isCurrentlySelected = (form.parkIds || []).includes(park.id);
                            const updatedParkIds = isCurrentlySelected
                              ? (form.parkIds || []).filter(id => id !== park.id)
                              : [...(form.parkIds || []), park.id];
                            
                            const validFieldIds = (form.fieldIds || []).filter(fieldId => {
                              const field = fields.find(f => f.id === fieldId);
                              return field && updatedParkIds.includes(field.parkId);
                            });
                            
                            setForm({ 
                              ...form, 
                              parkIds: updatedParkIds, 
                              fieldIds: validFieldIds 
                            });
                          }}
                        />
                        <span>{park.name}</span>
                      </label>
                    ))}
                  </div>
                  {parks.length > 0 && (form.parkIds || []).length === 0 && (
                    <div style={{ fontSize: 12, color: '#dc2626', marginTop: 4 }}>
                      Please select at least one park for this event
                    </div>
                  )}
                </div>

                {/* Fields Selection with Single and Bulk Creation */}
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <label className="label" style={{ margin: 0 }}>Fields</label>
                    {(form.parkIds || []).length > 0 && (
                      <div style={{ display: 'flex', gap: '8px' }}>
                        <button
                          type="button"
                          onClick={() => setShowBulkFieldForm(!showBulkFieldForm)}
                          className="btn-outline"
                          style={{ padding: '4px 12px', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '6px' }}
                        >
                          <Plus size={14} />
                          Bulk Create
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowNewFieldForm(!showNewFieldForm)}
                          className="btn-outline"
                          style={{ padding: '4px 12px', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '6px' }}
                        >
                          <Plus size={14} />
                          New Field
                        </button>
                      </div>
                    )}
                  </div>
                  
                  {/* Bulk Field Creation Form */}
                  {showBulkFieldForm && (
                    <div style={{ marginBottom: '12px', padding: '12px', background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: '8px' }}>
                      <h4 style={{ margin: '0 0 8px 0', fontSize: '14px', fontWeight: '600', color: '#1e40af' }}>
                        Bulk Create Fields (for {parks.find(p => p.id === form.parkIds[0])?.name})
                      </h4>
                      <div style={{ display: 'grid', gap: '8px' }}>
                        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '8px' }}>
                          <input
                            className="input"
                            placeholder="Base Name (e.g., 'Field') *"
                            value={bulkFieldForm.baseName}
                            onChange={(e) => setBulkFieldForm({ ...bulkFieldForm, baseName: e.target.value })}
                            style={{ fontSize: '13px' }}
                          />
                          <input
                            type="number"
                            className="input"
                            placeholder="Count"
                            min="1"
                            max="50"
                            value={bulkFieldForm.count}
                            onChange={(e) => setBulkFieldForm({ ...bulkFieldForm, count: parseInt(e.target.value) || 1 })}
                            style={{ fontSize: '13px' }}
                          />
                        </div>
                        <input
                          className="input"
                          placeholder="Image URL (optional, same for all)"
                          value={bulkFieldForm.imageUrl}
                          onChange={(e) => setBulkFieldForm({ ...bulkFieldForm, imageUrl: e.target.value })}
                          style={{ fontSize: '13px' }}
                        />
                        <select
                          className="select"
                          value={bulkFieldForm.templateId}
                          onChange={(e) => setBulkFieldForm({ ...bulkFieldForm, templateId: e.target.value })}
                          style={{ fontSize: '13px' }}
                        >
                          <option value="">No Spot Template</option>
                          {spotTemplates.map(template => (
                            <option key={template.id} value={template.id}>
                              {template.name} ({template.spots?.length || 0} spots)
                            </option>
                          ))}
                        </select>
                        <div style={{ fontSize: '11px', color: '#1e40af', fontStyle: 'italic' }}>
                          Will create: {bulkFieldForm.baseName} 1, {bulkFieldForm.baseName} 2, ..., {bulkFieldForm.baseName} {bulkFieldForm.count}
                        </div>
                        <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
                          <button
                            type="button"
                            onClick={() => {
                              setShowBulkFieldForm(false);
                              setBulkFieldForm({ baseName: "Field", count: 5, imageUrl: "", templateId: "" });
                            }}
                            className="btn-outline"
                            style={{ fontSize: '13px', padding: '6px 12px' }}
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={handleCreateBulkFields}
                            disabled={creatingBulkFields}
                            className="btn"
                            style={{ fontSize: '13px', padding: '6px 12px', background: '#3b82f6', borderColor: '#3b82f6' }}
                          >
                            {creatingBulkFields ? 'Creating...' : `Create ${bulkFieldForm.count} Fields`}
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Single Field Creation Form */}
                  {showNewFieldForm && (
                    <div style={{ marginBottom: '12px', padding: '12px', background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: '8px' }}>
                      <h4 style={{ margin: '0 0 8px 0', fontSize: '14px', fontWeight: '600', color: '#15803d' }}>
                        Create New Field (for {parks.find(p => p.id === form.parkIds[0])?.name})
                      </h4>
                      <div style={{ display: 'grid', gap: '8px' }}>
                        <input
                          className="input"
                          placeholder="Field Name *"
                          value={newFieldForm.name}
                          onChange={(e) => setNewFieldForm({ ...newFieldForm, name: e.target.value })}
                          style={{ fontSize: '13px' }}
                        />
                        <input
                          className="input"
                          placeholder="Image URL (optional)"
                          value={newFieldForm.imageUrl}
                          onChange={(e) => setNewFieldForm({ ...newFieldForm, imageUrl: e.target.value })}
                          style={{ fontSize: '13px' }}
                        />
                        <select
                          className="select"
                          value={newFieldForm.templateId}
                          onChange={(e) => setNewFieldForm({ ...newFieldForm, templateId: e.target.value })}
                          style={{ fontSize: '13px' }}
                        >
                          <option value="">No Spot Template (add spots later)</option>
                          {spotTemplates.map(template => (
                            <option key={template.id} value={template.id}>
                              {template.name} ({template.spots?.length || 0} spots)
                            </option>
                          ))}
                        </select>
                        <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
                          <button
                            type="button"
                            onClick={() => {
                              setShowNewFieldForm(false);
                              setNewFieldForm({ name: "", imageUrl: "", templateId: "" });
                            }}
                            className="btn-outline"
                            style={{ fontSize: '13px', padding: '6px 12px' }}
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={handleCreateField}
                            disabled={creatingField}
                            className="btn"
                            style={{ fontSize: '13px', padding: '6px 12px', background: '#10b981', borderColor: '#10b981' }}
                          >
                            {creatingField ? 'Creating...' : 'Create Field'}
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {(form.parkIds || []).length === 0 ? (
                    <div style={{ 
                      border: '1px solid #e2e8f0', 
                      borderRadius: '8px', 
                      padding: '12px',
                      background: '#f8fafc',
                      color: 'var(--muted)',
                      fontSize: 14
                    }}>
                      Select a park first to see available fields
                    </div>
                  ) : (
                    <div style={{ 
                      border: '1px solid #e2e8f0', 
                      borderRadius: '8px', 
                      padding: '12px',
                      maxHeight: '150px',
                      overflow: 'auto'
                    }}>
                      {filteredFieldsForEvent.length === 0 && (
                        <div style={{ color: 'var(--muted)', fontSize: 14 }}>
                          No fields available for the selected park(s). Create one using the buttons above.
                        </div>
                      )}
                      {filteredFieldsForEvent.map(field => {
                        const park = parks.find(p => p.id === field.parkId);
                        return (
                          <label key={field.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0' }}>
                            <input
                              type="checkbox"
                              checked={(form.fieldIds || []).includes(field.id)}
                              onChange={() => toggleField(field.id)}
                            />
                            <span>
                              {field.name}
                              {park && form.parkIds.length > 1 && (
                                <span style={{ color: 'var(--muted)', fontSize: 12, marginLeft: 6 }}>
                                  ({park.name})
                                </span>
                              )}
                            </span>
                          </label>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* NEW: Packages Selection */}
                <div>
                  <label className="label">Available Packages (leave empty to show all packages)</label>
                  <div style={{ 
                    border: '1px solid #e2e8f0', 
                    borderRadius: '8px', 
                    padding: '12px',
                    maxHeight: '200px',
                    overflow: 'auto'
                  }}>
                    {packages.length === 0 ? (
                      <div style={{ color: 'var(--muted)', fontSize: 14 }}>
                        No packages available. Create packages first in the Packages section.
                      </div>
                    ) : (
                      <>
                        {packages.map(pkg => (
                          <label key={pkg.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0' }}>
                            <input
                              type="checkbox"
                              checked={(form.packageIds || []).includes(pkg.id)}
                              onChange={() => togglePackage(pkg.id)}
                            />
                            <span>{pkg.name}</span>
                          </label>
                        ))}
                      </>
                    )}
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>
                    {(form.packageIds || []).length === 0 
                      ? "All active packages will be available for this event" 
                      : `${(form.packageIds || []).length} package(s) selected`
                    }
                  </div>
                </div>

                {/* League Configuration */}
                <div style={{ 
                  borderTop: '2px solid #e2e8f0', 
                  paddingTop: '16px',
                  marginTop: '8px'
                }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                    <input
                      type="checkbox"
                      checked={form.leagueEnabled || form.eventType === "league"}
                      onChange={(e) => setForm({ ...form, leagueEnabled: e.target.checked })}
                      disabled={form.eventType === "league"}
                    />
                    <span className="label" style={{ margin: 0 }}>Enable League Mode</span>
                  </label>

                  {(form.leagueEnabled || form.eventType === "league") && (
                    <div className="grid gap-4" style={{ 
                      background: '#f8fafc', 
                      padding: '16px', 
                      borderRadius: '8px' 
                    }}>
                      <div>
                        <label className="label">League Game Dates (comma-separated YYYY-MM-DD) *</label>
                        <textarea
                          className="textarea"
                          rows={2}
                          value={form.leagueDates}
                          onChange={(e) => setForm({ ...form, leagueDates: e.target.value })}
                          placeholder="2025-10-25, 2025-11-01, 2025-11-08"
                        />
                        <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>
                          Enter dates in YYYY-MM-DD format, separated by commas
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="label">First Game Time *</label>
                          <input
                            type="time"
                            className="input"
                            value={form.leagueStartTime}
                            onChange={(e) => setForm({ ...form, leagueStartTime: e.target.value })}
                          />
                        </div>

                        <div>
                          <label className="label">Last Game Time *</label>
                          <input
                            type="time"
                            className="input"
                            value={form.leagueEndTime}
                            onChange={(e) => setForm({ ...form, leagueEndTime: e.target.value })}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="label">Game Slot Duration (minutes) *</label>
                          <input
                            type="number"
                            className="input"
                            min="30"
                            step="5"
                            value={form.leagueBufferMinutes}
                            onChange={(e) => setForm({ ...form, leagueBufferMinutes: parseInt(e.target.value) || 90 })}
                          />
                          <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>
                            Includes game time + turnaround
                          </div>
                        </div>

                        <div>
                          <label className="label">Spots per Time Slot *</label>
                          <input
                            type="number"
                            className="input"
                            min="1"
                            step="1"
                            value={form.leagueDefaultSpotsPerSlot}
                            onChange={(e) => setForm({ ...form, leagueDefaultSpotsPerSlot: parseInt(e.target.value) || 2 })}
                          />
                          <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>
                            How many teams per time slot
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Active Toggle */}
                <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <input
                    type="checkbox"
                    checked={form.isActive}
                    onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
                  />
                  <span className="label" style={{ margin: 0 }}>Active (visible to customers)</span>
                </label>
              </div>

              {/* Form Actions */}
              <div className="flex justify-end gap-3 mt-6">
                <button type="button" onClick={resetForm} className="btn-outline">
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="btn"
                  style={{
                    background: 'linear-gradient(to right, #003f5c, #00507a)',
                    color: 'white',
                    border: 'none'
                  }}
                >
                  {editingEvent ? "Update Event" : "Create Event"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
