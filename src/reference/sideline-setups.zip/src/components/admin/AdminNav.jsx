
import React from "react";

export default function AdminNav({ active }) {
  return (
    <nav className="admin-nav">
      <a href="/admin" className={active === 'home' ? 'active' : ''}>
        🏠 Dashboard
      </a>
      <a href="/admin/events" className={active === 'events' ? 'active' : ''}>
        📅 Events
      </a>
      <a href="/admin/bookings" className={active === 'bookings' ? 'active' : ''}>
        📦 Bookings
      </a>
      <a href="/admin/parks" className={active === 'parks' ? 'active' : ''}>
        🏟️ Parks & Fields
      </a>
      <a href="/admin/packages" className={active === 'packages' ? 'active' : ''}>
        📦 Packages
      </a>
      <a href="/admin/staff" className={active === 'staff' ? 'active' : ''}>
        👥 Staff
      </a>
      <a href="/admin/xero" className={active === 'xero' ? 'active' : ''}>
        💰 Xero Sync
      </a>
      <a href="/admin/settings" className={active === 'settings' ? 'active' : ''}>
        ⚙️ Settings
      </a>

      <style>{`
        .admin-nav {
          display: flex;
          gap: 8px;
          padding: 16px;
          background: white;
          border-bottom: 2px solid #e2e8f0;
          overflow-x: auto;
          flex-wrap: wrap;
        }
        .admin-nav a {
          padding: 8px 16px;
          border-radius: 8px;
          text-decoration: none;
          color: #64748b;
          font-weight: 500;
          white-space: nowrap;
          transition: all 0.2s;
        }
        .admin-nav a:hover {
          background: #f8fafc;
          color: #003f5c;
        }
        .admin-nav a.active {
          background: #003f5c;
          color: white;
        }
      `}</style>
    </nav>
  );
}
