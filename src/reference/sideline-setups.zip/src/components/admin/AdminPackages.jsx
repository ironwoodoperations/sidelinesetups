
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Pencil, Trash2, Plus, X, Save, GripVertical } from "lucide-react";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import ImageUrlPicker from "./ImageUrlPicker";

export default function AdminPackages() {
  const [packages, setPackages] = useState([]);
  const [allEquipment, setAllEquipment] = useState([]);
  const [allAddOns, setAllAddOns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  
  const [form, setForm] = useState({
    name: "",
    description: "",
    thumbnailUrl: "",
    perGameUSD: 0,
    perDayUSD: 0,
    fullWeekendUSD: 0,
    baseItems: [],
    addOnIds: [],
    features: [],
    showForTournament: true,
    showForLeague: false,
    showOnPackagesPage: true, // Added new field
    isActive: true
  });

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    try {
      const [pkgs, equipment, addOns] = await Promise.all([
        base44.entities.Packages.list(),
        base44.entities.Equipment.list(),
        base44.entities.AddOns.list()
      ]);
      
      // Sort packages by displayOrder
      const sortedPkgs = (pkgs || []).sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
      
      setPackages(sortedPkgs);
      setAllEquipment(equipment || []);
      setAllAddOns(addOns || []);
    } catch (error) {
      console.error("Failed to load data:", error);
      alert("Failed to load data: " + error.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleDragEnd(result) {
    if (!result.destination) return;

    const items = Array.from(packages);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setPackages(items);

    // Update displayOrder for all packages
    try {
      const updatePromises = items.map((pkg, index) =>
        base44.entities.Packages.update(pkg.id, { displayOrder: index })
      );
      await Promise.all(updatePromises);
    } catch (error) {
      console.error("Failed to update package order:", error);
      alert("Failed to save new order");
      loadData(); // Reload to reset
    }
  }

  function startCreate() {
    setForm({
      name: "",
      description: "",
      thumbnailUrl: "",
      perGameUSD: 0,
      perDayUSD: 0,
      fullWeekendUSD: 0,
      baseItems: [],
      addOnIds: [],
      features: [],
      showForTournament: true,
      showForLeague: false,
      showOnPackagesPage: true, // Added new field initialization
      isActive: true
    });
    setEditingId(null);
    setShowCreateModal(true);
  }

  function startEdit(pkg) {
    setForm({
      name: pkg.name || "",
      description: pkg.description || "",
      thumbnailUrl: pkg.thumbnailUrl || "",
      perGameUSD: pkg.perGameUSD || 0,
      perDayUSD: pkg.perDayUSD || 0,
      fullWeekendUSD: pkg.fullWeekendUSD || 0,
      baseItems: pkg.baseItems || [],
      addOnIds: pkg.addOnIds || [],
      features: pkg.features || [],
      showForTournament: pkg.showForTournament !== false,
      showForLeague: pkg.showForLeague === true,
      showOnPackagesPage: pkg.showOnPackagesPage !== false, // Added new field population
      isActive: pkg.isActive !== false
    });
    setEditingId(pkg.id);
    setShowCreateModal(true);
  }

  async function handleSave() {
    if (!form.name) {
      alert("Package name is required");
      return;
    }

    try {
      if (editingId) {
        await base44.entities.Packages.update(editingId, form);
      } else {
        // New package gets added to the end
        await base44.entities.Packages.create({ ...form, displayOrder: packages.length });
      }
      
      setShowCreateModal(false);
      setEditingId(null);
      await loadData();
    } catch (error) {
      console.error("Failed to save package:", error);
      alert("Failed to save package: " + error.message);
    }
  }

  async function handleDelete(id) {
    if (!confirm("Delete this package? This cannot be undone.")) return;
    
    try {
      await base44.entities.Packages.delete(id);
      await loadData();
    } catch (error) {
      console.error("Failed to delete package:", error);
      alert("Failed to delete package: " + error.message);
    }
  }

  function addEquipmentToPackage(equipmentId) {
    if (!equipmentId) return;
    
    if (form.baseItems.some(item => item.equipmentId === equipmentId)) {
      alert("This equipment is already in the package");
      return;
    }
    
    setForm(prev => ({
      ...prev,
      baseItems: [...prev.baseItems, { equipmentId, qty: 1 }]
    }));
  }

  function updateEquipmentQty(equipmentId, newQty) {
    setForm(prev => ({
      ...prev,
      baseItems: prev.baseItems.map(item =>
        item.equipmentId === equipmentId
          ? { ...item, qty: Math.max(1, parseInt(newQty) || 1) }
          : item
      )
    }));
  }

  function removeEquipmentFromPackage(equipmentId) {
    setForm(prev => ({
      ...prev,
      baseItems: prev.baseItems.filter(item => item.equipmentId !== equipmentId)
    }));
  }

  function toggleAddOn(addonId) {
    setForm(prev => ({
      ...prev,
      addOnIds: prev.addOnIds.includes(addonId)
        ? prev.addOnIds.filter(id => id !== addonId)
        : [...prev.addOnIds, addonId]
    }));
  }

  function addFeature() {
    const feature = prompt("Enter feature description:");
    if (feature) {
      setForm(prev => ({
        ...prev,
        features: [...prev.features, feature]
      }));
    }
  }

  function removeFeature(index) {
    setForm(prev => ({
      ...prev,
      features: prev.features.filter((_, i) => i !== index)
    }));
  }

  if (loading) {
    return (
      <div style={{ padding: "20px", textAlign: "center" }}>
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
        <div>
          <h2>Packages</h2>
          <p style={{ color: "#64748b", fontSize: "14px", marginTop: "4px" }}>
            Drag to reorder - order determines display on booking page
          </p>
        </div>
        <button className="btn" onClick={startCreate}>
          <Plus size={16} style={{ marginRight: "8px" }} />
          Create Package
        </button>
      </div>

      {/* Packages List with Drag & Drop */}
      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="packages">
          {(provided) => (
            <div
              {...provided.droppableProps}
              ref={provided.innerRef}
              style={{ display: "grid", gap: "16px" }}
            >
              {packages.map((pkg, index) => {
                const equipmentCount = (pkg.baseItems || []).length;
                const addOnCount = (pkg.addOnIds || []).length;
                
                return (
                  <Draggable key={pkg.id} draggableId={pkg.id} index={index}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className="card"
                        style={{
                          padding: "16px",
                          background: snapshot.isDragging ? "#f8fafc" : "white",
                          ...provided.draggableProps.style
                        }}
                      >
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start" }}>
                          <div style={{ display: "flex", alignItems: "start", gap: "12px", flex: 1 }}>
                            <div
                              {...provided.dragHandleProps}
                              style={{
                                cursor: "grab",
                                color: "#94a3b8",
                                padding: "4px",
                                marginTop: "4px"
                              }}
                            >
                              <GripVertical size={20} />
                            </div>
                            
                            {/* Display Thumbnail Image */}
                            {pkg.thumbnailUrl && (
                              <img 
                                src={pkg.thumbnailUrl} 
                                alt={pkg.name}
                                style={{
                                  width: "80px",
                                  height: "80px",
                                  objectFit: "cover",
                                  borderRadius: "8px",
                                  border: "1px solid #e2e8f0"
                                }}
                              />
                            )}
                            
                            <div style={{ flex: 1 }}>
                              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px" }}>
                                <span style={{
                                  fontSize: "12px",
                                  color: "#64748b",
                                  fontWeight: "600",
                                  background: "#f1f5f9",
                                  padding: "2px 8px",
                                  borderRadius: "4px"
                                }}>
                                  #{index + 1}
                                </span>
                                <h3 style={{ margin: 0 }}>{pkg.name}</h3>
                                {!pkg.isActive && (
                                  <span className="badge" style={{ background: "#fee2e2", color: "#991b1b" }}>
                                    Inactive
                                  </span>
                                )}
                                {pkg.showForTournament && (
                                  <span className="badge-success" style={{ fontSize: "11px" }}>
                                    Tournament
                                  </span>
                                )}
                                {pkg.showForLeague && (
                                  <span className="badge" style={{ background: "#dbeafe", color: "#1e40af", fontSize: "11px" }}>
                                    League
                                  </span>
                                )}
                                {pkg.showOnPackagesPage && (
                                  <span className="badge" style={{ background: "#d1fae5", color: "#065f46", fontSize: "11px" }}>
                                    Public Page
                                  </span>
                                )}
                              </div>
                              
                              {pkg.description && (
                                <p style={{ color: "#64748b", fontSize: "14px", marginBottom: "12px" }}>
                                  {pkg.description}
                                </p>
                              )}
                              
                              <div style={{ display: "flex", gap: "16px", fontSize: "14px", marginBottom: "12px" }}>
                                <div>
                                  <strong>Per Game:</strong> ${(pkg.perGameUSD || 0).toFixed(2)}
                                </div>
                                <div>
                                  <strong>Per Day:</strong> ${(pkg.perDayUSD || 0).toFixed(2)}
                                </div>
                                <div>
                                  <strong>Weekend:</strong> ${(pkg.fullWeekendUSD || 0).toFixed(2)}
                                </div>
                              </div>
                              
                              <div style={{ fontSize: "13px", color: "#64748b" }}>
                                <strong>{equipmentCount}</strong> equipment item{equipmentCount !== 1 ? 's' : ''} • 
                                <strong style={{ marginLeft: "8px" }}>{addOnCount}</strong> add-on{addOnCount !== 1 ? 's' : ''}
                              </div>
                            </div>
                          </div>
                          
                          <div style={{ display: "flex", gap: "8px" }}>
                            <button className="btn-outline" onClick={() => startEdit(pkg)}>
                              <Pencil size={16} />
                            </button>
                            <button 
                              className="btn-outline" 
                              onClick={() => handleDelete(pkg.id)}
                              style={{ color: "#ef4444", borderColor: "#ef4444" }}
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </Draggable>
                );
              })}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      {/* Create/Edit Modal */}
      {showCreateModal && (
        <div style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: "rgba(0,0,0,0.5)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 1000,
          padding: "20px"
        }}>
          <div style={{
            background: "white",
            borderRadius: "12px",
            padding: "24px",
            maxWidth: "800px",
            width: "100%",
            maxHeight: "90vh",
            overflow: "auto"
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
              <h3 style={{ margin: 0 }}>
                {editingId ? "Edit Package" : "Create Package"}
              </h3>
              <button 
                onClick={() => setShowCreateModal(false)}
                style={{ background: "none", border: "none", cursor: "pointer" }}
              >
                <X size={24} />
              </button>
            </div>

            {/* Basic Info */}
            <div style={{ marginBottom: "24px" }}>
              <h4 style={{ marginBottom: "12px" }}>Basic Information</h4>
              
              <div className="form-group">
                <label className="label">Package Name *</label>
                <input
                  className="input"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="e.g., Family Setup Package"
                />
              </div>

              <div className="form-group">
                <label className="label">Description</label>
                <textarea
                  className="textarea"
                  rows={3}
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder="Describe what's included..."
                />
              </div>

              {/* ImageUrlPicker for Thumbnail */}
              <div className="form-group">
                <ImageUrlPicker
                  label="Package Thumbnail Image"
                  value={form.thumbnailUrl}
                  onChange={(url) => setForm({ ...form, thumbnailUrl: url })}
                />
                <p style={{ fontSize: "12px", color: "#64748b", marginTop: "4px" }}>
                  This image will appear next to the package in listings and booking pages
                </p>
              </div>
            </div>

            {/* Pricing */}
            <div style={{ marginBottom: "24px" }}>
              <h4 style={{ marginBottom: "12px" }}>Pricing</h4>
              
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "12px" }}>
                <div className="form-group">
                  <label className="label">Per Game ($)</label>
                  <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, perGameUSD: Math.max(0, (parseFloat(form.perGameUSD) || 0) - 1) })}
                      disabled={form.perGameUSD <= 0}
                      style={{
                        width: "32px",
                        height: "32px",
                        padding: "0",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        border: "1px solid #e2e8f0",
                        borderRadius: "6px",
                        background: "white",
                        cursor: "pointer",
                        fontSize: "18px",
                        fontWeight: "600",
                        color: "#003f5c",
                        opacity: form.perGameUSD <= 0 ? 0.3 : 1
                      }}
                    >
                      −
                    </button>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      className="input"
                      value={form.perGameUSD}
                      onChange={(e) => setForm({ ...form, perGameUSD: parseFloat(e.target.value) || 0 })}
                      style={{
                        flex: 1,
                        textAlign: "center",
                        fontWeight: "600"
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, perGameUSD: (parseFloat(form.perGameUSD) || 0) + 1 })}
                      style={{
                        width: "32px",
                        height: "32px",
                        padding: "0",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        border: "1px solid #e2e8f0",
                        borderRadius: "6px",
                        background: "white",
                        cursor: "pointer",
                        fontSize: "18px",
                        fontWeight: "600",
                        color: "#003f5c"
                      }}
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="form-group">
                  <label className="label">Per Day ($)</label>
                  <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, perDayUSD: Math.max(0, (parseFloat(form.perDayUSD) || 0) - 1) })}
                      disabled={form.perDayUSD <= 0}
                      style={{
                        width: "32px",
                        height: "32px",
                        padding: "0",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        border: "1px solid #e2e8f0",
                        borderRadius: "6px",
                        background: "white",
                        cursor: "pointer",
                        fontSize: "18px",
                        fontWeight: "600",
                        color: "#003f5c",
                        opacity: form.perDayUSD <= 0 ? 0.3 : 1
                      }}
                    >
                      −
                    </button>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      className="input"
                      value={form.perDayUSD}
                      onChange={(e) => setForm({ ...form, perDayUSD: parseFloat(e.target.value) || 0 })}
                      style={{
                        flex: 1,
                        textAlign: "center",
                        fontWeight: "600"
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, perDayUSD: (parseFloat(form.perDayUSD) || 0) + 1 })}
                      style={{
                        width: "32px",
                        height: "32px",
                        padding: "0",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        border: "1px solid #e2e8f0",
                        borderRadius: "6px",
                        background: "white",
                        cursor: "pointer",
                        fontSize: "18px",
                        fontWeight: "600",
                        color: "#003f5c"
                      }}
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="form-group">
                  <label className="label">Full Weekend ($)</label>
                  <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, fullWeekendUSD: Math.max(0, (parseFloat(form.fullWeekendUSD) || 0) - 1) })}
                      disabled={form.fullWeekendUSD <= 0}
                      style={{
                        width: "32px",
                        height: "32px",
                        padding: "0",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        border: "1px solid #e2e8f0",
                        borderRadius: "6px",
                        background: "white",
                        cursor: "pointer",
                        fontSize: "18px",
                        fontWeight: "600",
                        color: "#003f5c",
                        opacity: form.fullWeekendUSD <= 0 ? 0.3 : 1
                      }}
                    >
                      −
                    </button>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      className="input"
                      value={form.fullWeekendUSD}
                      onChange={(e) => setForm({ ...form, fullWeekendUSD: parseFloat(e.target.value) || 0 })}
                      style={{
                        flex: 1,
                        textAlign: "center",
                        fontWeight: "600"
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, fullWeekendUSD: (parseFloat(form.fullWeekendUSD) || 0) + 1 })}
                      style={{
                        width: "32px",
                        height: "32px",
                        padding: "0",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        border: "1px solid #e2e8f0",
                        borderRadius: "6px",
                        background: "white",
                        cursor: "pointer",
                        fontSize: "18px",
                        fontWeight: "600",
                        color: "#003f5c"
                      }}
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Equipment Selection */}
            <div style={{ marginBottom: "24px" }}>
              <h4 style={{ marginBottom: "12px" }}>Equipment Included</h4>
              
              <div className="form-group">
                <label className="label">Add Equipment</label>
                <select
                  className="select"
                  onChange={(e) => {
                    addEquipmentToPackage(e.target.value);
                    e.target.value = "";
                  }}
                >
                  <option value="">Select equipment to add...</option>
                  {allEquipment.map(equip => (
                    <option key={equip.id} value={equip.id}>
                      {equip.name} (Available: {equip.availableQty || 0})
                    </option>
                  ))}
                </select>
              </div>

              {form.baseItems.length > 0 && (
                <div style={{ marginTop: "12px" }}>
                  {form.baseItems.map(item => {
                    const equipment = allEquipment.find(e => e.id === item.equipmentId);
                    return (
                      <div 
                        key={item.equipmentId}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "12px",
                          padding: "8px",
                          background: "#f8fafc",
                          borderRadius: "8px",
                          marginBottom: "8px"
                        }}
                      >
                        <div style={{ flex: 1 }}>
                          <strong>{equipment?.name || "Unknown Equipment"}</strong>
                        </div>
                        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                          <label style={{ fontSize: "13px", color: "#64748b" }}>Qty:</label>
                          <button
                            type="button"
                            onClick={() => updateEquipmentQty(item.equipmentId, Math.max(1, item.qty - 1))}
                            disabled={item.qty <= 1}
                            style={{
                              width: "28px",
                              height: "28px",
                              padding: "0",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              border: "1px solid #e2e8f0",
                              borderRadius: "6px",
                              background: "white",
                              cursor: "pointer",
                              fontSize: "16px",
                              fontWeight: "600",
                              color: "#003f5c",
                              opacity: item.qty <= 1 ? 0.3 : 1
                            }}
                          >
                            −
                          </button>
                          <input
                            type="number"
                            min="1"
                            value={item.qty}
                            onChange={(e) => updateEquipmentQty(item.equipmentId, e.target.value)}
                            style={{ 
                              width: "50px", 
                              padding: "4px 8px",
                              textAlign: "center",
                              fontWeight: "600"
                            }}
                            className="input"
                          />
                          <button
                            type="button"
                            onClick={() => updateEquipmentQty(item.equipmentId, item.qty + 1)}
                            style={{
                              width: "28px",
                              height: "28px",
                              padding: "0",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              border: "1px solid #e2e8f0",
                              borderRadius: "6px",
                              background: "white",
                              cursor: "pointer",
                              fontSize: "16px",
                              fontWeight: "600",
                              color: "#003f5c"
                            }}
                          >
                            +
                          </button>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeEquipmentFromPackage(item.equipmentId)}
                          style={{
                            background: "none",
                            border: "none",
                            color: "#ef4444",
                            cursor: "pointer"
                          }}
                        >
                          <X size={18} />
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Add-Ons Selection */}
            <div style={{ marginBottom: "24px" }}>
              <h4 style={{ marginBottom: "12px" }}>Available Add-Ons</h4>
              
              {allAddOns.length === 0 ? (
                <p style={{ color: "#64748b", fontSize: "14px" }}>No add-ons available</p>
              ) : (
                <div style={{ display: "grid", gap: "8px" }}>
                  {allAddOns.map(addon => (
                    <label
                      key={addon.id}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "12px",
                        padding: "8px",
                        background: "#f8fafc",
                        borderRadius: "8px",
                        cursor: "pointer"
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={form.addOnIds.includes(addon.id)}
                        onChange={() => toggleAddOn(addon.id)}
                      />
                      <div style={{ flex: 1 }}>
                        <div><strong>{addon.label}</strong></div>
                        {addon.description && (
                          <div style={{ fontSize: "12px", color: "#64748b" }}>
                            {addon.description}
                          </div>
                        )}
                      </div>
                    </label>
                  ))}
                </div>
              )}
            </div>

            {/* Features */}
            <div style={{ marginBottom: "24px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
                <h4 style={{ margin: 0 }}>Features</h4>
                <button className="btn-outline" onClick={addFeature}>
                  <Plus size={16} /> Add Feature
                </button>
              </div>
              
              {form.features.length > 0 && (
                <ul style={{ paddingLeft: "20px", margin: 0 }}>
                  {form.features.map((feature, index) => (
                    <li key={index} style={{ marginBottom: "8px", display: "flex", alignItems: "center", gap: "8px" }}>
                      <span style={{ flex: 1 }}>{feature}</span>
                      <button
                        onClick={() => removeFeature(index)}
                        style={{
                          background: "none",
                          border: "none",
                          color: "#ef4444",
                          cursor: "pointer"
                        }}
                      >
                        <X size={16} />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* Settings */}
            <div style={{ marginBottom: "24px" }}>
              <h4 style={{ marginBottom: "12px" }}>Settings</h4>
              
              <div style={{ display: "grid", gap: "12px" }}>
                <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
                  <input
                    type="checkbox"
                    checked={form.showForTournament}
                    onChange={(e) => setForm({ ...form, showForTournament: e.target.checked })}
                  />
                  <span>Show for Tournament Events</span>
                </label>

                <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
                  <input
                    type="checkbox"
                    checked={form.showForLeague}
                    onChange={(e) => setForm({ ...form, showForLeague: e.target.checked })}
                  />
                  <span>Show for League Events</span>
                </label>

                <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
                  <input
                    type="checkbox"
                    checked={form.showOnPackagesPage} // New checkbox for showOnPackagesPage
                    onChange={(e) => setForm({ ...form, showOnPackagesPage: e.target.checked })}
                  />
                  <span>Show on Packages Page</span>
                </label>

                <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
                  <input
                    type="checkbox"
                    checked={form.isActive}
                    onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
                  />
                  <span>Active</span>
                </label>
              </div>
            </div>

            {/* Actions */}
            <div style={{ display: "flex", gap: "12px", justifyContent: "flex-end" }}>
              <button className="btn-outline" onClick={() => setShowCreateModal(false)}>
                Cancel
              </button>
              <button className="btn" onClick={handleSave}>
                <Save size={16} style={{ marginRight: "8px" }} />
                {editingId ? "Update Package" : "Create Package"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
