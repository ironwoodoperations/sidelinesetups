import React, { useState, useEffect } from "react";
import { getCtx } from "../lib/ctx";
import AdminCardList from "./AdminCardList";

export default function AdminFields() {
  const [fields, setFields] = useState([]);
  const [parks, setParks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editingField, setEditingField] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    parkId: "",
    name: "",
    imageUrl: ""
  });

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      setLoading(true);
      setError(null);
      const { entities } = await getCtx();
      
      const [fieldsData, parksData] = await Promise.all([
        entities.Fields.list(),
        entities.Parks.list()
      ]);
      
      setFields(fieldsData || []);
      setParks(parksData || []);
    } catch (err) {
      console.error("Error fetching fields:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      const { entities } = await getCtx();
      if (editingField) {
        await entities.Fields.update(editingField.id, formData);
      } else {
        await entities.Fields.create(formData);
      }
      setFormData({ parkId: "", name: "", imageUrl: "" });
      setEditingField(null);
      setShowForm(false);
      loadData();
    } catch (err) {
      console.error("Failed to save field:", err);
      alert("Failed to save field: " + err.message);
    }
  }

  function handleEdit(field) {
    setEditingField(field);
    setFormData({
      parkId: field.parkId || "",
      name: field.name || "",
      imageUrl: field.imageUrl || ""
    });
    setShowForm(true);
  }

  async function handleDelete(id) {
    if (!confirm("Delete this field?")) return;
    try {
      const { entities } = await getCtx();
      await entities.Fields.delete(id);
      loadData();
    } catch (err) {
      console.error("Failed to delete field:", err);
      alert("Failed to delete field: " + err.message);
    }
  }

  function handleCancel() {
    setEditingField(null);
    setShowForm(false);
    setFormData({ parkId: "", name: "", imageUrl: "" });
  }

  if (loading) {
    return <div className="spinner"></div>;
  }

  if (error) {
    return (
      <div className="card card-pad" style={{ textAlign: "center", color: "var(--danger)" }}>
        <p>Error loading fields: {error}</p>
        <button className="btn" onClick={loadData}>Retry</button>
      </div>
    );
  }

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        {!showForm ? (
          <button className="btn" onClick={() => setShowForm(true)}>
            + Add New Field
          </button>
        ) : (
          <div className="card card-pad">
            <h3>{editingField ? "Edit Field" : "Create New Field"}</h3>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="label">Park *</label>
                <select
                  className="select"
                  value={formData.parkId}
                  onChange={(e) => setFormData({ ...formData, parkId: e.target.value })}
                  required
                >
                  <option value="">Select a park</option>
                  {parks.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label className="label">Field Name *</label>
                <input
                  className="input"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label className="label">Image URL</label>
                <input
                  className="input"
                  value={formData.imageUrl}
                  onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                />
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button type="submit" className="btn">
                  {editingField ? "Update Field" : "Create Field"}
                </button>
                <button type="button" className="btn-outline" onClick={handleCancel}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}
      </div>

      <AdminCardList
        items={fields}
        keyField="id"
        getHeader={(field) => {
          const park = parks.find(p => p.id === field.parkId);
          return {
            title: field.name,
            subtitle: park ? `Park: ${park.name}` : field.parkId ? `Park ID: ${field.parkId}` : null,
            badgeText: null,
            badgeClass: null
          };
        }}
        getLines={(field) => [
          { label: "Park", value: parks.find(p => p.id === field.parkId)?.name || field.parkId || "—" },
          { label: "Image URL", value: field.imageUrl ? "✓ Set" : "—" }
        ]}
        onEdit={handleEdit}
        onDelete={handleDelete}
        emptyText="No fields yet. Create one above."
        cols={2}
      />
    </div>
  );
}