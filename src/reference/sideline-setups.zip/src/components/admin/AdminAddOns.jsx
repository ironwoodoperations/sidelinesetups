
import React, { useState, useEffect } from "react";
import { getCtx } from "../lib/ctx";
import { Plus, Trash2, Link, DollarSign, GripVertical, Edit } from "lucide-react";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import ImageUrlPicker from "./ImageUrlPicker";

export default function AdminAddOns() {
  const [addOns, setAddOns] = useState([]);
  const [allEquipment, setAllEquipment] = useState([]);
  const [editingAddOn, setEditingAddOn] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);
      const { entities } = await getCtx();
      const addOnsList = await entities.AddOns.list();
      const equipmentList = await entities.Equipment.list();
      console.log("Loaded equipment for dropdown:", equipmentList);
      
      // Sort by displayOrder
      const sortedAddOns = (addOnsList || []).sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
      
      setAddOns(sortedAddOns);
      setAllEquipment(equipmentList || []);
    } catch (err) {
      console.error("Error loading add-ons:", err);
      setError(err.message || "Failed to load data");
    } finally {
      setLoading(false);
    }
  };

  async function handleDragEnd(result) {
    if (!result.destination) return;

    const items = Array.from(addOns);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setAddOns(items);

    // Update displayOrder for all add-ons
    try {
      const { entities } = await getCtx();
      const updatePromises = items.map((addon, index) =>
        entities.AddOns.update(addon.id, { displayOrder: index })
      );
      await Promise.all(updatePromises);
    } catch (error) {
      console.error("Failed to update add-on order:", error);
      alert("Failed to save new order");
      loadData(); // Reload to reset
    }
  }

  const handleNew = () => {
    setEditingAddOn({
      label: "",
      description: "",
      thumbnailUrl: "",
      equipmentId: "",
      perGameUSD: 0,
      perDayUSD: 0,
      fullWeekendUSD: 0,
      isActive: true,
    });
    setShowForm(true);
  };

  const handleEdit = (addon) => {
    setEditingAddOn({ 
      ...addon,
      thumbnailUrl: addon.thumbnailUrl || "",
      equipmentId: addon.equipmentId || ""
    });
    setShowForm(true);
  };

  const handleSave = async () => {
    try {
      const { entities } = await getCtx();
      
      if (!editingAddOn.label || !editingAddOn.label.trim()) {
        alert("Please enter a label for this add-on");
        return;
      }

      const cleanedAddOn = {
        ...editingAddOn,
        equipmentId: editingAddOn.equipmentId || null,
        perGameUSD: Number(editingAddOn.perGameUSD) || 0,
        perDayUSD: Number(editingAddOn.perDayUSD) || 0,
        fullWeekendUSD: Number(editingAddOn.fullWeekendUSD) || 0,
      };

      console.log("Saving add-on:", cleanedAddOn);

      if (cleanedAddOn.id) {
        await entities.AddOns.update(cleanedAddOn.id, cleanedAddOn);
      } else {
        // New add-on gets added to the end
        await entities.AddOns.create({ ...cleanedAddOn, displayOrder: addOns.length });
      }
      
      setShowForm(false);
      setEditingAddOn(null);
      await loadData();
    } catch (error) {
      console.error("Save error:", error);
      alert("Failed to save: " + error.message);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this add-on?")) return;
    try {
      const { entities } = await getCtx();
      await entities.AddOns.delete(id);
      await loadData();
    } catch (error) {
      console.error("Delete error:", error);
      alert("Failed to delete: " + error.message);
    }
  };

  if (loading) {
    return (
      <div style={{ padding: "40px", textAlign: "center" }}>
        <div className="spinner"></div>
        <p style={{ marginTop: "16px", color: "#64748b" }}>Loading add-ons...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ padding: "40px", textAlign: "center" }}>
        <p style={{ color: "#ef4444" }}>Error: {error}</p>
        <button className="btn" onClick={loadData} style={{ marginTop: "16px" }}>
          Retry
        </button>
      </div>
    );
  }

  return (
    <div style={{ padding: "24px", maxWidth: "1400px", margin: "0 auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" }}>
        <div>
          <h2 style={{ margin: 0, fontSize: "24px", fontWeight: "700", color: "#003f5c" }}>Add-Ons Management</h2>
          <p style={{ color: "#64748b", fontSize: "14px", marginTop: "4px" }}>
            Drag to reorder add-ons
          </p>
        </div>
        <button 
          className="btn" 
          onClick={handleNew}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "8px",
            background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
            color: "white"
          }}
        >
          <Plus size={18} />
          New Add-On
        </button>
      </div>

      {/* Add-Ons Grid with Cards (similar to Equipment) */}
      {addOns.length === 0 ? (
        <div className="card" style={{ padding: "40px", textAlign: "center" }}>
          <Plus size={48} style={{ margin: "0 auto 16px", color: "#cbd5e1" }} />
          <h3 style={{ margin: "0 0 8px 0", color: "#64748b" }}>No Add-Ons Yet</h3>
          <p style={{ margin: "0 0 16px 0", color: "#94a3b8", fontSize: "14px" }}>
            Create your first add-on to start offering extras
          </p>
          <button
            onClick={handleNew}
            className="btn-outline"
            style={{ color: "#003f5c", borderColor: "#003f5c" }}
          >
            Create Add-On
          </button>
        </div>
      ) : (
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="addons">
            {(provided) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
                  gap: "20px"
                }}
              >
                {addOns.map((addon, index) => {
                  const equipment = allEquipment.find(e => e.id === addon.equipmentId);
                  
                  return (
                    <Draggable key={addon.id} draggableId={addon.id} index={index}>
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          className="card"
                          style={{
                            overflow: "hidden",
                            border: "1px solid #e2e8f0",
                            transition: "all 0.2s",
                            background: snapshot.isDragging ? "#f8fafc" : "white",
                            ...provided.draggableProps.style
                          }}
                        >
                          {/* Card Header */}
                          <div style={{
                            padding: "16px",
                            background: addon.isActive ? "#f8fafc" : "#fee2e2",
                            borderBottom: "1px solid #e2e8f0"
                          }}>
                            <div style={{
                              display: "flex",
                              justifyContent: "space-between",
                              alignItems: "start",
                              marginBottom: "8px"
                            }}>
                              <div style={{ display: "flex", alignItems: "start", gap: "8px", flex: 1 }}>
                                <div
                                  {...provided.dragHandleProps}
                                  style={{
                                    cursor: "grab",
                                    color: "#94a3b8",
                                    padding: "4px"
                                  }}
                                >
                                  <GripVertical size={16} />
                                </div>
                                
                                {/* Thumbnail Image */}
                                {addon.thumbnailUrl && (
                                  <img 
                                    src={addon.thumbnailUrl} 
                                    alt={addon.label}
                                    style={{
                                      width: "60px",
                                      height: "60px",
                                      objectFit: "cover",
                                      borderRadius: "8px",
                                      border: "1px solid #e2e8f0"
                                    }}
                                  />
                                )}
                                
                                <div style={{ flex: 1 }}>
                                  <h3 style={{
                                    margin: 0,
                                    fontSize: "18px",
                                    fontWeight: "600",
                                    color: "#0f172a"
                                  }}>
                                    {addon.label}
                                  </h3>
                                  {addon.description && (
                                    <p style={{
                                      margin: "4px 0 0 0",
                                      fontSize: "12px",
                                      color: "#64748b",
                                      lineHeight: "1.4"
                                    }}>
                                      {addon.description}
                                    </p>
                                  )}
                                </div>
                              </div>
                              <div style={{ display: "flex", gap: "4px" }}>
                                <button
                                  onClick={() => handleEdit(addon)}
                                  style={{
                                    padding: "6px",
                                    background: "white",
                                    border: "1px solid #e2e8f0",
                                    borderRadius: "6px",
                                    cursor: "pointer",
                                    color: "#64748b"
                                  }}
                                  title="Edit"
                                >
                                  <Edit size={16} />
                                </button>
                                <button
                                  onClick={() => handleDelete(addon.id)}
                                  style={{
                                    padding: "6px",
                                    background: "white",
                                    border: "1px solid #e2e8f0",
                                    borderRadius: "6px",
                                    cursor: "pointer",
                                    color: "#ef4444"
                                  }}
                                  title="Delete"
                                >
                                  <Trash2 size={16} />
                                </button>
                              </div>
                            </div>
                            
                            {/* Order Badge */}
                            <span style={{
                              fontSize: "12px",
                              color: "#64748b",
                              fontWeight: "600",
                              background: "#f1f5f9",
                              padding: "2px 8px",
                              borderRadius: "4px"
                            }}>
                              #{index + 1}
                            </span>
                          </div>

                          {/* Card Body */}
                          <div style={{ padding: "16px" }}>
                            {/* Linked Equipment */}
                            <div style={{ marginBottom: "12px" }}>
                              <div style={{ fontSize: "11px", color: "#64748b", marginBottom: "4px", textTransform: "uppercase", fontWeight: "600" }}>
                                Linked Equipment
                              </div>
                              {equipment ? (
                                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                                  <Link size={14} style={{ color: "#10b981" }} />
                                  <span style={{ fontSize: "14px", fontWeight: "500" }}>{equipment.name}</span>
                                  <span className="badge-success" style={{ fontSize: "10px" }}>
                                    {equipment.availableQty} avail
                                  </span>
                                </div>
                              ) : (
                                <span style={{ color: "#ef4444", fontSize: "12px" }}>
                                  ⚠️ No equipment linked
                                </span>
                              )}
                            </div>

                            {/* Pricing */}
                            <div style={{
                              padding: "12px",
                              background: "#f8fafc",
                              borderRadius: "8px",
                              fontSize: "13px"
                            }}>
                              <div style={{ fontWeight: "600", marginBottom: "8px", color: "#475569" }}>
                                Pricing:
                              </div>
                              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                                <span style={{ color: "#64748b" }}>Per Game:</span>
                                <span style={{ fontWeight: "600", color: "#003f5c" }}>${Number(addon.perGameUSD || 0).toFixed(2)}</span>
                              </div>
                              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                                <span style={{ color: "#64748b" }}>Per Day:</span>
                                <span style={{ fontWeight: "600", color: "#003f5c" }}>${Number(addon.perDayUSD || 0).toFixed(2)}</span>
                              </div>
                              <div style={{ display: "flex", justifyContent: "space-between" }}>
                                <span style={{ color: "#64748b" }}>Full Weekend:</span>
                                <span style={{ fontWeight: "600", color: "#003f5c" }}>${Number(addon.fullWeekendUSD || 0).toFixed(2)}</span>
                              </div>
                            </div>

                            {/* Status Badge */}
                            <div style={{ marginTop: "12px" }}>
                              <span className={addon.isActive ? "badge-success" : "badge"}>
                                {addon.isActive ? "Active" : "Inactive"}
                              </span>
                            </div>
                          </div>
                        </div>
                      )}
                    </Draggable>
                  );
                })}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      )}

      {/* Edit/Create Form Modal */}
      {showForm && editingAddOn && (
        <div style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: "rgba(0,0,0,0.5)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 1000,
          padding: "20px"
        }}>
          <div className="card" style={{
            maxWidth: "600px",
            width: "100%",
            maxHeight: "90vh",
            overflow: "auto",
            padding: "24px"
          }}>
            <h3 style={{ marginTop: 0 }}>
              {editingAddOn.id ? "Edit Add-On" : "New Add-On"}
            </h3>

            <div className="form-group">
              <label className="label">Label *</label>
              <input
                className="input"
                value={editingAddOn.label}
                onChange={(e) => setEditingAddOn({ ...editingAddOn, label: e.target.value })}
                placeholder="e.g., Extra Chair, Cooler, Fan"
              />
            </div>

            <div className="form-group">
              <label className="label">Description</label>
              <textarea
                className="textarea"
                rows={3}
                value={editingAddOn.description || ""}
                onChange={(e) => setEditingAddOn({ ...editingAddOn, description: e.target.value })}
                placeholder="Optional description"
              />
            </div>

            <div className="form-group">
              <ImageUrlPicker
                label="Add-On Thumbnail Image"
                value={editingAddOn.thumbnailUrl}
                onChange={(url) => setEditingAddOn({ ...editingAddOn, thumbnailUrl: url })}
              />
              <p style={{ fontSize: "12px", color: "#64748b", marginTop: "4px" }}>
                This image will appear in the add-on cards
              </p>
            </div>

            {/* CRITICAL: Equipment Dropdown */}
            <div className="form-group">
              <label className="label">
                <Link size={16} style={{ display: "inline", marginRight: "8px" }} />
                Link to Equipment * (for inventory tracking)
              </label>
              <select
                className="select"
                value={editingAddOn.equipmentId || ""}
                onChange={(e) => {
                  console.log("Equipment dropdown changed to:", e.target.value);
                  setEditingAddOn({ ...editingAddOn, equipmentId: e.target.value });
                }}
                style={{
                  width: "100%",
                  padding: "10px 12px",
                  border: "1px solid #e2e8f0",
                  borderRadius: "8px",
                  fontSize: "14px",
                  fontFamily: "inherit",
                  backgroundColor: "white"
                }}
              >
                <option value="">-- Select Equipment --</option>
                {allEquipment.map((equip) => (
                  <option key={equip.id} value={equip.id}>
                    {equip.name} (Available: {equip.availableQty})
                  </option>
                ))}
              </select>
              <div style={{ fontSize: "12px", color: "#64748b", marginTop: "4px" }}>
                Linking to equipment enables automatic inventory tracking
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "12px" }}>
              <div className="form-group">
                <label className="label">
                  <DollarSign size={14} style={{ display: "inline" }} /> Per Game
                </label>
                <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                  <button
                    type="button"
                    onClick={() => setEditingAddOn({ ...editingAddOn, perGameUSD: Math.max(0, (parseFloat(editingAddOn.perGameUSD) || 0) - 1) })}
                    disabled={editingAddOn.perGameUSD <= 0}
                    style={{
                      width: "32px",
                      height: "32px",
                      padding: "0",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      border: "1px solid #e2e8f0",
                      borderRadius: "6px",
                      background: "white",
                      cursor: "pointer",
                      fontSize: "18px",
                      fontWeight: "600",
                      color: "#003f5c",
                      opacity: editingAddOn.perGameUSD <= 0 ? 0.3 : 1
                    }}
                  >
                    −
                  </button>
                  <input
                    type="number"
                    className="input"
                    step="0.01"
                    min="0"
                    value={editingAddOn.perGameUSD}
                    onChange={(e) => setEditingAddOn({ ...editingAddOn, perGameUSD: e.target.value })}
                    style={{
                      flex: 1,
                      textAlign: "center",
                      fontWeight: "600"
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setEditingAddOn({ ...editingAddOn, perGameUSD: (parseFloat(editingAddOn.perGameUSD) || 0) + 1 })}
                    style={{
                      width: "32px",
                      height: "32px",
                      padding: "0",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      border: "1px solid #e2e8f0",
                      borderRadius: "6px",
                      background: "white",
                      cursor: "pointer",
                      fontSize: "18px",
                      fontWeight: "600",
                      color: "#003f5c"
                    }}
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="form-group">
                <label className="label">
                  <DollarSign size={14} style={{ display: "inline" }} /> Per Day
                </label>
                <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                  <button
                    type="button"
                    onClick={() => setEditingAddOn({ ...editingAddOn, perDayUSD: Math.max(0, (parseFloat(editingAddOn.perDayUSD) || 0) - 1) })}
                    disabled={editingAddOn.perDayUSD <= 0}
                    style={{
                      width: "32px",
                      height: "32px",
                      padding: "0",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      border: "1px solid #e2e8f0",
                      borderRadius: "6px",
                      background: "white",
                      cursor: "pointer",
                      fontSize: "18px",
                      fontWeight: "600",
                      color: "#003f5c",
                      opacity: editingAddOn.perDayUSD <= 0 ? 0.3 : 1
                    }}
                  >
                    −
                  </button>
                  <input
                    type="number"
                    className="input"
                    step="0.01"
                    min="0"
                    value={editingAddOn.perDayUSD}
                    onChange={(e) => setEditingAddOn({ ...editingAddOn, perDayUSD: e.target.value })}
                    style={{
                      flex: 1,
                      textAlign: "center",
                      fontWeight: "600"
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setEditingAddOn({ ...editingAddOn, perDayUSD: (parseFloat(editingAddOn.perDayUSD) || 0) + 1 })}
                    style={{
                      width: "32px",
                      height: "32px",
                      padding: "0",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      border: "1px solid #e2e8f0",
                      borderRadius: "6px",
                      background: "white",
                      cursor: "pointer",
                      fontSize: "18px",
                      fontWeight: "600",
                      color: "#003f5c"
                    }}
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="form-group">
                <label className="label">
                  <DollarSign size={14} style={{ display: "inline" }} /> Full Weekend
                </label>
                <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                  <button
                    type="button"
                    onClick={() => setEditingAddOn({ ...editingAddOn, fullWeekendUSD: Math.max(0, (parseFloat(editingAddOn.fullWeekendUSD) || 0) - 1) })}
                    disabled={editingAddOn.fullWeekendUSD <= 0}
                    style={{
                      width: "32px",
                      height: "32px",
                      padding: "0",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      border: "1px solid #e2e8f0",
                      borderRadius: "6px",
                      background: "white",
                      cursor: "pointer",
                      fontSize: "18px",
                      fontWeight: "600",
                      color: "#003f5c",
                      opacity: editingAddOn.fullWeekendUSD <= 0 ? 0.3 : 1
                    }}
                  >
                    −
                  </button>
                  <input
                    type="number"
                    className="input"
                    step="0.01"
                    min="0"
                    value={editingAddOn.fullWeekendUSD}
                    onChange={(e) => setEditingAddOn({ ...editingAddOn, fullWeekendUSD: e.target.value })}
                    style={{
                      flex: 1,
                      textAlign: "center",
                      fontWeight: "600"
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setEditingAddOn({ ...editingAddOn, fullWeekendUSD: (parseFloat(editingAddOn.fullWeekendUSD) || 0) + 1 })}
                    style={{
                      width: "32px",
                      height: "32px",
                      padding: "0",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      border: "1px solid #e2e8f0",
                      borderRadius: "6px",
                      background: "white",
                      cursor: "pointer",
                      fontSize: "18px",
                      fontWeight: "600",
                      color: "#003f5c"
                    }}
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            <div className="form-group">
              <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
                <input
                  type="checkbox"
                  checked={editingAddOn.isActive}
                  onChange={(e) => setEditingAddOn({ ...editingAddOn, isActive: e.target.checked })}
                />
                <span>Active (visible to customers)</span>
              </label>
            </div>

            <div style={{ display: "flex", gap: "12px", marginTop: "24px" }}>
              <button
                className="btn"
                onClick={handleSave}
                style={{ flex: 1 }}
              >
                Save Add-On
              </button>
              <button
                className="btn-outline"
                onClick={() => {
                  setShowForm(false);
                  setEditingAddOn(null);
                }}
                style={{ flex: 1 }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
