import React, { useState, useEffect } from "react";
import { getCtx } from "../lib/ctx";
import AdminCardList from "./AdminCardList";

export default function AdminParks() {
  const [parks, setParks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingPark, setEditingPark] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    parkType: "tournament",
    streetAddress: "",
    city: "",
    state: "",
    zip: "",
    notes: ""
  });

  useEffect(() => {
    loadParks();
  }, []);

  async function loadParks() {
    try {
      setLoading(true);
      const { entities } = await getCtx();
      const data = await entities.Parks.list();
      setParks(data || []);
    } catch (error) {
      console.error("Failed to fetch parks:", error);
      alert("Failed to load parks: " + error.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      const { entities } = await getCtx();
      if (editingPark) {
        await entities.Parks.update(editingPark.id, formData);
      } else {
        await entities.Parks.create(formData);
      }
      setFormData({
        name: "",
        parkType: "tournament",
        streetAddress: "",
        city: "",
        state: "",
        zip: "",
        notes: ""
      });
      setEditingPark(null);
      setShowForm(false);
      loadParks();
    } catch (error) {
      console.error("Failed to save park:", error);
      alert("Failed to save park: " + error.message);
    }
  }

  function handleEdit(park) {
    setEditingPark(park);
    setFormData({
      name: park.name || "",
      parkType: park.parkType || "tournament",
      streetAddress: park.streetAddress || "",
      city: park.city || "",
      state: park.state || "",
      zip: park.zip || "",
      notes: park.notes || ""
    });
    setShowForm(true);
  }

  async function handleDelete(id) {
    if (!confirm("Delete this park?")) return;
    try {
      const { entities } = await getCtx();
      await entities.Parks.delete(id);
      loadParks();
    } catch (error) {
      console.error("Failed to delete park:", error);
      alert("Failed to delete park: " + error.message);
    }
  }

  function handleCancel() {
    setEditingPark(null);
    setShowForm(false);
    setFormData({
      name: "",
      parkType: "tournament",
      streetAddress: "",
      city: "",
      state: "",
      zip: "",
      notes: ""
    });
  }

  if (loading) {
    return <div className="spinner"></div>;
  }

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        {!showForm ? (
          <button className="btn" onClick={() => setShowForm(true)}>
            + Add New Park
          </button>
        ) : (
          <div className="card card-pad">
            <h3>{editingPark ? "Edit Park" : "Create New Park"}</h3>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="label">Name *</label>
                <input
                  className="input"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label className="label">Park Type</label>
                <select
                  className="select"
                  value={formData.parkType}
                  onChange={(e) => setFormData({ ...formData, parkType: e.target.value })}
                >
                  <option value="tournament">Tournament</option>
                  <option value="league">League</option>
                  <option value="hybrid">Hybrid</option>
                </select>
              </div>
              <div className="form-group">
                <label className="label">Street Address</label>
                <input
                  className="input"
                  value={formData.streetAddress}
                  onChange={(e) => setFormData({ ...formData, streetAddress: e.target.value })}
                />
              </div>
              <div className="row">
                <div className="form-group">
                  <label className="label">City</label>
                  <input
                    className="input"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label className="label">State</label>
                  <input
                    className="input"
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label className="label">Zip</label>
                  <input
                    className="input"
                    value={formData.zip}
                    onChange={(e) => setFormData({ ...formData, zip: e.target.value })}
                  />
                </div>
              </div>
              <div className="form-group">
                <label className="label">Notes</label>
                <textarea
                  className="textarea"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={3}
                />
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button type="submit" className="btn">
                  {editingPark ? "Update Park" : "Create Park"}
                </button>
                <button type="button" className="btn-outline" onClick={handleCancel}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}
      </div>

      <AdminCardList
        items={parks}
        keyField="id"
        getHeader={(park) => ({
          title: park.name,
          subtitle: park.parkType ? `Type: ${park.parkType}` : null,
          badgeText: null,
          badgeClass: null
        })}
        getLines={(park) => [
          { label: "Address", value: park.streetAddress || "—" },
          { label: "City", value: park.city || "—" },
          { label: "State", value: park.state || "—" },
          { label: "Zip", value: park.zip || "—" },
          { label: "Notes", value: park.notes || "—" }
        ]}
        onEdit={handleEdit}
        onDelete={handleDelete}
        emptyText="No parks yet. Create one above."
        cols={2}
      />
    </div>
  );
}