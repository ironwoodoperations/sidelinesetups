
import React, { useState } from "react";
import { Folder, GitBranch, ChevronDown, ChevronRight } from "lucide-react";

export default function AdminFutureProjects() {
  const [expandedProjects, setExpandedProjects] = useState({});

  const toggleProject = (projectKey) => {
    setExpandedProjects(prev => ({
      ...prev,
      [projectKey]: !prev[projectKey]
    }));
  };

  const projects = [
    {
      key: 'abandoned-booking-recovery',
      title: 'Abandoned Booking Recovery System',
      description: 'Capture customer email during booking flow and send reminder emails if they don\'t complete the booking.',
      details: {
        overview: 'Re-engage potential customers who started the booking process but didn\'t complete it. Automatically capture their email and selections, then send personalized reminder emails with a link to resume their booking. This can recover 15-30% of abandoned bookings and increase revenue without additional marketing spend.',
        components: [
          {
            title: '1. New Entity: AbandonedBookings',
            content: `Create entities/AbandonedBookings.json:

{
  "name": "AbandonedBookings",
  "type": "object",
  "description": "Records of incomplete bookings for reminder emails",
  "properties": {
    "sessionId": {
      "type": "string",
      "description": "Frontend session ID from layout.js"
    },
    "customerEmail": {
      "type": "string",
      "description": "Email entered by customer"
    },
    "packageId": {
      "type": "string",
      "description": "ID of package selected"
    },
    "packageSelection": {
      "type": "object",
      "description": "Duration selection for package (game/day/weekend)"
    },
    "addOns": {
      "type": "array",
      "items": {"type": "object"},
      "description": "Array of selected add-ons with quantities"
    },
    "addOnSelections": {
      "type": "object",
      "description": "Duration selections for each add-on"
    },
    "eventId": {"type": "string"},
    "parkId": {"type": "string"},
    "fieldId": {"type": "string"},
    "spotId": {"type": "string"},
    "selectedSchedule": {
      "type": "object",
      "description": "Date/time selection"
    },
    "formData": {
      "type": "object",
      "description": "Customer info (name, phone, team, etc.)"
    },
    "status": {
      "type": "string",
      "enum": ["pending", "reminder_sent", "converted", "expired"],
      "default": "pending"
    },
    "lastUpdated": {
      "type": "string",
      "format": "date-time",
      "description": "Last time customer updated their selection"
    },
    "remindersSent": {
      "type": "integer",
      "default": 0
    },
    "lastReminderAt": {
      "type": "string",
      "format": "date-time"
    }
  },
  "required": ["sessionId", "customerEmail", "lastUpdated"]
}

Why This Structure:
• sessionId: Links to anonymous browsing session
• Stores complete booking state for restoration
• Tracks reminder email history
• Status tracking for conversion analytics`
          },
          {
            title: '2. Frontend Auto-Save Logic (pages/book-new.js)',
            content: `Implement debounced auto-save when email is entered:

Add useEffect Hook:

// Debounced save to AbandonedBookings
useEffect(() => {
  // Only save if customer has entered email
  if (!formData.contactEmail || !selectedPackage) return;
  
  // Debounce to avoid saving on every keystroke
  const timeoutId = setTimeout(async () => {
    try {
      const sessionId = sessionStorage.getItem('_session_id');
      
      // Check if already has a completed booking
      const existingBookings = await base44.entities.Bookings.filter({
        contactEmail: formData.contactEmail,
        status: ['paid', 'confirmed', 'setup']
      });
      
      // If they already booked, don't create abandoned record
      if (existingBookings.length > 0) return;
      
      // Find existing abandoned booking for this session/email
      const existing = await base44.entities.AbandonedBookings.filter({
        sessionId: sessionId,
        customerEmail: formData.contactEmail
      });
      
      const abandonedData = {
        sessionId,
        customerEmail: formData.contactEmail,
        packageId: selectedPackage?.id,
        packageSelection,
        addOns: selectedAddOns,
        addOnSelections,
        eventId: event?.id,
        parkId: selectedParkId,
        fieldId: selectedFieldId,
        spotId: selectedSpotId,
        selectedSchedule,
        formData,
        status: 'pending',
        lastUpdated: new Date().toISOString()
      };
      
      if (existing.length > 0) {
        // Update existing record
        await base44.entities.AbandonedBookings.update(
          existing[0].id,
          abandonedData
        );
      } else {
        // Create new record
        await base44.entities.AbandonedBookings.create(abandonedData);
      }
      
      console.log('Abandoned booking saved');
    } catch (error) {
      console.error('Failed to save abandoned booking:', error);
    }
  }, 2000); // Wait 2 seconds after last change
  
  return () => clearTimeout(timeoutId);
}, [
  formData.contactEmail,
  selectedPackage,
  packageSelection,
  selectedAddOns,
  addOnSelections,
  selectedParkId,
  selectedFieldId,
  selectedSpotId,
  selectedSchedule,
  event
]);

When This Runs:
• After customer enters email
• After selecting package
• After choosing add-ons
• After picking date/time/field
• Continuously updates as they progress
• Stops if they complete booking`
          },
          {
            title: '3. Backend Function: Send Abandoned Cart Emails',
            content: `Create functions/sendAbandonedBookingReminders.js:

Purpose:
• Scheduled function (runs every hour or daily)
• Finds abandoned bookings ready for reminder
• Checks they haven't completed booking
• Sends personalized reminder email
• Tracks reminder status

Function Logic:

import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import { Resend } from 'npm:resend@4.0.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Get pending abandoned bookings
    const now = new Date();
    const oneHourAgo = new Date(now.getTime() - (60 * 60 * 1000));
    const twentyFourHoursAgo = new Date(now.getTime() - (24 * 60 * 60 * 1000));
    
    const abandoned = await base44.asServiceRole.entities.AbandonedBookings.filter({
      status: 'pending'
    });
    
    const results = {
      checked: 0,
      sent: 0,
      converted: 0,
      expired: 0
    };
    
    for (const record of abandoned) {
      results.checked++;
      
      const lastUpdated = new Date(record.lastUpdated);
      
      // Skip if too recent (< 1 hour old)
      if (lastUpdated > oneHourAgo) continue;
      
      // Mark as expired if > 24 hours old
      if (lastUpdated < twentyFourHoursAgo) {
        await base44.asServiceRole.entities.AbandonedBookings.update(
          record.id,
          { status: 'expired' }
        );
        results.expired++;
        continue;
      }
      
      // Check if customer completed booking
      const completed = await base44.asServiceRole.entities.Bookings.filter({
        contactEmail: record.customerEmail,
        eventId: record.eventId,
        status: ['paid', 'confirmed', 'setup']
      });
      
      if (completed.length > 0) {
        await base44.asServiceRole.entities.AbandonedBookings.update(
          record.id,
          { status: 'converted' }
        );
        results.converted++;
        continue;
      }
      
      // Check if already sent reminder
      if (record.remindersSent >= 1) continue;
      
      // Get event and package details
      const event = record.eventId 
        ? await base44.asServiceRole.entities.Events.get(record.eventId).catch(() => null)
        : null;
        
      const pkg = record.packageId
        ? await base44.asServiceRole.entities.Packages.get(record.packageId).catch(() => null)
        : null;
      
      // Build resume link
      const resumeUrl = \`https://sideline-setups.com/book-new?event=\${record.eventId}&package=\${record.packageId}\`;
      
      // Send email
      const resend = new Resend(Deno.env.get('RESEND_API_KEY'));
      
      await resend.emails.send({
        from: 'Sideline Setups <noreply@sideline-setups.com>',
        to: record.customerEmail,
        subject: 'Complete Your Sideline Setups Booking 🏆',
        html: \`
          <h2>You're Almost Done!</h2>
          <p>Hi there,</p>
          <p>We noticed you started booking a setup for <strong>\${event?.name || 'your event'}</strong> but didn't finish.</p>
          
          <h3>Your Selection:</h3>
          <ul>
            <li>Package: \${pkg?.name || 'Selected package'}</li>
            \${record.selectedSchedule?.date ? \`<li>Date: \${record.selectedSchedule.date}</li>\` : ''}
            \${record.formData?.teamName ? \`<li>Team: \${record.formData.teamName}</li>\` : ''}
          </ul>
          
          <p><strong>Complete your booking in just 2 minutes:</strong></p>
          <a href="\${resumeUrl}" style="display: inline-block; padding: 14px 28px; background: #003f5c; color: white; text-decoration: none; border-radius: 8px; font-weight: 600;">
            Finish My Booking
          </a>
          
          <p style="margin-top: 24px; font-size: 13px; color: #64748b;">
            Questions? Reply to this email or call us at (903) 541-9287
          </p>
        \`
      });
      
      // Update record
      await base44.asServiceRole.entities.AbandonedBookings.update(record.id, {
        remindersSent: (record.remindersSent || 0) + 1,
        lastReminderAt: new Date().toISOString()
      });
      
      results.sent++;
    }
    
    return Response.json({
      success: true,
      results
    });
    
  } catch (error) {
    console.error('Abandoned booking reminder error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

Schedule This:
• Run every hour via cron
• Or daily at specific time
• Or trigger manually from admin dashboard`
          },
          {
            title: '4. Pre-fill Booking Page on Return',
            content: `When customer returns via reminder email:

Add to pages/book-new.js useEffect:

// Check for abandoned booking on page load
useEffect(() => {
  async function loadAbandonedBooking() {
    try {
      const sessionId = sessionStorage.getItem('_session_id');
      
      // Try to find abandoned booking for this session
      const abandoned = await base44.entities.AbandonedBookings.filter({
        sessionId: sessionId,
        status: 'pending'
      });
      
      if (abandoned.length > 0) {
        const record = abandoned[0];
        
        // Pre-fill all form fields
        setFormData(record.formData || {});
        
        // Pre-select package
        const pkg = packages.find(p => p.id === record.packageId);
        if (pkg) setSelectedPackage(pkg);
        
        // Restore duration selections
        if (record.packageSelection) {
          setPackageSelection(record.packageSelection);
        }
        
        // Restore add-ons
        if (record.addOns) {
          setSelectedAddOns(record.addOns);
        }
        
        if (record.addOnSelections) {
          setAddOnSelections(record.addOnSelections);
        }
        
        // Restore schedule
        if (record.selectedSchedule) {
          setSelectedSchedule(record.selectedSchedule);
        }
        
        // Restore park/field/spot
        if (record.parkId) setSelectedParkId(record.parkId);
        if (record.fieldId) setSelectedFieldId(record.fieldId);
        if (record.spotId) setSelectedSpotId(record.spotId);
        
        // Show notification
        setShowAbandonedNotice(true);
      }
    } catch (error) {
      console.error('Failed to load abandoned booking:', error);
    }
  }
  
  loadAbandonedBooking();
}, [packages]);

UI Notification:

{showAbandonedNotice && (
  <div style={{
    margin: '20px 0',
    padding: '16px',
    background: '#fef3c7',
    border: '2px solid #fbbf24',
    borderRadius: '12px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  }}>
    <div>
      <strong>👋 Welcome back!</strong>
      <p style={{ margin: '4px 0 0 0', fontSize: '14px', color: '#78350f' }}>
        We saved your selections. Continue where you left off!
      </p>
    </div>
    <button
      onClick={() => setShowAbandonedNotice(false)}
      style={{
        background: 'transparent',
        border: 'none',
        fontSize: '20px',
        cursor: 'pointer'
      }}
    >
      ×
    </button>
  </div>
)}`
          },
          {
            title: '5. Admin Dashboard for Abandoned Bookings',
            content: `Create components/admin/AdminAbandonedBookings.js:

Features:
• List all abandoned bookings
• Show customer email, package selected, last updated
• Show status (pending, reminder sent, converted)
• Manual actions:
  - Send reminder now
  - Mark as converted
  - Delete record
• Analytics:
  - Conversion rate
  - Average time to conversion
  - Most common abandonment points
  - Revenue recovered

Dashboard View:

Columns:
• Email
• Package
• Event
• Last Updated
• Reminders Sent
• Status
• Actions

Filters:
• Status (pending, reminder sent, etc.)
• Date range
• Event
• Package

Metrics Cards:
┌──────────────────────┐
│ Total Abandoned: 47  │
│ Reminders Sent: 23   │
│ Converted: 12 (26%)  │
│ Revenue Saved: $648  │
└──────────────────────┘

Manual Reminder:
<button onClick={() => sendReminderNow(record.id)}>
  Send Reminder Now
</button>

Implementation:
async function sendReminderNow(recordId) {
  try {
    await base44.functions.invoke('sendSingleAbandonedReminder', {
      recordId
    });
    alert('Reminder sent!');
    loadData();
  } catch (error) {
    alert('Failed: ' + error.message);
  }
}`
          },
          {
            title: '6. Conversion Tracking',
            content: `Track when abandoned bookings convert:

In pages/book-new.js handlePaymentSuccess:

// After booking is created successfully
if (formData.contactEmail) {
  try {
    // Mark any abandoned bookings as converted
    const sessionId = sessionStorage.getItem('_session_id');
    const abandoned = await base44.entities.AbandonedBookings.filter({
      customerEmail: formData.contactEmail,
      status: ['pending', 'reminder_sent']
    });
    
    for (const record of abandoned) {
      await base44.entities.AbandonedBookings.update(record.id, {
        status: 'converted',
        convertedAt: new Date().toISOString(),
        convertedBookingId: createdBooking.id
      });
    }
  } catch (error) {
    console.error('Failed to update abandoned bookings:', error);
    // Don't block booking completion
  }
}

Analytics Benefits:
• Track which reminders led to conversions
• Calculate ROI of reminder emails
• Identify best timing for reminders
• Optimize email content based on conversion rate`
          },
          {
            title: '7. Reminder Email Templates',
            content: `Multiple email variations for A/B testing:

Template 1: Simple & Direct
Subject: "Complete Your Booking - It Only Takes 2 Minutes"

Hi there,

You started booking a setup for [Event Name] but didn't finish.

Your selections are saved and ready to go:
• Package: [Package Name]
• Date: [Date]
• Add-ons: [List]

[Complete My Booking]

Questions? Call us at (903) 541-9287

Template 2: Urgency-Focused
Subject: "Don't Miss Out - Finish Your Booking Before Spots Fill Up"

Hi!

We saved your spot, but it won't last forever!

📦 Your Setup: [Package Name]
📅 Your Date: [Date]
⏰ Time to Complete: 2 minutes

Spots are filling fast for this event. Secure yours now:
[Finish Booking & Save My Spot]

Template 3: Incentive-Based
Subject: "🎁 Complete Your Booking & Get 100 Bonus Points!"

Hi there,

Almost there! Complete your booking in the next 24 hours and we'll add 100 bonus loyalty points to your account (a $10 value).

Your Selections:
✓ [Package Name]
✓ [Event Name] on [Date]

[Claim My Bonus & Complete Booking]

*Bonus expires in 24 hours

Template Timing:
• First reminder: 1 hour after abandonment
• Second reminder: 24 hours after abandonment
• Maximum: 2 reminders per customer`
          },
          {
            title: '8. Best Practices & Optimization',
            content: `Key Success Factors:

Timing:
• Send first reminder 30-60 minutes after abandonment
• Not too soon (they might still be deciding)
• Not too late (they've forgotten)
• Stop after 2 reminders (avoid spam)

Personalization:
• Use customer name if captured
• Reference specific package and event
• Include total price
• Show what they'll get

Easy Return:
• One-click link back to booking
• Auto-fill all their selections
• Skip straight to payment
• No friction to complete

Exclude Converters:
• Don't send if they already booked
• Check against completed bookings
• Mark as converted immediately
• Prevents annoying duplicate emails

Analytics:
• Track open rates
• Track click-through rates
• Track conversion rates
• A/B test subject lines
• Test different send times
• Optimize based on data

Privacy:
• Allow unsubscribe from reminders
• Honor email preferences
• Don't store sensitive data unnecessarily
• Comply with CAN-SPAM and GDPR

Cleanup:
• Delete expired records after 7 days
• Delete converted records after 30 days
• Keep aggregate stats only

Red Flags to Monitor:
• High abandonment at specific step → UX issue
• Low email open rates → subject line problem
• Low conversion rates → offer not compelling
• Many "unsubscribe" → sending too many reminders`
          }
        ],
        notes: [
          'Focus on high-intent abandoners (reached payment page)',
          'Test different email timings and content',
          'Consider SMS reminders for even better recovery',
          'Add incentives like "10% off if you book today"',
          'Track which steps have highest abandonment',
          'May want to survey abandoners to understand why',
          'Consider offering phone call for high-value abandonments',
          'Integrate with CRM to segment reminder strategy'
        ]
      }
    },
    {
      key: 'in-app-messaging',
      title: 'In-App Messaging System',
      description: 'Direct communication between customers and administrators regarding bookings, with message history and notifications.',
      details: {
        overview: 'Build a messaging system that allows customers to communicate directly with staff about their bookings or general inquiries. This reduces email/phone support load, keeps all communication in one place, and provides better customer service through real-time responses.',
        components: [
          {
            title: '1. Database Schema - Two Entity Approach',
            content: `Create entities/Conversations.json:

{
  "name": "Conversations",
  "type": "object",
  "description": "Message thread metadata",
  "properties": {
    "bookingId": {
      "type": "string",
      "description": "Optional link to specific booking"
    },
    "customerId": {
      "type": "string",
      "description": "Customer involved in conversation"
    },
    "customerEmail": {
      "type": "string",
      "description": "Customer email for easy lookup"
    },
    "subject": {
      "type": "string",
      "description": "Conversation subject or first message preview"
    },
    "status": {
      "type": "string",
      "enum": ["open", "pending_customer", "pending_admin", "resolved", "closed"],
      "default": "open"
    },
    "priority": {
      "type": "string",
      "enum": ["low", "normal", "high", "urgent"],
      "default": "normal"
    },
    "lastMessageAt": {
      "type": "string",
      "format": "date-time"
    },
    "lastCustomerReadAt": {
      "type": "string",
      "format": "date-time"
    },
    "lastAdminReadAt": {
      "type": "string",
      "format": "date-time"
    },
    "unreadByCustomer": {
      "type": "integer",
      "default": 0
    },
    "unreadByAdmin": {
      "type": "integer",
      "default": 0
    }
  }
}

Create entities/Messages.json:

{
  "name": "Messages",
  "type": "object",
  "description": "Individual messages in conversations",
  "properties": {
    "conversationId": {
      "type": "string",
      "description": "Parent conversation"
    },
    "senderId": {
      "type": "string",
      "description": "Who sent this (customer ID or employee ID)"
    },
    "senderType": {
      "type": "string",
      "enum": ["customer", "admin", "system"],
      "description": "Type of sender"
    },
    "senderName": {
      "type": "string",
      "description": "Display name of sender"
    },
    "content": {
      "type": "string",
      "description": "Message text"
    },
    "isRead": {
      "type": "boolean",
      "default": false
    },
    "readAt": {
      "type": "string",
      "format": "date-time"
    },
    "attachments": {
      "type": "array",
      "items": {"type": "string"},
      "default": [],
      "description": "Array of file URLs"
    }
  },
  "required": ["conversationId", "senderId", "senderType", "content"]
}`
          },
          {
            title: '2. Backend Functions for Messaging',
            content: `Create functions/messages/createConversation.js:

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const { customerEmail, subject, firstMessage, bookingId } = await req.json();
  
  // Create conversation
  const conversation = await base44.asServiceRole.entities.Conversations.create({
    customerEmail,
    subject,
    status: 'open',
    bookingId,
    lastMessageAt: new Date().toISOString(),
    unreadByAdmin: 1
  });
  
  // Create first message
  await base44.asServiceRole.entities.Messages.create({
    conversationId: conversation.id,
    senderId: customerEmail,
    senderType: 'customer',
    senderName: 'Customer',
    content: firstMessage
  });
  
  // Notify admins of new conversation
  await base44.functions.invoke('notifyNewMessage', {
    conversationId: conversation.id
  });
  
  return Response.json({ conversation });
});

Create functions/messages/sendMessage.js:

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const { conversationId, senderId, senderType, content } = await req.json();
  
  // Create message
  const message = await base44.asServiceRole.entities.Messages.create({
    conversationId,
    senderId,
    senderType,
    content
  });
  
  // Update conversation
  await base44.asServiceRole.entities.Conversations.update(conversationId, {
    lastMessageAt: new Date().toISOString(),
    status: senderType === 'customer' ? 'pending_admin' : 'pending_customer',
    unreadByAdmin: senderType === 'customer' ? 1 : 0,
    unreadByCustomer: senderType === 'admin' ? 1 : 0
  });
  
  // Send notification
  await base44.functions.invoke('notifyNewMessage', {
    conversationId,
    messageId: message.id
  });
  
  return Response.json({ message });
});

Create functions/messages/markAsRead.js:

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const { conversationId, readerType } = await req.json();
  
  const updateData = readerType === 'customer' 
    ? { lastCustomerReadAt: new Date().toISOString(), unreadByCustomer: 0 }
    : { lastAdminReadAt: new Date().toISOString(), unreadByAdmin: 0 };
  
  await base44.asServiceRole.entities.Conversations.update(
    conversationId,
    updateData
  );
  
  return Response.json({ success: true });
});`
          },
          {
            title: '3. Customer-Facing Message Interface',
            content: `Create pages/Messages.js (or integrate into /mybookings):

import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Send, MessageCircle, Clock } from "lucide-react";

export default function Messages() {
  const [conversations, setConversations] = useState([]);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [session, setSession] = useState(null);

  useEffect(() => {
    // Get customer session
    const custSession = JSON.parse(
      sessionStorage.getItem("customer.session") || "null"
    );
    setSession(custSession);
    
    if (custSession) {
      loadConversations(custSession.email);
    }
  }, []);

  async function loadConversations(email) {
    const convos = await base44.entities.Conversations.filter({
      customerEmail: email
    });
    setConversations(convos || []);
  }

  async function loadMessages(conversationId) {
    const msgs = await base44.entities.Messages.filter({
      conversationId
    });
    setMessages(msgs || []);
    
    // Mark as read
    await base44.functions.invoke('messages/markAsRead', {
      conversationId,
      readerType: 'customer'
    });
  }

  async function sendMessage() {
    if (!newMessage.trim()) return;
    
    await base44.functions.invoke('messages/sendMessage', {
      conversationId: selectedConversation.id,
      senderId: session.email,
      senderType: 'customer',
      content: newMessage
    });
    
    setNewMessage("");
    loadMessages(selectedConversation.id);
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '300px 1fr', height: '80vh' }}>
      {/* Conversation List */}
      <div style={{ borderRight: '1px solid #e2e8f0', padding: '16px' }}>
        <h2>Messages</h2>
        {conversations.map(convo => (
          <div
            key={convo.id}
            onClick={() => {
              setSelectedConversation(convo);
              loadMessages(convo.id);
            }}
            style={{
              padding: '12px',
              borderRadius: '8px',
              cursor: 'pointer',
              background: selectedConversation?.id === convo.id ? '#f0f9ff' : 'white',
              marginBottom: '8px'
            }}
          >
            <div style={{ fontWeight: '600' }}>{convo.subject}</div>
            <div style={{ fontSize: '12px', color: '#64748b' }}>
              {convo.unreadByCustomer > 0 && (
                <span style={{ color: '#10b981', fontWeight: '600' }}>
                  {convo.unreadByCustomer} new
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Message Thread */}
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {selectedConversation ? (
          <>
            {/* Messages */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '20px' }}>
              {messages.map(msg => (
                <div
                  key={msg.id}
                  style={{
                    display: 'flex',
                    justifyContent: msg.senderType === 'customer' ? 'flex-end' : 'flex-start',
                    marginBottom: '16px'
                  }}
                >
                  <div style={{
                    maxWidth: '70%',
                    padding: '12px 16px',
                    borderRadius: '12px',
                    background: msg.senderType === 'customer' ? '#003f5c' : '#f8fafc',
                    color: msg.senderType === 'customer' ? 'white' : '#0f172a'
                  }}>
                    <div>{msg.content}</div>
                    <div style={{ 
                      fontSize: '11px', 
                      marginTop: '6px',
                      opacity: 0.7 
                    }}>
                      {new Date(msg.created_date).toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Input */}
            <div style={{ 
              padding: '16px', 
              borderTop: '1px solid #e2e8f0',
              display: 'flex',
              gap: '12px'
            }}>
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                placeholder="Type your message..."
                style={{ flex: 1 }}
              />
              <button onClick={sendMessage} className="btn">
                <Send size={18} />
              </button>
            </div>
          </>
        ) : (
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            height: '100%',
            color: '#94a3b8'
          }}>
            Select a conversation to view messages
          </div>
        )}
      </div>
    </div>
  );
}`
          },
          {
            title: '4. Admin Message Interface',
            content: `Add to pages/Admin.js navigation and create admin view:

Similar to customer interface but:
• See ALL conversations from all customers
• Filter by status (open, pending, resolved)
• Search by customer email or booking ID
• Quick actions:
  - View booking details
  - Mark as resolved
  - Assign to staff member
  - Set priority
  - Add internal notes

Additional Features:
• Unread message counter in header
• Audio/visual notification for new messages
• Canned responses for common questions
• Link to booking from conversation
• View customer's booking history

Queue Management:
• Sort by newest unread first
• Filter by priority
• Show average response time
• Track resolution time`
          },
          {
            title: '5. Notification System',
            content: `Notify users of new messages:

Create functions/notifyNewMessage.js:

Purpose:
• Send email when new message arrives
• Send SMS for urgent messages (optional)
• Create in-app notification badge

Email Notification (to Admin):
Subject: "New Message from Customer - [Subject]"

Body:
A customer sent you a message:

From: [Customer Name] ([Email])
Re: [Subject]
Booking: [Booking ID] (if applicable)

Message:
"[First 200 chars of message...]"

[Reply in Dashboard]

Email Notification (to Customer):
Subject: "New Reply from Sideline Setups"

Body:
Hi [Name],

We responded to your message about "[Subject]":

"[First 200 chars of reply...]"

[View Full Conversation]

Real-Time Updates:
• Poll for new messages every 10 seconds
• Or use WebSockets for instant updates (advanced)
• Show badge with unread count
• Play subtle sound for new message
• Browser notification API (with permission)`
          },
          {
            title: '6. Message Templates & Automation',
            content: `Create entities/MessageTemplates.json for canned responses:

{
  "name": "MessageTemplates",
  "type": "object",
  "properties": {
    "title": {"type": "string"},
    "content": {"type": "string"},
    "category": {
      "type": "string",
      "enum": ["booking_change", "weather", "payment", "general"]
    }
  }
}

Common Templates:
• "How to change your booking date"
• "Weather policy explanation"
• "Payment issue resolution"
• "Setup location details"

Admin UI:
• Dropdown of templates during reply
• Click to insert template
• Personalize before sending
• Variables: {{customerName}}, {{bookingId}}, etc.

Automation:
• Auto-respond to "Where's my booking?" with booking details
• Auto-respond to "How do I cancel?" with cancellation link
• Flag complex questions for human review`
          },
          {
            title: '7. Integration Points',
            content: `Integrate messaging throughout the app:

1. My Bookings Page:
• "Message Support" button on each booking
• Opens conversation about that specific booking
• Pre-fills booking ID and basic details

2. Thank You Page:
• "Have questions about your booking?" CTA
• Quick start conversation
• Reduces inbound calls/emails

3. Check-In Process:
• "Need help?" message button
• Instant support during check-in
• Reduces staff interruptions

4. Admin Bookings Page:
• "Message Customer" button on each booking
• Proactive outreach
• Quick clarification requests

5. Header Notification:
• Bell icon with unread count
• Dropdown preview of recent messages
• Link to full messages page

6. Mobile App (Future):
• Push notifications
• Real-time messaging
• Photo attachments`
          },
          {
            title: '8. Implementation Phases',
            content: `Phased Rollout:

Phase 1 - MVP (Week 1-2):
✓ Create Conversations and Messages entities
✓ Backend functions (create, send, markAsRead)
✓ Basic customer UI (pages/Messages.js)
✓ Basic admin UI in Admin dashboard
✓ Email notifications

Phase 2 - Enhanced UX (Week 3):
✓ Unread message badges
✓ Real-time polling
✓ Message templates
✓ Search and filter
✓ Mobile-responsive design

Phase 3 - Integration (Week 4):
✓ Add to My Bookings page
✓ Add to Admin Bookings page
✓ Add to Thank You page
✓ Header notification icon

Phase 4 - Advanced (Week 5+):
✓ File attachments
✓ Typing indicators
✓ WebSocket real-time updates
✓ Conversation assignment to staff
✓ Internal notes
✓ Analytics dashboard

Testing Checklist:
☐ Create conversation as customer
☐ Send message as customer
☐ Receive and reply as admin
☐ Mark conversation as resolved
☐ Reopen resolved conversation
☐ Test email notifications
☐ Test unread counters
☐ Test on mobile devices
☐ Verify data persistence
☐ Load test with multiple conversations`
          }
        ],
        notes: [
          'Start with simple polling, add WebSockets later for real-time',
          'Consider rate limiting to prevent spam',
          'Add profanity filter for customer messages',
          'Allow customers to attach photos (ID issues, equipment damage)',
          'Track average response time and set SLA goals',
          'Consider chatbot for common questions before human escalation',
          'Add "Mark as spam" feature for abuse',
          'Export message history to CSV for compliance',
          'Consider adding video call integration for complex issues',
          'Integrate with CRM to track all customer touchpoints'
        ]
      }
    },
    {
      key: 'paypal-auth-capture',
      title: 'PayPal Authorization & Capture for Rentals',
      description: 'Implement PayPal\'s "Authorize & Capture" flow to hold funds at booking but only charge after equipment is returned safely.',
      details: {
        overview: 'Currently, PayPal immediately captures payment when a booking is made. For a rental business, it\'s better to only authorize (hold) the funds initially, then capture them after the rental period ends and equipment is returned in good condition. This protects both the business and the customer.',
        components: [
          {
            title: 'Phase 1: Update PayPal Create Order Function',
            content: `Modify functions/paypalCreateOrder.js:

Current Code:
intent: 'CAPTURE'

Change To:
intent: 'AUTHORIZE'

This simple change makes PayPal only place a hold on funds instead of immediately transferring them.

Important Notes:
- PayPal authorizations are valid for 3 days by default (can be extended to 29 days)
- For weekend tournaments, 3 days is usually enough
- For longer rentals, you may need to implement "reauthorization" or capture sooner
- Authorization shows as "pending" on customer's card/account`
          },
          {
            title: 'Phase 2: Update Frontend Booking Flow',
            content: `Modify pages/book-new.js (handlePaymentSuccess function):

Current Logic:
payment: { 
  provider: "paypal", 
  status: "captured", 
  orderId: paypalOrderId 
}

Change To:
payment: { 
  provider: "paypal", 
  status: "authorized",  // Changed from "captured"
  orderId: paypalOrderId,
  authorizedAt: new Date().toISOString()
}

Update Booking Status:
- Keep status as "pending" until authorization is captured
- Or create new status "authorized" to distinguish from fully paid bookings

Customer Communication:
- Update confirmation email to mention funds are on hold
- Explain they won't be charged until after the event
- Clarify the hold will appear on their statement`
          },
          {
            title: 'Phase 3: New Backend Function - Capture Payment',
            content: `Create functions/paypalCaptureAuthorizedPayment.js:

import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

async function getPayPalAccessToken() {
  const PAYPAL_CLIENT_ID = Deno.env.get("PAYPAL_CLIENT_ID");
  const PAYPAL_CLIENT_SECRET = Deno.env.get("PAYPAL_CLIENT_SECRET");
  const PAYPAL_MODE = Deno.env.get("PAYPAL_MODE") || "sandbox";
  const baseURL = PAYPAL_MODE === "live" 
    ? "https://api-m.paypal.com" 
    : "https://api-m.sandbox.paypal.com";

  const auth = btoa(\`\${PAYPAL_CLIENT_ID}:\${PAYPAL_CLIENT_SECRET}\`);
  
  const response = await fetch(\`\${baseURL}/v1/oauth2/token\`, {
    method: "POST",
    headers: {
      "Authorization": \`Basic \${auth}\`,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: "grant_type=client_credentials"
  });

  const data = await response.json();
  return data.access_token;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Only admins/staff should be able to capture
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const { bookingId } = await req.json();
    
    if (!bookingId) {
      return Response.json({ 
        error: 'Missing bookingId' 
      }, { status: 400 });
    }
    
    // Get booking
    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    
    if (!booking) {
      return Response.json({ 
        error: 'Booking not found' 
      }, { status: 404 });
    }
    
    if (booking.payment?.status !== 'authorized') {
      return Response.json({ 
        error: \`Cannot capture payment with status: \${booking.payment?.status}\` 
      }, { status: 400 });
    }
    
    const paypalOrderId = booking.payment.orderId;
    
    // Get PayPal access token
    const accessToken = await getPayPalAccessToken();
    
    const PAYPAL_MODE = Deno.env.get("PAYPAL_MODE") || "sandbox";
    const baseURL = PAYPAL_MODE === "live" 
      ? "https://api-m.paypal.com" 
      : "https://api-m.sandbox.paypal.com";
    
    // Capture the authorization
    const captureResponse = await fetch(
      \`\${baseURL}/v2/checkout/orders/\${paypalOrderId}/capture\`,
      {
        method: "POST",
        headers: {
          "Authorization": \`Bearer \${accessToken}\`,
          "Content-Type": "application/json"
        }
      }
    );
    
    const captureData = await captureResponse.json();
    
    if (!captureResponse.ok) {
      console.error("PayPal capture failed:", captureData);
      return Response.json({ 
        error: captureData.message || 'Capture failed',
        details: captureData
      }, { status: captureResponse.status });
    }
    
    // Extract capture ID
    const captureId = captureData.purchase_units?.[0]?.payments?.captures?.[0]?.id;
    
    // Update booking
    await base44.asServiceRole.entities.Bookings.update(bookingId, {
      payment: {
        ...booking.payment,
        status: 'captured',
        capturedAt: new Date().toISOString(),
        captureId: captureId
      },
      status: 'completed' // Or whatever final status you use
    });
    
    // Send receipt email
    await base44.functions.invoke('notifyBookingCompleted', { 
      bookingId 
    });
    
    return Response.json({
      success: true,
      captureId,
      message: 'Payment captured successfully'
    });
    
  } catch (error) {
    console.error('Error capturing payment:', error);
    return Response.json({ 
      error: error.message 
    }, { status: 500 });
  }
});

When to Call This:
- After equipment is returned and checked
- When booking status changes to "returned" or "completed"
- From admin dashboard manually
- Automatically via a scheduled job (e.g., 1 day after event ends)`
          },
          {
            title: 'Phase 4: New Backend Function - Void Authorization',
            content: `Create functions/paypalVoidAuthorization.js:

import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

// Reuse getPayPalAccessToken from previous example

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Only admins should void authorizations
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const { bookingId, reason } = await req.json();
    
    if (!bookingId) {
      return Response.json({ 
        error: 'Missing bookingId' 
      }, { status: 400 });
    }
    
    // Get booking
    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    
    if (!booking) {
      return Response.json({ 
        error: 'Booking not found' 
      }, { status: 404 });
    }
    
    if (booking.payment?.status !== 'authorized') {
      return Response.json({ 
        error: \`Cannot void payment with status: \${booking.payment?.status}\` 
      }, { status: 400 });
    }
    
    const paypalOrderId = booking.payment.orderId;
    
    // Get PayPal access token
    const accessToken = await getPayPalAccessToken();
    
    const PAYPAL_MODE = Deno.env.get("PAYPAL_MODE") || "sandbox";
    const baseURL = PAYPAL_MODE === "live" 
      ? "https://api-m.paypal.com" 
      : "https://api-m.sandbox.paypal.com";
    
    // Note: To void an authorization, we need the authorization ID
    // Get order details first to find the authorization ID
    const orderResponse = await fetch(
      \`\${baseURL}/v2/checkout/orders/\${paypalOrderId}\`,
      {
        headers: {
          "Authorization": \`Bearer \${accessToken}\`,
          "Content-Type": "application/json"
        }
      }
    );
    
    const orderData = await orderResponse.json();
    const authorizationId = orderData.purchase_units?.[0]?.payments?.authorizations?.[0]?.id;
    
    if (!authorizationId) {
      return Response.json({ 
        error: 'Authorization ID not found' 
      }, { status: 400 });
    }
    
    // Void the authorization
    const voidResponse = await fetch(
      \`\${baseURL}/v2/payments/authorizations/\${authorizationId}/void\`,
      {
        method: "POST",
        headers: {
          "Authorization": \`Bearer \${accessToken}\`,
          "Content-Type": "application/json"
        }
      }
    );
    
    if (!voidResponse.ok) {
      const voidError = await voidResponse.json();
      console.error("PayPal void failed:", voidError);
      return Response.json({ 
        error: voidError.message || 'Void failed',
        details: voidError
      }, { status: voidResponse.status });
    }
    
    // Update booking
    await base44.asServiceRole.entities.Bookings.update(bookingId, {
      payment: {
        ...booking.payment,
        status: 'voided',
        voidedAt: new Date().toISOString(),
        voidReason: reason
      },
      status: 'cancelled'
    });
    
    // Notify customer
    // TODO: Send cancellation email
    
    return Response.json({
      success: true,
      message: 'Authorization voided successfully'
    });
    
  } catch (error) {
    console.error('Error voiding authorization:', error);
    return Response.json({ 
      error: error.message 
    }, { status: 500 });
  }
});

When to Call This:
- When a booking is cancelled before the event
- When customer requests cancellation
- When equipment is damaged and you need to charge differently`
          },
          {
            title: 'Phase 5: Admin Dashboard Integration',
            content: `Update pages/AdminBookings.js:

Add new action buttons for authorized bookings:

{booking.payment?.status === 'authorized' && (
  <div style={{ display: 'flex', gap: '8px' }}>
    <button
      onClick={() => handleCapturePayment(booking.id)}
      className="btn"
      style={{ fontSize: '12px', padding: '6px 12px' }}
    >
      💳 Capture Payment
    </button>
    <button
      onClick={() => handleVoidAuthorization(booking.id)}
      className="btn-danger"
      style={{ fontSize: '12px', padding: '6px 12px' }}
    >
      ❌ Void Authorization
    </button>
  </div>
)}

Add handler functions:

async function handleCapturePayment(bookingId) {
  if (!confirm('Capture payment for this booking? Customer will be charged.')) {
    return;
  }
  
  setProcessingId(bookingId);
  
  try {
    const response = await base44.functions.invoke('paypalCaptureAuthorizedPayment', {
      bookingId
    });
    
    if (response.data.success) {
      alert('✅ Payment captured successfully!');
      await loadBookings();
    } else {
      alert('❌ Capture failed: ' + response.data.error);
    }
  } catch (error) {
    alert('❌ Error: ' + error.message);
  } finally {
    setProcessingId(null);
  }
}

async function handleVoidAuthorization(bookingId) {
  const reason = prompt('Reason for voiding authorization?');
  
  if (!reason) return;
  
  setProcessingId(bookingId);
  
  try {
    const response = await base44.functions.invoke('paypalVoidAuthorization', {
      bookingId,
      reason
    });
    
    if (response.data.success) {
      alert('✅ Authorization voided successfully!');
      await loadBookings();
    } else {
      alert('❌ Void failed: ' + response.data.error);
    }
  } catch (error) {
    alert('❌ Error: ' + error.message);
  } finally {
    setProcessingId(null);
  }
}

Visual Indicators:
- Show "AUTHORIZED (PENDING)" badge for authorized payments
- Show "CAPTURED (PAID)" badge for captured payments
- Show warning icon for authorizations older than 2 days
- Add countdown timer for expiring authorizations`
          },
          {
            title: 'Phase 6: Automated Capture Workflow',
            content: `Option A: Manual Capture (Recommended for MVP)
- Staff manually captures payment after equipment return check
- Gives maximum control
- Works well for small scale

Option B: Scheduled Auto-Capture
Create functions/autoCapturePendingPayments.js:

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Get all authorized bookings where event ended 1+ days ago
    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - (24 * 60 * 60 * 1000));
    
    const bookings = await base44.asServiceRole.entities.Bookings.filter({
      'payment.status': 'authorized',
      status: 'completed' // Or 'returned'
    });
    
    const results = {
      processed: 0,
      captured: 0,
      failed: 0,
      errors: []
    };
    
    for (const booking of bookings) {
      // Check if event was at least 1 day ago
      const eventDate = new Date(booking.date);
      
      if (eventDate < oneDayAgo) {
        results.processed++;
        
        try {
          const response = await base44.functions.invoke('paypalCaptureAuthorizedPayment', {
            bookingId: booking.id
          });
          
          if (response.data.success) {
            results.captured++;
          } else {
            results.failed++;
            results.errors.push({
              bookingId: booking.id,
              error: response.data.error
            });
          }
        } catch (error) {
          results.failed++;
          results.errors.push({
            bookingId: booking.id,
            error: error.message
          });
        }
      }
    }
    
    return Response.json({
      success: true,
      results
    });
    
  } catch (error) {
    console.error('Auto-capture error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

Schedule this to run daily via:
- Cron job
- Manual trigger from admin dashboard
- Base44 scheduled functions (if available)`
          },
          {
            title: 'Phase 7: Customer Communication Updates',
            content: `Update Booking Confirmation Email:

Subject: Booking Confirmed - Authorization Hold Placed

Body:
Hi [Name],

Your booking is confirmed! 

🎉 Booking Details:
- Event: [Event Name]
- Date: [Date]
- Package: [Package Name]
- Location: [Park/Field]

💳 Payment Authorization:
We've placed a hold on your payment method for $[Amount]. 
You will NOT be charged until after your event is complete 
and equipment is returned in good condition.

What this means:
- The hold may show as "pending" on your card
- Funds are reserved but not yet transferred
- Final charge happens within 24 hours after your event
- You'll receive a receipt email once payment is processed

Questions? Reply to this email or text us at [Phone].

Thanks for choosing Sideline Setups!

---

Create New Email: Payment Captured

Subject: Payment Processed - Thank You!

Body:
Hi [Name],

Your rental has been completed and payment has been processed.

Receipt Details:
- Amount Charged: $[Amount]
- Date: [Date]
- Booking ID: [ID]

Thank you for returning all equipment in good condition!

We hope you had a great experience. Book again soon!`
          },
          {
            title: 'Phase 8: Testing Checklist',
            content: `PayPal Sandbox Testing Steps:

1. Test Authorization:
   ✓ Create booking with PayPal
   ✓ Verify payment.status = "authorized"
   ✓ Check PayPal sandbox dashboard shows authorization
   ✓ Confirm customer receives "hold placed" email

2. Test Capture:
   ✓ Click "Capture Payment" in admin
   ✓ Verify payment.status = "captured"
   ✓ Check PayPal sandbox shows completed transaction
   ✓ Confirm customer receives receipt email

3. Test Void:
   ✓ Create booking, authorize payment
   ✓ Click "Void Authorization" before capture
   ✓ Verify payment.status = "voided"
   ✓ Check PayPal sandbox shows voided authorization
   ✓ Confirm customer receives cancellation email

4. Test Authorization Expiration:
   ✓ Create authorization in sandbox
   ✓ Wait 3 days (or use PayPal's time travel feature)
   ✓ Verify expired authorizations are handled gracefully
   ✓ Test reauthorization flow if needed

5. Edge Cases:
   ✓ Try capturing already-captured payment (should fail)
   ✓ Try voiding already-captured payment (should fail)
   ✓ Try capturing after authorization expires
   ✓ Test with different amounts (partial capture?)
   ✓ Test error handling for network failures

PayPal Sandbox URLs:
- Dashboard: https://www.sandbox.paypal.com
- Create test accounts: https://developer.paypal.com/dashboard/accounts`
          }
        ],
        notes: [
          'PayPal authorizations expire after 3 days by default (can extend to 29 days)',
          'Authorization shows as "pending" on customer\'s statement',
          'You can only capture once - cannot do partial captures with this flow',
          'If authorization expires, you\'ll need to request a new payment',
          'Consider adding a "reauthorize" flow for long-term rentals',
          'Authorization amounts can be adjusted up to 115% of original (for damages)',
          'Always test in PayPal sandbox before going live',
          'Document your capture timing policy clearly for customers',
          'Consider insurance or deposits for high-value equipment',
          'Monitor expiring authorizations and capture before they expire'
        ]
      }
    },
    {
      key: 'ai-customer-assistant',
      title: 'AI Customer Support Assistant',
      description: 'Implement an AI-powered assistant to answer customer questions using InvokeLLM integration and FAQ knowledge base.',
      details: {
        overview: 'Add an intelligent AI assistant that can answer customer questions about bookings, packages, events, and policies. The AI will be trained on your FAQ content and site settings, providing instant support 24/7 while reducing support ticket volume.',
        components: [
          {
            title: '1. Determine AI Assistant Placement and UI',
            content: `Choose Location Options:

Option A: Dedicated "Ask AI" Page (Simplest - Recommended for MVP)
• Create new page: pages/AskAI.js
• Add link in footer or navigation
• URL: /ask-ai or /help

Option B: Persistent Chat Widget
• Floating button in bottom-right corner
• Expands into chat interface
• Available on all customer-facing pages
• More complex but better UX

Option C: Integrated into FAQ Page
• Add "Ask AI" button at top of FAQ page
• If customer doesn't find answer, they can ask AI
• Good contextual placement

Option D: Multiple Entry Points
• Add to booking flow (help during checkout)
• Add to My Bookings page (booking-specific questions)
• Add to general FAQ page

Recommended Start: Option A (dedicated page), then expand to other entry points

UI Components Needed:

1. Input Section:
• Large text area for customer question
• Placeholder: "Ask me anything about Sideline Setups..."
• Character limit indicator (e.g., 500 chars)
• Submit button styled as primary CTA

2. Response Display:
• Chat-like interface showing conversation history
• Customer questions in one color/style
• AI responses in another color/style
• Timestamp for each message
• Markdown rendering for formatted responses

3. Loading State:
• Animated "AI is thinking..." indicator
• Progress dots or spinner
• Prevents multiple simultaneous submissions

4. Error Handling:
• User-friendly error messages
• "Try again" button
• Fallback to human support contact info

5. Suggested Questions:
• Pre-populated question buttons
• Common questions customers ask
• Clicking auto-fills the input
• Examples:
  - "How do I change my booking?"
  - "What's included in the MVP package?"
  - "How early should I arrive?"
  - "What if it rains?"

6. Conversation Controls:
• "Clear Chat" button
• "New Conversation" button
• Copy response to clipboard
• Rate response (thumbs up/down)`
          },
          {
            title: '2. Backend Integration with InvokeLLM',
            content: `Create Frontend Handler:

In pages/AskAI.js:

async function askAI(question) {
  setLoading(true);
  setError(null);
  
  try {
    // Fetch context data
    const [faqs, settings] = await Promise.all([
      base44.entities.FAQ.filter({ isActive: true }),
      base44.entities.SiteSettings.list()
    ]);
    
    // Build context string
    const faqContext = faqs.map(faq => 
      \`Q: \${faq.question}\\nA: \${faq.answer}\`
    ).join('\\n\\n');
    
    const siteSetting = settings[0] || {};
    
    // Construct prompt
    const prompt = \`You are a helpful customer service assistant for \${siteSetting.brandName || 'Sideline Setups'}. Your goal is to answer questions about our services, bookings, events, packages, and general policies. Keep your answers concise (under 200 words), accurate, and friendly. If you don't know the answer, politely state that you cannot assist with that specific query and suggest contacting human support.

Important Guidelines:
- Be conversational and warm
- Use bullet points for lists
- Bold important information
- If asked about pricing, always mention packages may vary
- For booking changes, direct to My Bookings page or support
- Never make up information

Context about our services (from FAQ):
\${faqContext}

Contact Information:
- Support Email: \${siteSetting.supportEmail || 'support@sideline-setups.com'}
- Support Phone: \${siteSetting.supportPhone || ''}
- Website: \${window.location.origin}

Previous conversation:
\${conversationHistory}

Customer Question: \${question}\`;

    // Call InvokeLLM
    const response = await base44.integrations.Core.InvokeLLM({
      prompt: prompt,
      add_context_from_internet: false // Keep focused on our data
    });
    
    // Add to conversation history
    setConversation(prev => [...prev, {
      type: 'question',
      text: question,
      timestamp: new Date()
    }, {
      type: 'answer',
      text: response,
      timestamp: new Date()
    }]);
    
  } catch (error) {
    setError('Sorry, I encountered an error. Please try again or contact support.');
    console.error('AI Error:', error);
  } finally {
    setLoading(false);
  }
}

Key Parameters:

• prompt: Detailed instructions + context + question
• add_context_from_internet: false (rely on our data)
• response_json_schema: undefined (simple string response)

Why add_context_from_internet is false:
• We want answers specific to OUR app
• Internet context might be generic or wrong
• Faster responses without web search
• Lower cost per query

When to set it to true:
• If customer asks about sports rules
• If asking about weather/location info
• General knowledge questions outside our domain
• Could add logic to detect question type`
          },
          {
            title: '3. Providing Context to the AI (Knowledge Base)',
            content: `Dynamic Knowledge Base Strategy:

1. FAQ Entity as Primary Source:
• Fetch all active FAQ entries: entities.FAQ.filter({ isActive: true })
• Format as Q&A pairs in prompt
• Keep FAQ entries up-to-date in admin
• This makes AI knowledge easily manageable

2. SiteSettings Context:
• Brand name
• Support email and phone
• Key policies (if added to SiteSettings)
• Operating hours
• Service areas

3. Package Information:
• Fetch active packages: entities.Packages.filter({ isActive: true })
• Include in context: name, description, price, features
• AI can answer "What packages do you offer?"
• AI can compare packages

4. Event Information:
• Upcoming events: entities.Events.filter({ isActive: true })
• Location information
• Dates and sport types
• AI can answer "What events are coming up?"

5. General Policies (Future):
• Create new entity: Policies
• Cancellation policy
• Weather policy
• Setup times
• What's included/not included

Example Context Builder:

async function buildAIContext() {
  const [faqs, settings, packages, events] = await Promise.all([
    base44.entities.FAQ.filter({ isActive: true }),
    base44.entities.SiteSettings.list(),
    base44.entities.Packages.filter({ isActive: true }),
    base44.entities.Events.filter({ isActive: true, archived: false })
  ]);
  
  let context = '';
  
  // FAQ Section
  context += '=== FREQUENTLY ASKED QUESTIONS ===\\n';
  faqs.forEach(faq => {
    context += \`Q: \${faq.question}\\n\`;
    context += \`A: \${faq.answer}\\n\\n\`;
  });
  
  // Packages Section
  context += '\\n=== AVAILABLE PACKAGES ===\\n';
  packages.forEach(pkg => {
    context += \`- \${pkg.name}: \${pkg.description}\\n\`;
    context += \`  Price: $\${pkg.perGameUSD}/game, $\${pkg.perDayUSD}/day\\n\`;
    if (pkg.features) {
      context += \`  Features: \${pkg.features.join(', ')}\\n\`;
    }
    context += '\\n';
  });
  
  // Events Section
  context += '\\n=== UPCOMING EVENTS ===\\n';
  events.slice(0, 5).forEach(evt => {
    context += \`- \${evt.name} (\${evt.sport})\\n\`;
    context += \`  Date: \${evt.startDate} to \${evt.endDate}\\n\`;
    context += \`  City: \${evt.city}\\n\\n\`;
  });
  
  return context;
}

Context Management Best Practices:

1. Keep Context Concise:
• Don't send entire database
• Limit to top 10-15 FAQs
• Limit to 5 upcoming events
• LLM has token limits

2. Prioritize Recent/Relevant:
• Sort FAQs by most common questions
• Only include events in next 60 days
• Filter inactive packages

3. Update Context Regularly:
• Fetch fresh data on each question
• Don't cache for too long
• Ensures accurate, current information

4. Add Metadata:
• "Last updated: [date]"
• "For more info, visit /faq"
• "Prices subject to change"`
          },
          {
            title: '4. Conversation History & Context Window',
            content: `Implementing Conversation Memory:

Why Conversation History Matters:
• AI can reference previous questions
• Enables follow-up questions
• More natural, conversational feel
• Example:
  - User: "What packages do you offer?"
  - AI: [lists packages]
  - User: "How much is the MVP?"
  - AI can reference previous response

State Management:

const [conversation, setConversation] = useState([]);

Structure:
[
  {
    type: 'question',
    text: 'What packages do you offer?',
    timestamp: '2025-01-15T10:00:00Z'
  },
  {
    type: 'answer',
    text: 'We offer three main packages: MVP, Premium, and VIP...',
    timestamp: '2025-01-15T10:00:03Z'
  },
  {
    type: 'question',
    text: 'How much is the MVP?',
    timestamp: '2025-01-15T10:00:15Z'
  }
]

Adding History to Prompt:

function formatConversationHistory(conversation) {
  return conversation.slice(-6).map(msg => {
    if (msg.type === 'question') {
      return \`Customer: \${msg.text}\`;
    } else {
      return \`Assistant: \${msg.text}\`;
    }
  }).join('\\n');
}

// In prompt:
\`Previous conversation:
\${formatConversationHistory(conversation)}

Current question: \${newQuestion}\`

Conversation Window Management:

1. Limit History Length:
• Only send last 3-4 turns (6-8 messages)
• Prevents token overflow
• Keeps context relevant

2. Session Management:
• Store conversation in component state
• Option: persist to localStorage
• Clear on page refresh or "New Chat" button

3. Context Reset:
• "Clear Chat" button resets conversation
• Useful when switching topics
• Starts fresh conversation

UI for Conversation Display:

<div style={{ maxHeight: '500px', overflowY: 'auto', marginBottom: '20px' }}>
  {conversation.map((msg, idx) => (
    <div key={idx} style={{
      display: 'flex',
      justifyContent: msg.type === 'question' ? 'flex-end' : 'flex-start',
      marginBottom: '12px'
    }}>
      <div style={{
        maxWidth: '70%',
        padding: '12px 16px',
        borderRadius: '12px',
        background: msg.type === 'question' ? '#003f5c' : '#f8fafc',
        color: msg.type === 'question' ? 'white' : '#0f172a'
      }}>
        {msg.text}
      </div>
    </div>
  ))}
  {loading && (
    <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
      <div className="spinner" />
      <span style={{ marginLeft: '8px', color: '#64748b' }}>AI is thinking...</span>
    </div>
  )}
</div>`
          },
          {
            title: '5. UI/UX Enhancements',
            content: `Suggested Questions (Quick Start):

const suggestedQuestions = [
  "What packages do you offer?",
  "How do I book a setup?",
  "What's your cancellation policy?",
  "What if it rains on game day?",
  "How early should I arrive?",
  "Can I change my booking?",
  "What sports do you support?",
  "Do you offer discounts?",
  "What's included in my setup?",
  "How does equipment pickup work?"
];

<div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '20px' }}>
  {suggestedQuestions.map((q, idx) => (
    <button
      key={idx}
      onClick={() => askAI(q)}
      className="btn-outline"
      style={{ fontSize: '13px' }}
    >
      {q}
    </button>
  ))}
</div>

Response Rating System:

After each AI response:

<div style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
  <button onClick={() => rateResponse(msg.id, 'positive')} title="Helpful">
    👍
  </button>
  <button onClick={() => rateResponse(msg.id, 'negative')} title="Not helpful">
    👎
  </button>
</div>

async function rateResponse(messageId, rating) {
  // Store rating for analytics
  await base44.entities.AIFeedback.create({
    messageId,
    rating,
    timestamp: new Date().toISOString()
  });
  
  // Show thank you message
  alert('Thank you for your feedback!');
}

Benefits:
• Track AI accuracy
• Identify areas for improvement
• Improve FAQ content based on feedback

Copy to Clipboard Feature:

<button 
  onClick={() => {
    navigator.clipboard.writeText(msg.text);
    setCopied(msg.id);
    setTimeout(() => setCopied(null), 2000);
  }}
  style={{ fontSize: '11px', color: '#64748b' }}
>
  {copied === msg.id ? '✓ Copied' : '📋 Copy'}
</button>

Loading States:

// While fetching context
if (loadingContext) {
  return <div>Preparing AI assistant...</div>;
}

// While AI is responding
{loading && (
  <div className="ai-thinking">
    <div className="spinner" />
    <span>AI is thinking...</span>
    <div className="typing-indicator">
      <span></span><span></span><span></span>
    </div>
  </div>
)}

Error Recovery:

{error && (
  <div style={{ background: '#fee2e2', padding: '16px', borderRadius: '8px' }}>
    <p style={{ color: '#991b1b', marginBottom: '12px' }}>{error}</p>
    <button onClick={retryLastQuestion} className="btn-outline">
      Try Again
    </button>
    <a href={\`mailto:\${supportEmail}\`} className="btn" style={{ marginLeft: '8px' }}>
      Contact Support
    </a>
  </div>
)}

Accessibility:

• ARIA labels on all interactive elements
• Keyboard navigation support
• Screen reader friendly
• High contrast mode support
• Focus indicators on buttons`
          },
          {
            title: '6. Advanced Features (Phase 2)',
            content: `Contextual AI (Booking-Aware):

When customer is logged in and asking about their booking:

const customerBookings = await base44.entities.Bookings.filter({
  contactEmail: session.email,
  status: ['confirmed', 'setup']
});

const bookingContext = \`
The customer has \${customerBookings.length} active bookings:
\${customerBookings.map(b => \`
  - Booking #\${b.id.slice(0,8)}
  - Date: \${b.date}
  - Package: \${b.packageName}
  - Location: \${b.parkName}
  - Status: \${b.status}
\`).join('\\n')}
\`;

// Add to prompt
// Now AI can say "I see you have a booking on June 15th..."

Smart Question Detection:

function detectQuestionType(question) {
  const q = question.toLowerCase();
  
  if (q.includes('my booking') || q.includes('change') || q.includes('cancel')) {
    return 'booking_specific';
  }
  if (q.includes('weather') || q.includes('rain') || q.includes('forecast')) {
    return 'weather';
  }
  if (q.includes('package') || q.includes('price') || q.includes('cost')) {
    return 'pricing';
  }
  
  return 'general';
}

// Use type to customize prompt or enable internet context
const useInternetContext = type === 'weather';

Multi-Language Support:

// Detect language
const language = detectLanguage(question);

// Add to prompt
\`Respond in \${language}. Customer asked: \${question}\`

Proactive Suggestions:

Based on booking status, suggest questions:

if (booking.status === 'confirmed' && daysBefore < 7) {
  suggestedQuestions = [
    "What should I bring on game day?",
    "How early should I arrive?",
    "What if the game is delayed?"
  ];
}

AI-Powered Search:

Instead of just Q&A, use AI for semantic search:

// Customer: "stuff about weather"
// AI interprets and searches FAQ
// Returns: "I found these related articles: [FAQ about rain policy]"

Analytics Dashboard (Admin):

Create entities/AIInteractions:
• question (string)
• response (string)
• rating (positive/negative)
• responseTime (number)
• wasHelpful (boolean)

Admin view shows:
• Most common questions
• Average helpfulness rating
• Questions AI struggled with
• Suggested new FAQ entries`
          },
          {
            title: '7. Implementation Checklist',
            content: `Phase 1: MVP (Week 1-2)

☐ Create pages/AskAI.js with basic UI
☐ Add input field and submit button
☐ Implement askAI() function
☐ Integrate base44.integrations.Core.InvokeLLM
☐ Build basic prompt with FAQ context
☐ Display AI response
☐ Add loading state
☐ Add error handling
☐ Test with sample questions
☐ Add link to FAQ page

Phase 2: Enhanced UX (Week 3)

☐ Add conversation history display
☐ Implement suggested questions
☐ Add response rating (thumbs up/down)
☐ Add "Copy response" button
☐ Add "Clear chat" button
☐ Improve prompt engineering based on testing
☐ Add character limit to input
☐ Style as chat interface

Phase 3: Integration (Week 4)

☐ Add AI button to FAQ page
☐ Add AI link to My Bookings page
☐ Add AI link to footer
☐ Create floating chat widget (optional)
☐ Add AI availability indicator

Phase 4: Context Enhancement (Week 5)

☐ Include Package data in context
☐ Include Event data in context
☐ Add booking-specific context (when logged in)
☐ Optimize context length
☐ Add context freshness timestamp

Phase 5: Analytics & Improvement (Week 6)

☐ Create AIInteractions entity
☐ Log all questions and responses
☐ Track response ratings
☐ Build admin analytics page
☐ Identify common questions
☐ Update FAQ based on insights
☐ Fine-tune prompts based on feedback

Testing Checklist:

☐ Test with common customer questions
☐ Test with nonsense questions
☐ Test with very long questions
☐ Test with multiple languages
☐ Test error scenarios (network failure)
☐ Test on mobile devices
☐ Test with slow connections
☐ Test conversation follow-ups
☐ Verify AI doesn't hallucinate
☐ Verify AI suggests human support when needed

Cost Monitoring:

☐ Track InvokeLLM usage
☐ Set budget alerts
☐ Optimize prompt length
☐ Consider caching common questions
☐ Monitor cost per conversation
☐ Implement rate limiting if needed`
          },
          {
            title: '8. Example Implementation Code',
            content: `Complete pages/AskAI.js Example:

import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Send, Sparkles, RotateCcw } from "lucide-react";

export default function AskAI() {
  const [question, setQuestion] = useState("");
  const [conversation, setConversation] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const suggestedQuestions = [
    "What packages do you offer?",
    "How do I book a setup?",
    "What's your cancellation policy?",
    "What if it rains?",
    "How early should I arrive?"
  ];

  async function askAI(q) {
    const questionText = q || question;
    if (!questionText.trim()) return;

    setLoading(true);
    setError(null);
    setQuestion("");

    // Add question to conversation
    setConversation(prev => [...prev, {
      type: 'question',
      text: questionText,
      timestamp: new Date()
    }]);

    try {
      // Fetch context
      const [faqs, settings] = await Promise.all([
        base44.entities.FAQ.filter({ isActive: true }),
        base44.entities.SiteSettings.list()
      ]);

      const siteSetting = settings[0] || {};
      const faqContext = faqs.map(f => 
        \`Q: \${f.question}\\nA: \${f.answer}\`
      ).join('\\n\\n');

      // Build prompt
      const prompt = \`You are a helpful customer service assistant for \${siteSetting.brandName || 'Sideline Setups'}. 

Guidelines:
- Keep answers under 200 words
- Be friendly and conversational
- Use bullet points for clarity
- If unsure, suggest contacting support
- Never make up information

FAQ Context:
\${faqContext}

Support Contact:
Email: \${siteSetting.supportEmail}
Phone: \${siteSetting.supportPhone}

Customer Question: \${questionText}\`;

      // Call AI
      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        add_context_from_internet: false
      });

      // Add response to conversation
      setConversation(prev => [...prev, {
        type: 'answer',
        text: response,
        timestamp: new Date()
      }]);

    } catch (err) {
      setError("Sorry, something went wrong. Please try again.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: '800px', margin: '40px auto', padding: '20px' }}>
      <div style={{ textAlign: 'center', marginBottom: '32px' }}>
        <Sparkles size={48} style={{ color: '#003f5c', margin: '0 auto 16px' }} />
        <h1>Ask AI Assistant</h1>
        <p style={{ color: '#64748b' }}>
          Get instant answers to your questions about Sideline Setups
        </p>
      </div>

      {/* Suggested Questions */}
      {conversation.length === 0 && (
        <div style={{ marginBottom: '24px' }}>
          <p style={{ fontSize: '14px', fontWeight: '600', marginBottom: '12px' }}>
            Try asking:
          </p>
          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
            {suggestedQuestions.map((q, idx) => (
              <button
                key={idx}
                onClick={() => askAI(q)}
                className="btn-outline"
                style={{ fontSize: '13px' }}
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Conversation */}
      <div style={{ 
        minHeight: '300px', 
        maxHeight: '500px', 
        overflowY: 'auto',
        marginBottom: '20px',
        background: '#f8fafc',
        borderRadius: '12px',
        padding: '16px'
      }}>
        {conversation.map((msg, idx) => (
          <div
            key={idx}
            style={{
              display: 'flex',
              justifyContent: msg.type === 'question' ? 'flex-end' : 'flex-start',
              marginBottom: '16px'
            }}
          >
            <div style={{
              maxWidth: '70%',
              padding: '12px 16px',
              borderRadius: '12px',
              background: msg.type === 'question' ? '#003f5c' : 'white',
              color: msg.type === 'question' ? 'white' : '#0f172a',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
            }}>
              {msg.text}
            </div>
          </div>
        ))}
        
        {loading && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div className="spinner" />
            <span style={{ color: '#64748b' }}>AI is thinking...</span>
          </div>
        )}
      </div>

      {/* Input */}
      <div style={{ display: 'flex', gap: '12px' }}>
        <input
          type="text"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && askAI()}
          placeholder="Ask a question..."
          disabled={loading}
          style={{ flex: 1 }}
        />
        <button
          onClick={() => askAI()}
          disabled={loading || !question.trim()}
          className="btn"
        >
          <Send size={18} />
        </button>
        {conversation.length > 0 && (
          <button
            onClick={() => setConversation([])}
            className="btn-outline"
          >
            <RotateCcw size={18} />
          </button>
        )}
      </div>

      {error && (
        <div style={{ 
          marginTop: '16px', 
          padding: '12px', 
          background: '#fee2e2', 
          borderRadius: '8px',
          color: '#991b1b'
        }}>
          {error}
        </div>
      )}
    </div>
  );
}`
          }
        ],
        notes: [
          'Start with dedicated page, then add chat widget if successful',
          'Monitor InvokeLLM costs carefully - each question is a paid API call',
          'Keep FAQ entity updated - it\'s the AI\'s knowledge source',
          'Consider adding rate limiting (e.g., max 10 questions per session)',
          'Track which questions customers ask most - improve FAQ accordingly',
          'Add disclaimer: "AI assistant - for complex issues, contact support"',
          'Test thoroughly before launch - AI can hallucinate or give wrong answers',
          'Consider adding "Was this helpful?" after each response',
          'Store conversation logs for quality assurance and improvement',
          'Add option to escalate to human support mid-conversation'
        ]
      }
    },
    {
      key: 'loyalty-phase-2',
      title: 'Loyalty Program - Phase 2: Tier System',
      description: 'Add Bronze/Silver/Gold/Platinum tiers with escalating benefits and lifetime points tracking.',
      details: {
        overview: 'Introduce membership tiers to reward your most loyal customers with progressively better perks. This creates aspirational goals and incentivizes repeat bookings.',
        components: [
          {
            title: '1. Database Schema Updates',
            content: `Update Customers Entity or Create CustomerLoyaltyProfile:

Add to entities/Customers or create new entity:
{
  "tier": {
    "type": "string",
    "enum": ["Bronze", "Silver", "Gold", "Platinum"],
    "default": "Bronze"
  },
  "lifetimePoints": {
    "type": "integer",
    "default": 0,
    "description": "Total points earned all-time (never decreases)"
  },
  "tierUpgradedAt": {
    "type": "string",
    "format": "date-time",
    "description": "When customer reached current tier"
  },
  "nextTierPointsNeeded": {
    "type": "integer",
    "description": "Points needed to reach next tier"
  }
}

Tier Thresholds (configurable in SiteSettings):
- Bronze: 0-499 lifetime points (default)
- Silver: 500-1,499 lifetime points
- Gold: 1,500-4,999 lifetime points
- Platinum: 5,000+ lifetime points`
          },
          {
            title: '2. Tier Calculation Backend Function',
            content: `functions/updateCustomerTier:

import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

const TIER_THRESHOLDS = {
  Bronze: 0,
  Silver: 500,
  Gold: 1500,
  Platinum: 5000
};

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const { customerEmail } = await req.json();
  
  // Get all transactions for customer
  const transactions = await base44.asServiceRole.entities.LoyaltyTransactions.filter({
    customerEmail,
    type: ['earned_booking', 'earned_bonus']
  });
  
  // Calculate lifetime points (only earned, not redeemed)
  const lifetimePoints = transactions.reduce((sum, txn) => sum + txn.pointsChange, 0);
  
  // Determine tier
  let newTier = 'Bronze';
  if (lifetimePoints >= TIER_THRESHOLDS.Platinum) newTier = 'Platinum';
  else if (lifetimePoints >= TIER_THRESHOLDS.Gold) newTier = 'Gold';
  else if (lifetimePoints >= TIER_THRESHOLDS.Silver) newTier = 'Silver';
  
  // Calculate next tier
  let nextTierName = null;
  let nextTierPoints = null;
  if (newTier === 'Bronze') {
    nextTierName = 'Silver';
    nextTierPoints = TIER_THRESHOLDS.Silver - lifetimePoints;
  } else if (newTier === 'Silver') {
    nextTierName = 'Gold';
    nextTierPoints = TIER_THRESHOLDS.Gold - lifetimePoints;
  } else if (newTier === 'Gold') {
    nextTierName = 'Platinum';
    nextTierPoints = TIER_THRESHOLDS.Platinum - lifetimePoints;
  }
  
  // Update customer record
  await base44.asServiceRole.entities.Customers.update(customerId, {
    tier: newTier,
    lifetimePoints,
    tierUpgradedAt: new Date().toISOString(),
    nextTierPointsNeeded: nextTierPoints
  });
  
  return Response.json({
    success: true,
    tier: newTier,
    lifetimePoints,
    nextTierName,
    nextTierPoints
  });
});

Call this function:
- After awarding points
- On a daily scheduled job
- When customer logs in to My Bookings`
          },
          {
            title: '3. Tier Benefits Configuration',
            content: `Add to SiteSettings entity:

{
  "loyaltyTiers": {
    "type": "object",
    "default": {
      "Bronze": {
        "pointsRequired": 0,
        "benefits": [
          "Earn 1 point per $1 spent",
          "Redeem points for discounts"
        ],
        "discountPercentage": 0,
        "earningMultiplier": 1.0
      },
      "Silver": {
        "pointsRequired": 500,
        "benefits": [
          "All Bronze benefits",
          "5% discount on all bookings",
          "Earn 1.25x points",
          "Priority email support"
        ],
        "discountPercentage": 5,
        "earningMultiplier": 1.25
      },
      "Gold": {
        "pointsRequired": 1500,
        "benefits": [
          "All Silver benefits",
          "10% discount on all bookings",
          "Earn 1.5x points",
          "Priority phone support",
          "Early access to new events"
        ],
        "discountPercentage": 10,
        "earningMultiplier": 1.5
      },
      "Platinum": {
        "pointsRequired": 5000,
        "benefits": [
          "All Gold benefits",
          "15% discount on all bookings",
          "Earn 2x points",
          "Dedicated support line",
          "Free equipment upgrades (when available)",
          "VIP setup locations"
        ],
        "discountPercentage": 15,
        "earningMultiplier": 2.0
      }
    }
  }
}`
          },
          {
            title: '4. Frontend Tier Display Component',
            content: `components/loyalty/TierBadge.jsx:

Shows current tier with visual flair

<div style={{
  padding: "20px",
  background: tierColors[tier],
  borderRadius: "12px",
  position: "relative",
  overflow: "hidden"
}}>
  <div style={{
    display: "flex",
    alignItems: "center",
    gap: "16px"
  }}>
    <div style={{
      width: "60px",
      height: "60px",
      borderRadius: "50%",
      background: "white",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }}>
      <Crown size={32} color={tierIconColor[tier]} />
    </div>
    <div>
      <div style={{ fontSize: "24px", fontWeight: "800", color: "white" }}>
        {tier} Member
      </div>
      <div style={{ fontSize: "14px", color: "rgba(255,255,255,0.9)" }}>
        {lifetimePoints} lifetime points
      </div>
    </div>
  </div>
  
  {nextTierName && (
    <div style={{ marginTop: "16px", paddingTop: "16px", borderTop: "1px solid rgba(255,255,255,0.3)" }}>
      <div style={{ fontSize: "12px", color: "rgba(255,255,255,0.8)", marginBottom: "8px" }}>
        Progress to {nextTierName}
      </div>
      <div style={{ 
        height: "8px", 
        background: "rgba(255,255,255,0.3)", 
        borderRadius: "4px",
        overflow: "hidden"
      }}>
        <div style={{
          height: "100%",
          background: "white",
          width: \`\${progress}%\`,
          transition: "width 0.3s"
        }} />
      </div>
      <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.8)", marginTop: "4px" }}>
        {nextTierPoints} points to go
      </div>
    </div>
  )}
</div>

Tier Colors:
- Bronze: Linear gradient from #CD7F32 to #B87333
- Silver: Linear gradient from #C0C0C0 to #A8A8A8
- Gold: Linear gradient from #FFD700 to #FFA500
- Platinum: Linear gradient from #E5E4E2 to #8B8B83`
          },
          {
            title: '5. Apply Tier Benefits in Booking Flow',
            content: `In booking calculation logic:

// Get customer tier
const customer = await entities.Customers.get(customerId);
const tier = customer?.tier || 'Bronze';

// Get tier config from settings
const settings = await entities.SiteSettings.list();
const tierConfig = settings[0]?.loyaltyTiers?.[tier];

// Apply tier discount
if (tierConfig?.discountPercentage > 0) {
  const tierDiscountCents = Math.floor(
    subtotalCents * (tierConfig.discountPercentage / 100)
  );
  totalCents -= tierDiscountCents;
  
  // Store in booking
  booking.tierDiscount = {
    tier,
    percentage: tierConfig.discountPercentage,
    amountCents: tierDiscountCents
  };
}

// Apply point earning multiplier
const basePoints = Math.floor(totalCents / 100);
const multipliedPoints = Math.floor(basePoints * (tierConfig?.earningMultiplier || 1.0));

// Award points with multiplier
await base44.functions.invoke('awardLoyaltyPoints', {
  bookingId,
  amountCents: totalCents,
  customerEmail,
  pointsMultiplier: tierConfig?.earningMultiplier || 1.0
});`
          },
          {
            title: '6. Tier Upgrade Notifications',
            content: `Send email when customer reaches new tier:

functions/notifyTierUpgrade:

const tierEmails = {
  Silver: {
    subject: "🎉 You've Reached Silver Status!",
    body: \`Congratulations! You've unlocked Silver tier benefits:
    
    ✨ 5% discount on all bookings
    ⚡ Earn 1.25x points on every purchase
    📧 Priority email support
    
    Keep booking to reach Gold tier and unlock even more rewards!\`
  },
  Gold: {
    subject: "🏆 Welcome to Gold Tier!",
    body: \`Amazing! You're now a Gold member with exclusive perks:
    
    ✨ 10% discount on all bookings
    ⚡ Earn 1.5x points
    📞 Priority phone support
    🎟️ Early access to new events
    
    You're just one tier away from our exclusive Platinum benefits!\`
  },
  Platinum: {
    subject: "💎 You've Achieved Platinum Status!",
    body: \`Incredible! You're now part of our elite Platinum tier:
    
    ✨ 15% discount on all bookings
    ⚡ Earn 2x points
    📞 Dedicated support line
    🎁 Free equipment upgrades
    🌟 VIP setup locations
    
    Thank you for being one of our most valued customers!\`
  }
};

// Send when tier changes
if (oldTier !== newTier) {
  await sendEmail({
    to: customerEmail,
    subject: tierEmails[newTier].subject,
    body: tierEmails[newTier].body
  });
}`
          }
        ],
        notes: [
          'Use lifetime points (never decreases) for tier calculation',
          'Current points balance can go up and down (spent/earned)',
          'Tier benefits apply automatically at checkout',
          'Consider seasonal tier challenges ("Reach Gold by end of summer")',
          'Add tier badges to customer profile in admin',
          'Show tier on booking receipts',
          'Create "Tier Benefits" page explaining each level'
        ]
      }
    },
    {
      key: 'loyalty-phase-3',
      title: 'Loyalty Program - Phase 3: Referral System',
      description: 'Reward customers for bringing in new customers with referral codes and bonuses.',
      details: {
        overview: 'Turn your customers into brand ambassadors by rewarding them when they refer friends and family.',
        components: [
          {
            title: '1. Referral Database Schema',
            content: `New Entity: Referrals

{
  "name": "Referrals",
  "type": "object",
  "properties": {
    "referrerEmail": {
      "type": "string",
      "description": "Customer who made the referral"
    },
    "refereeEmail": {
      "type": "string",
      "description": "New customer who was referred"
    },
    "referralCode": {
      "type": "string",
      "description": "Unique code used for referral"
    },
    "status": {
      "type": "string",
      "enum": ["pending", "completed", "rewarded"],
      "default": "pending",
      "description": "pending = signed up, completed = first booking made, rewarded = points given"
    },
    "refereeFirstBookingId": {
      "type": "string",
      "description": "Referee's first booking"
    },
    "pointsAwarded": {
      "type": "integer",
      "description": "Points given to referrer"
    },
    "refereeBonus": {
      "type": "integer",
      "description": "Points/discount given to referee"
    }
  }
}

Add to Customers entity:
{
  "referralCode": {
    "type": "string",
    "description": "Customer's unique referral code"
  },
  "referredBy": {
    "type": "string",
    "description": "Referral code they used to sign up"
  },
  "totalReferrals": {
    "type": "integer",
    "default": 0
  },
  "successfulReferrals": {
    "type": "integer",
    "default": 0,
    "description": "Referrals who completed first booking"
  }`
          },
          {
            title: '2. Generate Referral Codes',
            content: `functions/generateReferralCode:

Create unique codes when customer signs up or requests one

function generateCode(name, email) {
  // Use first name + random string
  const firstName = name.split(' ')[0].toUpperCase();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return \`\${firstName}\${random}\`;
  // Example: JOHN5X7K
}

Alternative formats:
- JOHNDOE10 (name + number)
- SIDELINE-JOHN-5X7K (branded)
- JD5X7K (initials + random)

Store in Customers entity when generated`
          },
          {
            title: '3. Referral Flow',
            content: `Step 1: Customer Shares Link

On My Bookings page, show:
┌─────────────────────────────────────┐
│ 📣 Refer a Friend, Get Rewards!     │
│                                     │
│ Your referral code: JOHN5X7K        │
│ [Copy Code] [Share Link]           │
│                                     │
│ When a friend books using your      │
│ code, you both get 200 points!     │
│                                     │
│ Successful referrals: 3             │
└─────────────────────────────────────┘

Share link:
https://sideline-setups.com/events?ref=JOHN5X7K

Step 2: New Customer Uses Code

On booking page, add referral code input:
┌─────────────────────────────────────┐
│ Have a referral code?               │
│ [____________] [Apply]              │
│                                     │
│ ✓ Applied! You'll get 200 points   │
│   after your first booking!         │
└─────────────────────────────────────┘

Store in booking:
{
  "referredByCode": "JOHN5X7K"
}

Step 3: Complete Booking & Award Points

After first booking completes:
1. Create Referrals record
2. Award referrer 200 points
3. Award referee 200 points
4. Send notification emails to both
5. Update Referrals.status to "rewarded"`
          },
          {
            title: '4. Referral Rewards Backend',
            content: `functions/processReferralReward:

Deno.serve(async (req) => {
  const { bookingId } = await req.json();
  
  // Get booking
  const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
  
  if (!booking.referredByCode) {
    return Response.json({ success: false, message: 'No referral code used' });
  }
  
  // Check if this is first booking
  const allBookings = await base44.asServiceRole.entities.Bookings.filter({
    contactEmail: booking.contactEmail
  });
  
  if (allBookings.length > 1) {
    return Response.json({ success: false, message: 'Not first booking' });
  }
  
  // Find referrer
  const referrer = await base44.asServiceRole.entities.Customers.filter({
    referralCode: booking.referredByCode
  });
  
  if (!referrer || referrer.length === 0) {
    return Response.json({ success: false, message: 'Invalid referral code' });
  }
  
  const referrerEmail = referrer[0].email;
  const refereeEmail = booking.contactEmail;
  
  // Award points to both (200 each)
  await base44.functions.invoke('awardLoyaltyPoints', {
    bookingId: null,
    amountCents: 0,
    customerEmail: referrerEmail,
    bonusPoints: 200,
    reason: \`Referral bonus: \${refereeEmail} completed first booking\`
  });
  
  await base44.functions.invoke('awardLoyaltyPoints', {
    bookingId: bookingId,
    amountCents: 0,
    customerEmail: refereeEmail,
    bonusPoints: 200,
    reason: \`Welcome bonus: Referred by \${booking.referredByCode}\`
  });
  
  // Create referral record
  await base44.asServiceRole.entities.Referrals.create({
    referrerEmail,
    refereeEmail,
    referralCode: booking.referredByCode,
    status: 'rewarded',
    refereeFirstBookingId: bookingId,
    pointsAwarded: 200,
    refereeBonus: 200
  });
  
  // Update referrer stats
  await base44.asServiceRole.entities.Customers.update(referrer[0].id, {
    successfulReferrals: (referrer[0].successfulReferrals || 0) + 1
  });
  
  // Send notification emails
  // ...
  
  return Response.json({ success: true });
});

Call this after booking is completed/paid`
          },
          {
            title: '5. Referral Leaderboard',
            content: `Show top referrers (optional, for gamification):

On My Bookings or dedicated page:

┌─────────────────────────────────────┐
│ 🏆 Top Referrers This Month         │
│                                     │
│ 1. Sarah J. - 12 referrals          │
│ 2. Mike T. - 8 referrals            │
│ 3. Jennifer L. - 7 referrals        │
│ 4. David K. - 5 referrals           │
│ 5. Your ranking: #15 (3 referrals)  │
│                                     │
│ Keep referring to climb the ranks!  │
└─────────────────────────────────────┘

Top referrer gets special recognition or bonus`
          },
          {
            title: '6. Advanced Referral Features',
            content: `Tiered Referral Bonuses:
- 1st referral: 200 points
- 2nd referral: 250 points
- 3rd referral: 300 points
- 5th referral: 500 points
- 10th referral: 1000 points + free booking

Referral Milestones:
- Refer 5 friends → Silver tier instant upgrade
- Refer 10 friends → Gold tier instant upgrade
- Refer 25 friends → Platinum tier + lifetime 20% discount

Social Sharing:
- One-click share to Facebook, Twitter, Email
- Pre-filled message templates
- Track which channel drives most referrals

Referral Contests:
- "Refer 3 friends this month, win free VIP package"
- Limited-time 2x referral points
- Team referral challenges

Customizable Rewards:
- Admin can set referral bonus amount
- Different rewards for different tiers
- Option for cash rewards vs. points`
          }
        ],
        notes: [
          'Make referral codes easy to remember and share',
          'Track referral source (email, social, direct link)',
          'Prevent abuse (same IP, same payment method)',
          'Consider both-sided rewards (referrer + referee)',
          'Add referral stats to admin dashboard',
          'Send reminder emails to encourage sharing',
          'Create shareable graphics/images for social media'
        ]
      }
    },
    {
      key: 'calendar-integration',
      title: 'Calendar Integration (Google/Apple/Outlook)',
      description: 'Automatically sync bookings to customer and staff calendars with reminders and updates.',
      details: {
        overview: 'Allow customers to add their bookings directly to their personal calendars (Google Calendar, Apple Calendar, Outlook) with one click. Staff can sync all daily setups to their calendar for better schedule management.',
        components: [
          {
            title: '1. Customer Calendar Export',
            content: `Features:
• "Add to Calendar" button on confirmation page
• Generate .ics file with booking details
• Support for Google Calendar, Apple Calendar, Outlook
• Include event details: date, time, location, field, package
• Add reminders (24 hours before, 2 hours before)
• Include check-in QR code link in calendar event

Implementation:
• Use ical-generator library to create .ics files
• Generate unique event UID for each booking
• Include geo-coordinates for park locations
• Add booking URL in event description

Technical Approach:
import ical from 'npm:ical-generator';

const generateCalendarEvent = (booking) => {
  const calendar = ical({ name: 'Sideline Setups Booking' });
  
  calendar.createEvent({
    start: new Date(booking.date + ' ' + booking.gameTimes[0]),
    end: new Date(booking.date + ' ' + booking.gameTimes[booking.gameTimes.length - 1]),
    summary: \`Sideline Setups - \${booking.eventName}\`,
    description: \`Your game day setup is ready!\\n\\nPackage: \${booking.packageName}\\nField: \${booking.fieldName}\\n\\nCheck-in: https://sideline-setups.com/checkin?b=\${booking.id}\`,
    location: \`\${booking.parkName}, \${booking.parkAddress}\`,
    url: \`https://sideline-setups.com/thankyou?b=\${booking.id}\`,
    alarms: [
      { trigger: 60 * 24 }, // 24 hours before
      { trigger: 60 * 2 }    // 2 hours before
    ]
  });
  
  return calendar.toString();
};`
          },
          {
            title: '2. Google Calendar Direct Integration',
            content: `Two-way sync with Google Calendar:

Customer Features:
• OAuth login to Google account
• One-click "Save to Google Calendar"
• Auto-update calendar when booking changes
• Delete calendar event if booking cancelled

Staff Features:
• View all daily setups in one calendar
• Color-coded by park/field
• See booking details in event
• Get notifications for new bookings

Setup Requirements:
• Google Calendar API credentials
• OAuth 2.0 flow for user authorization
• Webhook for calendar updates
• Store user's calendar token securely

API Endpoints Needed:
• POST /google-calendar/connect - Initiate OAuth
• POST /google-calendar/add-booking - Add event
• PUT /google-calendar/update-booking - Update event
• DELETE /google-calendar/remove-booking - Delete event`
          },
          {
            title: '3. Staff Calendar View',
            content: `Admin calendar dashboard showing all bookings:

Features:
• Month/Week/Day views
• Color-coded by status (confirmed, setup, completed)
• Filter by park, field, package
• Drag-and-drop to reschedule (if implemented)
• Print daily schedule
• Export to PDF

Calendar Library:
• Use FullCalendar.js or similar
• Custom event rendering with booking details
• Click event to see full booking info
• Right-click for quick actions

Benefits:
• Visual overview of busy days
• Identify scheduling conflicts
• Plan staff assignments
• Forecast equipment needs`
          }
        ],
        notes: [
          'Start with simple .ics download, add Google Calendar integration later',
          'Consider adding Outlook 365 integration for corporate customers',
          'Add timezone handling for customers in different regions',
          'Include weather forecast in calendar event description',
          'Auto-update calendar if game time changes',
          'Send calendar invite via email as backup'
        ]
      }
    },
    {
      key: 'loyalty-program',
      title: 'Loyalty & Rewards Program',
      description: 'Points system, tiered memberships, referral bonuses to encourage repeat bookings.',
      details: {
        overview: 'Reward repeat customers with points for every booking, unlock VIP perks at higher tiers, and incentivize referrals. Build customer lifetime value and increase retention.',
        components: [
          {
            title: '1. Points System',
            content: `Earning Points:
• 1 point per $1 spent
• Bonus points for first booking (100 pts)
• Bonus points for social media shares (25 pts)
• Bonus points for reviews (50 pts)
• Double points on birthday month
• Seasonal bonus promotions

Redeeming Points:
• 100 points = $10 off
• 500 points = Free chair upgrade
• 1000 points = Free add-on
• 2000 points = Free game day setup

Implementation:
• Create LoyaltyPoints entity
• Track points earned and spent
• Display point balance in customer dashboard
• Apply points discount at checkout
• Email notifications when milestones reached

Entity Structure:
{
  "customerId": "...",
  "bookingId": "...",
  "action": "earned" | "spent",
  "points": 50,
  "reason": "Booking completed",
  "balanceAfter": 450,
  "createdAt": "2025-01-15T10:30:00Z"
}`
          },
          {
            title: '2. Tier System',
            content: `Membership Tiers:

Bronze (0-499 points):
• Standard pricing
• Email support
• Basic booking management

Silver (500-1499 points):
• 5% discount on all bookings
• Priority email support
• Early access to new parks
• Birthday bonus (100 points)

Gold (1500-2999 points):
• 10% discount on all bookings
• Dedicated support line
• Free equipment upgrades (subject to availability)
• Season planning assistance
• Exclusive VIP parking info

Platinum (3000+ points):
• 15% discount on all bookings
• Concierge service
• First priority for sold-out events
• Free add-ons (up to $50 value per season)
• Personalized setup preferences saved
• Annual thank-you gift

UI Changes:
• Badge on customer dashboard showing tier
• Progress bar to next tier
• "X points away from Gold!" motivation
• Tier benefits clearly listed
• Upgrade celebration modal when tier achieved`
          },
          {
            title: '3. Referral Program',
            content: `Referral Rewards:

Referrer Gets:
• $20 credit when friend makes first booking
• 200 loyalty points
• Bonus $50 credit after 5 successful referrals

Referee Gets:
• $10 off first booking
• 100 welcome bonus points

Implementation:
• Generate unique referral code per customer
• Track referral link clicks
• Attribute booking to referrer
• Auto-apply rewards after payment
• Create Referrals entity to track conversions

Referral Code Format:
• Personal: SMITH2025
• Shareable link: sideline-setups.com/?ref=SMITH2025

Tracking:
• Store referral code in booking
• Dashboard showing:
  - Total referrals sent
  - Successful conversions
  - Total credits earned
  - Pending referrals (clicked but not booked)

Marketing Materials:
• Pre-written social media posts
• Email template to share with friends
• Printable referral cards to hand out at games`
          },
          {
            title: '4. VIP Perks & Experiences',
            content: `Exclusive Benefits:

Early Access:
• Book new parks 48 hours before public
• Reserve prime spots (home side, shaded areas)
• First notification of special promotions

Personalization:
• Save setup preferences (chair types, cooler size)
• "Setup Favorites" for one-click rebooking
• Personal account manager (Platinum only)

Surprise & Delight:
• Random upgrades to premium packages
• Free add-ons on milestone bookings (10th, 25th, 50th)
• Birthday setup with decorations (opt-in)
• End-of-season thank you note

Communication:
• Monthly newsletter with insider tips
• Exclusive Facebook group for VIP members
• Behind-the-scenes content
• Input on new product offerings`
          },
          {
            title: '5. Gamification',
            content: `Engagement Mechanics:

Badges & Achievements:
• "Tournament Warrior" - 5 tournament bookings
• "Weekend Warrior" - 3 weekend bookings in a row
• "Early Bird" - Book 30+ days in advance
• "Weather Warrior" - Book in rain/heat
• "Referral Rockstar" - 10 successful referrals
• "Loyal Fan" - 1 year anniversary

Challenges:
• "Book 3 times this month, get 100 bonus points"
• "Share on social media, unlock mystery reward"
• "Complete profile, earn 50 points"

Leaderboard (optional):
• Top referrers of the month
• Most loyal customers of the season
• Recognition on website/social media

Progress Tracking:
• Visual dashboard showing badges earned
• Progress bars for active challenges
• Notification when badge unlocked
• Shareable badge graphics for social media`
          }
        ],
        notes: [
          'Start with simple points system, add tiers later',
          'Make sure point expiration policy is clear (e.g., points expire after 1 year)',
          'Consider partnering with local businesses for cross-promotional rewards',
          'Track ROI on loyalty program (retention rate, repeat booking increase)',
          'Survey customers to understand which perks are most valued',
          'Legal compliance: clearly state terms & conditions of loyalty program'
        ]
      }
    },
    {
      key: 'package-builder',
      title: 'Custom Package Builder',
      description: 'Let customers design their own packages by selecting individual equipment items and quantities.',
      details: {
        overview: 'Give customers full control to build their perfect setup. Choose from all available equipment, set quantities, see real-time pricing, and save custom configurations for future bookings.',
        components: [
          {
            title: '1. Equipment Selection Interface',
            content: `Interactive Builder UI:

Categories:
• Shade & Shelter (tents, canopies, sidewalls)
• Seating (chairs, benches, stools)
• Cooling (fans, misters, ice chests)
• Storage (coolers, wagons, carts)
• Extras (tables, umbrellas, lighting, audio)

For Each Item:
• Photo of equipment
• Name and description
• Price per game/day/weekend
• Availability indicator
• Quantity selector (+/- buttons)
• "Add to Package" button

Visual Preview:
• Show selected items in a summary panel
• Display total quantity of each item
• Running price total
• Visual representation of setup (optional: drag-drop layout)

Filters:
• Price range
• Item type
• Availability
• Most popular
• Recommended for sport (baseball vs softball vs soccer)`
          },
          {
            title: '2. Real-time Pricing Calculator',
            content: `Dynamic Pricing Display:

Pricing Options:
• Per Game: $X
• Per Day: $Y (save 15%)
• Full Weekend: $Z (save 25%)

Price Breakdown:
Base Package Items:
• 1x 10x10 Tent: $15
• 2x Rocker Chair: $8 each
• 1x Wheeled Cooler: $10
Subtotal: $41

Add-ons:
• 1x USB Fan: $5
• 1x Sidewall: $8
Add-ons Total: $13

Grand Total: $54/game

Savings Indicator:
• "Save $15 by choosing Full Weekend!"
• "Add 1 more item for volume discount"

Constraints:
• Minimum order: $25
• Maximum items: 20 pieces (for logistics)
• Show warning if approaching max

Dynamic Discounts:
• 10% off if 5+ items
• Free delivery over $100
• Seasonal promotions applied automatically`
          },
          {
            title: '3. Save & Share Custom Packages',
            content: `Package Management:

Save Custom Package:
• Name your package (e.g., "Smith Family Setup")
• Save for future bookings
• Edit saved packages anytime
• Delete when no longer needed

Share Packages:
• Generate shareable link
• Other customers can clone your package
• Popular community packages featured
• "Most Cloned This Month" section

Package Templates:
• Start from scratch
• Start from existing package (MVP, Premium, etc.)
• Start from your previous booking
• Use recommended package for your sport

Backend:
• Store in CustomPackages entity
• Link to customer account
• Track usage statistics
• Allow marking as "public" for sharing

Entity Structure:
{
  "customerId": "...",
  "name": "Smith Family Setup",
  "description": "Perfect for hot weekend tournaments",
  "items": [{
    "equipmentId": "...",
    "qty": 2
  }],
  "isPublic": true,
  "timesUsed": 14,
  "timesCloned": 3,
  "createdAt": "..."
}`
          },
          {
            title: '4. Recommendations Engine',
            content: `Smart Suggestions:

Based on Sport:
• Baseball: Larger tents (sun position), more seating
• Soccer: Portable shade, fewer chairs (more standing)
• Softball: Balanced setup

Based on Weather:
• Hot day: Add fans, extra cooler, sidewalls for shade
• Rainy: Add sidewalls, waterproof bags
• Windy: Recommend weights, secure tent stakes

Based on Team Size:
• Small team (10 players): 1 tent, 4 chairs
• Medium team (15 players): 2 tents, 6 chairs
• Large team (20+ players): 3 tents, 8 chairs

Based on Event Type:
• Single game: Basic setup
• All-day tournament: Full comfort package
• Multi-day: Weekend package with premium add-ons

Intelligent Prompts:
• "Customers who booked similar setups also added..."
• "For your field size, we recommend..."
• "Based on forecast (95°F), consider adding..."
• "Popular this weekend: USB fans (42% of bookings)"

Upsell Opportunities:
• "Add a fan for just $5 more"
• "Upgrade to premium chairs for $3/chair"
• "Bundle discount: Add cooler + fan for $12 (save $3)"`
          },
          {
            title: '5. Package Preview & Visualization',
            content: `Visual Confirmation:

3D Preview (Advanced):
• Show tent, chairs, cooler in 3D space
• Rotate and zoom
• See dimensions and spacing
• Export preview image

Simple List View:
• Itemized list with photos
• Quantities clearly shown
• Expandable details
• Print-friendly format

Comparison Tool:
• Compare your custom package vs standard packages
• See price difference
• Highlight what's included/excluded
• Switch between packages easily

Mobile-Friendly:
• Swipe through equipment photos
• Tap to add/remove items
• Quick quantity adjustment
• Sticky total bar at bottom

Confirmation Screen:
• "Review Your Custom Setup"
• Edit button for each section
• Notes field for special requests
• "Save for Next Time" checkbox
• Proceed to date selection`
          }
        ],
        notes: [
          'Start with simple form-based builder, add visual features later',
          'Ensure real-time inventory checking (don\'t let customers build unavailable packages)',
          'Add "Quick Build" option for customers who don\'t want to customize',
          'Track which custom configurations are most popular (inform future package design)',
          'Allow sharing custom packages on social media ("Check out my game day setup!")',
          'Consider offering "Package Consultation" service for premium customers',
          'Add equipment compatibility warnings (e.g., "sidewalls require specific tent type")',
          'Gamify the builder: "You\'ve created the perfect setup! Share it and earn points"'
        ]
      }
    },
    {
      key: 'waitlist-management',
      title: 'Waitlist & Overbooking Management',
      description: 'When spots are full, let customers join a waitlist and get notified when availability opens up.',
      details: {
        overview: 'Never lose a customer to "sold out" status. Capture demand through waitlists, automatically notify when spots open, and manage overbooking scenarios with smart allocation.',
        components: [
          {
            title: '1. Waitlist Signup',
            content: `When Spot is Full:

Instead of "Sold Out" message, show:
• "This spot is currently full"
• "Join the waitlist to get notified if it opens up"
• "X people ahead of you in line"
• Form to capture:
  - Name
  - Email
  - Phone (for SMS alerts)
  - Preferred package
  - Notes/flexibility

Waitlist Priority:
1. First come, first served
2. VIP/loyalty tier members (optional jump the line)
3. Customers willing to take any available spot
4. Customers with specific requirements

Confirmation:
• Email: "You're #5 on the waitlist for Airport Park Field 3"
• Show waitlist position in customer dashboard
• Option to cancel waitlist spot

Entity: Waitlist
{
  "customerId": "...",
  "eventId": "...",
  "parkId": "...",
  "fieldId": "...",
  "spotId": "...",
  "date": "2025-06-15",
  "packageId": "...",
  "position": 5,
  "status": "waiting" | "notified" | "converted" | "cancelled",
  "notifiedAt": "2025-06-14T12:00:00Z",
  "expiresAt": "2025-06-14T12:00:00Z"
}`
          },
          {
            title: '2. Automatic Notifications',
            content: `When Spot Opens:

Trigger Events:
• Customer cancels booking
• Booking moves to different spot
• Additional inventory added
• Overbooking cleared

Notification Flow:
1. System detects available spot
2. Find next person on waitlist
3. Send immediate notification (email + SMS)
4. Hold spot for 2 hours
5. If no response, move to next person

Notification Content:
Subject: "Great News! A spot just opened up at [Park Name]"

Body:
"Hi [Name],

A setup spot just became available for your requested date:

• Event: [Event Name]
• Date: [Date]
• Park: [Park Name]
• Field: [Field Name]
• Package: [Package Name]

Click here to claim this spot within the next 2 hours:
[Claim Booking Link]

If you don't claim it, we'll offer it to the next person on the waitlist.

- Sideline Setups Team"

SMS:
"Spot available! [Park] on [Date]. Claim in 2 hrs: [Short Link]"

Claim Process:
• Click link → pre-filled booking form
• Review and confirm details
• Complete payment
• Booking confirmed, removed from waitlist`
          },
          {
            title: '3. Waitlist Dashboard (Admin)',
            content: `Staff Management Tools:

Overview Screen:
• List all active waitlists
• Sort by date, park, priority
• See waitlist depth per event
• Identify high-demand spots

Per-Waitlist View:
• All customers waiting for specific spot
• Contact details
• Time on waitlist
• Priority level
• Notes/flexibility

Actions:
• Manually notify customer
• Skip customer (with reason)
• Clear entire waitlist
• Add customer to waitlist manually
• Adjust customer priority

Reports:
• Waitlist conversion rate
• Average wait time
• Most popular spots with waitlists
• Customers who joined but never converted
• Revenue captured from waitlist

Overbooking Strategy:
• Allow 10% overbooking for high-cancellation events
• System warns when approaching capacity
• Auto-allocate overflow to nearby fields
• Upgrade customer to better package if needed`
          },
          {
            title: '4. Customer Waitlist Experience',
            content: `Customer Dashboard Section:

"My Waitlists" Tab:
• List of all active waitlist positions
• Show position in line
• Estimated likelihood of opening ("High chance!")
• Option to cancel waitlist
• Set notification preferences

Notification Preferences:
• Email only
• SMS only
• Both email and SMS
• Notification frequency (immediate, daily digest)

Waitlist Flexibility:
• "I'm flexible on date" (show alternative dates)
• "I'm flexible on park" (show nearby parks)
• "I'm flexible on package" (show downgrade options)
• Alert me for any opening at this event

Gamification:
• "You moved up! Now #3 in line"
• "Estimated wait: 2-5 days based on historical data"
• Progress bar showing movement

Alternative Suggestions:
• "While you wait, check out these available spots:"
• Show similar parks/fields with availability
• Offer discount for booking alternative date
• "Upgrade to VIP to jump the waitlist" (if loyalty program exists)`
          }
        ],
        notes: [
          'Set clear expectations on waitlist notification timing',
          'Don\'t spam customers - only send for genuinely severe conditions',
          'Track waitlist→booking conversion rate to optimize process',
          'Consider offering incentive for customers who accept alternative spots',
          'Add "Cancel without Penalty" feature for waitlist bookings',
          'Integrate with inventory system to prevent double-booking',
          'Use historical data to predict waitlist success probability',
          'Offer "Backup Date" option when joining waitlist'
        ]
      }
    },
    {
      key: 'weather-alerts',
      title: 'Weather Alerts & Rescheduling',
      description: 'Automatically notify customers of severe weather and provide easy rescheduling options.',
      details: {
        overview: 'Monitor weather forecasts for all upcoming bookings, send proactive alerts for severe weather, and allow customers to reschedule without penalties. Reduce no-shows and improve customer satisfaction.',
        components: [
          {
            title: '1. Weather Monitoring',
            content: `Automated Weather Tracking:

Data Sources:
• National Weather Service API (free, reliable)
• OpenWeatherMap API (backup)
• Weather.gov alerts for severe weather

Monitoring Triggers:
• Check forecast 7 days before event
• Check again 3 days before
• Check again 24 hours before
• Check again 2 hours before (for severe weather only)

Alert Conditions:
• Severe Thunderstorm Warning
• Tornado Warning/Watch
• Excessive Heat Warning (100°F+)
• Flash Flood Warning
• High Wind Warning (30+ mph sustained)
• Temperature below 40°F or above 105°F

Backend Function:
functions/weatherMonitor.js
• Runs every 6 hours via cron
• Fetches forecast for each booking's park location
• Compares conditions to alert thresholds
• Creates WeatherAlert entity records
• Triggers customer notifications

Entity: WeatherAlerts
{
  "bookingId": "...",
  "parkId": "...",
  "eventDate": "2025-06-15",
  "alertType": "severe_thunderstorm" | "extreme_heat" | "high_wind",
  "severity": "watch" | "warning" | "advisory",
  "forecast": {
    "temp": 98,
    "conditions": "Thunderstorms",
    "windSpeed": 25,
    "precipChance": 80
  },
  "notifiedAt": "2025-06-14T08:00:00Z",
  "customerResponse": "rescheduled" | "proceeding" | "cancelled"
}`
          },
          {
            title: '2. Customer Notifications',
            content: `Weather Alert Messages:

Email Template (Severe Weather):
Subject: "⚠️ Weather Alert for Your Booking on [Date]"

Hi [Name],

We're monitoring a severe weather system that may impact your setup at [Park Name] on [Date].

Current Forecast:
🌡️ Temperature: 102°F
⛈️ Conditions: Severe Thunderstorms
💨 Wind: 30 mph gusts
☔ Rain Chance: 85%

Your Options:
1. Proceed with Booking - We'll monitor and keep you updated
2. Reschedule - No fees, pick any available date within 90 days
3. Cancel - Full refund

[Reschedule Button] [Keep Booking Button] [Contact Us]

We'll continue monitoring and update you if conditions change.

Stay safe,
Sideline Setups Team

SMS (Severe Weather):
"⚠️ Severe weather alert for your [Date] booking at [Park]. Forecast: Storms, 85% rain. Reschedule free: [Link]"

Email Template (Extreme Heat):
Subject: "☀️ Heat Advisory for Your [Date] Booking"

Hi [Name],

The forecast shows extreme heat (105°F) for your setup date at [Park Name].

Heat Safety Recommendations:
• We'll provide extra water and ice
• Consider these FREE upgrades:
  - Additional sidewalls for shade
  - Extra cooling fans
  - Misting system

[Claim Free Heat Package] [Reschedule] [Keep Booking]

Your health and comfort are our priority!`
          },
          {
            title: '3. Easy Rescheduling Flow',
            content: `Streamlined Rescheduling:

From Notification Email:
• Click "Reschedule" button
• Goes directly to rescheduling page
• Original booking details pre-filled
• Show only available alternative dates
• One-click confirm new date

Rescheduling Rules:
• No fee if rescheduled 48+ hours before event
• No fee for weather-related rescheduling
• Can reschedule to any date within 90 days
• Same package, park, and pricing honored
• Credit applied automatically

Calendar View:
• Show available dates in green
• Show unavailable dates in gray
• Show customer's original date
• Highlight recommended alternatives (same day of week, similar conditions)

Confirmation:
• Email confirmation of new date
• Update calendar invites automatically
• SMS reminder 24 hours before new date
• Original booking marked as "rescheduled"

Admin Dashboard:
• List of all weather-impacted bookings
• Show customer response (rescheduled, proceeding, cancelled)
• Batch reschedule tool (move all bookings from Date A to Date B)
• Weather forecast for upcoming week
• Historical weather impact data`
          },
          {
            title: '4. Proactive Weather Features',
            content: `Enhanced Weather UX:

Booking Page Weather Preview:
• Show 10-day forecast for selected date
• Display weather icon and temp
• Warn if conditions may be unfavorable
• Suggest alternative dates with better weather

Weather Guarantee:
• "If it rains on your game day, reschedule free!"
• Build trust and reduce booking hesitation
• Track weather guarantee claims

Post-Weather Follow-up:
• "How did the weather impact your game day?"
• Offer discount if weather was worse than forecast
• Collect feedback to improve forecasting

Weather-Based Recommendations:
• "Hot day ahead! Consider adding fans and coolers"
• "Rain possible - add sidewalls for extra protection"
• Dynamic pricing: discount for bookings on "iffy" weather days

Weather Dashboard (Staff):
• Week-at-a-glance forecast for all parks
• Red flag days (severe weather likely)
• Capacity planning based on expected weather
• Historical weather vs booking volume correlation`
          }
        ],
        notes: [
          'Don\'t over-alert customers - only send for genuinely severe conditions',
          'Allow customers to opt-in/out of weather notifications',
          'Partner with local weather services for hyperlocal forecasts',
          'Track accuracy of weather alerts vs actual conditions',
          'Offer "Weather Insurance" add-on for risk-averse customers',
          'Create standardized weather response playbook for staff',
          'Consider push notifications for last-minute severe weather',
          'Add weather widget to customer dashboard showing upcoming event forecasts'
        ]
      }
    },
    {
      key: 'team-accounts',
      title: 'Team & Organization Accounts',
      description: 'Bulk booking management for coaches, league organizers, and team parents.',
      details: {
        overview: 'Allow teams and organizations to create accounts, manage multiple bookings, centralize billing, and get volume discounts. Perfect for leagues, travel ball teams, and tournament organizers.',
        components: [
          {
            title: '1. Organization Account Structure',
            content: `Account Types:

Team Account:
• One coach/parent as primary account holder
• Add team members (players' parents)
• Team name, age group, sport
• Season schedule
• Bulk booking for tournament weekends

League Account:
• League administrator as primary
• Add team coaches as sub-accounts
• Manage multiple teams
• Coordinate field assignments
• Volume pricing tier

Tournament Organizer Account:
• Manage vendor setups
• VIP packages for sponsors
• Bulk discount codes for participants

Entity: Organizations
{
  "name": "ETX Tigers 12U",
  "type": "team" | "league" | "tournament",
  "sport": "softball",
  "primaryContactId": "...",
  "members": [{
    "userId": "...",
    "role": "coach" | "parent" | "admin",
    "permissions": ["book", "view", "manage"]
  }],
  "billingEmail": "coach@etxtigers.com",
  "volumeDiscount": 15, // percent
  "seasonDates": {
    "start": "2025-03-01",
    "end": "2025-10-31"
  }
}`
          },
          {
            title: '2. Bulk Booking Features',
            content: `Team Season Booking:

Upload Tournament Schedule:
• Import CSV with dates, locations, game times
• System suggests optimal booking dates
• Review and approve suggested bookings
• One-click checkout for entire season

Recurring Bookings:
• "Book every Saturday from March-October"
• "Book 10 weekends, same package"
• Auto-apply to all dates
• Manage exceptions (skip dates, change parks)

Bulk Discount Calculator:
• 5+ bookings: 10% off
• 10+ bookings: 15% off
• 20+ bookings: 20% off
• Season pass: 25% off (all bookings for season)

Shared Calendar:
• Team calendar showing all bookings
• Members can view but not edit (unless permitted)
• iCal feed for external calendar apps
• Reminders sent to all team members

Delegation:
• Coach books, parents can view
• "Parent Payment Mode": each parent pays for their dates
• Split billing between parents
• Assign specific bookings to specific members`
          },
          {
            title: '3. Centralized Billing',
            content: `Payment Options:

Single Account Holder Pays:
• Coach/admin credit card on file
• Monthly invoices
• Net 30 terms (for established accounts)
• Auto-pay option

Split Payments:
• Divide total among team members
• Each parent pays their share
• Track who has paid, who hasn't
• Send reminders to outstanding payers
• Allow partial payments

PO/Invoice Billing:
• For leagues and organizations
• Issue PO number
• Send invoices after service
• Payment terms (Net 15, Net 30)
• Credit application required

Payment Dashboard:
• See all bookings and payment status
• Download invoices and receipts
• Payment history
• Projected costs for season
• Budget tracking

Entity: OrganizationInvoices
{
  "organizationId": "...",
  "billingPeriod": "2025-06",
  "lineItems": [{
    "bookingId": "...",
    "date": "...",
    "amount": 54.00
  }],
  "subtotal": 540.00,
  "discount": 81.00, // 15% volume discount
  "total": 459.00,
  "status": "unpaid" | "paid" | "overdue",
  "dueDate": "2025-07-15"
}`
          },
          {
            title: '4. Team Management Portal',
            content: `Admin Dashboard for Teams:

Overview Screen:
• Upcoming bookings
• Season booking calendar
• Payment status
• Team roster
• Volume discount progress

Roster Management:
• Add/remove team members
• Assign roles and permissions
• View member booking history
• Communication preferences

Booking Management:
• View all team bookings
• Filter by date, status, park
• Bulk actions (cancel, reschedule, modify)
• Notes for staff (special requests)
• Equipment preferences saved

Communication Tools:
• Send message to all team members
• Booking confirmations CC'd to team
• Automated reminders
• Share booking details

Reports:
• Total spend for season
• Most-booked parks/fields
• Equipment utilization
• Comparison to last season
• Savings from volume discounts

Team Preferences:
• Preferred parks
• Preferred packages
• Standard add-ons
• Setup instructions (e.g., "always home side")
• Emergency contact`
          }
        ],
        notes: [
          'Require minimum team size (e.g., 8 members) to qualify for team account',
          'Offer free trial season for teams to encourage adoption',
          'Create onboarding flow to help coaches set up team accounts',
          'Provide team account templates for different sports',
          'Add referral bonus for teams that recruit other teams',
          'Consider partnership with league management software (GameChanger, TeamSnap)',
          'Offer concierge service to help teams plan entire season',
          'Create case studies showing cost savings for team accounts'
        ]
      }
    },
    {
      key: 'id-capture',
      title: 'Customer ID Verification via QR Check-In',
      description: 'Capture and securely store photo IDs when customers check in via QR code for booking verification and security.',
      details: {
        overview: 'When customers scan their QR code to check in, prompt them to take a photo of their government-issued ID. This enhances security, verifies customer identity, and helps prevent fraud. The ID photo is securely stored in private storage and linked to their booking.',
        components: [
          {
            title: '1. Update Bookings Entity',
            content: `Add fields to store ID photo information:

File: entities/Bookings.json

New Fields:
• idPhotoUri (string): Private file URI of the uploaded ID photo
• idPhotoUploadedAt (string, date-time): Timestamp when ID was captured
• idVerifiedBy (string, optional): Staff member who verified the ID
• idVerifiedAt (string, date-time, optional): When ID was verified

Purpose:
• Link ID photos to specific bookings
• Track verification status
• Audit trail for compliance
• Support data retention policies`
          },
          {
            title: '2. Update Check-In Page (pages/CheckIn)',
            content: `Modify check-in flow to include ID capture:

Current Flow:
1. Scan QR code → Find booking → Update status → Done

New Flow:
1. Scan QR code
2. Find booking
3. **Prompt for ID photo capture**
4. Show camera interface
5. Capture & preview photo
6. Upload to private storage
7. Update booking with ID URI
8. Update status & complete check-in

UI Components Needed:
• Modal/Section with clear explanation
• Camera access prompt
• Live camera preview
• Capture button
• Photo preview with retake option
• Upload progress indicator
• Success/Error messages

User Experience:
• Clear headline: "Verify Your Booking with a Photo ID"
• Friendly explanation: "To ensure accuracy and secure your setup, we require a photo of your valid government-issued ID. This helps us confirm your identity for booking [ID]."
• Simple "Take Photo" button
• "Retake Photo" if unhappy with result
• "Upload & Continue" to proceed
• Loading spinner during upload
• Success message: "✅ ID verified! Your setup is confirmed."`
          },
          {
            title: '3. Backend Function: Upload ID Photo',
            content: `Create functions/uploadIdPhoto.js for secure upload:

Purpose:
• Handle ID photo upload securely
• Use UploadPrivateFile (not public upload)
• Update booking record with file URI
• Return success/error status

Function Flow:
1. Receive image file from frontend
2. Validate file type (jpg, png, pdf)
3. Validate file size (< 5MB recommended)
4. Upload to private storage using Core.UploadPrivateFile
5. Get file_uri from response
6. Update Bookings entity with:
   - idPhotoUri: result.file_uri
   - idPhotoUploadedAt: current timestamp
7. Return success message

Security Benefits:
• Files stored in private directory
• Not publicly accessible
• Requires signed URL to view
• Automatic encryption at rest

Example Code Structure:
import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { bookingId, imageFile } = await req.formData();
    
    // Validate booking exists
    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }
    
    // Upload to private storage
    const result = await base44.integrations.Core.UploadPrivateFile({ 
      file: imageFile 
    });
    
    // Update booking
    await base44.asServiceRole.entities.Bookings.update(bookingId, {
      idPhotoUri: result.file_uri,
      idPhotoUploadedAt: new Date().toISOString()
    });
    
    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});`
          },
          {
            title: '4. Backend Function: View ID Photo (Admin)',
            content: `Create functions/viewIdPhoto.js for secure viewing:

Purpose:
• Generate temporary signed URLs for staff to view IDs
• Enforce admin-only access
• Set expiration time on links

Function Flow:
1. Receive bookingId from admin user
2. Verify user is authenticated admin
3. Fetch booking to get idPhotoUri
4. Generate signed URL using Core.CreateFileSignedUrl
5. Return signed URL (expires in 5-10 minutes)

Security Checks:
• Verify base44.auth.me() is admin role
• Check booking exists
• Check idPhotoUri is present
• Generate short-lived signed URL

Example Code:
import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    // Admin only
    if (user.role !== 'admin') {
      return Response.json({ error: 'Unauthorized' }, { status: 403 });
    }
    
    const { bookingId } = await req.json();
    
    // Get booking
    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking?.idPhotoUri) {
      return Response.json({ error: 'No ID photo found' }, { status: 404 });
    }
    
    // Generate signed URL (expires in 5 minutes)
    const result = await base44.integrations.Core.CreateFileSignedUrl({
      file_uri: booking.idPhotoUri,
      expires_in: 300
    });
    
    return Response.json({ 
      signed_url: result.signed_url,
      expires_in: 300 
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});`
          },
          {
            title: '5. Admin Dashboard Updates',
            content: `Update AdminBookings component to show ID verification:

Features to Add:
• "View ID" button in booking details
• Shows "ID Verified ✓" badge if uploaded
• Shows "No ID" warning if missing
• Click "View ID" to open photo in new tab
• Shows upload timestamp
• Option to mark as "Verified" after review

UI Changes in AdminBookings:

In expanded booking details section, add:

<div style={{ marginTop: "16px", padding: "12px", background: "#f8fafc", borderRadius: "8px" }}>
  <h4>ID Verification</h4>
  {booking.idPhotoUri ? (
    <>
      <div className="badge badge-success">ID Uploaded ✓</div>
      <div style={{ fontSize: "12px", color: "#64748b", marginTop: "4px" }}>
        Uploaded: {new Date(booking.idPhotoUploadedAt).toLocaleString()}
      </div>
      <button 
        onClick={() => handleViewId(booking.id)}
        className="btn-outline"
        style={{ marginTop: "8px" }}
      >
        View ID Photo
      </button>
    </>
  ) : (
    <div className="badge badge-warn">No ID Uploaded</div>
  )}
</div>

Handler Function:
async function handleViewId(bookingId) {
  try {
    const response = await base44.functions.invoke('viewIdPhoto', { bookingId });
    window.open(response.data.signed_url, '_blank');
  } catch (error) {
    alert('Failed to load ID: ' + error.message);
  }
}`
          },
          {
            title: '6. Camera Interface Implementation',
            content: `Implement camera capture in CheckIn page:

Use Web APIs for camera access:

const IdCapture = ({ onCapture, onSkip }) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [stream, setStream] = useState(null);
  const [capturedImage, setCapturedImage] = useState(null);
  const [cameraActive, setCameraActive] = useState(false);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } // Use back camera on mobile
      });
      videoRef.current.srcObject = mediaStream;
      setStream(mediaStream);
      setCameraActive(true);
    } catch (error) {
      alert('Camera access denied. Please enable camera permissions.');
    }
  };

  const capturePhoto = () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0);
    
    canvas.toBlob((blob) => {
      setCapturedImage(URL.createObjectURL(blob));
      stopCamera();
    }, 'image/jpeg', 0.9);
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setCameraActive(false);
    }
  };

  const retake = () => {
    setCapturedImage(null);
    startCamera();
  };

  const uploadPhoto = async () => {
    const canvas = canvasRef.current;
    canvas.toBlob(async (blob) => {
      const file = new File([blob], 'id-photo.jpg', { type: 'image/jpeg' });
      onCapture(file);
    }, 'image/jpeg', 0.9);
  };

  return (
    <div style={{ /* modal styling */ }}>
      <h2>Verify Your ID</h2>
      <p>Take a clear photo of your government-issued ID</p>
      
      {!cameraActive && !capturedImage && (
        <button onClick={startCamera} className="btn">
          Take Photo of ID
        </button>
      )}
      
      {cameraActive && (
        <div>
          <video ref={videoRef} autoPlay playsInline style={{ width: '100%' }} />
          <button onClick={capturePhoto} className="btn">Capture</button>
        </div>
      )}
      
      {capturedImage && (
        <div>
          <img src={capturedImage} alt="ID Preview" style={{ width: '100%' }} />
          <button onClick={retake} className="btn-outline">Retake</button>
          <button onClick={uploadPhoto} className="btn">Upload & Continue</button>
        </div>
      )}
      
      <canvas ref={canvasRef} style={{ display: 'none' }} />
    </div>
  );
};

Mobile Optimization:
• Use 'environment' facing mode for back camera
• Ensure responsive design
• Large, easy-to-tap buttons
• Clear visual feedback
• Handle portrait/landscape orientation`
          },
          {
            title: '7. Privacy & Compliance Considerations',
            content: `Important legal and privacy requirements:

Data Retention Policy:
• Determine how long ID photos should be kept
• Recommended: 30 days after event completion
• Automatically delete expired ID photos
• Document retention policy in Terms of Service

Privacy Notice:
• Update Privacy Policy to include ID capture
• Explain why IDs are collected (verification, fraud prevention)
• Describe how data is stored (encrypted, private)
• Explain who can access (staff only, for verification)
• Outline deletion timeline

Consent:
• Add checkbox during booking: "I consent to providing photo ID during check-in"
• Or prompt consent during ID capture step
• Store consent timestamp in booking record

Access Control:
• Only admin users can view ID photos
• Log all ID photo access attempts
• Staff member name recorded when viewing ID
• Create audit trail entity for compliance

Automatic Cleanup:
Create a scheduled function to delete old ID photos:

functions/cleanupExpiredIdPhotos.js:
• Run daily via cron job
• Find bookings with ID photos where event date + 30 days < today
• Delete file from private storage
• Clear idPhotoUri from booking record
• Log deletion for audit trail

Security Best Practices:
• Never store IDs in public storage
• Use signed URLs with short expiration
• Encrypt data at rest (automatic with UploadPrivateFile)
• Require re-authentication for sensitive operations
• Implement rate limiting on view requests`
          },
          {
            title: '8. Implementation Workflow',
            content: `Step-by-step rollout plan:

Phase 1 - Data Model (Week 1):
1. Update Bookings entity with ID fields
2. Test entity changes in dev environment
3. Document new fields in admin guide

Phase 2 - Backend Functions (Week 1-2):
4. Create uploadIdPhoto function
5. Create viewIdPhoto function
6. Test upload and signed URL generation
7. Add error handling and validation

Phase 3 - Check-In Page (Week 2):
8. Build IdCapture component
9. Integrate camera interface
10. Test on multiple devices (iOS, Android, desktop)
11. Handle camera permission denials gracefully
12. Add loading states and error messages

Phase 4 - Admin Interface (Week 2):
13. Update AdminBookings to show ID status
14. Add "View ID" button
15. Test signed URL generation from admin view
16. Add verification tracking

Phase 5 - Privacy & Compliance (Week 3):
17. Update Privacy Policy
18. Update Terms of Service
19. Add consent mechanisms
20. Create cleanup function for old IDs
21. Document retention policy

Phase 6 - Testing (Week 3):
22. Test full flow: QR scan → ID capture → Upload → Admin view
23. Test on multiple devices and browsers
24. Test camera on iOS Safari, Android Chrome
25. Test error scenarios (no camera, upload failure)
26. Security audit of file storage and access

Phase 7 - Staff Training (Week 4):
27. Create training materials for staff
28. Document how to view and verify IDs
29. Explain when to request ID re-upload
30. Train on privacy requirements

Phase 8 - Rollout (Week 4):
31. Deploy to production
32. Monitor first few check-ins closely
33. Gather customer feedback
34. Adjust UX based on real-world usage`
          }
        ],
        notes: [
          'Test camera access on various mobile browsers (iOS Safari can be tricky)',
          'Consider fallback option for users without camera access (manual upload via email/support)',
          'May want to add OCR to automatically extract name from ID for verification',
          'Consider adding face matching between ID photo and live selfie for enhanced security',
          'Ensure compliance with local privacy laws (GDPR, CCPA, etc.)',
          'Consider adding ID type field (Driver License, Passport, State ID)',
          'May want to blur/mask sensitive ID information (address, ID number) in admin view',
          'Add notification to staff when ID is uploaded for review',
          'Consider adding "ID Verification Required" badge on bookings missing ID'
        ]
      }
    },
    {
      key: 'coupon-system',
      title: 'Coupon/Discount Code System',
      description: 'Implement a system for creating and applying coupon or discount codes during booking.',
      details: {
        overview: 'Allow customers to enter discount codes during checkout to receive percentage or fixed-amount discounts on their bookings.',
        components: [
          {
            title: '1. New Entity: DiscountCode',
            content: `Create a new entity to store discount code details:

Fields:
• code (string, unique): The actual coupon code (e.g., "SAVE10", "WELCOME20")
• type (string, enum: "percentage", "fixed_amount"): Whether the discount is a percentage or fixed amount
• value (number): The discount value (e.g., 10 for 10%, or 20 for $20 off)
• minimumPurchaseUSD (number, optional): Minimum order value required to apply discount
• expiryDate (date, optional): When the discount code expires
• usageLimit (number, optional): Total number of times this code can be used across all customers
• perCustomerLimit (number, optional): How many times a single customer can use this code
• applicableTo (string, enum: "all", "packages", "events", optional): What the discount applies to
• applicableIds (array of strings, optional): If applicableTo is "packages" or "events", list of specific IDs
• isActive (boolean): Whether the code is currently active

File: entities/DiscountCode.json`
          },
          {
            title: '2. Integrate into Booking Flow',
            content: `Modify pages/book.js to add discount code functionality:

UI Changes:
• Add text input field for entering discount code
• Add "Apply" button next to the input field
• Show success/error messages after code validation
• Display discount amount in the totals breakdown

Validation Logic:
• Fetch DiscountCode entity matching the entered code
• Check if code is active and not expired
• Verify minimum purchase requirements are met
• Check usage limits (total and per customer)
• Display appropriate success or error message

Update Totals:
• Modify calculateTotals function to apply discount before tax/fees
• Deduct discount amount from subtotal
• Store applied discount in booking record`
          },
          {
            title: '3. Backend Function for Validation',
            content: `Create functions/applyDiscountCode.js for secure validation:

Purpose:
• Centralized, secure discount validation logic
• Prevents client-side manipulation
• Ensures consistent application across the platform

Function Responsibilities:
• Receive booking details (package, add-ons, etc.) and entered code
• Perform all validation checks against DiscountCode entity
• Calculate exact discount amount
• Return updated totals or error message
• Log usage for tracking purposes

Security Benefits:
• Validates code on server-side
• Checks limits against database records
• Prevents unauthorized discount application`
          },
          {
            title: '4. Update Bookings Entity',
            content: `Add discount tracking fields to entities/Bookings.json:

New Fields:
• discountCodeId (string, optional): Reference to DiscountCode entity used
• discountAmountCents (integer, optional): Actual monetary value of discount applied
• discountType (string, enum: "percentage", "fixed_amount", optional): Type of discount for records

Purpose:
• Track which discounts were applied to each booking
• Calculate discount usage statistics
• Support refund calculations
• Generate financial reports`
          },
          {
            title: '5. Admin Interface',
            content: `Create components/admin/AdminDiscountCodes.js:

Features:
• Create new discount codes with all settings
• View list of all discount codes with status
• Edit existing codes (dates, limits, values)
• Deactivate or delete codes
• View usage statistics for each code:
  - Total times used
  - Revenue impact
  - Top customers using the code
  - Usage over time graph

Management Capabilities:
• Bulk create codes for campaigns
• Export usage data to CSV
• Set automatic expiration
• Clone existing codes for similar promotions`
          },
          {
            title: '6. Implementation Workflow',
            content: `Step-by-step implementation order:

Phase 1 - Foundation:
1. Create DiscountCode entity (entities/DiscountCode.json)
2. Create backend validation function (functions/applyDiscountCode.js)
3. Update Bookings entity with discount fields

Phase 2 - Admin Tools:
4. Create AdminDiscountCodes component
5. Add to Admin navigation
6. Test code creation and management

Phase 3 - Customer-Facing:
7. Modify Book page UI (input field, apply button)
8. Integrate backend validation function
9. Update calculateTotals to apply discounts
10. Update receipt/confirmation to show discount

Phase 4 - Reporting:
11. Add discount tracking to reports
12. Create discount performance dashboard
13. Add to financial exports`
          }
        ],
        notes: [
          'Consider adding automatic discount application based on customer segments or order value',
          'May want to add referral codes that give discounts to both referrer and referee',
          'Could integrate with email campaigns to send targeted discount codes',
          'Consider time-based discounts (e.g., early bird pricing) as extension',
          'May want to track marketing channel attribution with discount codes'
        ]
      }
    },
    {
      key: 'schedule-import',
      title: 'Import Tournament & League Schedules',
      description: 'Automatically import game schedules from PlayNCS (tournaments) and GotSport (leagues) to eliminate manual data entry.',
      details: {
        overview: 'Allow customers to select their team from tournament/league websites, automatically pulling their game times, fields, and opponents. This eliminates manual entry of 100+ games across 26 fields for leagues, and streamlines tournament bookings.',
        components: [
          {
            title: '1. NCS Tournament Import (PlayNCS.com)',
            content: `Import tournament schedules from PlayNCS public pages:

Example URL:
https://www.playncs.com/fastpitch/Events/Schedule/10838/2nd-annual-strike-out-cancer

How it Works:
• Customer enters tournament event ID and slug from URL
• Customer selects their division (e.g., "12U OPEN")
• Customer types their team name
• System fetches printable schedule page for that division
• Parses game rows containing team name
• Extracts: date, time, field, opponent, division
• Auto-fills game times on booking page

Backend Function: functions/ncs/schedule.js
• GET endpoint with params: eventId, slug, division, team
• Fetches printable schedule URL (consistent HTML format)
• Parses rows matching team name
• Returns normalized game list with ISO timestamps
• Calculates setup windows (e.g., 90 min before first game)

Frontend Widget:
• Add "Import Team Schedule" section on Book page
• Input fields: Event ID, Slug, Division, Team Name
• "Fetch Schedule" button → displays game list preview
• "Use These Times" button → pre-fills booking form

Data Returned:
{
  "games": [{
    "startsAtISO": "2025-10-04T08:00:00",
    "endsAtISO": "2025-10-04T09:15:00",
    "dateLabel": "Sat",
    "field": "Airport Park 4",
    "teamA": "ETX Tigers 12U",
    "teamB": "Nitro 2K14",
    "division": "12U OPEN"
  }],
  "sourceUrl": "https://www.playncs.com/..."
}`
          },
          {
            title: '2. GotSport League Import',
            content: `Import full league schedules from GotSport public pages:

Example URL:
https://system.gotsport.com/org_event/events/48243

The Challenge:
• 100+ games across 26 fields
• Ages 5U to 18U
• Variable game durations (not fixed intervals)
• Multiple divisions and teams

Two Import Methods:

A) Admin CSV/XLSX Export (Preferred):
• League admin exports entire schedule from GotSport
• Upload to Sideline Setups admin panel
• System maps columns: Date, Start, End, Field, Home Team, Away Team, Age Group
• Auto-creates: Fields, Divisions, Teams, Games
• Generates bookable setup windows for each game

B) Public Page Scraper (No Admin Access):
• Paste event hub URL
• System crawls all age/gender groups
• For each group, fetches "View All Matches" HTML page
• Parses game table (Match#, Time, Home, Away, Location)
• Falls back to "View PDF" if HTML unavailable
• Returns normalized game list

Backend Functions:
• functions/import/gotsport/csv.js - handles CSV/XLSX upload
• functions/import/gotsport/fetch.js - scrapes public pages
• functions/import/gotsport/group.js - fetches one group's schedule

Normalized Game Object:
{
  "division": "U5 Boys",
  "date": "2025-10-18",
  "timeLocal": "09:30",
  "tz": "America/Chicago",
  "field": "Lindsey Park - 4v4-01E",
  "home": "Tyler SA Squirtle Squad",
  "away": "Tyler SA Gators",
  "matchNo": "301",
  "source": "gotsport:view-all-matches"
}`
          },
          {
            title: '3. New Entities for League Management',
            content: `Create new entities to store imported league data:

Entity: LeagueSeasons
• name (string): "Fall 2025", "Spring 2026"
• startDate, endDate (dates)
• provider (enum): "gotsport", "ncs", "manual"
• externalId (string): reference to source system
• importedAt (datetime)

Entity: Divisions
• leagueSeasonId (ref)
• name (string): "U5 Boys", "12U Girls"
• ageGroup (string): "5U", "12U"
• gender (enum): "boys", "girls", "coed"
• defaultGameDuration (number): minutes

Entity: Teams
• divisionId (ref)
• name (string): "ETX Tigers 12U"
• externalId (string): from source system
• contactEmail, contactPhone (optional)

Entity: Games
• leagueSeasonId (ref)
• divisionId (ref)
• fieldId (ref to existing Fields entity)
• homeTeamId (ref to Teams)
• awayTeamId (ref to Teams)
• startsAt (datetime)
• endsAt (datetime)
• source (enum): "gotsport_csv", "gotsport_html", "ncs", "manual"
• importKey (string, unique): for idempotency (date|time|field|home|away)
• externalMatchId (string): from source system

Benefits:
• One import creates all games in single pass
• Idempotent by importKey (re-import safe)
• Links to existing Fields entity
• Ready for parent-facing booking`
          },
          {
            title: '4. Admin Interface Updates',
            content: `Add "Import Schedules" tab to League admin section:

Features:

A) CSV/XLSX Upload:
• Drag-and-drop file upload
• Preview table showing parsed games
• Column mapping interface (if headers vary)
• "Import N Games" button
• Progress indicator during import
• Summary report (X games, Y fields, Z teams created)

B) Public URL Import:
• Input field for event hub URL
• "Fetch Groups" button → lists all divisions
• Preview each division's schedule
• Select which divisions to import
• "Import Selected" button

C) Mappings Panel:
• Age Group → Division mapping
• Default game durations per division
• Field name normalization (handle variations)

D) Sync & Updates:
• "Re-fetch from Source" button
• Shows diff of changes since last import
• Option to update existing games or skip
• Maintains booking history

E) Import History:
• List of past imports with timestamps
• Games imported count
• Source (CSV vs URL)
• Re-import or rollback options`
          },
          {
            title: '5. Customer Booking Flow Changes',
            content: `Update League booking page to use imported schedules:

Current Flow (Manual):
• Customer enters date
• Selects park and field
• Manually types game times
• Limited to fixed-interval slots

New Flow (Imported):

Step 1: Select League & Division
• Dropdown of active league seasons
• Select division (auto-populated from imports)

Step 2: Select Team
• Typeahead search of teams in division
• Shows team's game count for season

Step 3: Preview Team Schedule
• Display table of team's games:
  - Date, Time, Opponent, Field
• Highlight games needing setup
• Option to select specific games

Step 4: Choose Setup Type
• "Before each game" (separate setups)
• "Continuous" (one setup for multiple games)
• "Custom" (select specific games)

Step 5: Auto-Generate Setup Windows
• System suggests windows (e.g., 60 min before kickoff)
• Shows field availability for each window
• Customer confirms or adjusts

Step 6: Complete Booking
• Package selection (existing flow)
• Add-ons (existing flow)
• Payment (existing flow)

Benefits:
• No manual time entry
• Accurate field assignments
• See real opponent info
• Handle schedule changes via re-import`
          },
          {
            title: '6. Implementation Workflow',
            content: `Step-by-step rollout plan:

Phase 1 - Data Model (Week 1):
1. Create LeagueSeasons entity
2. Create Divisions entity
3. Create Teams entity
4. Create Games entity
5. Update Fields entity if needed

Phase 2 - Backend Functions (Week 2):
6. Build functions/import/gotsport/csv.js
7. Build functions/import/gotsport/fetch.js
8. Build functions/import/gotsport/gotsport/group.js
9. Build functions/ncs/schedule.js
10. Add helper functions (parsing, normalization)

Phase 3 - Admin Interface (Week 3):
11. Create AdminLeagueImport component
12. Add CSV upload UI
13. Add URL scraper UI
14. Add preview/mapping interface
15. Add import history table
16. Integrate into Admin nav

Phase 4 - Customer Booking (Week 4):
17. Update League booking page
18. Add division/team selectors
19. Add schedule preview component
20. Add setup window generator
21. Wire to existing booking flow

Phase 5 - Testing & Polish (Week 5):
22. Test with real GotSport schedules
23. Test with real NCS tournaments
24. Handle edge cases (TBD fields, time conflicts)
25. Add error handling and user feedback
26. Documentation for staff

Phase 6 - Rollout (Week 6):
27. Import one league season (test)
28. Train staff on import process
29. Beta test with select customers
30. Full rollout to all leagues`
          },
          {
            title: '7. Technical Considerations',
            content: `Important factors to consider:

A) Scraping Ethics & Legality:
• PlayNCS and GotSport show public schedules
• Scraping may violate Terms of Service
• Always prefer admin exports (CSV) when available
• Respect robots.txt and rate limits
• Add proper User-Agent header
• Cache responses (5-10 min) to reduce load
• Have fallback to manual entry

B) Data Consistency:
• Team names may vary ("ETX Tigers" vs "ETX Tigers 12U")
• Use fuzzy matching for team lookups
• Field names need normalization
• Handle timezone conversions (America/Chicago)
• Store both local and UTC times

C) Schedule Changes:
• Leagues frequently update schedules
• Weather delays and makeups
• Need sync mechanism for updates
• Notify customers of changed game times
• Allow rebooking if field changes

D) Time Zones:
• Normalize all times to America/Chicago (Central)
• Display in user's local time on frontend
• Store UTC in database for consistency

E) Performance:
• Importing 100+ games should be fast (<30 sec)
• Use batch operations for DB writes
• Show progress indicators to user
• Queue large imports in background

F) Idempotency:
• Re-importing same schedule shouldn't duplicate
• Use importKey for deduplication
• Update existing records rather than create new`
          }
        ],
        notes: [
          'Start with CSV import first (simpler, more reliable)',
          'Add public scraper as backup for leagues without admin access',
          'Consider supporting other platforms (QuickScores, SportsEngine)',
          'Build manual fallback for sites that block scraping',
          'Add webhook support if GotSport/NCS offer APIs in future',
          'Track import success rates and common failure patterns',
          'Consider adding OCR for PDF schedules that are image-based',
          'May want to add schedule change notifications via SMS/email'
        ]
      }
    }
  ];

  return (
    <div style={{ padding: "24px" }}>
      <div style={{ marginBottom: "32px" }}>
        <h1 style={{ 
          margin: "0 0 8px 0", 
          fontSize: "28px", 
          fontWeight: "700", 
          color: "#003f5c",
          display: "flex",
          alignItems: "center",
          gap: "12px"
        }}>
          <Folder size={28} />
          Future Projects
        </h1>
        <p style={{ margin: 0, color: "#64748b", fontSize: "14px" }}>
          Ideas and plans for features to implement later. Click on any project to expand details.
        </p>
      </div>

      <div style={{ display: "grid", gap: "20px" }}>
        {projects.map((project) => (
          <div 
            key={project.key}
            style={{ 
              background: "white", 
              borderRadius: "12px", 
              border: "1px solid #e2e8f0", 
              overflow: "hidden",
              boxShadow: "0 1px 3px rgba(0,0,0,0.1)" 
            }}
          >
            {/* Project Header */}
            <button
              onClick={() => toggleProject(project.key)}
              style={{
                width: "100%",
                padding: "20px",
                background: expandedProjects[project.key] ? "#f8fafc" : "white",
                border: "none",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                transition: "background 0.2s"
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "12px", textAlign: "left" }}>
                <GitBranch size={20} style={{ color: "#003f5c", flexShrink: 0 }} />
                <div>
                  <h3 style={{ 
                    margin: "0 0 4px 0", 
                    fontSize: "18px", 
                    fontWeight: "600", 
                    color: "#003f5c" 
                  }}>
                    {project.title}
                  </h3>
                  <p style={{ margin: 0, color: "#64748b", fontSize: "14px" }}>
                    {project.description}
                  </p>
                </div>
              </div>
              {expandedProjects[project.key] ? (
                <ChevronDown size={20} style={{ color: "#64748b", flexShrink: 0 }} />
              ) : (
                <ChevronRight size={20} style={{ color: "#64748b", flexShrink: 0 }} />
              )}
            </button>

            {/* Project Details */}
            {expandedProjects[project.key] && (
              <div style={{ padding: "0 20px 20px 20px" }}>
                <div style={{ 
                  padding: "16px", 
                  background: "#f8fafc", 
                  borderRadius: "8px",
                  marginBottom: "20px"
                }}>
                  <h4 style={{ 
                    margin: "0 0 8px 0", 
                    fontSize: "14px", 
                    fontWeight: "600", 
                    color: "#003f5c",
                    textTransform: "uppercase",
                    letterSpacing: "0.05em"
                  }}>
                    Overview
                  </h4>
                  <p style={{ margin: 0, color: "#475569", fontSize: "14px", lineHeight: "1.6" }}>
                    {project.details.overview}
                  </p>
                </div>

                {/* Components */}
                <div style={{ display: "grid", gap: "16px" }}>
                  {project.details.components.map((component, idx) => (
                    <div 
                      key={idx}
                      style={{ 
                        padding: "16px", 
                        background: "white", 
                        border: "1px solid #e2e8f0",
                        borderRadius: "8px"
                      }}
                    >
                      <h4 style={{ 
                        margin: "0 0 12px 0", 
                        fontSize: "15px", 
                        fontWeight: "600", 
                        color: "#003f5c"
                      }}>
                        {component.title}
                      </h4>
                      <pre style={{ 
                        margin: 0, 
                        color: "#475569", 
                        fontSize: "13px", 
                        lineHeight: "1.6",
                        fontFamily: "ui-monospace, monospace",
                        whiteSpace: "pre-wrap",
                        wordWrap: "break-word"
                      }}>
                        {component.content}
                      </pre>
                    </div>
                  ))}
                </div>

                {/* Notes */}
                {project.details.notes && project.details.notes.length > 0 && (
                  <div style={{ 
                    marginTop: "20px",
                    padding: "16px", 
                    background: "#fffbeb", 
                    border: "1px solid #fde68a",
                    borderRadius: "8px"
                  }}>
                    <h4 style={{ 
                      margin: "0 0 12px 0", 
                      fontSize: "14px", 
                      fontWeight: "600", 
                      color: "#92400e",
                      textTransform: "uppercase",
                      letterSpacing: "0.05em"
                    }}>
                      Additional Notes & Ideas
                    </h4>
                    <ul style={{ 
                      margin: 0, 
                      paddingLeft: "20px",
                      color: "#78350f", 
                      fontSize: "13px", 
                      lineHeight: "1.6"
                    }}>
                      {project.details.notes.map((note, idx) => (
                        <li key={idx} style={{ marginBottom: "6px" }}>{note}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Add New Project Button */}
      <div style={{ 
        marginTop: "24px", 
        padding: "20px", 
        background: "white",
        border: "2px dashed #e2e8f0",
        borderRadius: "12px",
        textAlign: "center"
      }}>
        <p style={{ margin: "0 0 12px 0", color: "#64748b", fontSize: "14px" }}>
          Have more ideas? Add them to this section by editing:
        </p>
        <code style={{ 
          padding: "4px 8px", 
          background: "#f1f5f9", 
          borderRadius: "4px",
          fontSize: "13px",
          color: "#0f172a"
        }}>
          components/admin/AdminFutureProjects.js
        </code>
      </div>
    </div>
  );
}
