import React from "react";

export default function CrudTable({ title: entityName, entityClient, fields: columns, defaultSortKey, onCreate, onEdit }) {
  const [rows, setRows] = React.useState([]);
  const [editingRow, setEditingRow] = React.useState(null);
  const [newRow, setNewRow] = React.useState({});
  const [showCreateModal, setShowCreateModal] = React.useState(false);
  const [refData, setRefData] = React.useState({});

  async function load() {
    const data = await entityClient.list(defaultSortKey ? `-${defaultSortKey}` : undefined);
    setRows(data || []);
  }

  React.useEffect(() => {
    load();
    loadReferenceData();
  }, []);

  async function loadReferenceData() {
    const refs = {};
    for (const column of columns) {
      if (column.reference) {
        try {
          const { base44 } = await import("../../api/base44Client");
          const data = await base44.entities[column.reference].list();
          refs[column.key] = data || [];
        } catch (e) {
          console.warn(`Failed to load ${column.reference}:`, e);
          refs[column.key] = [];
        }
      }
    }
    setRefData(refs);
  }

  async function handleSaveEdit() {
    try {
      if (editingRow?.id) {
        await entityClient.update(editingRow.id, editingRow);
        if (onEdit) onEdit(editingRow);
      }
      setEditingRow(null);
      load();
    } catch (e) {
      alert("Error: " + e.message);
    }
  }

  async function handleCreateSave() {
    try {
      await entityClient.create(newRow);
      setShowCreateModal(false);
      setNewRow({});
      load();
      if (onCreate) onCreate(newRow);
    } catch (e) {
      alert("Error: " + e.message);
    }
  }

  async function handleDelete(id) {
    if (!confirm("Delete this record?")) return;
    try {
      await entityClient.delete(id);
      load();
    } catch (e) {
      alert("Error: " + e.message);
    }
  }

  function handleEdit(row) {
    setEditingRow({ ...row });
  }

  function handleStartCreate() {
    const defaults = {};
    columns.forEach(c => {
      if (c.default !== undefined) defaults[c.key] = c.default;
      else if (c.type === 'boolean') defaults[c.key] = false;
      else if (c.type === 'number') defaults[c.key] = 0;
      else defaults[c.key] = '';
    });
    setNewRow(defaults);
    setShowCreateModal(true);
  }

  function renderModalField(column, currentValue, onChangeHandler) {
    if (column.reference) {
      const options = refData[column.key] || [];
      return (
        <select
          className="select"
          value={currentValue || ""}
          onChange={(e) => onChangeHandler(e.target.value)}
        >
          <option value="">-- Select {column.label} --</option>
          {options.map((opt) => (
            <option key={opt.id} value={opt.id}>
              {opt.name || opt.label || opt.title || opt.fullName || opt.id}
            </option>
          ))}
        </select>
      );
    }

    if (column.type === "select") {
      return (
        <select
          className="select"
          value={currentValue || ""}
          onChange={(e) => onChangeHandler(e.target.value)}
        >
          <option value="">-- Select --</option>
          {column.options?.map((opt) => (
            <option key={opt} value={opt}>{opt}</option>
          ))}
        </select>
      );
    }

    if (column.type === "boolean") {
      return (
        <select
          className="select"
          value={String(currentValue ?? false)}
          onChange={(e) => onChangeHandler(e.target.value === 'true')}
        >
          <option value="true">Yes</option>
          <option value="false">No</option>
        </select>
      );
    }

    if (column.type === "number") {
      return (
        <input
          type="number"
          className="input"
          value={currentValue || ""}
          onChange={(e) => onChangeHandler(parseFloat(e.target.value) || 0)}
          style={{ maxWidth: '100%' }}
        />
      );
    }

    if (column.type === "textarea") {
      return (
        <textarea
          className="textarea"
          value={currentValue || ""}
          onChange={(e) => onChangeHandler(e.target.value)}
          rows={3}
          style={{ maxWidth: '100%' }}
        />
      );
    }

    if (column.type === "date") {
      return (
        <input
          type="date"
          className="input"
          value={currentValue || ""}
          onChange={(e) => onChangeHandler(e.target.value)}
          style={{ maxWidth: '100%' }}
        />
      );
    }

    if (column.type === "json") {
      return (
        <textarea
          className="textarea"
          value={typeof currentValue === "string" ? currentValue : JSON.stringify(currentValue || column.default, null, 2)}
          onChange={(e) => {
            try {
              const parsed = JSON.parse(e.target.value);
              onChangeHandler(parsed);
            } catch {
              onChangeHandler(e.target.value);
            }
          }}
          rows={5}
          style={{ fontFamily: "monospace", fontSize: 12, maxWidth: '100%' }}
        />
      );
    }

    if (column.key.includes('Url') || column.key.includes('url')) {
      return (
        <input
          className="input"
          type="text"
          value={currentValue || ''}
          onChange={(e) => onChangeHandler(e.target.value)}
          style={{
            maxWidth: '100%',
            fontSize: '12px'
          }}
          placeholder="Enter URL..."
        />
      );
    }

    return (
      <input
        type="text"
        className="input"
        value={currentValue || ""}
        onChange={(e) => onChangeHandler(e.target.value)}
        style={{ maxWidth: '100%' }}
      />
    );
  }

  function renderCell(row, column) {
    const value = row[column.key];

    if (column.reference && value) {
      const options = refData[column.key] || [];
      const match = options.find(opt => opt.id === value);
      return match ? (match.name || match.label || match.title || match.fullName || value) : value;
    }

    if (column.type === "boolean") return value ? "✓" : "";
    if (column.type === "json") return value !== null && value !== undefined ? JSON.stringify(value) : "—";
    if (value === null || value === undefined || value === "") return "—";
    return String(value);
  }

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2>{entityName}</h2>
        <button className="btn" onClick={handleStartCreate}>+ Add New</button>
      </div>

      {/* Table */}
      <div style={{ overflowX: 'auto' }}>
        <table className="table" style={{ minWidth: '100%', tableLayout: 'fixed' }}>
          <thead>
            <tr>
              {columns.map(col => (
                <th key={col.key} style={{
                  whiteSpace: 'nowrap',
                  padding: '8px 3px',
                  maxWidth: '120px',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                }}>
                  {col.label}
                </th>
              ))}
              <th style={{ width: '140px', textAlign: 'right', padding: '8px 3px' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(row => (
              <tr key={row.id}>
                {columns.map(col => (
                  <td key={col.key} style={{
                    maxWidth: '120px',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                    padding: '8px 3px',
                    fontSize: '13px'
                  }}>
                    {renderCell(row, col)}
                  </td>
                ))}
                <td style={{ textAlign: 'right', whiteSpace: 'nowrap', padding: '8px 3px' }}>
                  <button className="btn-outline" onClick={() => handleEdit(row)} style={{ marginRight: 4, fontSize: 11, padding: '4px 8px' }}>
                    Edit
                  </button>
                  <button className="btn-danger" onClick={() => handleDelete(row.id)} style={{ fontSize: 11, padding: '4px 8px' }}>
                    Del
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Edit Modal */}
      {editingRow && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100
        }}>
          <div className="card card-pad" style={{
            maxWidth: 600,
            width: '90%',
            maxHeight: '90vh',
            overflowY: 'auto'
          }}>
            <h3 style={{ marginBottom: 16 }}>Edit {entityName}</h3>
            <div style={{ display: 'grid', gap: 12 }}>
              {columns.map(col => (
                <div key={col.key}>
                  <label className="label">{col.label}{col.required && " *"}</label>
                  {renderModalField(col, editingRow[col.key], (value) =>
                    setEditingRow({ ...editingRow, [col.key]: value })
                  )}
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 16, justifyContent: 'flex-end' }}>
              <button className="btn-outline" onClick={() => setEditingRow(null)}>
                Cancel
              </button>
              <button className="btn" onClick={handleSaveEdit}>
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create Modal */}
      {showCreateModal && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100
        }}>
          <div className="card card-pad" style={{
            maxWidth: 600,
            width: '90%',
            maxHeight: '90vh',
            overflowY: 'auto'
          }}>
            <h3 style={{ marginBottom: 16 }}>Create {entityName}</h3>
            <div style={{ display: 'grid', gap: 12 }}>
              {columns.map(col => (
                <div key={col.key}>
                  <label className="label">{col.label}{col.required && " *"}</label>
                  {renderModalField(col, newRow[col.key], (value) =>
                    setNewRow({ ...newRow, [col.key]: value })
                  )}
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 16, justifyContent: 'flex-end' }}>
              <button className="btn-outline" onClick={() => setShowCreateModal(false)}>
                Cancel
              </button>
              <button className="btn" onClick={handleCreateSave}>
                Create
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}