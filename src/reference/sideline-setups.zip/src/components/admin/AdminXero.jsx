import AdminXero from "../../pages/AdminXero";

export default AdminXero;