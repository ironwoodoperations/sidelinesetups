
import React, { useState, useEffect } from "react";
import { getCtx } from "../lib/ctx";
import { Box, Edit, Trash2, Plus, AlertTriangle, GripVertical } from "lucide-react";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import ImageUrlPicker from "./ImageUrlPicker";

export default function AdminEquipment() {
  const [equipment, setEquipment] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingItem, setEditingItem] = useState(null);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    loadEquipment();
  }, []);

  async function loadEquipment() {
    try {
      setLoading(true);
      const { entities } = await getCtx();
      const items = await entities.Equipment.list();
      // Sort by displayOrder
      const sortedItems = (items || []).sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
      setEquipment(sortedItems);
    } catch (error) {
      console.error("Failed to load equipment:", error);
      alert("Failed to load equipment");
    } finally {
      setLoading(false);
    }
  }

  async function handleDragEnd(result) {
    if (!result.destination) return;

    const items = Array.from(equipment);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setEquipment(items);

    // Update displayOrder for all equipment
    try {
      const { entities } = await getCtx();
      const updatePromises = items.map((item, index) =>
        entities.Equipment.update(item.id, { displayOrder: index })
      );
      await Promise.all(updatePromises);
    } catch (error) {
      console.error("Failed to update equipment order:", error);
      alert("Failed to save new order");
      loadEquipment(); // Reload to reset
    }
  }

  async function handleSave(formData) {
    try {
      const { entities } = await getCtx();
      
      if (editingItem) {
        await entities.Equipment.update(editingItem.id, formData);
      } else {
        // New equipment gets added to the end
        await entities.Equipment.create({ ...formData, displayOrder: equipment.length });
      }
      
      setShowForm(false);
      setEditingItem(null);
      loadEquipment();
    } catch (error) {
      console.error("Failed to save equipment:", error);
      alert("Failed to save equipment");
    }
  }

  async function handleDelete(id) {
    if (!confirm("Delete this equipment item?")) return;
    
    try {
      const { entities } = await getCtx();
      await entities.Equipment.delete(id);
      loadEquipment();
    } catch (error) {
      console.error("Failed to delete equipment:", error);
      alert("Failed to delete equipment");
    }
  }

  function handleEdit(item) {
    setEditingItem(item);
    setShowForm(true);
  }

  function handleCancel() {
    setShowForm(false);
    setEditingItem(null);
  }

  const typeColors = {
    tent: "bg-blue-100 text-blue-800",
    chair: "bg-green-100 text-green-800",
    cooler: "bg-purple-100 text-purple-800",
    sidewall: "bg-orange-100 text-orange-800",
    fan: "bg-cyan-100 text-cyan-800",
    lighting: "bg-yellow-100 text-yellow-800",
    audio: "bg-pink-100 text-pink-800",
    misc: "bg-gray-100 text-gray-800"
  };

  const conditionColors = {
    excellent: "bg-green-100 text-green-800",
    good: "bg-blue-100 text-blue-800",
    fair: "bg-yellow-100 text-yellow-800",
    needs_repair: "bg-red-100 text-red-800"
  };

  if (loading) {
    return (
      <div style={{ padding: "40px", textAlign: "center" }}>
        <div className="spinner"></div>
        <p style={{ marginTop: "16px", color: "#64748b" }}>Loading equipment...</p>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <div style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: "24px"
      }}>
        <div>
          <h2 style={{ margin: 0, fontSize: "24px", fontWeight: "700", color: "#003f5c" }}>
            Equipment Inventory
          </h2>
          <p style={{ margin: "4px 0 0 0", color: "#64748b", fontSize: "14px" }}>
            Drag to reorder equipment display
          </p>
        </div>
        <button
          onClick={() => {
            setEditingItem(null);
            setShowForm(true);
          }}
          className="btn"
          style={{
            display: "flex",
            alignItems: "center",
            gap: "8px",
            background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
            color: "white"
          }}
        >
          <Plus size={18} />
          Add Equipment
        </button>
      </div>

      {/* Form Modal */}
      {showForm && (
        <EquipmentForm
          item={editingItem}
          onSave={handleSave}
          onCancel={handleCancel}
        />
      )}

      {/* Equipment Grid with Drag & Drop */}
      {equipment.length === 0 ? (
        <div className="card" style={{ padding: "40px", textAlign: "center" }}>
          <Box size={48} style={{ margin: "0 auto 16px", color: "#cbd5e1" }} />
          <h3 style={{ margin: "0 0 8px 0", color: "#64748b" }}>No Equipment Yet</h3>
          <p style={{ margin: "0 0 16px 0", color: "#94a3b8", fontSize: "14px" }}>
            Add your first equipment item to start tracking inventory
          </p>
          <button
            onClick={() => {
              setEditingItem(null);
              setShowForm(true);
            }}
            className="btn-outline"
            style={{ color: "#003f5c", borderColor: "#003f5c" }}
          >
            Add Equipment
          </button>
        </div>
      ) : (
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="equipment">
            {(provided) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
                  gap: "20px"
                }}
              >
                {equipment.map((item, index) => {
                  const available = Number(item.availableQty || 0);
                  const total = Number(item.totalQty || 0);
                  const rented = Number(item.rentedQty || 0);
                  const maintenance = Number(item.maintenanceQty || 0);
                  const damaged = Number(item.damagedQty || 0);
                  
                  const availabilityPercent = total > 0 ? (available / total) * 100 : 0;
                  const isLowStock = availabilityPercent < 20 && availabilityPercent > 0;
                  const isOutOfStock = available === 0;

                  return (
                    <Draggable key={item.id} draggableId={item.id} index={index}>
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          className="card"
                          style={{
                            overflow: "hidden",
                            border: isOutOfStock ? "2px solid #ef4444" : isLowStock ? "2px solid #f59e0b" : "1px solid #e2e8f0",
                            transition: "all 0.2s",
                            background: snapshot.isDragging ? "#f8fafc" : "white",
                            ...provided.draggableProps.style
                          }}
                        >
                          {/* Card Header */}
                          <div style={{
                            padding: "16px",
                            background: isOutOfStock ? "#fef2f2" : isLowStock ? "#fffbeb" : "#f8fafc",
                            borderBottom: "1px solid #e2e8f0"
                          }}>
                            <div style={{
                              display: "flex",
                              justifyContent: "space-between",
                              alignItems: "start",
                              marginBottom: "8px"
                            }}>
                              <div style={{ display: "flex", alignItems: "start", gap: "8px", flex: 1 }}>
                                <div
                                  {...provided.dragHandleProps}
                                  style={{
                                    cursor: "grab",
                                    color: "#94a3b8",
                                    padding: "4px"
                                  }}
                                >
                                  <GripVertical size={16} />
                                </div>
                                
                                {/* Thumbnail Image */}
                                {item.thumbnailUrl && (
                                  <img 
                                    src={item.thumbnailUrl} 
                                    alt={item.name}
                                    style={{
                                      width: "60px",
                                      height: "60px",
                                      objectFit: "cover",
                                      borderRadius: "8px",
                                      border: "1px solid #e2e8f0"
                                    }}
                                  />
                                )}
                                
                                <div style={{ flex: 1 }}>
                                  <h3 style={{
                                    margin: 0,
                                    fontSize: "18px",
                                    fontWeight: "600",
                                    color: "#0f172a"
                                  }}>
                                    {item.name}
                                  </h3>
                                </div>
                              </div>
                              <div style={{ display: "flex", gap: "4px" }}>
                                <button
                                  onClick={() => handleEdit(item)}
                                  style={{
                                    padding: "6px",
                                    background: "white",
                                    border: "1px solid #e2e8f0",
                                    borderRadius: "6px",
                                    cursor: "pointer",
                                    color: "#64748b"
                                  }}
                                  title="Edit"
                                >
                                  <Edit size={16} />
                                </button>
                                <button
                                  onClick={() => handleDelete(item.id)}
                                  style={{
                                    padding: "6px",
                                    background: "white",
                                    border: "1px solid #e2e8f0",
                                    borderRadius: "6px",
                                    cursor: "pointer",
                                    color: "#ef4444"
                                  }}
                                  title="Delete"
                                >
                                  <Trash2 size={16} />
                                </button>
                              </div>
                            </div>
                            
                            {/* Type Badge */}
                            <span
                              className={`badge ${typeColors[item.type] || typeColors.misc}`}
                              style={{ fontSize: "11px", textTransform: "capitalize" }}
                            >
                              {item.type || "misc"}
                            </span>
                          </div>

                          {/* Card Body */}
                          <div style={{ padding: "16px" }}>
                            {/* Availability Alert */}
                            {isOutOfStock && (
                              <div style={{
                                display: "flex",
                                alignItems: "center",
                                gap: "8px",
                                padding: "8px 12px",
                                background: "#fee2e2",
                                border: "1px solid #fecaca",
                                borderRadius: "6px",
                                marginBottom: "12px",
                                fontSize: "13px",
                                color: "#991b1b"
                              }}>
                                <AlertTriangle size={16} />
                                <span style={{ fontWeight: "600" }}>Out of Stock</span>
                              </div>
                            )}
                            
                            {isLowStock && !isOutOfStock && (
                              <div style={{
                                display: "flex",
                                alignItems: "center",
                                gap: "8px",
                                padding: "8px 12px",
                                background: "#fef3c7",
                                border: "1px solid #fde68a",
                                borderRadius: "6px",
                                marginBottom: "12px",
                                fontSize: "13px",
                                color: "#92400e"
                              }}>
                                <AlertTriangle size={16} />
                                <span style={{ fontWeight: "600" }}>Low Stock</span>
                              </div>
                            )}

                            {/* Inventory Stats */}
                            <div style={{
                              display: "grid",
                              gridTemplateColumns: "1fr 1fr 1fr",
                              gap: "12px",
                              marginBottom: "12px"
                            }}>
                              <div>
                                <div style={{ fontSize: "11px", color: "#64748b", marginBottom: "4px" }}>
                                  Available
                                </div>
                                <div style={{ fontSize: "24px", fontWeight: "700", color: "#10b981" }}>
                                  {available}
                                </div>
                              </div>
                              <div>
                                <div style={{ fontSize: "11px", color: "#64748b", marginBottom: "4px" }}>
                                  Rented
                                </div>
                                <div style={{ fontSize: "24px", fontWeight: "700", color: "#f59e0b" }}>
                                  {rented}
                                </div>
                              </div>
                              <div>
                                <div style={{ fontSize: "11px", color: "#64748b", marginBottom: "4px" }}>
                                  Total
                                </div>
                                <div style={{ fontSize: "24px", fontWeight: "700", color: "#003f5c" }}>
                                  {total}
                                </div>
                              </div>
                            </div>

                            {/* Detailed Breakdown - Only show if there are issues */}
                            {(maintenance > 0 || damaged > 0) && (
                              <div style={{
                                padding: "12px",
                                background: "#f8fafc",
                                borderRadius: "6px",
                                fontSize: "13px"
                              }}>
                                <div style={{ fontWeight: "600", marginBottom: "8px", color: "#475569" }}>
                                  Issues:
                                </div>
                                {maintenance > 0 && (
                                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                                    <span style={{ color: "#64748b" }}>Maintenance:</span>
                                    <span style={{ fontWeight: "600", color: "#f59e0b" }}>{maintenance}</span>
                                  </div>
                                )}
                                {damaged > 0 && (
                                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                                    <span style={{ color: "#64748b" }}>Damaged:</span>
                                    <span style={{ fontWeight: "600", color: "#ef4444" }}>{damaged}</span>
                                  </div>
                                )}
                              </div>
                            )}

                            {/* Condition Badge */}
                            {item.condition && (
                              <div style={{ marginTop: "12px" }}>
                                <span
                                  className={`badge ${conditionColors[item.condition] || conditionColors.good}`}
                                  style={{ fontSize: "11px", textTransform: "capitalize" }}
                                >
                                  {item.condition.replace('_', ' ')}
                                </span>
                              </div>
                            )}

                            {/* Notes */}
                            {item.notes && (
                              <div style={{
                                marginTop: "12px",
                                padding: "8px",
                                background: "#f8fafc",
                                borderRadius: "6px",
                                fontSize: "12px",
                                color: "#64748b",
                                fontStyle: "italic"
                              }}>
                                {item.notes}
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </Draggable>
                  );
                })}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      )}
    </div>
  );
}

function EquipmentForm({ item, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    type: item?.type || "misc",
    name: item?.name || "",
    thumbnailUrl: item?.thumbnailUrl || "",
    totalQty: item?.totalQty || 0,
    availableQty: item?.availableQty || 0,
    rentedQty: item?.rentedQty || 0,
    maintenanceQty: item?.maintenanceQty || 0,
    damagedQty: item?.damagedQty || 0,
    condition: item?.condition || "excellent",
    purchaseDate: item?.purchaseDate || "",
    cogsPerUseUSD: item?.cogsPerUseUSD || 0,
    notes: item?.notes || ""
  });

  function handleSubmit(e) {
    e.preventDefault();
    onSave(formData);
  }

  const QuantityInput = ({ label, field, min = 0 }) => (
    <div className="form-group">
      <label className="label">{label}</label>
      <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
        <button
          type="button"
          onClick={() => setFormData({ ...formData, [field]: Math.max(min, formData[field] - 1) })}
          disabled={formData[field] <= min}
          style={{
            width: "32px",
            height: "32px",
            padding: "0",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            border: "1px solid #e2e8f0",
            borderRadius: "6px",
            background: "white",
            cursor: "pointer",
            fontSize: "18px",
            fontWeight: "600",
            color: "#003f5c",
            opacity: formData[field] <= min ? 0.3 : 1
          }}
        >
          −
        </button>
        <input
          type="number"
          className="input"
          value={formData[field]}
          onChange={(e) => setFormData({ ...formData, [field]: parseInt(e.target.value) || 0 })}
          min={min}
          style={{
            flex: 1,
            textAlign: "center",
            fontWeight: "600"
          }}
        />
        <button
          type="button"
          onClick={() => setFormData({ ...formData, [field]: formData[field] + 1 })}
          style={{
            width: "32px",
            height: "32px",
            padding: "0",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            border: "1px solid #e2e8f0",
            borderRadius: "6px",
            background: "white",
            cursor: "pointer",
            fontSize: "18px",
            fontWeight: "600",
            color: "#003f5c"
          }}
        >
          +
        </button>
      </div>
    </div>
  );

  return (
    <div style={{
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: "rgba(0,0,0,0.5)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      zIndex: 1000,
      padding: "20px"
    }}>
      <div className="card" style={{
        maxWidth: "600px",
        width: "100%",
        maxHeight: "90vh",
        overflow: "auto",
        padding: "24px"
      }}>
        <h3 style={{ margin: "0 0 20px 0", fontSize: "20px", fontWeight: "700", color: "#003f5c" }}>
          {item ? "Edit Equipment" : "Add Equipment"}
        </h3>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="label">Type *</label>
            <select
              className="select"
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value })}
              required
            >
              <option value="tent">Tent</option>
              <option value="chair">Chair</option>
              <option value="cooler">Cooler</option>
              <option value="sidewall">Sidewall</option>
              <option value="fan">Fan</option>
              <option value="lighting">Lighting</option>
              <option value="audio">Audio</option>
              <option value="misc">Miscellaneous</option>
            </select>
          </div>

          <div className="form-group">
            <label className="label">Name *</label>
            <input
              type="text"
              className="input"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <ImageUrlPicker
              label="Equipment Thumbnail Image"
              value={formData.thumbnailUrl}
              onChange={(url) => setFormData({ ...formData, thumbnailUrl: url })}
            />
            <p style={{ fontSize: "12px", color: "#64748b", marginTop: "4px" }}>
              This image will appear on add-ons that use this equipment
            </p>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
            <QuantityInput label="Total Quantity *" field="totalQty" />
            <QuantityInput label="Available Quantity *" field="availableQty" />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "12px" }}>
            <QuantityInput label="Rented" field="rentedQty" />
            <QuantityInput label="Maintenance" field="maintenanceQty" />
            <QuantityInput label="Damaged" field="damagedQty" />
          </div>

          <div className="form-group">
            <label className="label">Condition</label>
            <select
              className="select"
              value={formData.condition}
              onChange={(e) => setFormData({ ...formData, condition: e.target.value })}
            >
              <option value="excellent">Excellent</option>
              <option value="good">Good</option>
              <option value="fair">Fair</option>
              <option value="needs_repair">Needs Repair</option>
            </select>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
            <div className="form-group">
              <label className="label">Purchase Date</label>
              <input
                type="date"
                className="input"
                value={formData.purchaseDate}
                onChange={(e) => setFormData({ ...formData, purchaseDate: e.target.value })}
              />
            </div>

            <div className="form-group">
              <label className="label">COGS per Use ($)</label>
              <input
                type="number"
                step="0.01"
                className="input"
                value={formData.cogsPerUseUSD}
                onChange={(e) => setFormData({ ...formData, cogsPerUseUSD: parseFloat(e.target.value) || 0 })}
                min="0"
              />
            </div>
          </div>

          <div className="form-group">
            <label className="label">Notes</label>
            <textarea
              className="textarea"
              rows={3}
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            />
          </div>

          <div style={{ display: "flex", gap: "12px", marginTop: "20px" }}>
            <button
              type="submit"
              className="btn"
              style={{
                flex: 1,
                background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
                color: "white"
              }}
            >
              {item ? "Update" : "Create"}
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="btn-outline"
              style={{
                flex: 1,
                color: "#64748b",
                borderColor: "#e2e8f0"
              }}
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
