
// components/admin/AdminSiteSettings.js
import React, { useState, useEffect } from "react";
import buildEntities from "../lib/entities";
import ImageUrlPicker from "./ImageUrlPicker"; // Import the new ImageUrlPicker component
// import { getCtx } from "../lib/ctx"; // No longer needed as alert is replaced by setMessage

export default function AdminSiteSettings() {
  const entities = buildEntities();
  // const { alert } = getCtx(); // Removed: Using internal message state instead of global alert

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({});
  const [message, setMessage] = useState(null);
  const [settingsId, setSettingsId] = useState(null); // New state to store the ID of the settings document

  useEffect(() => {
    async function fetchSettings() {
      try {
        setLoading(true);
        // Changed from .get() to .list() as SiteSettings might be an entity collection
        const settingsList = await entities.SiteSettings.list();

        if (settingsList && settingsList.length > 0) {
          const settings = settingsList[0];
          setForm(settings);
          setSettingsId(settings.id); // Store the ID of the fetched settings
        } else {
          // If no settings exist, initialize with default values
          setForm({
            brandName: "Sideline Setups",
            defaultSport: "softball",
            theme: "light",
            paypalMode: "sandbox",
            twilioTestMode: true,
            // Include other default values as necessary
            // Default URLs to avoid 'undefined' issues, if the ImageUrlPicker expects a string
            logoUrl: "",
            heroSoftballUrl: "",
            heroBaseballUrl: "",
            heroSoccerUrl: "",
            heroHomePageUrl: "",
            heroEventsPageUrl: "",
            heroOurStoryPageUrl: "",
            heroFaqPageUrl: "",
            heroMyBookingsPageUrl: "",
            heroAdminPageUrl: "",
            // NEW: Default for Page Background Pattern URL
            pageBackgroundPatternUrl: "",
            // NEW: Default for internalIpAddresses
            internalIpAddresses: [],
          });
        }
      } catch (error) {
        console.error("Failed to fetch site settings:", error);
        // Replaced alert.error with internal message display
        setMessage({ type: "error", text: "Failed to load site settings." });
      } finally {
        setLoading(false);
      }
    }
    fetchSettings();
  }, []); // Empty dependency array means this effect runs once on mount

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setMessage(null); // Clear previous messages
    try {
      let savedSettings;
      if (settingsId) {
        // If settingsId exists, update the existing document
        savedSettings = await entities.SiteSettings.update(settingsId, form);
      } else {
        // If no settingsId, create a new document
        savedSettings = await entities.SiteSettings.create(form);
        setSettingsId(savedSettings.id); // Store the ID of the newly created settings
      }
      // Replaced alert.success with internal message display
      setMessage({ type: "success", text: "Site settings updated successfully!" });
    } catch (error) {
      console.error("Failed to update site settings:", error);
      // Replaced alert.error with internal message display
      setMessage({ type: "error", text: "Failed to update site settings." });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6" style={{ color: '#003f5c' }}>Site Settings</h2>

      {loading && <div className="spinner"></div>}
      {!loading && (
        <div className="card card-pad">
          {message && (
            <div className={`p-3 mb-4 rounded ${message.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
              {message.text}
            </div>
          )}
          <form onSubmit={handleSave} className="space-y-6">
            {/* Brand Name */}
            <div>
              <label className="label">Brand Name</label>
              <input
                className="input"
                value={form.brandName || ""}
                onChange={(e) => setForm({ ...form, brandName: e.target.value })}
                placeholder="Your Brand Name"
              />
            </div>

            {/* Logo URL - Now using ImageUrlPicker */}
            <div>
              <label className="label">Logo URL</label>
              <ImageUrlPicker
                value={form.logoUrl}
                onChange={(url) => setForm({ ...form, logoUrl: url })}
                label="Brand Logo" // This label is for the picker's dropdown list, not the main form field label
              />
            </div>

            {/* Default Sport */}
            <div>
              <label className="label">Default Sport</label>
              <select
                className="select"
                value={form.defaultSport || "softball"}
                onChange={(e) => setForm({ ...form, defaultSport: e.target.value })}
              >
                <option value="softball">Softball</option>
                <option value="baseball">Baseball</option>
                <option value="soccer">Soccer</option>
              </select>
            </div>

            {/* Theme */}
            <div>
              <label className="label">Theme</label>
              <select
                className="select"
                value={form.theme || "light"}
                onChange={(e) => setForm({ ...form, theme: e.target.value })}
              >
                <option value="light">Light</option>
                <option value="dark">Dark</option>
              </select>
            </div>

            {/* Support Email */}
            <div>
              <label className="label">Support Email</label>
              <input
                className="input"
                type="email"
                value={form.supportEmail || ""}
                onChange={(e) => setForm({ ...form, supportEmail: e.target.value })}
                placeholder="support@example.com"
              />
            </div>

            {/* Support Phone (Added based on outline's implied existence) */}
            <div>
              <label className="label">Support Phone</label>
              <input
                className="input"
                type="tel"
                value={form.supportPhone || ""}
                onChange={(e) => setForm({ ...form, supportPhone: e.target.value })}
                placeholder="(XXX) XXX-XXXX"
              />
            </div>

            {/* PayPal Mode */}
            <div>
              <label className="label">PayPal Mode</label>
              <select
                className="select"
                value={form.paypalMode || "sandbox"}
                onChange={(e) => setForm({ ...form, paypalMode: e.target.value })}
              >
                <option value="sandbox">Sandbox</option>
                <option value="live">Live</option>
              </select>
            </div>

            {/* Twilio Test Mode */}
            <div className="flex items-center">
              <input
                type="checkbox"
                id="twilioTestMode"
                className="toggle-checkbox"
                checked={!!form.twilioTestMode}
                onChange={(e) => setForm({ ...form, twilioTestMode: e.target.checked })}
              />
              <label htmlFor="twilioTestMode" className="label ml-2 mb-0">Twilio Test Mode</label>
            </div>

            {/* Sport-specific Hero Images - Now using ImageUrlPicker */}
            <div style={{
              borderTop: '2px solid #e2e8f0',
              paddingTop: '16px',
              marginTop: '16px'
            }}>
              <h3 style={{ marginBottom: '16px', fontSize: '16px', fontWeight: '600', color: '#003f5c' }}>Hero Images by Sport</h3>

              <div style={{ display: 'grid', gap: '16px' }}>
                <ImageUrlPicker
                  value={form.heroSoftballUrl}
                  onChange={(url) => setForm({ ...form, heroSoftballUrl: url })}
                  label="Softball Hero Image"
                />

                <ImageUrlPicker
                  value={form.heroBaseballUrl}
                  onChange={(url) => setForm({ ...form, heroBaseballUrl: url })}
                  label="Baseball Hero Image"
                />

                <ImageUrlPicker
                  value={form.heroSoccerUrl}
                  onChange={(url) => setForm({ ...form, heroSoccerUrl: url })}
                  label="Soccer Hero Image"
                />
              </div>
            </div>

            {/* Page-specific Hero Images - Now using ImageUrlPicker */}
            <div style={{
              borderTop: '2px solid #e2e8f0',
              paddingTop: '16px',
              marginTop: '16px'
            }}>
              <h3 style={{ marginBottom: '16px', fontSize: '16px', fontWeight: '600', color: '#003f5c' }}>Page-Specific Hero Images (Optional)</h3>
              <p style={{ fontSize: '13px', color: 'var(--muted)', marginBottom: '16px' }}>
                Override default sport hero images for specific pages. Leave blank to use sport defaults.
              </p>

              <div style={{ display: 'grid', gap: '16px' }}>
                <ImageUrlPicker
                  value={form.heroHomePageUrl}
                  onChange={(url) => setForm({ ...form, heroHomePageUrl: url })}
                  label="Home Page Hero"
                />

                <ImageUrlPicker
                  value={form.heroEventsPageUrl}
                  onChange={(url) => setForm({ ...form, heroEventsPageUrl: url })}
                  label="Events Page Hero"
                />

                <ImageUrlPicker
                  value={form.heroOurStoryPageUrl}
                  onChange={(url) => setForm({ ...form, heroOurStoryPageUrl: url })}
                  label="Our Story Page Hero"
                />

                <ImageUrlPicker
                  value={form.heroFaqPageUrl}
                  onChange={(url) => setForm({ ...form, heroFaqPageUrl: url })}
                  label="FAQ Page Hero"
                />

                <ImageUrlPicker
                  value={form.heroMyBookingsPageUrl}
                  onChange={(url) => setForm({ ...form, heroMyBookingsPageUrl: url })}
                  label="My Bookings Page Hero"
                />

                {/* This was in the original code, ensuring it's also converted */}
                <ImageUrlPicker
                  value={form.heroAdminPageUrl}
                  onChange={(url) => setForm({ ...form, heroAdminPageUrl: url })}
                  label="Admin Dashboard Hero"
                />
              </div>
            </div>

            {/* NEW: Page Background Pattern */}
            <div style={{ marginTop: '20px', paddingTop: '20px', borderTop: '1px solid var(--border)' }}>
              <label className="label">
                Page Background Pattern URL
                <span style={{ fontSize: '12px', color: 'var(--muted)', display: 'block', marginTop: '4px' }}>
                  This background image will appear on all public pages below the hero
                </span>
              </label>
              <ImageUrlPicker
                value={form.pageBackgroundPatternUrl || ""}
                onChange={(url) => setForm({ ...form, pageBackgroundPatternUrl: url })}
                label="Page Background Pattern"
                placeholder="Enter or upload background pattern image"
              />
              {form.pageBackgroundPatternUrl && (
                <div style={{ marginTop: '12px' }}>
                  <img
                    src={form.pageBackgroundPatternUrl}
                    alt="Background pattern preview"
                    style={{
                      maxWidth: "200px",
                      height: "auto",
                      borderRadius: "8px",
                      border: "1px solid var(--border)"
                    }}
                  />
                </div>
              )}
            </div>

            {/* NEW: Internal IP Addresses for Analytics */}
            <div style={{ marginTop: '20px', paddingTop: '20px', borderTop: '1px solid var(--border)' }}>
              <label className="label">
                Internal IP Addresses (Analytics Exclusion)
                <span style={{ fontSize: '12px', color: 'var(--muted)', display: 'block', marginTop: '4px' }}>
                  Add your office/home IP addresses to exclude from analytics. One IP per line.
                </span>
              </label>
              <textarea
                className="input"
                value={(form.internalIpAddresses || []).join('\n')}
                onChange={(e) => setForm({ 
                  ...form, 
                  internalIpAddresses: e.target.value.split('\n').filter(ip => ip.trim()) 
                })}
                placeholder="192.168.1.100&#10;203.0.113.5"
                rows={5}
                style={{ fontFamily: 'monospace', fontSize: '13px' }}
              />
              <div style={{ 
                marginTop: '8px', 
                padding: '10px', 
                background: '#f0f9ff', 
                borderRadius: '6px',
                fontSize: '12px',
                color: '#0369a1'
              }}>
                💡 <strong>How to find your IP:</strong> Visit <a href="https://whatismyipaddress.com/" target="_blank" rel="noopener" style={{ textDecoration: 'underline' }}>whatismyipaddress.com</a> and add the "IPv4" address shown.
              </div>
              {form.internalIpAddresses && form.internalIpAddresses.length > 0 && (
                <div style={{ marginTop: '8px', fontSize: '12px', color: '#64748b' }}>
                  Currently excluding {form.internalIpAddresses.length} IP address(es)
                </div>
              )}
            </div>

            <div className="flex gap-4">
              <button type="submit" className="btn" disabled={saving}>
                {saving ? "Saving..." : "Save Settings"}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
