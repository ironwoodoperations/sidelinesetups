import React, { useState } from "react";
import { base44 } from "../../api/base44Client";
import { Download } from "lucide-react";

export default function AdminTimeReports() {
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [rounding, setRounding] = useState("nearest_15");
  const [dailyOT, setDailyOT] = useState(8);
  const [weeklyOT, setWeeklyOT] = useState(40);
  const [exporting, setExporting] = useState(false);

  const exportCsv = async () => {
    if (!start || !end) {
      alert("Please select start and end dates");
      return;
    }

    setExporting(true);
    try {
      const response = await base44.functions.invoke('timeEntriesCsv', {
        start,
        end,
        rounding,
        dailyOvertimeHours: dailyOT,
        weeklyOvertimeHours: weeklyOT
      });

      // response.data contains the CSV content
      const blob = new Blob([response.data], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `timeentries_${start}_to_${end}.csv`;
      document.body.appendChild(a);
      a.click();
      URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error("Failed to export CSV:", error);
      alert("Failed to export CSV: " + error.message);
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="card card-pad">
      <h3 style={{ margin: "0 0 16px 0", color: "#003f5c" }}>
        Time Entries Export (Payroll)
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        <div>
          <label className="label">Start Date *</label>
          <input
            className="input"
            type="date"
            value={start}
            onChange={(e) => setStart(e.target.value)}
          />
        </div>

        <div>
          <label className="label">End Date *</label>
          <input
            className="input"
            type="date"
            value={end}
            onChange={(e) => setEnd(e.target.value)}
          />
        </div>

        <div style={{ alignSelf: "end" }}>
          <button
            className="btn"
            onClick={exportCsv}
            disabled={exporting || !start || !end}
            style={{
              background: 'linear-gradient(to right, #003f5c, #00507a)',
              color: 'white',
              border: 'none',
              width: '100%'
            }}
          >
            {exporting ? (
              "Exporting..."
            ) : (
              <>
                <Download size={16} className="inline mr-2" />
                Export CSV
              </>
            )}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="label">Rounding</label>
          <select
            className="select"
            value={rounding}
            onChange={(e) => setRounding(e.target.value)}
          >
            <option value="none">None</option>
            <option value="nearest_15">Nearest 15 min</option>
            <option value="up_15">Round Up 15 min</option>
            <option value="down_15">Round Down 15 min</option>
          </select>
        </div>

        <div>
          <label className="label">Daily OT Hours</label>
          <input
            className="input"
            type="number"
            min="0"
            step="0.25"
            value={dailyOT}
            onChange={(e) => setDailyOT(Number(e.target.value))}
          />
        </div>

        <div>
          <label className="label">Weekly OT Hours</label>
          <input
            className="input"
            type="number"
            min="0"
            step="0.5"
            value={weeklyOT}
            onChange={(e) => setWeeklyOT(Number(e.target.value))}
          />
        </div>
      </div>

      <div style={{ 
        marginTop: 16, 
        padding: 12, 
        background: "#f8fafc", 
        borderRadius: 8,
        fontSize: 13,
        color: "#64748b"
      }}>
        <strong>Note:</strong> Exported CSV includes raw hours, rounded hours, regular/OT split by daily and weekly thresholds.
      </div>
    </div>
  );
}