
import React from "react";
import { getCtx } from "../lib/ctx";
import { base44 } from "../../api/base44Client";
import { format } from "date-fns";

function Badge({ children, kind }) {
  const cls = kind === "muted" ? "badge" : `badge ${kind}`;
  return <span className={cls}>{children}</span>;
}

export default function AdminCRM() {
  const [tab, setTab] = React.useState("contacts");
  const [loading, setLoading] = React.useState(false);
  const [contacts, setContacts] = React.useState([]);
  const [allTags, setAllTags] = React.useState([]);
  const [q, setQ] = React.useState("");
  const [tag, setTag] = React.useState("");
  const [editing, setEditing] = React.useState(null);

  const [channel, setChannel] = React.useState("email");
  const [subject, setSubject] = React.useState("");
  const [bodyText, setBodyText] = React.useState("");
  const [bodyHtml, setBodyHtml] = React.useState("");
  const [segment, setSegment] = React.useState("all");
  const [segmentTag, setSegmentTag] = React.useState("");
  const [scheduleAt, setScheduleAt] = React.useState("");

  async function loadContacts() {
    setLoading(true);
    try {
      const response = await base44.functions.invoke('crmListContacts', { q: q, tag: tag });
      const contacts = Array.isArray(response.data) ? response.data : [];
      setContacts(contacts);
    } catch (e) {
      console.error('Failed to load contacts:', e);
      setContacts([]);
    } finally {
      setLoading(false);
    }
  }

  async function loadTags() {
    try {
      const response = await base44.functions.invoke('crmListTags');
      const tags = response.data?.data || [];
      setAllTags(tags);
    } catch (e) {
      console.error('Failed to load tags:', e);
      setAllTags([]);
    }
  }

  React.useEffect(() => { loadContacts(); }, []);
  React.useEffect(() => { loadTags(); }, []);

  async function importFromBookings() {
    if (!confirm("Import all contacts from bookings? This will dedupe by email/phone.")) return;
    setLoading(true);
    try {
      const { data } = await base44.functions.invoke('crmUpsertContactsFromBookings');
      alert(`Import complete: ${data.created} created, ${data.updated} updated`);
      await loadContacts();
      await loadTags();
    } catch (err) {
      console.error("Import failed:", err);
      alert("Import failed: " + err.message);
    } finally {
      setLoading(false);
    }
  }

  function normalizePhone(p) {
    if (!p) return "";
    const digits = (""+p).replace(/\D/g, "");
    if (digits.length === 10) return `+1${digits}`;
    if (digits.length === 11 && digits.startsWith("1")) return `+${digits}`;
    if (digits.startsWith("+")) return digits;
    return p;
  }

  async function saveContact(c) {
    setLoading(true);
    try {
      const { entities } = await getCtx();
      const row = {
        ...c,
        email: (c.email || "").trim().toLowerCase(),
        phone: normalizePhone(c.phone),
      };
      if (row.id) {
        await entities.Contacts.update(row.id, row);
      } else {
        await entities.Contacts.create(row);
      }
      setEditing(null);
      await loadContacts();
    } catch (err) {
      console.error("Save failed:", err);
      alert("Save failed: " + err.message);
    } finally {
      setLoading(false);
    }
  }

  async function deleteContact(id) {
    if (!window.confirm("Delete this contact?")) return;
    setLoading(true);
    try {
      const { entities } = await getCtx();
      await entities.Contacts.delete(id);
      await loadContacts();
    } catch (err) {
      console.error("Delete failed:", err);
      alert("Delete failed: " + err.message);
    } finally {
      setLoading(false);
    }
  }

  async function toggleSubscribe(id, field, next) {
    setLoading(true);
    try {
      await base44.functions.invoke('crmSubscribeStatus', { id, field, value: !!next });
      await loadContacts();
    } catch (err) {
      console.error("Toggle failed:", err);
      alert("Toggle failed: " + err.message);
    } finally {
      setLoading(false);
    }
  }

  async function sendTest() {
    const testTo = window.prompt(channel === "email" ? "Test email address:" : "Test E.164 phone (+1...):");
    if (!testTo) return;
    setLoading(true);
    try {
      if (channel === "email") {
        await base44.functions.invoke('crmSendEmailCampaign', {
          subject, bodyText, bodyHtml,
          testTo,
          previewOnly: false,
        });
      } else {
        await base44.functions.invoke('crmSendSmsCampaign', {
          bodyText,
          testTo,
          previewOnly: false,
        });
      }
      alert("Test sent.");
    } catch (err) {
      console.error("Send test failed:", err);
      alert("Send test failed: " + err.message);
    } finally {
      setLoading(false);
    }
  }

  async function sendCampaign() {
    if (!window.confirm("Send campaign to selected segment?")) return;
    setLoading(true);
    try {
      if (channel === "email") {
        const { data } = await base44.functions.invoke('crmSendEmailCampaign', {
          subject, bodyText, bodyHtml,
          segment, segmentTag,
          scheduleAt,
          previewOnly: false,
        });
        if (data.scheduled) {
          alert(`Campaign scheduled for ${scheduleAt}`);
        } else {
          alert(`Campaign sent to ${data.count} contacts.`);
        }
      } else {
        const { data } = await base44.functions.invoke('crmSendSmsCampaign', {
          bodyText,
          segment, segmentTag,
          previewOnly: false,
        });
        alert(`Campaign sent to ${data.count} contacts.`);
      }
    } catch (err) {
      console.error("Send campaign failed:", err);
      alert("Send campaign failed: " + err.message);
    } finally {
      setLoading(false);
    }
  }

  async function viewHistory() {
    try {
      const campaigns = await base44.asServiceRole.entities.Campaigns.list();
      const recent = (campaigns || []).slice(0, 5);
      const msg = recent.length > 0
        ? recent.map(c => `${format(new Date(c.created_date), "MMM d, HH:mm")} | ${c.subject || c.bodyText?.slice(0, 30) || 'No Subject'} (${c.status})`).join("\n")
        : "No campaigns yet.";
      alert("Recent campaigns:\n" + msg);
    } catch (err) {
      alert("Failed to load history: " + err.message);
    }
  }

  async function fetchMetrics() {
    try {
      const { data } = await base44.functions.invoke('crmResendMetrics');
      console.log("Resend Metrics:", data);
      alert("Check browser console for full Resend analytics (opens/clicks).");
    } catch (err) {
      alert("Failed to fetch metrics: " + err.message);
    }
  }

  return (
    <div>
      <div className="section-head" style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom: 24 }}>
        <h2>CRM</h2>
        <div style={{ display:"flex", gap:8 }}>
          <button 
            className={tab==="contacts" ? "btn" : "btn-outline"} 
            onClick={()=>setTab("contacts")}
          >
            Contacts
          </button>
          <button 
            className={tab==="import" ? "btn" : "btn-outline"} 
            onClick={()=>setTab("import")}
          >
            Import
          </button>
          <button 
            className={tab==="campaigns" ? "btn" : "btn-outline"} 
            onClick={()=>setTab("campaigns")}
          >
            Campaigns
          </button>
        </div>
      </div>

      {tab === "contacts" && (
        <div>
          <div style={{ display:"flex", gap:8, marginBottom:16 }}>
            <input 
              className="input"
              placeholder="Search name/email/phone..." 
              value={q} 
              onChange={e=>setQ(e.target.value)} 
            />
            <input 
              className="input"
              placeholder="Tag filter (optional)" 
              value={tag} 
              onChange={e=>setTag(e.target.value)}
              list="tag-filter-list"
            />
            <datalist id="tag-filter-list">
              {allTags.map(t => <option key={t} value={t} />)}
            </datalist>
            <button className="btn" onClick={loadContacts} disabled={loading}>Search</button>
            <button className="btn" onClick={()=>setEditing({})}>New Contact</button>
          </div>

          {editing && (
            <div className="card card-pad" style={{ marginBottom: 16 }}>
              <h3>{editing.id ? "Edit Contact" : "New Contact"}</h3>
              <div style={{ display:"grid", gap:12, gridTemplateColumns:"repeat(2, minmax(0,1fr))" }}>
                <div className="form-group">
                  <label className="label">Name</label>
                  <input 
                    className="input"
                    value={editing.fullName||""} 
                    onChange={e=>setEditing({...editing, fullName:e.target.value})}
                  />
                </div>
                <div className="form-group">
                  <label className="label">Email</label>
                  <input 
                    className="input"
                    value={editing.email||""} 
                    onChange={e=>setEditing({...editing, email:e.target.value})}
                  />
                </div>
                <div className="form-group">
                  <label className="label">Phone</label>
                  <input 
                    className="input"
                    value={editing.phone||""} 
                    onChange={e=>setEditing({...editing, phone:e.target.value})}
                  />
                </div>
                <div className="form-group">
                  <label className="label">Tags (comma-separated)</label>
                  <input 
                    className="input"
                    value={(editing.tags||[]).join(", ")} 
                    onChange={e=>setEditing({...editing, tags:e.target.value.split(",").map(s=>s.trim()).filter(Boolean)})}
                  />
                </div>
              </div>
              <div style={{ display:"flex", gap:8, marginTop:12 }}>
                <button className="btn" onClick={()=>saveContact(editing)} disabled={loading}>Save</button>
                <button className="btn-ghost" onClick={()=>setEditing(null)}>Cancel</button>
              </div>
            </div>
          )}

          {loading && <div className="card card-pad">Loading...</div>}

          <div className="grid grid-2">
            {contacts.map(c => (
              <div key={c.id} className="card card-pad">
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"start" }}>
                  <div>
                    <h3 style={{ margin:"0 0 8px 0" }}>{c.fullName || "(no name)"}</h3>
                    <div style={{ color:"var(--muted)", fontSize:13 }}>
                      {c.email && <div>{c.email}</div>}
                      {c.phone && <div>{c.phone}</div>}
                      <div>Added: {c.created_date ? format(new Date(c.created_date), "MMM d, yyyy") : "-"}</div>
                    </div>
                  </div>
                  <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                    {c.unsubscribedEmail ? <Badge kind="muted">Email-Off</Badge> : <Badge kind="badge-success">Email-On</Badge>}
                    {c.unsubscribedSms   ? <Badge kind="muted">SMS-Off</Badge>   : <Badge kind="badge-success">SMS-On</Badge>}
                  </div>
                </div>

                <div style={{ marginTop:8, fontSize:13 }}>
                  {(c.tags||[]).length>0 && (
                    <div>
                      <b>Tags:</b>{' '}
                      <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 4 }}>
                        {(c.tags||[]).map((t, i) => (
                          <span key={i} className="badge">{t}</span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div style={{ display:"flex", gap:8, marginTop:12, flexWrap:"wrap" }}>
                  <button className="btn-outline" onClick={()=>setEditing(c)}>Edit</button>
                  <button className="btn-ghost" onClick={()=>deleteContact(c.id)}>Delete</button>
                  <button className="btn-ghost" onClick={()=>toggleSubscribe(c.id,"email", c.unsubscribedEmail ? false : true)}>
                    {c.unsubscribedEmail ? "Enable Email" : "Disable Email"}
                  </button>
                  <button className="btn-ghost" onClick={()=>toggleSubscribe(c.id,"sms", c.unsubscribedSms ? false : true)}>
                    {c.unsubscribedSms ? "Enable SMS" : "Disable SMS"}
                  </button>
                </div>
              </div>
            ))}
          </div>

          {(!loading && contacts.length===0) && (
            <div className="card card-pad" style={{ textAlign:"center", color:"var(--muted)" }}>
              <p>No contacts. Use Import tab to pull from Bookings.</p>
            </div>
          )}
        </div>
      )}

      {tab === "import" && (
        <div className="card card-pad">
          <h3>Import from Bookings</h3>
          <p style={{ color:"var(--muted)", marginBottom:16 }}>
            Pulls unique contacts from booking records. Dedupes by normalized email and phone.
            Automatically tags contacts with sport, event type, and team name.
          </p>
          <button className="btn" onClick={importFromBookings} disabled={loading}>
            Run Import
          </button>
        </div>
      )}

      {tab === "campaigns" && (
        <div className="card card-pad">
          <h3>Campaign</h3>
          
          <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
            <button className="btn" onClick={viewHistory} disabled={loading}>View History</button>
            <button className="btn-ghost" onClick={fetchMetrics} disabled={loading}>Fetch Metrics</button>
          </div>

          <div style={{ display:"grid", gap:12, gridTemplateColumns:"repeat(2, minmax(0,1fr))", marginBottom:16 }}>
            <div className="form-group">
              <label className="label">Channel</label>
              <select className="select" value={channel} onChange={e=>setChannel(e.target.value)} disabled={loading}>
                <option value="email">Email (Resend)</option>
                <option value="sms">SMS (Twilio)</option>
              </select>
            </div>

            <div className="form-group">
              <label className="label">Segment</label>
              <select className="select" value={segment} onChange={e=>setSegment(e.target.value)} disabled={loading}>
                <option value="all">All Contacts</option>
                <option value="tag">Tag =</option>
              </select>
            </div>

            {segment === "tag" && (
              <div className="form-group">
                <label className="label">Tag</label>
                <input 
                  className="input"
                  list="crm-tags"
                  value={segmentTag} 
                  onChange={e=>setSegmentTag(e.target.value)} 
                  placeholder="type:tournament / event:texas-classic / park:mcinnis-park / city:allen / team:wildcats / date:2025-01" 
                  disabled={loading}
                />
                <datalist id="crm-tags">
                  {allTags.map(t => <option key={t} value={t} />)}
                </datalist>
              </div>
            )}
          </div>

          {channel === "email" && (
            <div style={{ marginTop: 12 }}>
              <div className="form-group">
                <label className="label">Subject (supports &#123;&#123;fullName&#125;&#125;, &#123;&#123;teamName&#125;&#125;, etc.)</label>
                <input 
                  className="input"
                  value={subject} 
                  onChange={e => setSubject(e.target.value)} 
                  placeholder="Hi {{fullName}}! Ready for {{eventName}}?"
                  disabled={loading}
                />
              </div>
              <div className="form-group">
                <label className="label">Body (Text)</label>
                <textarea 
                  className="textarea"
                  rows={4} 
                  value={bodyText} 
                  onChange={e => setBodyText(e.target.value)} 
                  placeholder="Variables like {{fullName}} will be replaced per contact"
                  disabled={loading}
                />
              </div>
              <div className="form-group">
                <label className="label">Body (HTML, optional)</label>
                <textarea 
                  className="textarea"
                  rows={6} 
                  value={bodyHtml} 
                  onChange={e => setBodyHtml(e.target.value)} 
                  placeholder="<p>Hi {{fullName}}, ...</p>" 
                  disabled={loading}
                />
              </div>
              <div className="form-group">
                <label className="label">Send Later (optional)</label>
                <input 
                  className="input"
                  type="datetime-local"
                  value={scheduleAt} 
                  onChange={e => setScheduleAt(e.target.value)} 
                  disabled={loading}
                />
              </div>
            </div>
          )}

          {channel === "sms" && (
            <div style={{ marginTop:12 }}>
              <div className="form-group">
                <label className="label">Message (Text)</label>
                <textarea 
                  className="textarea"
                  rows={4} 
                  value={bodyText} 
                  onChange={e=>setBodyText(e.target.value)} 
                  placeholder="160 chars recommended" 
                  disabled={loading}
                />
              </div>
            </div>
          )}

          <div style={{ display:"flex", gap:8, marginTop:16 }}>
            <button className="btn-ghost" onClick={sendTest} disabled={loading}>Send Test</button>
            <button className="btn" onClick={sendCampaign} disabled={loading}>
              {scheduleAt ? "Schedule Campaign" : "Send Campaign"}
            </button>
          </div>

          <p style={{ color: "var(--muted)", marginTop: 12, fontSize: 13 }}>
            💡 Use &#123;&#123;fullName&#125;&#125;, &#123;&#123;teamName&#125;&#125;, &#123;&#123;eventName&#125;&#125; for personalization. 
            Sends in batches with rate limiting. Respects unsubscribes.
          </p>
        </div>
      )}
    </div>
  );
}
