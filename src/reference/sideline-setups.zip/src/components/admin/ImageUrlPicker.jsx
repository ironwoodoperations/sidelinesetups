import React, { useState, useEffect } from "react";
import { getCtx } from "../lib/ctx";
import { Image, ChevronDown, X } from "lucide-react";

export default function ImageUrlPicker({ value, onChange, label = "Image URL" }) {
  const [uploadedImages, setUploadedImages] = useState([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUploadedImages();
  }, []);

  async function loadUploadedImages() {
    try {
      const { entities } = await getCtx();
      const uploads = await entities.UploadedFiles.list("-created_date");
      const images = (uploads || []).filter(file => 
        file.fileType && file.fileType.startsWith('image/')
      );
      setUploadedImages(images);
    } catch (error) {
      console.error("Failed to load uploaded images:", error);
      setUploadedImages([]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ position: "relative" }}>
      <label className="label">{label}</label>
      
      <input
        className="input"
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Paste image URL or select from dropdown"
        style={{ marginBottom: "8px" }}
      />

      <button
        type="button"
        className="btn-outline"
        onClick={() => setShowDropdown(!showDropdown)}
        style={{ 
          width: "100%", 
          justifyContent: "space-between", 
          display: "flex", 
          alignItems: "center", 
          fontSize: "14px", 
          padding: "8px 12px",
          marginBottom: "8px"
        }}
      >
        <span style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <Image size={16} />
          {loading ? "Loading images..." : uploadedImages.length > 0 ? "Select from Uploaded Images" : "No Images Uploaded Yet"}
        </span>
        <ChevronDown size={16} />
      </button>

      {uploadedImages.length === 0 && !loading && (
        <div style={{
          padding: "12px",
          background: "#fef3c7",
          border: "1px solid #fde047",
          borderRadius: "8px",
          fontSize: "13px",
          marginBottom: "8px"
        }}>
          <strong>No images uploaded yet.</strong> Go to <strong>Upload Files</strong> to add images.
        </div>
      )}

      {showDropdown && uploadedImages.length > 0 && (
        <>
          <div 
            style={{
              position: "fixed",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              zIndex: 999
            }}
            onClick={() => setShowDropdown(false)}
          />
          <div style={{
            position: "absolute",
            top: "100%",
            left: 0,
            right: 0,
            marginTop: "4px",
            maxHeight: "400px",
            overflowY: "auto",
            background: "white",
            border: "1px solid #e2e8f0",
            borderRadius: "8px",
            boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
            zIndex: 1000
          }}>
            {uploadedImages.map(img => (
              <button
                key={img.id}
                type="button"
                onClick={() => {
                  onChange(img.fileUrl);
                  setShowDropdown(false);
                }}
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  gap: "12px",
                  padding: "12px",
                  background: value === img.fileUrl ? "#f0f9ff" : "white",
                  border: "none",
                  borderBottom: "1px solid #e2e8f0",
                  cursor: "pointer",
                  textAlign: "left",
                  transition: "background 0.2s"
                }}
                onMouseEnter={(e) => e.currentTarget.style.background = "#f8fafc"}
                onMouseLeave={(e) => e.currentTarget.style.background = value === img.fileUrl ? "#f0f9ff" : "white"}
              >
                <img 
                  src={img.fileUrl} 
                  alt={img.fileName}
                  style={{
                    width: "60px",
                    height: "60px",
                    objectFit: "cover",
                    borderRadius: "4px",
                    border: "1px solid #e2e8f0"
                  }}
                />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: "13px", fontWeight: 500 }}>{img.fileName}</div>
                  <div style={{ fontSize: "11px", color: "var(--muted)" }}>
                    {img.fileSize ? `${(img.fileSize / 1024).toFixed(1)} KB` : ""}
                  </div>
                </div>
                {value === img.fileUrl && (
                  <div style={{
                    width: "18px",
                    height: "18px",
                    background: "#003f5c",
                    color: "white",
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "11px"
                  }}>
                    ✓
                  </div>
                )}
              </button>
            ))}
          </div>
        </>
      )}

      {value && (
        <div style={{ marginTop: "12px" }}>
          <div style={{ 
            display: "flex", 
            justifyContent: "space-between", 
            alignItems: "center",
            marginBottom: "6px" 
          }}>
            <div style={{ fontSize: "12px", color: "var(--muted)" }}>Preview:</div>
            <button
              type="button"
              onClick={() => onChange("")}
              className="btn-outline"
              style={{ 
                fontSize: "11px", 
                padding: "4px 8px",
                display: "flex",
                alignItems: "center",
                gap: "4px"
              }}
            >
              <X size={12} />
              Clear
            </button>
          </div>
          <img 
            src={value} 
            alt="Preview"
            style={{
              width: "100%",
              maxWidth: "300px",
              height: "auto",
              borderRadius: "8px",
              border: "1px solid #e2e8f0"
            }}
          />
        </div>
      )}
    </div>
  );
}