import React from "react";

function calculatePackageInventory(pkg, allEquipment) {
  if (!pkg.baseItems || pkg.baseItems.length === 0) {
    return 999;
  }
  
  let minAvailable = Infinity;
  
  for (const item of pkg.baseItems) {
    const equipment = allEquipment.find(e => e.id === item.equipmentId);
    if (!equipment) continue;
    
    const requiredQty = Number(item.qty || 1);
    const availableQty = Number(equipment.availableQty || 0);
    
    if (requiredQty > 0) {
      const possiblePackages = Math.floor(availableQty / requiredQty);
      minAvailable = Math.min(minAvailable, possiblePackages);
    }
  }
  
  return minAvailable === Infinity ? 999 : minAvailable;
}

const currency = (n) => `$${(Math.max(0, Number(n) || 0)).toFixed(2)}`;

export default function PackageCompactCard({ pkg, allEquipment, isSelected, onClick }) {
  const inventory = calculatePackageInventory(pkg, allEquipment);
  
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        width: "100%",
        textAlign: "left",
        padding: "16px",
        background: isSelected ? "rgba(0, 63, 92, 0.05)" : "white",
        border: isSelected ? "2px solid #003f5c" : "1px solid #e2e8f0",
        borderRadius: "12px",
        cursor: "pointer",
        transition: "all 0.2s",
        display: "flex",
        gap: "12px"
      }}
      onMouseEnter={(e) => {
        if (!isSelected) {
          e.currentTarget.style.borderColor = "#003f5c";
          e.currentTarget.style.boxShadow = "0 4px 12px rgba(0, 63, 92, 0.15)";
        }
      }}
      onMouseLeave={(e) => {
        if (!isSelected) {
          e.currentTarget.style.borderColor = "#e2e8f0";
          e.currentTarget.style.boxShadow = "none";
        }
      }}
    >
      {/* Thumbnail Image - Same size and position as admin/public packages page */}
      {pkg.thumbnailUrl && (
        <img 
          src={pkg.thumbnailUrl} 
          alt={pkg.name}
          style={{
            width: "80px",
            height: "80px",
            objectFit: "cover",
            borderRadius: "8px",
            border: "1px solid #e2e8f0",
            flexShrink: 0
          }}
        />
      )}
      
      <div style={{ 
        flex: 1,
        display: "flex",
        flexDirection: "column",
        gap: "8px",
        justifyContent: "center"
      }}>
        <div style={{ 
          fontSize: "18px", 
          fontWeight: "600", 
          color: "#003f5c",
          marginBottom: "4px"
        }}>
          {pkg.name}
        </div>
        
        <div style={{ 
          display: "flex", 
          alignItems: "center", 
          justifyContent: "space-between",
          gap: "8px"
        }}>
          <span className="badge-success" style={{ fontSize: "11px" }}>
            {inventory > 50 ? "50+" : inventory} available
          </span>
          
          <div style={{ 
            fontSize: "16px", 
            fontWeight: "600",
            color: "#003f5c"
          }}>
            from {currency(pkg.perGameUSD || 0)}
          </div>
        </div>
      </div>
    </button>
  );
}