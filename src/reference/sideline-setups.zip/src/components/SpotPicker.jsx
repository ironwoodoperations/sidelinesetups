// components/SpotPicker.jsx
import React from "react";
import { getCtx } from "./lib/ctx";

export default function SpotPicker({ fieldId, date, times, value, onChange }) {
  const [field,setField] = React.useState(null);
  const [spots,setSpots] = React.useState([]);
  const [locks,setLocks] = React.useState([]);

  React.useEffect(()=>{ (async()=>{
    if(!fieldId) return;
    const { entities } = await getCtx();
    const f = await entities.Fields.get({id:fieldId});
    setField(f);
    setSpots(await entities.Spots.filter({fieldId}));
    const allLocks = await entities.Locks.filter({fieldId,date,status:"active"});
    const now = new Date().toISOString();
    setLocks(allLocks.filter(l=>(l.expiresAt||"")>now));
  })(); },[fieldId,date,times?.join("|")]);

  const locked = new Set(locks.map(l=>l.spotId));

  return (
    <div style={{position:"relative",width:"100%",maxWidth:800,margin:"0 auto"}}>
      {field?.imageUrl ?
        <div style={{position:"relative",border:"1px solid #e2e8f0",borderRadius:12,overflow:"hidden"}}>
          <img src={field.imageUrl} alt="Field" style={{width:"100%",display:"block"}}/>
          {spots.map(s=>{
            const left=`${Math.max(0,Math.min(100,s.x||0))}%`;
            const top =`${Math.max(0,Math.min(100,s.y||0))}%`;
            const sel=value===s.id, dis=locked.has(s.id);
            return (
              <button key={s.id}
                onClick={()=>!dis&&onChange?.(s.id)}
                disabled={dis}
                style={{
                  position:"absolute",left,top,transform:"translate(-50%,-50%)",
                  width:26,height:26,borderRadius:"50%",cursor:dis?"not-allowed":"pointer",
                  border:"2px solid #fff",
                  background:sel?"var(--brand)":dis?"#94a3b8":"#fff",
                  boxShadow:sel?"0 0 10px var(--brand)":"0 0 3px rgba(0,0,0,.2)",
                  transition:"all .25s ease-in-out"
                }}
                onMouseEnter={e=>{ if(!sel&&!dis) e.currentTarget.style.transform="translate(-50%,-50%) scale(1.3)"; }}
                onMouseLeave={e=>{ e.currentTarget.style.transform="translate(-50%,-50%)"; }}
                title={s.label}
                aria-label={`${s.label}${sel?' (selected)':''}${dis?' (unavailable)':''}`}>
              </button>
            );
          })}
        </div>
      :<div style={{padding:12,border:"1px solid #eee",borderRadius:8}}>No field diagram uploaded.</div>}
    </div>
  );
}