import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ChevronLeft, ChevronRight, Calendar, Filter, X, Eye } from "lucide-react";

export default function BookingCalendar({ userRole = "admin" }) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [bookings, setBookings] = useState([]);
  const [availability, setAvailability] = useState({});
  const [parks, setParks] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Filters
  const [selectedPark, setSelectedPark] = useState("all");
  const [selectedEventType, setSelectedEventType] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  
  // Modal state
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [bookingDetails, setBookingDetails] = useState(null);
  const [loadingDetails, setLoadingDetails] = useState(false);

  useEffect(() => {
    loadCalendarData();
  }, [currentDate, selectedPark, selectedEventType, selectedStatus]);

  async function loadCalendarData() {
    setLoading(true);
    try {
      const startDate = getMonthStartDate(currentDate);
      const endDate = getMonthEndDate(currentDate);
      
      const response = await base44.functions.invoke('getCalendarData', {
        startDate,
        endDate,
        parkId: selectedPark,
        eventType: selectedEventType,
        status: selectedStatus
      });
      
      setBookings(response.data.bookings || []);
      setAvailability(response.data.availability || {});
      setParks(response.data.parks || []);
      setEvents(response.data.events || []);
    } catch (error) {
      console.error("Failed to load calendar data:", error);
      alert("Failed to load calendar data");
    } finally {
      setLoading(false);
    }
  }

  async function loadBookingDetails(bookingId) {
    setLoadingDetails(true);
    try {
      const response = await base44.functions.invoke('getBookingDetails', {
        bookingId
      });
      setBookingDetails(response.data);
    } catch (error) {
      console.error("Failed to load booking details:", error);
      alert("Failed to load booking details");
    } finally {
      setLoadingDetails(false);
    }
  }

  function getMonthStartDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}-01`;
  }

  function getMonthEndDate(date) {
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const lastDay = new Date(year, month, 0).getDate();
    return `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
  }

  function goToPreviousMonth() {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  }

  function goToNextMonth() {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  }

  function goToToday() {
    setCurrentDate(new Date());
  }

  function getCalendarDays() {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    
    const startDay = firstDay.getDay(); // 0 = Sunday
    const daysInMonth = lastDay.getDate();
    
    const days = [];
    
    // Add days from previous month
    const prevMonthLastDay = new Date(year, month, 0).getDate();
    for (let i = startDay - 1; i >= 0; i--) {
      days.push({
        date: new Date(year, month - 1, prevMonthLastDay - i),
        isCurrentMonth: false
      });
    }
    
    // Add days from current month
    for (let i = 1; i <= daysInMonth; i++) {
      days.push({
        date: new Date(year, month, i),
        isCurrentMonth: true
      });
    }
    
    // Add days from next month to complete the grid
    const remainingDays = 42 - days.length; // 6 rows × 7 days = 42
    for (let i = 1; i <= remainingDays; i++) {
      days.push({
        date: new Date(year, month + 1, i),
        isCurrentMonth: false
      });
    }
    
    return days;
  }

  function getBookingsForDate(date) {
    const dateStr = formatDate(date);
    return bookings.filter(b => b.date === dateStr);
  }

  function getAvailabilityForDate(date) {
    const dateStr = formatDate(date);
    return availability[dateStr] || {};
  }

  function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function isToday(date) {
    const today = new Date();
    return date.getDate() === today.getDate() &&
           date.getMonth() === today.getMonth() &&
           date.getFullYear() === today.getFullYear();
  }

  function getStatusColor(status) {
    const colors = {
      pending: '#f59e0b',
      confirmed: '#10b981',
      setup: '#3b82f6',
      completed: '#6b7280',
      returned: '#8b5cf6',
      closed: '#64748b',
      cancelled: '#ef4444'
    };
    return colors[status] || '#64748b';
  }

  function getAvailabilityColor(parkCapacity) {
    if (!parkCapacity || !parkCapacity.total) return '#f8fafc';
    
    const percentBooked = (parkCapacity.booked / parkCapacity.total) * 100;
    
    if (percentBooked >= 90) return '#fee2e2'; // Red - nearly full
    if (percentBooked >= 70) return '#fed7aa'; // Orange - getting full
    if (percentBooked >= 40) return '#fef3c7'; // Yellow - moderate
    return '#d1fae5'; // Green - plenty available
  }

  function handleBookingClick(booking) {
    setSelectedBooking(booking);
    setShowBookingModal(true);
    loadBookingDetails(booking.id);
  }

  function closeModal() {
    setShowBookingModal(false);
    setSelectedBooking(null);
    setBookingDetails(null);
  }

  const calendarDays = getCalendarDays();
  const monthName = currentDate.toLocaleString('default', { month: 'long', year: 'numeric' });

  return (
    <div style={{ padding: "24px" }}>
      {/* Header & Filters */}
      <div style={{ marginBottom: "24px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
          <div>
            <h1 style={{ margin: "0 0 8px 0", fontSize: "28px", fontWeight: "700", color: "#003f5c" }}>
              Booking Calendar
            </h1>
            <p style={{ margin: 0, color: "#64748b" }}>
              View all bookings and availability
            </p>
          </div>
          
          <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
            <button onClick={goToPreviousMonth} className="btn-outline">
              <ChevronLeft size={20} />
            </button>
            <button onClick={goToToday} className="btn-outline">
              <Calendar size={16} style={{ marginRight: "8px" }} />
              Today
            </button>
            <button onClick={goToNextMonth} className="btn-outline">
              <ChevronRight size={20} />
            </button>
          </div>
        </div>

        {/* Filters */}
        <div style={{ 
          background: "white", 
          padding: "16px", 
          borderRadius: "12px",
          boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
          display: "flex",
          gap: "12px",
          alignItems: "center",
          flexWrap: "wrap"
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <Filter size={16} color="#64748b" />
            <span style={{ fontWeight: "600", color: "#003f5c" }}>Filters:</span>
          </div>
          
          <select
            value={selectedPark}
            onChange={(e) => setSelectedPark(e.target.value)}
            style={{ padding: "8px 12px", borderRadius: "8px", border: "1px solid #e2e8f0" }}
          >
            <option value="all">All Parks</option>
            {parks.map(park => (
              <option key={park.id} value={park.id}>{park.name}</option>
            ))}
          </select>

          <select
            value={selectedEventType}
            onChange={(e) => setSelectedEventType(e.target.value)}
            style={{ padding: "8px 12px", borderRadius: "8px", border: "1px solid #e2e8f0" }}
          >
            <option value="all">All Event Types</option>
            <option value="tournament">Tournament</option>
            <option value="league">League</option>
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            style={{ padding: "8px 12px", borderRadius: "8px", border: "1px solid #e2e8f0" }}
          >
            <option value="all">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="confirmed">Confirmed</option>
            <option value="setup">Setup</option>
            <option value="completed">Completed</option>
            <option value="returned">Returned</option>
            <option value="cancelled">Cancelled</option>
          </select>

          {(selectedPark !== 'all' || selectedEventType !== 'all' || selectedStatus !== 'all') && (
            <button
              onClick={() => {
                setSelectedPark('all');
                setSelectedEventType('all');
                setSelectedStatus('all');
              }}
              style={{
                padding: "8px 12px",
                borderRadius: "8px",
                border: "none",
                background: "#f1f5f9",
                color: "#64748b",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "4px"
              }}
            >
              <X size={14} />
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Calendar Grid */}
      <div style={{ 
        background: "white", 
        borderRadius: "12px",
        overflow: "hidden",
        boxShadow: "0 2px 8px rgba(0,0,0,0.1)"
      }}>
        {/* Month Header */}
        <div style={{ 
          background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
          padding: "16px",
          textAlign: "center",
          color: "white",
          fontSize: "20px",
          fontWeight: "700"
        }}>
          {monthName}
        </div>

        {/* Day Names */}
        <div style={{ 
          display: "grid", 
          gridTemplateColumns: "repeat(7, 1fr)",
          background: "#f8fafc",
          borderBottom: "1px solid #e2e8f0"
        }}>
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} style={{ 
              padding: "12px", 
              textAlign: "center", 
              fontWeight: "600",
              color: "#64748b",
              fontSize: "14px"
            }}>
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Days */}
        {loading ? (
          <div style={{ padding: "60px", textAlign: "center" }}>
            <div className="spinner" style={{ margin: "0 auto" }}></div>
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)" }}>
            {calendarDays.map((day, index) => {
              const dayBookings = getBookingsForDate(day.date);
              const dayAvailability = getAvailabilityForDate(day.date);
              const totalBooked = Object.values(dayAvailability).reduce((sum, park) => sum + park.booked, 0);
              const totalAvailable = Object.values(dayAvailability).reduce((sum, park) => sum + park.available, 0);
              
              return (
                <div
                  key={index}
                  style={{
                    minHeight: "120px",
                    padding: "8px",
                    borderRight: (index % 7 !== 6) ? "1px solid #e2e8f0" : "none",
                    borderBottom: "1px solid #e2e8f0",
                    background: day.isCurrentMonth ? "white" : "#f8fafc",
                    opacity: day.isCurrentMonth ? 1 : 0.5
                  }}
                >
                  <div style={{ 
                    display: "flex", 
                    justifyContent: "space-between", 
                    alignItems: "flex-start",
                    marginBottom: "8px"
                  }}>
                    <div style={{
                      width: "28px",
                      height: "28px",
                      borderRadius: "50%",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "14px",
                      fontWeight: isToday(day.date) ? "700" : "500",
                      background: isToday(day.date) ? "#003f5c" : "transparent",
                      color: isToday(day.date) ? "white" : "#0f172a"
                    }}>
                      {day.date.getDate()}
                    </div>
                    
                    {dayBookings.length > 0 && (
                      <div style={{
                        fontSize: "11px",
                        padding: "2px 6px",
                        borderRadius: "10px",
                        background: "#e0f2fe",
                        color: "#0369a1",
                        fontWeight: "600"
                      }}>
                        {dayBookings.length}
                      </div>
                    )}
                  </div>

                  {/* Availability Indicator */}
                  {totalBooked > 0 && (
                    <div style={{
                      fontSize: "10px",
                      padding: "4px 6px",
                      borderRadius: "6px",
                      background: Object.keys(dayAvailability).length > 0 
                        ? getAvailabilityColor(Object.values(dayAvailability)[0])
                        : "#f8fafc",
                      marginBottom: "6px",
                      textAlign: "center",
                      color: "#0f172a",
                      fontWeight: "600"
                    }}>
                      {totalAvailable > 0 ? `${totalAvailable} spots free` : 'Fully booked'}
                    </div>
                  )}

                  {/* Booking Pills */}
                  <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
                    {dayBookings.slice(0, 2).map(booking => (
                      <div
                        key={booking.id}
                        onClick={() => handleBookingClick(booking)}
                        style={{
                          fontSize: "11px",
                          padding: "4px 6px",
                          borderRadius: "4px",
                          background: getStatusColor(booking.status),
                          color: "white",
                          cursor: "pointer",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          whiteSpace: "nowrap",
                          transition: "transform 0.2s",
                        }}
                        onMouseEnter={(e) => e.target.style.transform = "scale(1.02)"}
                        onMouseLeave={(e) => e.target.style.transform = "scale(1)"}
                        title={`${booking.fullName} - ${booking.packageName}`}
                      >
                        {booking.fullName}
                      </div>
                    ))}
                    {dayBookings.length > 2 && (
                      <div style={{
                        fontSize: "10px",
                        color: "#64748b",
                        textAlign: "center",
                        fontWeight: "600"
                      }}>
                        +{dayBookings.length - 2} more
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Legend */}
      <div style={{
        marginTop: "20px",
        background: "white",
        padding: "16px",
        borderRadius: "12px",
        boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
      }}>
        <div style={{ fontWeight: "600", marginBottom: "12px", color: "#003f5c" }}>Status Legend:</div>
        <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div style={{ width: "16px", height: "16px", borderRadius: "4px", background: "#f59e0b" }}></div>
            <span style={{ fontSize: "14px", color: "#64748b" }}>Pending</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div style={{ width: "16px", height: "16px", borderRadius: "4px", background: "#10b981" }}></div>
            <span style={{ fontSize: "14px", color: "#64748b" }}>Confirmed</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div style={{ width: "16px", height: "16px", borderRadius: "4px", background: "#3b82f6" }}></div>
            <span style={{ fontSize: "14px", color: "#64748b" }}>Setup</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div style={{ width: "16px", height: "16px", borderRadius: "4px", background: "#6b7280" }}></div>
            <span style={{ fontSize: "14px", color: "#64748b" }}>Completed</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div style={{ width: "16px", height: "16px", borderRadius: "4px", background: "#ef4444" }}></div>
            <span style={{ fontSize: "14px", color: "#64748b" }}>Cancelled</span>
          </div>
        </div>

        <div style={{ fontWeight: "600", marginTop: "16px", marginBottom: "12px", color: "#003f5c" }}>Availability:</div>
        <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div style={{ width: "16px", height: "16px", borderRadius: "4px", background: "#d1fae5" }}></div>
            <span style={{ fontSize: "14px", color: "#64748b" }}>High (0-40%)</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div style={{ width: "16px", height: "16px", borderRadius: "4px", background: "#fef3c7" }}></div>
            <span style={{ fontSize: "14px", color: "#64748b" }}>Moderate (40-70%)</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div style={{ width: "16px", height: "16px", borderRadius: "4px", background: "#fed7aa" }}></div>
            <span style={{ fontSize: "14px", color: "#64748b" }}>Low (70-90%)</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div style={{ width: "16px", height: "16px", borderRadius: "4px", background: "#fee2e2" }}></div>
            <span style={{ fontSize: "14px", color: "#64748b" }}>Full (90%+)</span>
          </div>
        </div>
      </div>

      {/* Booking Details Modal */}
      {showBookingModal && selectedBooking && (
        <div style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: "rgba(0,0,0,0.5)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 1000,
          padding: "20px"
        }}>
          <div style={{
            background: "white",
            borderRadius: "12px",
            maxWidth: "600px",
            width: "100%",
            maxHeight: "90vh",
            overflow: "auto",
            padding: "24px",
            boxShadow: "0 20px 60px rgba(0,0,0,0.3)"
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
              <h2 style={{ margin: 0, fontSize: "24px", fontWeight: "700", color: "#003f5c" }}>
                Booking Details
              </h2>
              <button
                onClick={closeModal}
                style={{
                  background: "transparent",
                  border: "none",
                  color: "#64748b",
                  cursor: "pointer",
                  padding: "4px"
                }}
              >
                <X size={24} />
              </button>
            </div>

            {loadingDetails ? (
              <div style={{ padding: "40px", textAlign: "center" }}>
                <div className="spinner" style={{ margin: "0 auto" }}></div>
              </div>
            ) : bookingDetails ? (
              <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
                <div>
                  <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "4px" }}>Customer</div>
                  <div style={{ fontSize: "16px", fontWeight: "600", color: "#0f172a" }}>
                    {bookingDetails.booking.fullName}
                  </div>
                  <div style={{ fontSize: "14px", color: "#64748b" }}>
                    {bookingDetails.booking.contactEmail}
                  </div>
                  {bookingDetails.booking.phone && (
                    <div style={{ fontSize: "14px", color: "#64748b" }}>
                      {bookingDetails.booking.phone}
                    </div>
                  )}
                </div>

                <div>
                  <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "4px" }}>Status</div>
                  <span style={{
                    display: "inline-block",
                    padding: "6px 12px",
                    borderRadius: "6px",
                    fontSize: "14px",
                    fontWeight: "600",
                    background: getStatusColor(bookingDetails.booking.status),
                    color: "white"
                  }}>
                    {bookingDetails.booking.status}
                  </span>
                </div>

                {bookingDetails.event && (
                  <div>
                    <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "4px" }}>Event</div>
                    <div style={{ fontSize: "16px", fontWeight: "600", color: "#0f172a" }}>
                      {bookingDetails.event.name}
                    </div>
                    <div style={{ fontSize: "14px", color: "#64748b" }}>
                      {bookingDetails.event.sport} • {bookingDetails.event.eventType}
                    </div>
                  </div>
                )}

                {bookingDetails.park && (
                  <div>
                    <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "4px" }}>Location</div>
                    <div style={{ fontSize: "16px", fontWeight: "600", color: "#0f172a" }}>
                      {bookingDetails.park.name}
                    </div>
                    {bookingDetails.field && (
                      <div style={{ fontSize: "14px", color: "#64748b" }}>
                        Field: {bookingDetails.field.name}
                      </div>
                    )}
                  </div>
                )}

                <div>
                  <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "4px" }}>Date</div>
                  <div style={{ fontSize: "16px", fontWeight: "600", color: "#0f172a" }}>
                    {new Date(bookingDetails.booking.date).toLocaleDateString()}
                  </div>
                </div>

                {bookingDetails.packageData && (
                  <div>
                    <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "4px" }}>Package</div>
                    <div style={{ fontSize: "16px", fontWeight: "600", color: "#0f172a" }}>
                      {bookingDetails.packageData.name}
                    </div>
                    {bookingDetails.packageEquipment && bookingDetails.packageEquipment.length > 0 && (
                      <div style={{ fontSize: "14px", color: "#64748b", marginTop: "8px" }}>
                        <strong>Includes:</strong>
                        <ul style={{ margin: "4px 0", paddingLeft: "20px" }}>
                          {bookingDetails.packageEquipment.map((item, idx) => (
                            <li key={idx}>{item.qty}x {item.name}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}

                {bookingDetails.booking.teamName && (
                  <div>
                    <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "4px" }}>Team</div>
                    <div style={{ fontSize: "16px", fontWeight: "600", color: "#0f172a" }}>
                      {bookingDetails.booking.teamName}
                    </div>
                    {bookingDetails.booking.coachName && (
                      <div style={{ fontSize: "14px", color: "#64748b" }}>
                        Coach: {bookingDetails.booking.coachName}
                      </div>
                    )}
                  </div>
                )}

                {bookingDetails.booking.notes && (
                  <div>
                    <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "4px" }}>Notes</div>
                    <div style={{ fontSize: "14px", color: "#0f172a", whiteSpace: "pre-wrap" }}>
                      {bookingDetails.booking.notes}
                    </div>
                  </div>
                )}

                <div style={{ marginTop: "8px", paddingTop: "16px", borderTop: "1px solid #e2e8f0" }}>
                  <a
                    href={`/AdminBookings?id=${bookingDetails.booking.id}`}
                    target="_blank"
                    className="btn"
                    style={{ width: "100%", textAlign: "center", display: "block" }}
                  >
                    <Eye size={16} style={{ marginRight: "8px", display: "inline" }} />
                    View Full Details in Admin
                  </a>
                </div>
              </div>
            ) : (
              <div style={{ padding: "40px", textAlign: "center", color: "#64748b" }}>
                Failed to load booking details
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}