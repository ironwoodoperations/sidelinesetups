import { useState } from 'react';
import { Mail, Send, CheckCircle } from 'lucide-react';
import { base44 } from '../api/base44Client';

export default function CustomerLoginPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const result = await base44.functions.invoke('requestMagicLink', {
        kind: 'customer',
        email: email.trim().toLowerCase()
      });
      
      if (result.data.ok) {
        setSent(true);
      } else {
        setError(result.data.error || 'Failed to send login link');
      }
    } catch (err) {
      console.error('Login error:', err);
      setError('Failed to send login link. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  if (sent) {
    return (
      <div style={{ 
        minHeight: '60vh', 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'center',
        padding: '20px'
      }}>
        <div style={{
          maxWidth: '500px',
          width: '100%',
          background: 'white',
          borderRadius: '16px',
          padding: '40px',
          boxShadow: '0 8px 24px rgba(0,0,0,0.1)',
          textAlign: 'center'
        }}>
          <div style={{
            width: '64px',
            height: '64px',
            borderRadius: '50%',
            background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 24px'
          }}>
            <CheckCircle size={32} color="white" />
          </div>
          
          <h2 style={{ margin: '0 0 12px 0', color: '#003f5c' }}>Check Your Email!</h2>
          
          <p style={{ color: '#64748b', fontSize: '16px', lineHeight: '1.6', marginBottom: '24px' }}>
            We've sent a secure login link to <strong>{email}</strong>
          </p>
          
          <p style={{ color: '#64748b', fontSize: '14px', marginBottom: '24px' }}>
            Click the link in your email to access your bookings. The link will expire in 15 minutes.
          </p>
          
          <button
            onClick={() => {
              setSent(false);
              setEmail('');
            }}
            className="btn-outline"
            style={{ width: '100%' }}
          >
            Send Another Link
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ 
      minHeight: '60vh', 
      display: 'flex', 
      alignItems: 'center', 
      justifyContent: 'center',
      padding: '20px'
    }}>
      <div style={{
        maxWidth: '450px',
        width: '100%',
        background: 'white',
        borderRadius: '16px',
        padding: '40px',
        boxShadow: '0 8px 24px rgba(0,0,0,0.1)'
      }}>
        <div style={{
          width: '64px',
          height: '64px',
          borderRadius: '50%',
          background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '0 auto 24px'
        }}>
          <Mail size={32} color="white" />
        </div>
        
        <h2 style={{ textAlign: 'center', margin: '0 0 8px 0', color: '#003f5c' }}>
          View Your Bookings
        </h2>
        
        <p style={{ textAlign: 'center', color: '#64748b', fontSize: '14px', marginBottom: '32px' }}>
          Enter your email to receive a secure login link
        </p>

        {error && (
          <div style={{
            padding: '12px',
            background: '#fee2e2',
            border: '1px solid #fecaca',
            borderRadius: '8px',
            color: '#991b1b',
            fontSize: '14px',
            marginBottom: '20px'
          }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: '24px' }}>
            <label style={{ 
              display: 'block', 
              marginBottom: '8px', 
              fontWeight: '600',
              color: '#0f172a',
              fontSize: '14px'
            }}>
              Email Address
            </label>
            <input
              type="email"
              className="input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              required
              disabled={loading}
              style={{ fontSize: '16px' }}
            />
          </div>

          <button
            type="submit"
            className="btn"
            disabled={loading || !email}
            style={{
              width: '100%',
              background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
              fontSize: '16px',
              padding: '12px'
            }}
          >
            {loading ? (
              <>
                <div className="spinner" style={{ width: '20px', height: '20px' }}></div>
                Sending...
              </>
            ) : (
              <>
                <Send size={20} />
                Send Login Link
              </>
            )}
          </button>
        </form>

        <div style={{
          marginTop: '24px',
          padding: '16px',
          background: '#f8fafc',
          borderRadius: '8px',
          fontSize: '13px',
          color: '#64748b'
        }}>
          <strong style={{ color: '#0f172a' }}>Note:</strong> We'll send you a secure link that expires in 15 minutes. No password needed!
        </div>
      </div>
    </div>
  );
}