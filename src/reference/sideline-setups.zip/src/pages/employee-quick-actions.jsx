import EmployeeQuickActions from "./EmployeeQuickActions";

export default EmployeeQuickActions;