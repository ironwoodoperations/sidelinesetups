
// pages/admindashboard.js (lowercase for Base44 routing)
// This re-exports the Admin component to match the URL routes
import Admin from "./Admin";

export default Admin;
