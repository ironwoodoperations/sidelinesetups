import React, { useState } from "react";
import { base44 } from "../api/base44Client";
import { Calendar, Printer, ArrowLeft, RefreshCw } from "lucide-react";

export default function ManagerDailyOverview() {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [overview, setOverview] = useState([]);
  const [loading, setLoading] = useState(false);

  const loadOverview = async () => {
    if (!date) {
      alert("Please select a date");
      return;
    }

    setLoading(true);
    try {
      const response = await base44.functions.invoke('generateManagerOverview', { date });
      setOverview(response.data || []);
    } catch (error) {
      console.error("Failed to load overview:", error);
      alert("Failed to load overview: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const formatTime = (timeStr) => {
    if (!timeStr) return '';
    const [hh, mm] = timeStr.split(':').map(n => parseInt(n, 10));
    const ampm = hh >= 12 ? 'PM' : 'AM';
    const hour = ((hh + 11) % 12) + 1;
    return `${hour}:${mm.toString().padStart(2, '0')} ${ampm}`;
  };

  return (
    <div style={{ minHeight: '100vh', background: '#f8fafc', padding: '24px' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        {/* Header - Hidden when printing */}
        <div className="no-print" style={{ marginBottom: '24px' }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '20px'
          }}>
            <h2 style={{ margin: 0, fontSize: '24px', fontWeight: '700', color: '#003f5c' }}>
              Manager Daily Overview
            </h2>
            <a
              href="/staff-dashboard"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                color: '#003f5c',
                textDecoration: 'none',
                padding: '8px 16px',
                border: '1px solid #003f5c',
                borderRadius: '8px',
                fontSize: '14px',
                fontWeight: '600',
                transition: 'all 0.2s'
              }}
              onMouseEnter={(e) => e.target.style.background = '#f8fafc'}
              onMouseLeave={(e) => e.target.style.background = 'transparent'}
            >
              <ArrowLeft size={16} />
              Back to Dashboard
            </a>
          </div>

          <div className="card" style={{ padding: '20px', marginBottom: '24px' }}>
            <div style={{
              display: 'flex',
              gap: '16px',
              alignItems: 'flex-end'
            }}>
              <div style={{ flex: 1 }}>
                <label style={{
                  display: 'block',
                  marginBottom: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  color: '#0f172a'
                }}>
                  Date *
                </label>
                <input
                  type="date"
                  className="input"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                />
              </div>

              <button
                onClick={loadOverview}
                disabled={loading || !date}
                className="btn"
                style={{
                  background: 'linear-gradient(to right, #003f5c, #00507a)',
                  color: 'white',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px'
                }}
              >
                {loading ? (
                  <>
                    <RefreshCw size={16} className="animate-spin" />
                    Loading...
                  </>
                ) : (
                  <>
                    <Calendar size={16} />
                    Load Overview
                  </>
                )}
              </button>

              {overview.length > 0 && (
                <button
                  onClick={handlePrint}
                  className="btn-outline"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    color: '#003f5c',
                    borderColor: '#003f5c'
                  }}
                >
                  <Printer size={16} />
                  Print Overview
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Overview Content */}
        {loading && (
          <div style={{ textAlign: 'center', padding: '40px' }}>
            <div className="spinner"></div>
            <p style={{ marginTop: '16px', color: '#64748b' }}>Loading overview...</p>
          </div>
        )}

        {!loading && overview.length === 0 && date && (
          <div className="card" style={{ padding: '40px', textAlign: 'center' }}>
            <Calendar size={48} style={{ margin: '0 auto 16px', color: '#cbd5e1' }} />
            <h3 style={{ margin: '0 0 8px 0', color: '#64748b' }}>No Bookings Found</h3>
            <p style={{ margin: 0, color: '#94a3b8', fontSize: '14px' }}>
              No bookings found for {date}
            </p>
          </div>
        )}

        {!loading && overview.length > 0 && (
          <div className="card" style={{ padding: '20px' }}>
            <h3 style={{ margin: '0 0 20px 0', fontSize: '20px', fontWeight: '700', color: '#003f5c' }}>
              Daily Setup Overview - {new Date(date).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
            </h3>
            
            <div style={{ overflowX: 'auto' }}>
              <table className="table" style={{ width: '100%' }}>
                <thead>
                  <tr>
                    <th>Event</th>
                    <th>Park</th>
                    <th>Field</th>
                    <th>Customer</th>
                    <th>Game Times</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {overview.map((item, index) => (
                    <tr key={index}>
                      <td>{item.eventName}</td>
                      <td>{item.parkName}</td>
                      <td>{item.fieldName}</td>
                      <td style={{ fontWeight: '600' }}>{item.customerName}</td>
                      <td>
                        {item.gameTimes && item.gameTimes.length > 0
                          ? item.gameTimes.map(t => formatTime(t)).join(', ')
                          : 'TBD'}
                      </td>
                      <td>
                        <span className={`badge ${
                          item.status === 'setup' ? 'badge-success' : 
                          item.status === 'completed' ? 'badge-success' :
                          'badge-warn'
                        }`}>
                          {item.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Print Styles */}
        <style>{`
          @media print {
            .no-print {
              display: none !important;
            }
            
            body {
              background: white;
            }
            
            @page {
              size: letter landscape;
              margin: 0.5in;
            }
          }
        `}</style>
      </div>
    </div>
  );
}