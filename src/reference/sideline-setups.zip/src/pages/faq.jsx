
import React from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import SEO from "../components/SEO";

const faqData = [
  {
    id: 1,
    question: "How far in advance should I book?",
    category: "booking",
    answer: "We recommend booking at least 1-2 weeks in advance to ensure availability, especially for popular tournament weekends. However, we understand plans change and we'll do our best to accommodate last-minute bookings when possible. Contact us directly for urgent requests."
  },
  {
    id: 2,
    question: "What if it rains on game day?",
    category: "general",
    answer: "Our pop-up tents provide excellent rain protection! If games are postponed or cancelled due to weather, please contact us as soon as possible. We offer rescheduling options or credits toward future bookings. Check our cancellation policy for full details."
  },
  {
    id: 3,
    question: "When do you set up and tear down?",
    category: "equipment",
    answer: "We arrive early to set up your equipment before your first game (typically 30-60 minutes before game time). After your last game, we return to pack everything up. You don't have to wait around or do anything - just enjoy your day and head home when you're ready!"
  },
  {
    id: 4,
    question: "What's included in the MVP Setup?",
    category: "equipment",
    answer: "The MVP Setup includes a 10x10 pop-up tent for shade, 2 comfortable rocker chairs, and a wheeled cooler. This is our most popular package and provides excellent comfort for watching games. You can also add extras like additional chairs, fans, or a stocked cooler."
  },
  {
    id: 5,
    question: "How do I pay for my booking?",
    category: "payment",
    answer: "We accept all major credit cards and PayPal through our secure online booking system. Payment is processed at the time of booking to confirm your reservation. You'll receive an instant confirmation email with all your booking details and a QR code for easy check-in on game day."
  },
  {
    id: 6,
    question: "Can I cancel or reschedule my booking?",
    category: "booking",
    answer: "Yes! We understand plans change. Cancellations made 48+ hours before your event receive a full refund. For cancellations within 48 hours, we offer a credit toward a future booking. Rescheduling is always free - just contact us as soon as you know your plans have changed."
  },
  {
    id: 7,
    question: "Do you service all ballparks in the area?",
    category: "general",
    answer: "We're expanding our coverage constantly! Check our Events page to see current tournaments and venues we're servicing. If you don't see your park or event listed, please contact us - we're always looking to add new locations based on customer demand."
  },
  {
    id: 8,
    question: "What if my equipment gets damaged during the game?",
    category: "equipment",
    answer: "Normal wear and tear is expected and covered. However, if equipment is intentionally damaged or lost, you may be responsible for replacement costs. We inspect all equipment before and after each rental. Our gear is built to last and withstand typical game day conditions including sun, wind, and rain."
  }
];

const categories = [
  { id: "all", label: "All Questions" },
  { id: "general", label: "General" },
  { id: "booking", label: "Booking" },
  { id: "equipment", label: "Equipment" },
  { id: "payment", label: "Payment" }
];

export default function FAQ() {
  const [activeCategory, setActiveCategory] = React.useState("all");
  const [openQuestion, setOpenQuestion] = React.useState(null);
  const [settings, setSettings] = React.useState(null);

  React.useEffect(() => {
    (async () => {
      const { getCtx } = await import("../components/lib/ctx");
      const { settings } = await getCtx();
      setSettings(settings || {});
    })();
  }, []);

  const filteredQuestions = activeCategory === "all" 
    ? faqData 
    : faqData.filter(q => q.category === activeCategory);

  return (
    <div 
      className="min-h-screen py-12"
      style={{
        backgroundImage: settings?.pageBackgroundPatternUrl 
          ? `linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.92)), url('${settings.pageBackgroundPatternUrl}')`
          : undefined,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
        backgroundColor: '#f8fafc'
      }}
    >
      <SEO 
        title="FAQ - Frequently Asked Questions | Sideline Setups"
        description="Get answers to common questions about Sideline Setups youth sports tournament tent and chair rentals. Learn about booking, pricing, setup, and our service areas in East Texas."
        keywords="youth sports setup FAQ, tournament rental questions, travel ball setup service, sideline setups questions, game day rental info"
        canonicalUrl="https://sideline-setups.com/faq"
      />
      
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4" style={{ color: '#003f5c' }}>
            Frequently Asked Questions About Youth Sports Setup Rentals
          </h1>
          <p className="text-gray-600 text-lg">
            Find answers to common questions about our sideline setup service for travel ball and youth sports tournaments
          </p>
        </div>

        {/* Category Tabs */}
        <div className="card card-pad mb-6">
          <div className="flex flex-wrap gap-2 justify-center">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={activeCategory === cat.id ? "btn" : "btn-outline"}
                style={
                  activeCategory === cat.id
                    ? {
                        background: 'linear-gradient(to right, #003f5c, #00507a)',
                        color: 'white',
                        border: 'none'
                      }
                    : {
                        color: '#003f5c',
                        borderColor: '#003f5c'
                      }
                }
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Questions */}
        <div className="space-y-4">
          {filteredQuestions.map((faq) => (
            <div 
              key={faq.id} 
              className="card card-pad"
              onMouseEnter={() => setOpenQuestion(faq.id)}
              onMouseLeave={() => setOpenQuestion(null)}
              style={{
                transition: 'all 0.2s ease',
                cursor: 'pointer'
              }}
            >
              <button
                onClick={() => setOpenQuestion(openQuestion === faq.id ? null : faq.id)}
                className="w-full text-left flex justify-between items-center"
                style={{ background: 'none', border: 'none', cursor: 'pointer' }}
              >
                <h3 className="text-lg font-bold pr-4" style={{ color: '#003f5c' }}>
                  {faq.question}
                </h3>
                {openQuestion === faq.id ? (
                  <ChevronUp size={24} style={{ color: '#003f5c', flexShrink: 0 }} />
                ) : (
                  <ChevronDown size={24} style={{ color: '#003f5c', flexShrink: 0 }} />
                )}
              </button>
              
              {openQuestion === faq.id && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <p className="text-gray-700 leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Contact Section */}
        <div className="card card-pad mt-8 text-center">
          <h2 className="text-2xl font-bold mb-4" style={{ color: '#003f5c' }}>
            Still Have Questions?
          </h2>
          <p className="text-gray-700 mb-6">
            Can't find what you're looking for? We're here to help! Get in touch with us directly.
          </p>
          <div className="space-y-2 text-gray-700">
            <p>
              <strong>Call or Text:</strong>{' '}
              <a href="tel:9035419287" style={{ color: '#003f5c', textDecoration: 'underline' }}>
                (903) 541-9287
              </a>
            </p>
            <p>
              <strong>Email:</strong>{' '}
              <a href="mailto:sidelinesetups@gmail.com" style={{ color: '#003f5c', textDecoration: 'underline' }}>
                sidelinesetups@gmail.com
              </a>
            </p>
          </div>
          <div className="mt-6">
            <a 
              href="/" 
              className="btn-outline"
              style={{
                color: '#003f5c',
                borderColor: '#003f5c',
                padding: '10px 24px',
                borderRadius: '9999px',
                fontWeight: '600',
                textDecoration: 'none',
                display: 'inline-block'
              }}
            >
              Back to Home
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
