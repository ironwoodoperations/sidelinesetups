import React, { useState } from "react";
import { base44 } from "../api/base44Client";
import { Upload, Copy, Check } from "lucide-react";

export default function AdminUpload() {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadedUrl, setUploadedUrl] = useState("");
  const [recentUploads, setRecentUploads] = useState([]);
  const [copiedUrl, setCopiedUrl] = useState("");

  const handleFileChange = (e) => {
    const selected = e.target.files?.[0];
    if (selected) {
      setFile(selected);
    }
  };

  const handleUpload = async () => {
    if (!file) {
      alert("Please select a file first");
      return;
    }

    setUploading(true);
    try {
      const result = await base44.integrations.Core.UploadFile({ file });
      const url = result?.file_url || result?.url;
      
      if (url) {
        setUploadedUrl(url);
        setRecentUploads(prev => [{ url, name: file.name, timestamp: new Date() }, ...prev]);
        setFile(null);
        // Reset file input
        const fileInput = document.getElementById("file-input");
        if (fileInput) fileInput.value = "";
      } else {
        alert("Upload succeeded but no URL returned");
      }
    } catch (error) {
      console.error("Upload error:", error);
      alert("Upload failed: " + (error.message || "Unknown error"));
    } finally {
      setUploading(false);
    }
  };

  const copyToClipboard = (url) => {
    navigator.clipboard.writeText(url);
    setCopiedUrl(url);
    setTimeout(() => setCopiedUrl(""), 2000);
  };

  const isImageUrl = (url) => {
    return /\.(jpg|jpeg|png|gif|webp|svg)$/i.test(url);
  };

  return (
    <div className="container section">
      <h1>Upload Images</h1>
      <p style={{ color: "var(--muted)", marginTop: 8 }}>
        Upload images for events, logos, hero banners, and more.
      </p>

      <div className="card card-pad" style={{ marginTop: 24, maxWidth: 600 }}>
        <h3 style={{ marginBottom: 16 }}>Upload New Image</h3>
        
        <div style={{ marginBottom: 16 }}>
          <label className="label">Select Image File</label>
          <input
            id="file-input"
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="input"
            style={{ padding: "8px" }}
          />
        </div>

        {file && (
          <div style={{ marginBottom: 16, padding: 12, background: "var(--bg-2)", borderRadius: 8 }}>
            <div style={{ fontSize: 14, color: "var(--muted)" }}>Selected:</div>
            <div style={{ fontWeight: 600 }}>{file.name}</div>
            <div style={{ fontSize: 12, color: "var(--muted)" }}>
              {(file.size / 1024).toFixed(1)} KB
            </div>
          </div>
        )}

        <button
          className="btn"
          onClick={handleUpload}
          disabled={!file || uploading}
          style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
        >
          <Upload size={18} />
          {uploading ? "Uploading..." : "Upload Image"}
        </button>

        {uploadedUrl && (
          <div style={{ marginTop: 16, padding: 12, background: "#ecfdf5", border: "1px solid #c7f9e9", borderRadius: 8 }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: "#065f46", marginBottom: 8 }}>
              ✓ Upload Successful!
            </div>
            {isImageUrl(uploadedUrl) && (
              <div style={{ marginBottom: 12 }}>
                <img 
                  src={uploadedUrl} 
                  alt="Uploaded" 
                  style={{ 
                    maxWidth: "100%", 
                    maxHeight: 200, 
                    borderRadius: 8,
                    border: "1px solid var(--border)"
                  }} 
                />
              </div>
            )}
            <div style={{ fontSize: 12, color: "#065f46", wordBreak: "break-all", marginBottom: 8 }}>
              {uploadedUrl}
            </div>
            <button
              className="btn-outline"
              onClick={() => copyToClipboard(uploadedUrl)}
              style={{ display: "flex", alignItems: "center", gap: 6 }}
            >
              {copiedUrl === uploadedUrl ? <Check size={16} /> : <Copy size={16} />}
              {copiedUrl === uploadedUrl ? "Copied!" : "Copy URL"}
            </button>
          </div>
        )}
      </div>

      {recentUploads.length > 0 && (
        <div style={{ marginTop: 32 }}>
          <h2 style={{ marginBottom: 16 }}>Recent Uploads</h2>
          <div className="grid grid-2" style={{ gap: 16 }}>
            {recentUploads.map((upload, idx) => (
              <div key={idx} className="card card-pad">
                {isImageUrl(upload.url) && (
                  <div style={{ marginBottom: 12 }}>
                    <img 
                      src={upload.url} 
                      alt={upload.name} 
                      style={{ 
                        width: "100%", 
                        height: 200, 
                        objectFit: "cover", 
                        borderRadius: 8,
                        border: "1px solid var(--border)"
                      }} 
                    />
                  </div>
                )}
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>
                  {upload.name}
                </div>
                <div style={{ fontSize: 12, color: "var(--muted)", marginBottom: 8, wordBreak: "break-all" }}>
                  {upload.url}
                </div>
                <button
                  className="btn-outline"
                  onClick={() => copyToClipboard(upload.url)}
                  style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13 }}
                >
                  {copiedUrl === upload.url ? <Check size={14} /> : <Copy size={14} />}
                  {copiedUrl === upload.url ? "Copied!" : "Copy URL"}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={{ marginTop: 32, padding: 16, background: "var(--bg-2)", borderRadius: 8 }}>
        <h3 style={{ fontSize: 16, marginBottom: 8 }}>How to use uploaded images:</h3>
        <ol style={{ paddingLeft: 20, color: "var(--muted)", fontSize: 14, lineHeight: 1.6 }}>
          <li>Upload your image using the form above</li>
          <li>Copy the URL that appears</li>
          <li>Paste the URL into any image field in your app (e.g., Event imageUrl, SiteSettings logoUrl, etc.)</li>
          <li>The image will be publicly accessible at that URL</li>
        </ol>
      </div>
    </div>
  );
}