
// pages/AdminSpend.jsx
import React from "react";
import NavBar from "../components/NavBar";
import { getCtx } from "../components/lib/ctx";
import { loadSpendRows, groupByPark, groupByEvent, groupByProduct, toCSV } from "../components/lib/spend";

function Section({ title, children, right=null }) {
  return (
    <section style={{ background: "white", border: "1px solid #e2e8f0", borderRadius: 16, padding: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <h3 style={{ margin: 0 }}>{title}</h3>
        {right}
      </div>
      {children}
    </section>
  );
}

function Table({ columns, rows }) {
  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr>
            {columns.map(c => (
              <th key={c.key} style={{ textAlign: "left", borderBottom: "1px solid #e2e8f0", padding: "8px 6px", fontWeight: 800 }}>{c.title}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} style={{ borderBottom: "1px solid #f1f5f9" }}>
              {columns.map(c => (
                <td key={c.key} style={{ padding: "8px 6px", fontSize: 14 }}>
                  {typeof c.render === "function" ? c.render(r) : r[c.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function AdminSpend() {
  const [dateFrom, setDateFrom] = React.useState(() => new Date(Date.now()-7*864e5).toISOString().slice(0,10));
  const [dateTo, setDateTo] = React.useState(() => new Date().toISOString().slice(0,10));
  const [parkId, setParkId] = React.useState("");
  const [parks, setParks] = React.useState([]);
  const [rows, setRows] = React.useState([]);
  const [laborUSD, setLaborUSD] = React.useState(0);
  const [laborHours, setLaborHours] = React.useState(0);
  const [hourly, setHourly] = React.useState(20);
  const [note, setNote] = React.useState("");

  React.useEffect(() => { (async () => {
    try {
      const { entities } = await getCtx();
      const ps = await entities.Parks.list() || [];
      setParks(ps);
    } catch (e) {
      setNote(e?.message || "Load parks failed");
    }
  })(); }, []);

  async function run() {
    try {
      const { rows: fetchedRows, parks, events, laborUSD, totalLaborHours, hourly } =
        await loadSpendRows({ dateFrom, dateTo, parkId: parkId || null });
      setRows(fetchedRows);
      setLaborUSD(laborUSD);
      setLaborHours(totalLaborHours);
      setHourly(hourly);
    } catch (e) {
      setNote(e?.message || "Failed");
    }
  }

  const gross = rows.reduce((s, r) => s + Number(r.totalUSD || 0), 0);
  const cogs  = rows.reduce((s, r) => s + Number(r.cogsUSD  || 0), 0);
  const netAfterLaborCOGS = Math.max(0, gross - laborUSD - cogs);

  const byPark = groupByPark(rows);
  const byEvent = groupByEvent(rows);
  const byProduct = groupByProduct(rows);

  function downloadCSV(name, data, headers) {
    const blob = new Blob([toCSV(data, headers)], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  return (
    <>
      <NavBar />
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: 16, display: "grid", gap: 16 }}>
        <h2>Admin Spend Map</h2>

        <Section title="Filters">
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr auto", gap: 8 }}>
            <div>
              <label style={{ fontSize: 12, color: "#64748b" }}>From</label>
              <input type="date" value={dateFrom} onChange={(e)=>setDateFrom(e.target.value)}
                style={{ width: "100%", padding: "10px 12px", border: "1px solid #e2e8f0", borderRadius: 10 }} />
            </div>
            <div>
              <label style={{ fontSize: 12, color: "#64748b" }}>To</label>
              <input type="date" value={dateTo} onChange={(e)=>setDateTo(e.target.value)}
                style={{ width: "100%", padding: "10px 12px", border: "1px solid #e2e8f0", borderRadius: 10 }} />
            </div>
            <div>
              <label style={{ fontSize: 12, color: "#64748b" }}>Park</label>
              <select value={parkId} onChange={(e)=>setParkId(e.target.value)}
                style={{ width: "100%", padding: "10px 12px", border: "1px solid #e2e8f0", borderRadius: 10 }}>
                <option value="">All parks</option>
                {parks.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            <div style={{ display: "flex", alignItems: "end" }}>
              <button onClick={run} style={{ padding: "10px 14px", borderRadius: 10, border: "1px solid #0ea5e9", background: "#0ea5e9", color: "white", fontWeight: 800 }}>
                Run
              </button>
            </div>
          </div>
        </Section>

        <Section title="Totals">
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12 }}>
            <div style={{ background: "#eff6ff", border: "1px solid #bfdbfe", borderRadius: 12, padding: 14 }}>
              <div style={{ color: "#1e3a8a", fontSize: 12, fontWeight: 700 }}>Gross Revenue</div>
              <div style={{ fontSize: 26, fontWeight: 900 }}>${gross.toFixed(2)}</div>
            </div>
            <div style={{ background: "#fef3c7", border: "1px solid #fde68a", borderRadius: 12, padding: 14 }}>
              <div style={{ color: "#92400e", fontSize: 12, fontWeight: 700 }}>Labor ({laborHours.toFixed(1)}h @ ${hourly}/h)</div>
              <div style={{ fontSize: 26, fontWeight: 900 }}>${laborUSD.toFixed(2)}</div>
            </div>
            <div style={{ background: "#f1f5f9", border: "1px solid #cbd5e1", borderRadius: 12, padding: 14 }}>
              <div style={{ color: "#0f172a", fontSize: 12, fontWeight: 700 }}>COGS (per-use)</div>
              <div style={{ fontSize: 26, fontWeight: 900 }}>${cogs.toFixed(2)}</div>
            </div>
            <div style={{ background: "#ecfdf5", border: "1px solid #a7f3d0", borderRadius: 12, padding: 14 }}>
              <div style={{ color: "#065f46", fontSize: 12, fontWeight: 700 }}>Net (Gross − Labor − COGS)</div>
              <div style={{ fontSize: 26, fontWeight: 900 }}>${netAfterLaborCOGS.toFixed(2)}</div>
            </div>
          </div>
        </Section>

        <Section
          title="By Park"
          right={<button onClick={()=>downloadCSV("by-park.csv", byPark, ["parkId","parkName","grossUSD","cogsUSD","bookings"])}>Export CSV</button>}
        >
          <Table
            columns={[
              { key: "parkName", title: "Park" },
              { key: "bookings", title: "Bookings" },
              { key: "grossUSD", title: "Gross", render: r => `$${r.grossUSD.toFixed(2)}` },
              { key: "cogsUSD",  title: "COGS",  render: r => `$${r.cogsUSD.toFixed(2)}` },
            ]}
            rows={byPark}
          />
        </Section>

        <Section
          title="By Event"
          right={<button onClick={()=>downloadCSV("by-event.csv", byEvent, ["eventId","eventName","grossUSD","cogsUSD","bookings"])}>Export CSV</button>}
        >
          <Table
            columns={[
              { key: "eventName", title: "Event" },
              { key: "bookings", title: "Bookings" },
              { key: "grossUSD", title: "Gross", render: r => `$${r.grossUSD.toFixed(2)}` },
              { key: "cogsUSD",  title: "COGS",  render: r => `$${r.cogsUSD.toFixed(2)}` },
            ]}
            rows={byEvent}
          />
        </Section>

        <Section
          title="By Product (Package x Mode)"
          right={<button onClick={()=>downloadCSV("by-product.csv", byProduct, ["packageId","packageMode","grossUSD","cogsUSD","bookings"])}>Export CSV</button>}
        >
          <Table
            columns={[
              { key: "packageId", title: "Package" },
              { key: "packageMode", title: "Mode" },
              { key: "bookings", title: "Bookings" },
              { key: "grossUSD", title: "Gross", render: r => `$${r.grossUSD.toFixed(2)}` },
              { key: "cogsUSD",  title: "COGS",  render: r => `$${r.cogsUSD.toFixed(2)}` },
            ]}
            rows={byProduct}
          />
        </Section>

        {!!note && <div style={{ color: "#ef4444" }}>{note}</div>}
      </div>
    </>
  );
}
