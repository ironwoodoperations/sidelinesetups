import React, { useState, useEffect } from "react";
import { base44 } from "../api/base44Client";
import { Download, Calendar, TrendingUp, DollarSign, Users, Package, Clock } from "lucide-react";

function Money({ cents }) {
  return <>${(Number(cents || 0) / 100).toFixed(2)}</>;
}

function Card({ title, icon: Icon, children, onExport }) {
  return (
    <div style={{
      background: "white",
      borderRadius: "12px",
      border: "1px solid #e2e8f0",
      padding: "20px",
      boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
    }}>
      <div style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: "16px",
        paddingBottom: "12px",
        borderBottom: "2px solid #e2e8f0"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          {Icon && <Icon size={20} style={{ color: "#003f5c" }} />}
          <h3 style={{ margin: 0, fontSize: "18px", fontWeight: "700", color: "#003f5c" }}>
            {title}
          </h3>
        </div>
        {onExport && (
          <button
            onClick={onExport}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "6px",
              padding: "6px 12px",
              background: "transparent",
              border: "1px solid #003f5c",
              borderRadius: "6px",
              color: "#003f5c",
              fontSize: "13px",
              cursor: "pointer",
              fontWeight: "600"
            }}
          >
            <Download size={14} />
            Export CSV
          </button>
        )}
      </div>
      {children}
    </div>
  );
}

function Table({ rows, cols }) {
  if (!rows || rows.length === 0) {
    return (
      <div style={{ 
        padding: "40px", 
        textAlign: "center", 
        color: "#64748b",
        fontSize: "14px"
      }}>
        No data available for selected date range
      </div>
    );
  }

  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ width: "100%", fontSize: "14px", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ borderBottom: "2px solid #e2e8f0" }}>
            {cols.map(c => (
              <th key={c.key} style={{
                padding: "10px 12px",
                textAlign: "left",
                fontWeight: "600",
                color: "#64748b",
                fontSize: "12px",
                textTransform: "uppercase",
                letterSpacing: "0.05em"
              }}>
                {c.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} style={{
              borderBottom: "1px solid #f1f5f9"
            }}>
              {cols.map(c => (
                <td key={c.key} style={{
                  padding: "12px",
                  color: "#0f172a"
                }}>
                  {c.render ? c.render(r[c.key], r) : String(r[c.key] ?? "")}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function AdminReports() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [loading, setLoading] = useState(false);
  
  // Report data states
  const [revDay, setRevDay] = useState([]);
  const [revPark, setRevPark] = useState([]);
  const [pkgMix, setPkgMix] = useState([]);
  const [addons, setAddons] = useState([]);
  const [timesheet, setTimesheet] = useState([]);
  const [payroll, setPayroll] = useState([]);
  const [pulls, setPulls] = useState([]);
  const [util, setUtil] = useState([]);
  const [ltv, setLtv] = useState([]);

  async function loadReport(reportName, setter) {
    try {
      const response = await base44.functions.invoke(`reports/${reportName}`, {
        from: from || undefined,
        to: to || undefined
      });
      setter(response.data || []);
    } catch (error) {
      console.error(`Error loading ${reportName}:`, error);
      setter([]);
    }
  }

  async function loadAllReports() {
    setLoading(true);
    try {
      await Promise.all([
        loadReport('revenueByDay', setRevDay),
        loadReport('revenueByPark', setRevPark),
        loadReport('packageMix', setPkgMix),
        loadReport('addonSales', setAddons),
        loadReport('timesheet', setTimesheet),
        loadReport('payrollSummary', setPayroll),
        loadReport('setupPulls', setPulls),
        loadReport('utilizationByParkDay', setUtil),
        loadReport('customerLtv', setLtv),
      ]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAllReports();
  }, [from, to]);

  async function handleExport(reportName) {
    try {
      const params = new URLSearchParams();
      params.set('report', reportName);
      if (from) params.set('from', from);
      if (to) params.set('to', to);

      const response = await base44.functions.invoke('reports/exportCsv', Object.fromEntries(params));
      
      // Create blob and download
      const blob = new Blob([response.data], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${reportName}-${from || 'all'}-${to || 'all'}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Export error:', error);
      alert('Failed to export CSV');
    }
  }

  return (
    <div style={{ padding: "24px" }}>
      {/* Header */}
      <div style={{ marginBottom: "32px" }}>
        <h1 style={{ 
          margin: "0 0 8px 0", 
          fontSize: "28px", 
          fontWeight: "700",
          color: "#003f5c"
        }}>
          Reports & Analytics
        </h1>
        <p style={{ margin: 0, color: "#64748b", fontSize: "14px" }}>
          Comprehensive business insights and operational metrics
        </p>
      </div>

      {/* Date Filters */}
      <div style={{
        background: "white",
        borderRadius: "12px",
        border: "1px solid #e2e8f0",
        padding: "20px",
        marginBottom: "24px",
        display: "flex",
        alignItems: "end",
        gap: "16px",
        flexWrap: "wrap"
      }}>
        <div>
          <label style={{
            display: "block",
            marginBottom: "6px",
            fontSize: "13px",
            fontWeight: "600",
            color: "#64748b"
          }}>
            From Date
          </label>
          <input
            type="date"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
            style={{
              padding: "8px 12px",
              border: "1px solid #e2e8f0",
              borderRadius: "6px",
              fontSize: "14px"
            }}
          />
        </div>
        <div>
          <label style={{
            display: "block",
            marginBottom: "6px",
            fontSize: "13px",
            fontWeight: "600",
            color: "#64748b"
          }}>
            To Date
          </label>
          <input
            type="date"
            value={to}
            onChange={(e) => setTo(e.target.value)}
            style={{
              padding: "8px 12px",
              border: "1px solid #e2e8f0",
              borderRadius: "6px",
              fontSize: "14px"
            }}
          />
        </div>
        <button
          onClick={loadAllReports}
          disabled={loading}
          style={{
            padding: "9px 20px",
            background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
            color: "white",
            border: "none",
            borderRadius: "6px",
            fontSize: "14px",
            fontWeight: "600",
            cursor: loading ? "not-allowed" : "pointer",
            opacity: loading ? 0.7 : 1
          }}
        >
          {loading ? "Loading..." : "Refresh Reports"}
        </button>
        <div style={{ marginLeft: "auto", fontSize: "12px", color: "#64748b" }}>
          Timezone: America/Chicago
        </div>
      </div>

      {loading && (
        <div style={{ textAlign: "center", padding: "40px" }}>
          <div className="spinner"></div>
          <p style={{ marginTop: "16px", color: "#64748b" }}>Loading reports...</p>
        </div>
      )}

      {!loading && (
        <div style={{ display: "grid", gap: "24px" }}>
          {/* Revenue Reports */}
          <Card 
            title="Revenue by Day" 
            icon={TrendingUp}
            onExport={() => handleExport('revenueByDay')}
          >
            <Table
              rows={revDay}
              cols={[
                { key: 'sale_date', label: 'Date' },
                { key: 'gross_cents', label: 'Gross', render: v => <Money cents={v} /> },
                { key: 'tax_cents', label: 'Tax', render: v => <Money cents={v} /> },
                { key: 'fee_cents', label: 'Fees', render: v => <Money cents={v} /> },
                { key: 'net_cents', label: 'Net', render: v => <Money cents={v} /> },
              ]}
            />
          </Card>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(400px, 1fr))", gap: "24px" }}>
            <Card 
              title="Revenue by Park" 
              icon={DollarSign}
              onExport={() => handleExport('revenueByPark')}
            >
              <Table
                rows={revPark}
                cols={[
                  { key: 'park_name', label: 'Park' },
                  { key: 'gross_cents', label: 'Gross', render: v => <Money cents={v} /> },
                  { key: 'net_cents', label: 'Net', render: v => <Money cents={v} /> },
                ]}
              />
            </Card>

            <Card 
              title="Package Mix" 
              icon={Package}
              onExport={() => handleExport('packageMix')}
            >
              <Table
                rows={pkgMix}
                cols={[
                  { key: 'package_name', label: 'Package' },
                  { key: 'orders', label: 'Orders' },
                  { key: 'gross_cents', label: 'Revenue', render: v => <Money cents={v} /> },
                ]}
              />
            </Card>
          </div>

          <Card 
            title="Add-On Sales" 
            icon={Package}
            onExport={() => handleExport('addonSales')}
          >
            <Table
              rows={addons}
              cols={[
                { key: 'label', label: 'Add-On' },
                { key: 'qty', label: 'Quantity' },
                { key: 'total_cents', label: 'Total Revenue', render: v => <Money cents={v} /> },
              ]}
            />
          </Card>

          {/* Employee Reports */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(400px, 1fr))", gap: "24px" }}>
            <Card 
              title="Timesheet Detail" 
              icon={Clock}
              onExport={() => handleExport('timesheet')}
            >
              <Table
                rows={timesheet.slice(0, 10)}
                cols={[
                  { key: 'employee_name', label: 'Employee' },
                  { key: 'start_local', label: 'Start', render: v => new Date(v).toLocaleString() },
                  { key: 'hours', label: 'Hours', render: v => v.toFixed(2) },
                  { key: 'pay_cents', label: 'Pay', render: v => <Money cents={v} /> },
                ]}
              />
              {timesheet.length > 10 && (
                <div style={{ marginTop: "12px", textAlign: "center", fontSize: "13px", color: "#64748b" }}>
                  Showing 10 of {timesheet.length} entries
                </div>
              )}
            </Card>

            <Card 
              title="Payroll Summary (Weekly)" 
              icon={Users}
              onExport={() => handleExport('payrollSummary')}
            >
              <Table
                rows={payroll}
                cols={[
                  { key: 'week_start', label: 'Week' },
                  { key: 'employee_name', label: 'Employee' },
                  { key: 'hours', label: 'Hours', render: v => v.toFixed(2) },
                  { key: 'pay_cents', label: 'Pay', render: v => <Money cents={v} /> },
                ]}
              />
            </Card>
          </div>

          {/* Operations Reports */}
          <Card 
            title="Setup Pull Sheets" 
            icon={Calendar}
            onExport={() => handleExport('setupPulls')}
          >
            <Table
              rows={pulls}
              cols={[
                { key: 'service_date', label: 'Date' },
                { key: 'park_name', label: 'Park' },
                { key: 'field_name', label: 'Field' },
                { key: 'spot', label: 'Spot' },
                { key: 'customer_name', label: 'Customer' },
                { key: 'package_name', label: 'Package' },
                { key: 'status', label: 'Status' },
              ]}
            />
          </Card>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(400px, 1fr))", gap: "24px" }}>
            <Card 
              title="Utilization by Park & Day" 
              icon={TrendingUp}
              onExport={() => handleExport('utilizationByParkDay')}
            >
              <Table
                rows={util}
                cols={[
                  { key: 'day', label: 'Date' },
                  { key: 'park_name', label: 'Park' },
                  { key: 'bookings_count', label: 'Bookings' },
                  { key: 'capacity_estimate', label: 'Capacity' },
                ]}
              />
            </Card>

            <Card 
              title="Customer Lifetime Value" 
              icon={Users}
              onExport={() => handleExport('customerLtv')}
            >
              <Table
                rows={ltv.slice(0, 10)}
                cols={[
                  { key: 'customer_email', label: 'Customer' },
                  { key: 'orders', label: 'Orders' },
                  { key: 'gross_cents', label: 'Total', render: v => <Money cents={v} /> },
                ]}
              />
              {ltv.length > 10 && (
                <div style={{ marginTop: "12px", textAlign: "center", fontSize: "13px", color: "#64748b" }}>
                  Showing top 10 of {ltv.length} customers
                </div>
              )}
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}