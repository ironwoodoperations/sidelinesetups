
import React, { useState, useEffect } from "react";
import { getCtx } from "../components/lib/ctx";
import {
  ArrowRight,
  Shield,
  Star,
  RockingChair,
  Loader2
} from "lucide-react";

export default function Home() {
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const { settings: fetchedSettings } = await getCtx();
        setSettings(fetchedSettings || {});
      } catch (error) {
        console.error("Could not load site settings.", error);
        setSettings({});
      } finally {
        setLoading(false);
      }
    };

    fetchSettings();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin" size={48} />
      </div>
    );
  }

  const fallbackImages = {
    softball: "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/eb3b03633_brandon-mowinkel-3_JwPJwq6CI-unsplash.jpg",
    baseball: "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/96e85a991_mike-bowman-xKShyIiTNJk-unsplash.jpg",
    soccer: "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/fc0a60797_vikram-tkv-JO19K0HDDXI-unsplash.jpg",
  };

  const defaultPageBackgroundPattern = "linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.92)), url('https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/c08b7e9db_generated-image.jpg')";

  // Changed heroBackgroundImage URL
  const heroBackgroundImage = "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/c08b7e9db_generated-image.jpg";

  const brandName = settings?.brandName || "Sideline Setups";
  const supportEmail = settings?.supportEmail || "support@sidelinesetups.com";

  const primaryBtnStyle = {
    background: 'linear-gradient(to right, #003f5c, #00507a)',
    color: 'white',
    border: 'none',
    borderRadius: '9999px',
    padding: '1rem 2rem',
    fontSize: '1.125rem',
    fontWeight: '600',
    textDecoration: 'none',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    transition: 'all 0.2s ease-in-out',
  };

  const outlineBtnStyle = {
    background: 'transparent',
    color: '#003f5c',
    border: '2px solid #003f5c',
    borderRadius: '9999px',
    padding: '1rem 2rem',
    fontSize: '1.125rem',
    fontWeight: '600',
    textDecoration: 'none',
    transition: 'all 0.2s ease-in-out',
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section with Background Image */}
      <section
        className="relative bg-cover bg-center text-white"
        style={{
          minHeight: '375px',
          backgroundImage: `url('${heroBackgroundImage}')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          position: 'relative',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}
      >
        {/* Dark overlay */}
        <div style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          zIndex: 1
        }}></div>

        <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
          {settings?.logoUrl && (
            <img
              src={settings.logoUrl}
              alt={settings?.brandName || "Sideline Setups"}
              style={{
                maxWidth: '200px',
                height: 'auto',
                margin: '0 auto 2rem auto',
                display: 'block',
                filter: 'drop-shadow(0 4px 6px rgba(0, 0, 0, 0.3))'
              }}
            />
          )}

          <h1
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold mb-6 leading-tight"
            style={{
              color: 'white',
              textShadow: '0 2px 4px rgba(0,0,0,0.1)'
            }}
          >
            GAME DAY, WITHOUT THE HAUL
          </h1>

          <p className="text-xl sm:text-2xl md:text-3xl mb-8 leading-relaxed" style={{ color: 'white' }}>
            Your shade, chairs, fans, and coolers<br />
            ready when you arrive
          </p>

          <p className="text-lg sm:text-xl mb-10 max-w-2xl mx-auto" style={{ color: 'white' }}>
            Skip the packing, skip the sweat.<br />
            Just show up, watch, and go home
          </p>

          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <a
              href="/events"
              className="btn"
              style={{
                background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
                color: 'white',
                padding: '16px 40px',
                fontSize: '1.25rem',
                fontWeight: '700',
                borderRadius: '9999px',
                textDecoration: 'none',
                display: 'inline-block',
                boxShadow: '0 4px 14px rgba(0, 63, 92, 0.4)',
                transition: 'all 0.3s',
                border: 'none'
              }}
            >
              Get Your Setup Started
            </a>
            <a
              href="/packages"
              className="btn-outline"
              style={{
                background: 'rgba(255, 255, 255, 0.9)',
                color: '#003f5c',
                border: '2px solid white',
                padding: '16px 40px',
                fontSize: '1.25rem',
                fontWeight: '700',
                borderRadius: '9999px',
                textDecoration: 'none',
                display: 'inline-block',
                boxShadow: '0 4px 14px rgba(0, 0, 0, 0.2)',
                transition: 'all 0.3s'
              }}
            >
              View Our Packages
            </a>
          </div>
        </div>
      </section>

      {/* Why Choose Section */}
      <section
        className="py-16 sm:py-24 px-4"
        style={{
          backgroundImage: settings?.pageBackgroundPatternUrl 
            ? `linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.92)), url('${settings.pageBackgroundPatternUrl}')`
            : defaultPageBackgroundPattern,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      >
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4" style={{ color: '#003f5c' }}>
              Why Sports Parents Choose {brandName}
            </h2>
            <p className="text-lg sm:text-xl text-gray-700 max-w-3xl mx-auto">
              Tournament weekends are long enough. Let us handle the setup so you can focus on what matters — your athlete.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Benefit 1 */}
            <div
              className="bg-white rounded-2xl p-8 text-center"
              style={{
                boxShadow: '0 10px 30px rgba(0, 0, 0, 0.08)',
                border: '1px solid rgba(0, 63, 92, 0.1)',
                transition: 'transform 0.3s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-8px)';
                e.currentTarget.style.boxShadow = '0 20px 40px rgba(0, 63, 92, 0.15)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.08)';
              }}
            >
              <div
                style={{
                  background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
                  width: '80px',
                  height: '80px',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 1.5rem'
                }}
              >
                <Shield size={40} color="white" />
              </div>
              <h3 className="text-2xl font-bold mb-3" style={{ color: '#003f5c' }}>
                Arrive Ready
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Your tent, chairs, and cooler are set up before you arrive. Walk straight to your spot — no hauling, no stress.
              </p>
            </div>

            {/* Benefit 2 */}
            <div
              className="bg-white rounded-2xl p-8 text-center"
              style={{
                boxShadow: '0 10px 30px rgba(0, 0, 0, 0.08)',
                border: '1px solid rgba(0, 63, 92, 0.1)',
                transition: 'transform 0.3s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-8px)';
                e.currentTarget.style.boxShadow = '0 20px 40px rgba(0, 63, 92, 0.15)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.08)';
              }}
            >
              <div
                style={{
                  background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
                  width: '80px',
                  height: '80px',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 1.5rem'
                }}
              >
                <Star size={40} color="white" />
              </div>
              <h3 className="text-2xl font-bold mb-3" style={{ color: '#003f5c' }}>
                Premium Comfort
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Professional-grade 10x10 tents, padded rocker chairs, wheeled coolers, and optional fans. Tournament-day luxury without the work.
              </p>
            </div>

            {/* Benefit 3 */}
            <div
              className="bg-white rounded-2xl p-8 text-center"
              style={{
                boxShadow: '0 10px 30px rgba(0, 0, 0, 0.08)',
                border: '1px solid rgba(0, 63, 92, 0.1)',
                transition: 'transform 0.3s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-8px)';
                e.currentTarget.style.boxShadow = '0 20px 40px rgba(0, 63, 92, 0.15)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.08)';
              }}
            >
              <div
                style={{
                  background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
                  width: '80px',
                  height: '80px',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 1.5rem'
                }}
              >
                <RockingChair size={40} color="white" />
              </div>
              <h3 className="text-2xl font-bold mb-3" style={{ color: '#003f5c' }}>
                Leave When You're Ready
              </h3>
              <p className="text-gray-600 leading-relaxed">
                After the last out, just go. We'll pack everything up. Spend those extra hours celebrating or getting home to rest.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 sm:py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4" style={{ color: '#003f5c' }}>
              How It Works
            </h2>
            <p className="text-lg sm:text-xl text-gray-700 max-w-3xl mx-auto">
              Three simple steps to a stress-free tournament weekend
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="text-center">
              <div
                style={{
                  background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
                  width: '64px',
                  height: '64px',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 1.5rem',
                  fontSize: '28px',
                  fontWeight: '700',
                  color: 'white',
                  boxShadow: '0 4px 12px rgba(0, 63, 92, 0.3)'
                }}
              >
                1
              </div>
              <h3 className="text-xl font-bold mb-3" style={{ color: '#003f5c' }}>
                Book Online
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Select your tournament, choose your package, and reserve your spot. Takes 2 minutes.
              </p>
            </div>

            {/* Step 2 */}
            <div className="text-center">
              <div
                style={{
                  background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
                  width: '64px',
                  height: '64px',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 1.5rem',
                  fontSize: '28px',
                  fontWeight: '700',
                  color: 'white',
                  boxShadow: '0 4px 12px rgba(0, 63, 92, 0.3)'
                }}
              >
                2
              </div>
              <h3 className="text-xl font-bold mb-3" style={{ color: '#003f5c' }}>
                We Set Up
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Arrive at the field to find your tent, chairs, and cooler ready and waiting at your spot.
              </p>
            </div>

            {/* Step 3 */}
            <div className="text-center">
              <div
                style={{
                  background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
                  width: '64px',
                  height: '64px',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 1.5rem',
                  fontSize: '28px',
                  fontWeight: '700',
                  color: 'white',
                  boxShadow: '0 4px 12px rgba(0, 63, 92, 0.3)'
                }}
              >
                3
              </div>
              <h3 className="text-xl font-bold mb-3" style={{ color: '#003f5c' }}>
                Enjoy & Go
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Watch the games in comfort. When you're done, just leave — we'll handle the rest.
              </p>
            </div>
          </div>

          <div className="text-center mt-12">
            <a
              href="/events"
              className="btn"
              style={{
                ...primaryBtnStyle,
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                padding: '1rem 2.5rem',
                fontSize: '1.125rem'
              }}
            >
              Book Your Setup Now
              <ArrowRight size={20} />
            </a>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section
        className="py-16 sm:py-24 px-4"
        style={{
          backgroundImage: settings?.pageBackgroundPatternUrl 
            ? `linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.92)), url('${settings.pageBackgroundPatternUrl}')`
            : defaultPageBackgroundPattern,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      >
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4" style={{ color: '#003f5c' }}>
              What Sports Parents Say
            </h2>
            <p className="text-lg sm:text-xl text-gray-700 max-w-3xl mx-auto">
              Join hundreds of families who've discovered a better way to do tournaments
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <div className="bg-white rounded-2xl p-8" style={{ boxShadow: '0 10px 30px rgba(0, 0, 0, 0.08)' }}>
              <div className="flex items-center gap-1 mb-4">
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
              </div>
              <p className="text-gray-700 mb-4 leading-relaxed italic">
                "Game changer! No more fighting with the tent in the wind or hauling everything back to the car exhausted. Worth every penny."
              </p>
              <div className="font-semibold" style={{ color: '#003f5c' }}>— Sarah M.</div>
              <div className="text-sm text-gray-500">Softball Mom, Dallas</div>
            </div>

            {/* Testimonial 2 */}
            <div className="bg-white rounded-2xl p-8" style={{ boxShadow: '0 10px 30px rgba(0, 0, 0, 0.08)' }}>
              <div className="flex items-center gap-1 mb-4">
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
              </div>
              <p className="text-gray-700 mb-4 leading-relaxed italic">
                "My wife and I actually got to relax and enjoy watching our son play instead of stressing about setup. Can't recommend enough!"
              </p>
              <div className="font-semibold" style={{ color: '#003f5c' }}>— Mike T.</div>
              <div className="text-sm text-gray-500">Baseball Dad, Tyler</div>
            </div>

            {/* Testimonial 3 */}
            <div className="bg-white rounded-2xl p-8" style={{ boxShadow: '0 10px 30px rgba(0, 0, 0, 0.08)' }}>
              <div className="flex items-center gap-1 mb-4">
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
                <Star size={20} fill="#f59e0b" color="#f59e0b" />
              </div>
              <p className="text-gray-700 mb-4 leading-relaxed italic">
                "So convenient! Setup was perfect, chairs were comfy, and leaving after a long day without packing up was amazing. Will use every tournament!"
              </p>
              <div className="font-semibold" style={{ color: '#003f5c' }}>— Jennifer L.</div>
              <div className="text-sm text-gray-500">Soccer Mom, Longview</div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-16 sm:py-24 px-4 bg-white text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6" style={{ color: '#003f5c' }}>
            Ready for a Better Tournament Experience?
          </h2>
          <p className="text-lg sm:text-xl text-gray-700 mb-10 max-w-2xl mx-auto">
            Book your setup now and discover why families across Texas are choosing {brandName} for every game.
          </p>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <a
              href="/events"
              className="btn"
              style={{
                ...primaryBtnStyle,
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                padding: '1rem 2.5rem',
                fontSize: '1.125rem'
              }}
            >
              Book Your Setup Now
              <ArrowRight size={20} />
            </a>
            <a
              href={`mailto:${supportEmail}`}
              className="btn-outline"
              style={{
                ...outlineBtnStyle,
                display: 'inline-block',
                padding: '1rem 2.5rem',
                fontSize: '1.125rem'
              }}
            >
              Contact Us
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
