import React from "react";
import { getCtx } from "../components/lib/ctx";
import { markSetupReady } from "../components/lib/staff";

export default function StaffDay() {
  const [bookings, setBookings] = React.useState([]);
  const [selectedDate, setSelectedDate] = React.useState(new Date().toISOString().slice(0, 10));

  async function loadBookings() {
    const { entities } = await getCtx();
    const rows = await entities.Bookings.filter({ date: selectedDate });
    setBookings(rows || []);
  }

  React.useEffect(() => {
    loadBookings();
  }, [selectedDate]);

  async function onMarkReady(bookingId) {
    await markSetupReady(bookingId, "staff-user", "Setup complete");
    alert("Marked ready!");
    loadBookings();
  }

  async function onPackingSlip(booking) {
    alert("Packing slip feature coming soon");
  }

  return (
    <>
      <div className="nav">
        <div className="container nav-inner">
          <a className="brand" href="/">
            <span className="badge">SS</span>
            <span>Sideline Setups</span>
          </a>
          <div className="nav-links">
            <a className="btn-ghost" href="/staffday">Staff Day</a>
            <a className="btn-ghost" href="/admindashboard">Admin</a>
          </div>
        </div>
      </div>

      <div className="container section">
        <h1>Staff Dashboard</h1>

        <div className="card card-pad" style={{ marginTop: 24 }}>
          <label className="label">Select Date</label>
          <input
            className="input"
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
          />
        </div>

        <div className="grid grid-2" style={{ marginTop: 24, gap: 16 }}>
          {bookings.map((b) => (
            <div className="card card-pad" key={b.id}>
              <h3>{b.fullName} — {b.teamName || "Team"}</h3>
              <div style={{ color: "var(--muted)", fontSize: 14, marginTop: 4 }}>
                {b.date} • {(Array.isArray(b.gameTimes) ? b.gameTimes.join(", ") : b.gameTimes) || "TBD"}
              </div>
              <div style={{ marginTop: 8 }}>
                <span className="badge">{b.status}</span>
              </div>
              <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
                <button className="btn" onClick={() => onMarkReady(b.id)}>
                  Mark Ready
                </button>
                <button className="btn-outline" onClick={() => onPackingSlip(b)}>
                  Print Packing Slip
                </button>
              </div>
            </div>
          ))}
          {bookings.length === 0 && (
            <div className="card card-pad">
              <p style={{ color: "var(--muted)" }}>No bookings for this date.</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}