
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, FileText, Mail, ExternalLink, CheckCircle, CheckCircle2 } from "lucide-react";
import LineItemsTable from "../components/LineItemsTable";

// 12-hour time formatter - MADE MORE DEFENSIVE
function fmt12h(timeStr) {
  if (!timeStr || typeof timeStr !== 'string') return "";
  
  const parts = timeStr.split(":");
  if (parts.length !== 2) return timeStr; // Return original if not in HH:mm format
  
  const hh = parseInt(parts[0], 10);
  const mm = parseInt(parts[1], 10);
  
  if (isNaN(hh) || isNaN(mm)) return timeStr; // Return original if not valid numbers
  
  const ampm = hh >= 12 ? "PM" : "AM";
  const hour = ((hh + 11) % 12) + 1;
  return `${hour}:${mm.toString().padStart(2, "0")} ${ampm}`;
}

export default function ThankYou() {
  const [booking, setBooking] = useState(null);
  const [event, setEvent] = useState(null);
  const [park, setPark] = useState(null);
  const [field, setField] = useState(null);
  const [spot, setSpot] = useState(null);
  const [packageData, setPackageData] = useState(null);
  const [packageEquipment, setPackageEquipment] = useState([]);
  const [loading, setLoading] = useState(true);
  // Removed downloading state as it's no longer needed for window.print()
  const [resendingEmail, setResendingEmail] = useState(false);
  const [showBackButton, setShowBackButton] = useState(false);

  useEffect(() => {
    // Check if user came from mybookings
    const params = new URLSearchParams(window.location.search);
    const fromMyBookings = params.get("from") === "mybookings" || document.referrer.includes("/mybookings");
    setShowBackButton(fromMyBookings);
    
    loadBooking();
  }, []);

  async function loadBooking() {
    try {
      const params = new URLSearchParams(window.location.search);
      const bookingId = params.get("b");
      
      if (!bookingId) {
        alert("No booking ID provided");
        setLoading(false);
        return;
      }

      // Fetch all booking details via backend function
      const response = await base44.functions.invoke('getBookingDetails', {
        bookingId
      });

      const data = response.data;
      
      if (!data.success) {
        throw new Error(data.error || 'Failed to load booking');
      }

      setBooking(data.booking);
      setEvent(data.event);
      setPark(data.park);
      setField(data.field);
      setSpot(data.spot);
      setPackageData(data.packageData);
      setPackageEquipment(data.packageEquipment || []);

    } catch (error) {
      console.error("Failed to load booking:", error);
      alert("Failed to load booking details");
    } finally {
      setLoading(false);
    }
  }

  // Removed handleDownloadReceipt function as it's no longer used

  async function handleResendEmail() {
    if (!booking) return;
    
    setResendingEmail(true);
    try {
      await base44.functions.invoke('notifyBookingConfirmed', {
        bookingId: booking.id
      });
      alert('✅ Receipt has been emailed to you!');
    } catch (error) {
      console.error("Failed to resend email:", error);
      alert("Failed to send email. Please contact support.");
    } finally {
      setResendingEmail(false);
    }
  }

  if (loading) {
    return (
      <div style={{ 
        minHeight: "60vh", 
        display: "flex", 
        alignItems: "center", 
        justifyContent: "center" 
      }}>
        <Loader2 className="animate-spin" size={48} style={{ color: "#003f5c" }} />
      </div>
    );
  }

  if (!booking) {
    return (
      <div style={{ 
        minHeight: "60vh", 
        display: "flex", 
        alignItems: "center", 
        justifyContent: "center",
        flexDirection: "column",
        gap: "16px"
      }}>
        <h2 style={{ color: "#003f5c" }}>Booking Not Found</h2>
        <a href="/" className="btn">Return Home</a>
      </div>
    );
  }

  // Helper function to get human-readable status
  function getStatusDisplay(status) {
    const statusLabels = {
      'pending': 'Pending',
      'paid': 'Paid',
      'photo_uploaded': 'ID Uploaded',
      'setup': 'Setup Complete',
      'checked_in': 'Checked In',
      'leaving': 'Customer Leaving',
      'picked_up': 'Equipment Picked Up',
      'closed': 'Closed',
      'cancelled': 'Cancelled'
    };
    return statusLabels[status] || status;
  }

  // Format values
  const dateStr = booking.date 
    ? new Date(booking.date).toLocaleDateString('en-US', { 
        weekday: 'long', 
        month: 'long', 
        day: 'numeric', 
        year: 'numeric' 
      })
    : 'TBD';

  const gameTimesStr = (booking.gameTimes && booking.gameTimes.length > 0)
    ? booking.gameTimes.map(t => fmt12h(t)).join(', ')
    : 'TBD';

  const totalCents = booking.totalCents || 0;
  const totalAmount = `$${(totalCents / 100).toFixed(2)}`;

  // Filter out system messages from notes for display
  const cleanNotes = booking.notes
    ? booking.notes
        .split('\n')
        .filter(line => !line.includes('[SYSTEM]') && !line.includes('Warning:') && !line.includes('Inventory allocation'))
        .join('\n')
        .trim()
    : '';

  const phoneNumberRaw = "9035419287"; // Your support number (unformatted for tel/sms links)
  const formattedPhoneNumberDisplay = "(903) 541-9287"; // Formatted for visible text
  const supportEmail = "support@sideline-setups.com";
  const textMessage = encodeURIComponent(`Hi! I have a question about booking ${booking.id}`);

  // Generate QR code URL
  const siteDomain = window.location.origin;
  const qrUrl = `${siteDomain}/checkin?b=${encodeURIComponent(booking.id)}`;
  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(qrUrl)}`;

  // Pre-fill email for update booking info
  const updateEmailSubject = `Update Booking Info - ${booking.id}`;
  const updateEmailBody = `Hi Sideline Setups Team,

I need to update my booking information:

Booking ID: ${booking.id}
Name: ${booking.fullName || 'N/A'}
Event: ${event?.name || 'N/A'}
Team: ${booking.teamName || 'N/A'}

Please update the following:
[Describe what you need to update]

Thank you!`;

  const updateEmailLink = `mailto:scott@sideline-setups.com?subject=${encodeURIComponent(updateEmailSubject)}&body=${encodeURIComponent(updateEmailBody)}`;

  // Check if ID upload is needed
  const needsIdUpload = !booking.idPhotoUri && !booking.idSkipApprovedBy;
  const idUploadUrl = `${siteDomain}/checkin?b=${encodeURIComponent(booking.id)}`;

  return (
    <div style={{ 
      minHeight: "60vh", 
      padding: "40px 20px",
      maxWidth: "900px",
      margin: "0 auto"
    }}>
      {/* Back Button - Only shown when coming from My Bookings */}
      {showBackButton && (
        <div style={{ marginBottom: "20px" }}>
          <a 
            href="/mybookings"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "8px",
              padding: "10px 16px",
              background: "white",
              border: "2px solid #e2e8f0",
              borderRadius: "8px",
              color: "#003f5c",
              textDecoration: "none",
              fontSize: "14px",
              fontWeight: "600",
              transition: "all 0.2s"
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = "#f8fafc";
              e.currentTarget.style.borderColor = "#003f5c";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = "white";
              e.currentTarget.style.borderColor = "#e2e8f0";
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            Back to My Bookings
          </a>
        </div>
      )}

      {/* Success Header */}
      <div style={{
        background: "linear-gradient(135deg, #10b981 0%, #059669 100%)",
        borderRadius: "16px",
        padding: "40px",
        color: "white",
        textAlign: "center",
        marginBottom: "32px",
        boxShadow: "0 4px 16px rgba(16, 185, 129, 0.2)"
      }}>
        <CheckCircle size={64} style={{ marginBottom: "16px" }} />
        <h1 style={{ fontSize: "32px", fontWeight: "700", margin: "0 0 12px 0" }}>
          Booking Confirmed!
        </h1>
        <p style={{ fontSize: "18px", margin: 0, opacity: 0.95 }}>
          We've sent a confirmation email to {booking.contactEmail}
        </p>
      </div>

      {/* ID Upload Prompt - ONLY if needed */}
      {needsIdUpload && (
        <div style={{
          background: "#fffbeb",
          border: "2px solid #fbbf24",
          borderRadius: "12px",
          padding: "20px",
          marginBottom: "24px",
          textAlign: "center"
        }}>
          <h3 style={{ margin: "0 0 8px 0", color: "#92400e", fontSize: "18px", fontWeight: "600" }}>
            📸 Complete Your Verification
          </h3>
          <p style={{ margin: "0 0 16px 0", color: "#78350f", fontSize: "14px", lineHeight: "1.6" }}>
            To ensure a smooth check-in experience, please upload a photo of your ID. 
            Your image will be securely stored and automatically deleted 48 hours after your booking is completed.
          </p>
          <a 
            href={idUploadUrl}
            className="btn"
            style={{ 
              display: "inline-block",
              textDecoration: "none"
            }}
          >
            Upload ID Now
          </a>
        </div>
      )}

      {/* Action Buttons */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
        gap: "16px",
        marginBottom: "32px"
      }}>
        <button
          onClick={() => window.print()}
          style={{
            padding: '16px',
            background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
            color: 'white',
            border: 'none',
            borderRadius: '12px',
            fontSize: '16px',
            fontWeight: '600',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px',
            transition: 'all 0.2s'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-2px)';
            e.currentTarget.style.boxShadow = '0 8px 16px rgba(0,63,92,0.3)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.boxShadow = 'none';
          }}
        >
          <FileText size={20} />
          Print Receipt
        </button>

        <button
          onClick={handleResendEmail}
          disabled={resendingEmail}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "8px",
            padding: "14px 20px",
            background: resendingEmail ? "#94a3b8" : "#10b981",
            color: "white",
            border: "none",
            borderRadius: "10px",
            fontSize: "15px",
            fontWeight: "600",
            cursor: resendingEmail ? "not-allowed" : "pointer",
            transition: "all 0.2s",
            opacity: resendingEmail ? 0.6 : 1
          }}
          onMouseEnter={(e) => {
            if (!resendingEmail) e.target.style.transform = "translateY(-2px)";
          }}
          onMouseLeave={(e) => {
            e.target.style.transform = "translateY(0)";
          }}
        >
          {resendingEmail ? (
            <>
              <Loader2 className="animate-spin" size={18} />
              Sending...
            </>
          ) : (
            <>
              <Mail size={18} />
              Email Receipt
            </>
          )}
        </button>

        <a
          href={updateEmailLink}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "8px",
            padding: "14px 20px",
            background: "#f97316",
            color: "white",
            border: "none",
            borderRadius: "10px",
            fontSize: "15px",
            fontWeight: "600",
            textDecoration: "none",
            transition: "all 0.2s"
          }}
          onMouseEnter={(e) => {
            e.target.style.transform = "translateY(-2px)";
            e.target.style.background = "#ea580c";
          }}
          onMouseLeave={(e) => {
            e.target.style.transform = "translateY(0)";
            e.target.style.background = "#f97316";
          }}
        >
          <Mail size={18} />
          Update Booking Info
        </a>

        <a
          href={`sms:${phoneNumberRaw}?&body=${textMessage}`}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "8px",
            padding: "14px 20px",
            background: "#8b5cf6",
            color: "white",
            border: "none",
            borderRadius: "10px",
            fontSize: "15px",
            fontWeight: "600",
            textDecoration: "none",
            transition: "all 0.2s"
          }}
          onMouseEnter={(e) => {
            e.target.style.transform = "translateY(-2px)";
            e.target.style.background = "#7c3aed";
          }}
          onMouseLeave={(e) => {
            e.target.style.transform = "translateY(0)";
            e.target.style.background = "#8b5cf6";
          }}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
          </svg>
          Text Us
        </a>
      </div>

      {/* Booking Details with WHITE title on navy background */}
      <div style={{
        background: "white",
        borderRadius: "12px",
        overflow: "hidden",
        boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
        marginBottom: "24px"
      }}>
        <div style={{
          background: "#003f5c",
          padding: "16px 24px"
        }}>
          <h2 style={{ 
            margin: 0, 
            fontSize: "20px", 
            fontWeight: "700",
            color: "white"
          }}>
            Booking Details
          </h2>
        </div>
        <div style={{ padding: "24px" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <tbody>
              <tr style={{ borderBottom: "1px solid #f1f5f9" }}>
                <td style={{ padding: "12px 0", color: "#64748b", fontWeight: "500" }}>Booking ID:</td>
                <td style={{ padding: "12px 0", color: "#0f172a", fontWeight: "600", wordBreak: "break-all" }}>{booking.id}</td>
              </tr>
              <tr style={{ borderBottom: "1px solid #f1f5f9" }}>
                <td style={{ padding: "12px 0", color: "#64748b", fontWeight: "500" }}>Status:</td>
                <td style={{ padding: "12px 0", color: "#0f172a", fontWeight: "600" }}>{getStatusDisplay(booking.status)}</td>
              </tr>
              <tr style={{ borderBottom: "1px solid #f1f5f9" }}>
                <td style={{ padding: "12px 0", color: "#64748b", fontWeight: "500" }}>Event:</td>
                <td style={{ padding: "12px 0", color: "#0f172a", fontWeight: "600" }}>
                  {event?.name || "TBD"}
                  {event?.website && (
                    <a 
                      href={event.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      style={{
                        fontSize: "14px",
                        color: "#003f5c",
                        textDecoration: "none",
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "4px",
                        marginLeft: "8px",
                        fontWeight: "normal"
                      }}
                    >
                      <ExternalLink size={14} />
                    </a>
                  )}
                </td>
              </tr>
              <tr style={{ borderBottom: "1px solid #f1f5f9" }}>
                <td style={{ padding: "12px 0", color: "#64748b", fontWeight: "500" }}>Date:</td>
                <td style={{ padding: "12px 0", color: "#0f172a", fontWeight: "600" }}>{dateStr}</td>
              </tr>
              {booking.teamName && (
                <tr style={{ borderBottom: "1px solid #f1f5f9" }}>
                  <td style={{ padding: "12px 0", color: "#64748b", fontWeight: "500" }}>Team Name:</td>
                  <td style={{ padding: "12px 0", color: "#0f172a", fontWeight: "600" }}>{booking.teamName}</td>
                </tr>
              )}
              <tr style={{ borderBottom: "1px solid #f1f5f9" }}>
                <td style={{ padding: "12px 0", color: "#64748b", fontWeight: "500" }}>Game Times:</td>
                <td style={{ padding: "12px 0", color: "#0f172a", fontWeight: "600" }}>{gameTimesStr}</td>
              </tr>
              <tr style={{ borderBottom: "1px solid #f1f5f9" }}>
                <td style={{ padding: "12px 0", color: "#64748b", fontWeight: "500" }}>Package:</td>
                <td style={{ padding: "12px 0", color: "#0f172a", fontWeight: "600" }}>{packageData?.name || "Package"}</td>
              </tr>
              <tr style={{ borderBottom: "1px solid #f1f5f9" }}>
                <td style={{ padding: "12px 0", color: "#64748b", fontWeight: "500" }}>Park:</td>
                <td style={{ padding: "12px 0", color: "#0f172a", fontWeight: "600" }}>{park?.name || "TBD"}</td>
              </tr>
              {field && (
                <tr style={{ borderBottom: "1px solid #f1f5f9" }}>
                  <td style={{ padding: "12px 0", color: "#64748b", fontWeight: "500" }}>Field:</td>
                  <td style={{ padding: "12px 0", color: "#0f172a", fontWeight: "600" }}>{field.name}</td>
                </tr>
              )}
              {spot && (
                <tr style={{ borderBottom: "1px solid #f1f5f9" }}>
                  <td style={{ padding: "12px 0", color: "#64748b", fontWeight: "500" }}>Spot:</td>
                  <td style={{ padding: "12px 0", color: "#0f172a", fontWeight: "600" }}>{spot.label}</td>
                </tr>
              )}
              {booking.setupSideLabel && !spot && (
                <tr>
                  <td style={{ padding: "12px 0", color: "#64748b", fontWeight: "500" }}>Setup:</td>
                  <td style={{ padding: "12px 0", color: "#0f172a", fontWeight: "600" }}>{booking.setupSideLabel}</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* NEW SECTION: Your Setup Location Map */}
      {field?.imageUrl && spot && (
        <div style={{
          background: "white",
          borderRadius: "12px",
          overflow: "hidden",
          boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
          marginBottom: "24px"
        }}>
          <div style={{
            background: "#003f5c",
            padding: "16px 24px"
          }}>
            <h2 style={{ 
              margin: 0, 
              fontSize: "20px", 
              fontWeight: "700",
              color: "white"
            }}>
              Your Setup Location
            </h2>
          </div>
          <div style={{ padding: "24px", textAlign: "center" }}>
            <p style={{ marginBottom: "16px", color: "#64748b" }}>
              Here's where we'll set up your package on {field.name}:
            </p>
            <div style={{
              position: "relative",
              maxWidth: "600px",
              margin: "0 auto",
              border: "2px solid #e2e8f0",
              borderRadius: "8px",
              overflow: "hidden",
              background: "#f8fafc"
            }}>
              <img
                src={field.imageUrl}
                alt={field.name}
                style={{ width: "100%", height: "auto", display: "block" }}
              />
              <div style={{
                position: "absolute",
                left: `${spot.x}%`,
                top: `${spot.y}%`,
                transform: "translate(-50%, -50%)",
                width: "40px",
                height: "40px",
                background: "rgba(250, 204, 21, 0.8)",
                border: "3px solid #eab308",
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontWeight: "700",
                fontSize: "12px",
                color: "#713f12",
                boxShadow: "0 4px 12px rgba(0,0,0,0.3)",
                zIndex: 10
              }}>
                {spot.label}
              </div>
            </div>
            <p style={{ marginTop: "16px", fontSize: "14px", color: "#003f5c", fontWeight: "600" }}>
              Spot: {spot.label}
            </p>
          </div>
        </div>
      )}

      {/* Package Features with WHITE title */}
      {packageData && packageData.features && packageData.features.length > 0 && (
        <div style={{
          background: "white",
          borderRadius: "12px",
          overflow: "hidden",
          boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
          marginBottom: "24px"
        }}>
          <div style={{
            background: "#003f5c",
            padding: "16px 24px"
          }}>
            <h2 style={{ 
              margin: 0, 
              fontSize: "20px", 
              fontWeight: "700",
              color: "white"
            }}>
              Included with {packageData.name}
            </h2>
          </div>
          <div style={{ padding: "24px" }}>
            <ul style={{ 
              listStyle: "none", 
              padding: 0, 
              margin: 0,
              display: "grid",
              gap: "12px"
            }}>
              {packageData.features.map((feature, idx) => (
                <li key={idx} style={{ 
                  display: "flex", 
                  alignItems: "start", 
                  gap: "12px",
                  padding: "12px",
                  background: "#f8fafc",
                  borderRadius: "8px"
                }}>
                  <CheckCircle2 size={20} style={{ color: "#10b981", flexShrink: 0, marginTop: "2px" }} />
                  <span style={{ color: "#0f172a", fontSize: "15px" }}>{feature}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Order Summary with WHITE title */}
      {booking.lineItemsJson && booking.lineItemsJson.length > 0 && (
        <div style={{
          background: "white",
          borderRadius: "12px",
          overflow: "hidden",
          boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
          marginBottom: "24px"
        }}>
          <div style={{
            background: "#003f5c",
            padding: "16px 24px"
          }}>
            <h2 style={{ 
              margin: 0, 
              fontSize: "20px", 
              fontWeight: "700",
              color: "white"
            }}>
              Order Summary
            </h2>
          </div>
          <div style={{ padding: "24px" }}>
            <LineItemsTable
              items={booking.lineItemsJson || []}
              baseCents={booking.baseCents}
              addOnCents={booking.addOnCents}
              totalCents={booking.totalCents}
            />
          </div>
        </div>
      )}

      {/* Special Instructions */}
      {cleanNotes && (
        <div style={{
          background: "white",
          borderRadius: "12px",
          padding: "24px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
          marginBottom: "24px",
          overflow: "hidden"
        }}>
          <h3 style={{ margin: "0 0 12px 0", color: "#003f5c", fontSize: "18px", fontWeight: "600" }}>
            Special Instructions
          </h3>
          <p style={{ margin: 0, color: "#64748b", whiteSpace: "pre-wrap" }}>
            {cleanNotes}
          </p>
        </div>
      )}

      {/* Check-In QR Code with WHITE title */}
      <div style={{
        background: "white",
        borderRadius: "12px",
        overflow: "hidden",
        boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
        marginBottom: "24px"
      }}>
        <div style={{
          background: "#003f5c",
          padding: "16px 24px"
        }}>
          <h2 style={{ 
            margin: 0, 
            fontSize: "20px", 
            fontWeight: "700",
            color: "white"
          }}>
            Check-In QR Code
          </h2>
        </div>
        <div style={{ padding: "24px", textAlign: "center" }}>
          <p style={{ marginBottom: "16px", color: "#64748b" }}>
            Show this QR code to staff when you arrive for quick check-in:
          </p>
          <img
            src={qrImageUrl}
            alt="Check-in QR Code"
            style={{
              maxWidth: "200px",
              height: "auto",
              margin: "0 auto",
              border: "2px solid #e2e8f0",
              borderRadius: "8px",
              padding: "8px",
              background: "white"
            }}
          />
          <p style={{ 
            marginTop: "16px", 
            fontSize: "12px", 
            color: "#94a3b8"
          }}>
            Or visit: <a href={qrUrl} target="_blank" rel="noopener noreferrer" style={{ color: "#003f5c", textDecoration: "none", fontWeight: "600" }}>sideline-setups.com/checkin?b={booking.id.substring(0, 8)}</a>
          </p>
        </div>
      </div>

      {/* What's Next - Enhanced with integrated messaging */}
      <div style={{
        background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
        color: "white",
        borderRadius: "12px",
        padding: "32px",
        marginBottom: "32px",
        boxShadow: "0 4px 16px rgba(0,63,92,0.2)"
      }}>
        <h2 style={{ margin: "0 0 24px 0", fontSize: "24px", fontWeight: "700", color: "white" }}>
          What's Next?
        </h2>
        <div style={{ display: "grid", gap: "20px" }}>
          <div style={{ display: "flex", gap: "16px", alignItems: "start" }}>
            <div style={{
              background: "rgba(255, 255, 255, 0.2)",
              borderRadius: "50%",
              width: "40px",
              height: "40px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
              fontWeight: "700",
              fontSize: "18px",
              color: "white"
            }}>
              1
            </div>
            <div>
              <h3 style={{ margin: "0 0 8px 0", fontSize: "18px", fontWeight: "600", color: "white" }}>
                We'll Keep You Updated
              </h3>
              <p style={{ margin: 0, opacity: 0.95, lineHeight: "1.6", color: "white" }}>
                You'll receive a reminder email 24 hours before your event with all the important details and setup information.
              </p>
            </div>
          </div>

          <div style={{ display: "flex", gap: "16px", alignItems: "start" }}>
            <div style={{
              background: "rgba(255, 255, 255, 0.2)",
              borderRadius: "50%",
              width: "40px",
              height: "40px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
              fontWeight: "700",
              fontSize: "18px",
              color: "white"
            }}>
              2
            </div>
            <div>
              <h3 style={{ margin: "0 0 8px 0", fontSize: "18px", fontWeight: "600", color: "white" }}>
                Your Setup Will Be Ready
              </h3>
              <p style={{ margin: 0, opacity: 0.95, lineHeight: "1.6", color: "white" }}>
                Our team will arrive early to set everything up. We'll send you a text message when your setup is complete and ready for you to use. Just show up and enjoy!
              </p>
            </div>
          </div>

          <div style={{ display: "flex", gap: "16px", alignItems: "start" }}>
            <div style={{
              background: "rgba(255, 255, 255, 0.2)",
              borderRadius: "50%",
              width: "40px",
              height: "40px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
              fontWeight: "700",
              fontSize: "18px",
              color: "white"
            }}>
              3
            </div>
            <div>
              <h3 style={{ margin: "0 0 8px 0", fontSize: "18px", fontWeight: "600", color: "white" }}>
                When You're Heading Out
              </h3>
              <p style={{ margin: 0, opacity: 0.95, lineHeight: "1.6", color: "white" }}>
                When you're finished and leaving, just send us a quick text at{" "}
                <a 
                  href={`tel:${phoneNumberRaw}`}
                  style={{ 
                    color: "white", 
                    textDecoration: "underline",
                    fontWeight: "600"
                  }}
                >
                  {formattedPhoneNumberDisplay}
                </a>
                {" "}so we can come break down your setup. Easy as that!
              </p>
            </div>
          </div>

          <div style={{ display: "flex", gap: "16px", alignItems: "start" }}>
            <div style={{
              background: "rgba(255, 255, 255, 0.2)",
              borderRadius: "50%",
              width: "40px",
              height: "40px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
              fontWeight: "700",
              fontSize: "18px",
              color: "white"
            }}>
              4
            </div>
            <div>
              <h3 style={{ margin: "0 0 8px 0", fontSize: "18px", fontWeight: "600", color: "white" }}>
                Questions or Changes?
              </h3>
              <p style={{ margin: 0, opacity: 0.95, lineHeight: "1.6", color: "white" }}>
                Need to update your booking or have questions? Call or text us at{" "}
                <a 
                  href={`tel:${phoneNumberRaw}`}
                  style={{ 
                    color: "white", 
                    textDecoration: "underline",
                    fontWeight: "600"
                  }}
                >
                  {formattedPhoneNumberDisplay}
                </a>
                {" "}or email{" "}
                <a 
                  href={`mailto:${supportEmail}`}
                  style={{ 
                    color: "white", 
                    textDecoration: "underline",
                    fontWeight: "600"
                  }}
                >
                  {supportEmail}
                </a>
                . We're here to help!
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div style={{
        textAlign: "center",
        padding: "24px",
        borderTop: "1px solid #e2e8f0",
        color: "#64748b",
        fontSize: "14px"
      }}>
        <p style={{ margin: "0 0 8px 0" }}>
          Questions? Contact us at{" "}
          <a href={`mailto:${supportEmail}`} style={{ color: "#003f5c", textDecoration: "none", fontWeight: "600" }}>
            {supportEmail}
          </a>
          {" "}or{" "}
          <a href={`tel:${phoneNumberRaw}`} style={{ color: "#003f5c", textDecoration: "none", fontWeight: "600" }}>
            {formattedPhoneNumberDisplay}
          </a>
        </p>
        <p style={{ margin: 0 }}>
          Thank you for choosing Sideline Setups!
        </p>
      </div>
    </div>
  );
}
