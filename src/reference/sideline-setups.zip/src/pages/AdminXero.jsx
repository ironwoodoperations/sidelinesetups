import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Download, Upload, CheckCircle, AlertCircle, ExternalLink } from "lucide-react";

export default function AdminXero() {
  const [bookings, setBookings] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pushing, setPushing] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [message, setMessage] = useState(null);
  
  // Filters
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [selectedEvent, setSelectedEvent] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("confirmed");
  
  // Selection
  const [selectedBookings, setSelectedBookings] = useState(new Set());

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    try {
      const [bookingsData, eventsData] = await Promise.all([
        base44.entities.Bookings.list("-created_date"),
        base44.entities.Events.list()
      ]);
      
      setBookings(bookingsData || []);
      setEvents(eventsData || []);
    } catch (error) {
      console.error("Failed to load data:", error);
      setMessage({ type: "error", text: "Failed to load data: " + error.message });
    } finally {
      setLoading(false);
    }
  }

  async function handlePushToXero() {
    if (selectedBookings.size === 0) {
      setMessage({ type: "error", text: "Please select at least one booking" });
      return;
    }

    if (!confirm(`Push ${selectedBookings.size} booking(s) to Xero?`)) {
      return;
    }

    setPushing(true);
    setMessage(null);

    try {
      // Get account mappings from settings
      const settings = (await base44.entities.SiteSettings.list())[0] || {};
      const accountMapping = settings.xeroAccountMappings || {};

      const response = await base44.functions.invoke('xeroPush', {
        bookingIds: Array.from(selectedBookings),
        accountMapping
      });

      if (response.data.ok) {
        setMessage({ 
          type: "success", 
          text: `Successfully created ${response.data.count} invoice(s) in Xero!` 
        });
        setSelectedBookings(new Set());
        await loadData(); // Reload to show updated Xero IDs
      } else {
        setMessage({ 
          type: "error", 
          text: "Failed to push to Xero: " + (response.data.error || "Unknown error") 
        });
      }
    } catch (error) {
      console.error("Push to Xero error:", error);
      setMessage({ 
        type: "error", 
        text: "Failed to push to Xero: " + error.message 
      });
    } finally {
      setPushing(false);
    }
  }

  async function handleExportCsv() {
    if (selectedBookings.size === 0) {
      setMessage({ type: "error", text: "Please select at least one booking" });
      return;
    }

    setExporting(true);
    setMessage(null);

    try {
      const bookingIdsParam = Array.from(selectedBookings).join(',');
      const response = await fetch(
        `/api/functions/xeroExportCsv?bookingIds=${encodeURIComponent(bookingIdsParam)}`
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `xero-invoices-${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      setMessage({ type: "success", text: "CSV exported successfully!" });
    } catch (error) {
      console.error("Export CSV error:", error);
      setMessage({ type: "error", text: "Failed to export CSV: " + error.message });
    } finally {
      setExporting(false);
    }
  }

  function toggleBooking(bookingId) {
    const newSelected = new Set(selectedBookings);
    if (newSelected.has(bookingId)) {
      newSelected.delete(bookingId);
    } else {
      newSelected.add(bookingId);
    }
    setSelectedBookings(newSelected);
  }

  function toggleAll() {
    if (selectedBookings.size === filteredBookings.length) {
      setSelectedBookings(new Set());
    } else {
      setSelectedBookings(new Set(filteredBookings.map(b => b.id)));
    }
  }

  // Filter bookings
  const filteredBookings = bookings.filter(booking => {
    const dateMatch = (!fromDate || booking.date >= fromDate) && (!toDate || booking.date <= toDate);
    const eventMatch = selectedEvent === "all" || booking.eventId === selectedEvent;
    const statusMatch = selectedStatus === "all" || booking.status === selectedStatus;
    return dateMatch && eventMatch && statusMatch && !booking.archived;
  });

  const selectedTotal = Array.from(selectedBookings)
    .map(id => bookings.find(b => b.id === id))
    .filter(Boolean)
    .reduce((sum, b) => sum + (b.totalCents || 0), 0);

  if (loading) {
    return (
      <div style={{ padding: "40px", textAlign: "center" }}>
        <div className="spinner"></div>
        <p style={{ marginTop: "16px", color: "#64748b" }}>Loading bookings...</p>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: "24px" }}>
        <h2 style={{ margin: "0 0 8px 0", fontSize: "24px", fontWeight: "700", color: "#003f5c" }}>
          Xero Integration
        </h2>
        <p style={{ margin: 0, color: "#64748b", fontSize: "14px" }}>
          Push invoices to Xero or export as CSV for manual import
        </p>
      </div>

      {/* Message */}
      {message && (
        <div style={{
          padding: "16px",
          marginBottom: "24px",
          borderRadius: "8px",
          background: message.type === "success" ? "#d1fae5" : "#fee2e2",
          color: message.type === "success" ? "#065f46" : "#991b1b",
          border: `1px solid ${message.type === "success" ? "#10b981" : "#ef4444"}`
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            {message.type === "success" ? <CheckCircle size={20} /> : <AlertCircle size={20} />}
            <span>{message.text}</span>
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div style={{
        background: "white",
        borderRadius: "12px",
        border: "1px solid #e2e8f0",
        padding: "20px",
        marginBottom: "24px"
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "16px" }}>
          <div>
            <div style={{ fontSize: "14px", color: "#64748b", marginBottom: "4px" }}>
              {selectedBookings.size} booking(s) selected
            </div>
            <div style={{ fontSize: "20px", fontWeight: "700", color: "#003f5c" }}>
              Total: ${(selectedTotal / 100).toFixed(2)}
            </div>
          </div>
          <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" }}>
            <button
              onClick={handlePushToXero}
              disabled={selectedBookings.size === 0 || pushing}
              style={{
                padding: "10px 20px",
                background: selectedBookings.size === 0 || pushing ? "#94a3b8" : "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
                color: "white",
                border: "none",
                borderRadius: "8px",
                fontSize: "14px",
                fontWeight: "600",
                cursor: selectedBookings.size === 0 || pushing ? "not-allowed" : "pointer",
                display: "flex",
                alignItems: "center",
                gap: "8px"
              }}
            >
              <Upload size={16} />
              {pushing ? "Pushing..." : "Push to Xero"}
            </button>
            <button
              onClick={handleExportCsv}
              disabled={selectedBookings.size === 0 || exporting}
              style={{
                padding: "10px 20px",
                background: "white",
                color: "#003f5c",
                border: "1px solid #003f5c",
                borderRadius: "8px",
                fontSize: "14px",
                fontWeight: "600",
                cursor: selectedBookings.size === 0 || exporting ? "not-allowed" : "pointer",
                opacity: selectedBookings.size === 0 || exporting ? 0.5 : 1,
                display: "flex",
                alignItems: "center",
                gap: "8px"
              }}
            >
              <Download size={16} />
              {exporting ? "Exporting..." : "Export CSV"}
            </button>
            <a
              href="/admin-xero-mapping"
              style={{
                padding: "10px 20px",
                background: "white",
                color: "#64748b",
                border: "1px solid #e2e8f0",
                borderRadius: "8px",
                fontSize: "14px",
                fontWeight: "600",
                textDecoration: "none",
                display: "flex",
                alignItems: "center",
                gap: "8px"
              }}
            >
              Account Mapping
            </a>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div style={{
        background: "white",
        borderRadius: "12px",
        border: "1px solid #e2e8f0",
        padding: "20px",
        marginBottom: "24px"
      }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "16px" }}>
          <div>
            <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", fontWeight: "600", color: "#64748b" }}>
              From Date
            </label>
            <input
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              style={{ width: "100%", padding: "8px 12px", border: "1px solid #e2e8f0", borderRadius: "6px", fontSize: "14px" }}
            />
          </div>
          <div>
            <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", fontWeight: "600", color: "#64748b" }}>
              To Date
            </label>
            <input
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              style={{ width: "100%", padding: "8px 12px", border: "1px solid #e2e8f0", borderRadius: "6px", fontSize: "14px" }}
            />
          </div>
          <div>
            <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", fontWeight: "600", color: "#64748b" }}>
              Event
            </label>
            <select
              value={selectedEvent}
              onChange={(e) => setSelectedEvent(e.target.value)}
              style={{ width: "100%", padding: "8px 12px", border: "1px solid #e2e8f0", borderRadius: "6px", fontSize: "14px" }}
            >
              <option value="all">All Events</option>
              {events.map(event => (
                <option key={event.id} value={event.id}>{event.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", fontWeight: "600", color: "#64748b" }}>
              Status
            </label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              style={{ width: "100%", padding: "8px 12px", border: "1px solid #e2e8f0", borderRadius: "6px", fontSize: "14px" }}
            >
              <option value="all">All Status</option>
              <option value="confirmed">Confirmed</option>
              <option value="setup">Setup</option>
              <option value="completed">Completed</option>
              <option value="returned">Returned</option>
              <option value="closed">Closed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Bookings List */}
      {filteredBookings.length === 0 ? (
        <div style={{
          background: "white",
          borderRadius: "12px",
          border: "1px solid #e2e8f0",
          padding: "40px",
          textAlign: "center"
        }}>
          <p style={{ margin: 0, color: "#64748b" }}>No bookings match the selected filters</p>
        </div>
      ) : (
        <div style={{
          background: "white",
          borderRadius: "12px",
          border: "1px solid #e2e8f0",
          overflow: "hidden"
        }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "#f8fafc", borderBottom: "2px solid #e2e8f0" }}>
                <th style={{ padding: "12px", textAlign: "left" }}>
                  <input
                    type="checkbox"
                    checked={selectedBookings.size === filteredBookings.length && filteredBookings.length > 0}
                    onChange={toggleAll}
                  />
                </th>
                <th style={{ padding: "12px", textAlign: "left", fontSize: "12px", fontWeight: "600", color: "#64748b", textTransform: "uppercase" }}>
                  Date
                </th>
                <th style={{ padding: "12px", textAlign: "left", fontSize: "12px", fontWeight: "600", color: "#64748b", textTransform: "uppercase" }}>
                  Customer
                </th>
                <th style={{ padding: "12px", textAlign: "left", fontSize: "12px", fontWeight: "600", color: "#64748b", textTransform: "uppercase" }}>
                  Event
                </th>
                <th style={{ padding: "12px", textAlign: "right", fontSize: "12px", fontWeight: "600", color: "#64748b", textTransform: "uppercase" }}>
                  Amount
                </th>
                <th style={{ padding: "12px", textAlign: "center", fontSize: "12px", fontWeight: "600", color: "#64748b", textTransform: "uppercase" }}>
                  Xero Status
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredBookings.map(booking => {
                const event = events.find(e => e.id === booking.eventId);
                return (
                  <tr key={booking.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                    <td style={{ padding: "12px" }}>
                      <input
                        type="checkbox"
                        checked={selectedBookings.has(booking.id)}
                        onChange={() => toggleBooking(booking.id)}
                      />
                    </td>
                    <td style={{ padding: "12px", fontSize: "14px", color: "#0f172a" }}>
                      {booking.date || "TBD"}
                    </td>
                    <td style={{ padding: "12px", fontSize: "14px", color: "#0f172a", fontWeight: "600" }}>
                      {booking.fullName || "Unknown"}
                    </td>
                    <td style={{ padding: "12px", fontSize: "14px", color: "#64748b" }}>
                      {event?.name || "Unknown Event"}
                    </td>
                    <td style={{ padding: "12px", fontSize: "14px", color: "#0f172a", fontWeight: "600", textAlign: "right" }}>
                      ${((booking.totalCents || 0) / 100).toFixed(2)}
                    </td>
                    <td style={{ padding: "12px", textAlign: "center" }}>
                      {booking.xeroInvoiceId ? (
                        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }}>
                          <CheckCircle size={16} style={{ color: "#10b981" }} />
                          <span style={{ fontSize: "12px", color: "#10b981", fontWeight: "600" }}>
                            {booking.xeroInvoiceNumber || "Synced"}
                          </span>
                          {booking.xeroInvoiceUrl && (
                            <a
                              href={booking.xeroInvoiceUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              style={{ color: "#64748b" }}
                            >
                              <ExternalLink size={14} />
                            </a>
                          )}
                        </div>
                      ) : (
                        <span style={{ fontSize: "12px", color: "#94a3b8" }}>Not synced</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}