// pages/Event.jsx
import React from "react";
import { getCtx } from "../components/lib/ctx";

function Hero({ title, sport, settings }) {
  const map = {
    softball: settings?.heroSoftballUrl,
    baseball: settings?.heroBaseballUrl || settings?.heroSoftballUrl,
    soccer: settings?.heroSoccerUrl
  };
  const bg = map[(sport||"softball")] || map.softball || "";
  return (
    <div className="hero" style={{
      backgroundImage: bg ? `linear-gradient(to top, rgba(0,0,0,.5), rgba(0,0,0,.1)), url(${bg})` : "none",
      backgroundSize:"cover", backgroundPosition:"center"
    }}>
      <div className="hero-body">
        <div className="kicker" style={{color:"#fff"}}>{sport || "event"}</div>
        <h1 style={{color:"#fff"}}>{title}</h1>
        <p className="mt-8" style={{color:"rgba(255,255,255,.9)"}}>
          Reserve shade, seating, and extras right by the action.
        </p>
      </div>
    </div>
  );
}

export default function Event() {
  const [ev, setEv] = React.useState(null);
  const [settings, setSettings] = React.useState(null);
  const [packages, setPackages] = React.useState([]);

  React.useEffect(() => {
    (async () => {
      const sp = new URLSearchParams(location.search);
      const id = sp.get("event");
      const { entities, settings } = await getCtx();
      setSettings(settings || {});
      const item = await entities.Events.get({ id });
      setEv(item);
      const pks = await entities.Packages.list();
      setPackages((pks || []).filter(p => p.isActive !== false));
    })();
  }, []);

  return (
    <>
      <div className="nav">
        <div className="container nav-inner">
          <a className="brand" href="/">
            <span className="badge">SS</span>
            <span>{settings?.brandName || "Sideline Setups"}</span>
          </a>
          <div className="nav-links">
            <a className="btn-ghost" href="/events">Events</a>
            <a className="btn-ghost" href="/mybookings">My Bookings</a>
            <a className="btn-ghost" href="/admindashboard">Admin</a>
          </div>
        </div>
      </div>

      <main>
        <Hero title={ev?.name || "Event"} sport={ev?.sport} settings={settings} />

        <div className="container section">
          <div className="grid grid-2">
            <div>
              <div className="card card-pad">
                <div className="kicker">{ev?.eventType} • {ev?.sport}</div>
                <h3 style={{marginTop:4}}>{ev?.name}</h3>
                <div className="mt-12" style={{display:"grid", gap:8}}>
                  <div style={{display:"flex", justifyContent:"space-between"}}>
                    <span>When</span>
                    <b>{ev?.startDate} → {ev?.endDate}</b>
                  </div>
                  <div style={{display:"flex", justifyContent:"space-between"}}>
                    <span>Where</span>
                    <b>{ev?.city || ev?.location || "-"}</b>
                  </div>
                </div>
                <p className="mt-12" style={{whiteSpace:"pre-wrap"}}>{ev?.description || ""}</p>

                <div className="mt-12">
                  <a className="btn" href={`/book?event=${encodeURIComponent(ev?.id || "")}`}>Book this event</a>
                  {ev?.website && <a className="btn-outline" style={{marginLeft:8}} href={ev.website} target="_blank" rel="noreferrer">Event site</a>}
                </div>
              </div>
            </div>

            <div>
              <div className="card card-pad">
                <div className="kicker">Packages</div>
                <h3 style={{marginTop:4}}>Popular options</h3>
                <div className="mt-12" style={{display:"grid", gap:12}}>
                  {(packages||[]).map(p => (
                    <div key={p.id} className="card" style={{padding:16, cursor:"pointer"}}
                         onClick={()=>location.href=`/book?event=${ev?.id}&pkg=${p.id}`}>
                      <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", gap:12}}>
                        <div>
                          <div className="kicker">{p.colorTheme || "blue"}</div>
                          <div style={{fontWeight:600}}>{p.name}</div>
                        </div>
                        <div style={{textAlign:"right"}}>
                          {p.perGameUSD && <div><span className="kicker">per game</span> ${p.perGameUSD}</div>}
                          {p.perDayUSD && <div><span className="kicker">per day</span> ${p.perDayUSD}</div>}
                          {p.fullWeekendUSD && <div><span className="kicker">weekend</span> ${p.fullWeekendUSD}</div>}
                          {!p.perGameUSD && !p.perDayUSD && !p.fullWeekendUSD && p.basePrice && (
                            <div><span className="kicker">from</span> ${p.basePrice}</div>
                          )}
                        </div>
                      </div>
                      {p.features?.length > 0 && (
                        <div className="mt-8" style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                          {p.features.map((f,ix)=> <span key={ix} className="badge">{f}</span>)}
                        </div>
                      )}
                    </div>
                  ))}
                  {(!packages || packages.length===0) && (
                    <div className="badge">No packages published yet.</div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="footer">
        <div className="container">
          © {new Date().getFullYear()} {settings?.brandName || "Sideline Setups"} — All rights reserved.
        </div>
      </footer>
    </>
  );
}