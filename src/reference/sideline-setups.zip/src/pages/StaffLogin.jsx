import React, { useState } from "react";
import { base44 } from "../api/base44Client";
import { LogIn, Mail, Phone, Hash } from "lucide-react";
import useSession from "../components/auth/SessionProvider";

export default function StaffLogin() {
  const { setSession } = useSession();
  const [mode, setMode] = useState("pin"); // pin, email, phone
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [step, setStep] = useState("input"); // input, verify

  // PIN mode
  const [pin, setPin] = useState("");

  // Email mode
  const [email, setEmail] = useState("");

  // Phone mode
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");

  const urlParams = new URLSearchParams(window.location.search);
  const redirectUrl = urlParams.get("redirect") || "/employee-quick-actions";

  async function handlePinLogin(e) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const response = await base44.functions.invoke('employeePinLogin', { pin });
      
      if (response.data.ok) {
        setSession(response.data.employee);
        window.location.href = redirectUrl;
      } else {
        setMessage("Invalid PIN. Please try again.");
      }
    } catch (error) {
      console.error("PIN login error:", error);
      setMessage("Invalid PIN. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  async function handleEmailRequest(e) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const response = await base44.functions.invoke('requestMagicLink', {
        kind: "employee",
        email
      });

      if (response.data.ok) {
        setMessage("Check your email for a login link!");
        setStep("verify");
      }
    } catch (error) {
      console.error("Email request error:", error);
      setMessage("Failed to send login link. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  async function handlePhoneRequest(e) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const response = await base44.functions.invoke('auth/requestSmsOtp', {
        kind: "employee_sms",
        phone
      });

      if (response.data.ok) {
        setMessage("Check your phone for a verification code!");
        setStep("verify");
      }
    } catch (error) {
      console.error("Phone request error:", error);
      setMessage("Failed to send code. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  async function handlePhoneVerify(e) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const response = await base44.functions.invoke('auth/verifySmsOtp', {
        kind: "employee_sms",
        phone,
        code: otp
      });

      if (response.data.ok) {
        setSession(response.data.session);
        window.location.href = redirectUrl;
      } else {
        setMessage("Invalid code. Please try again.");
      }
    } catch (error) {
      console.error("Phone verify error:", error);
      setMessage("Invalid code. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
      padding: '20px'
    }}>
      <div style={{
        background: 'white',
        borderRadius: '16px',
        boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
        maxWidth: '420px',
        width: '100%',
        padding: '40px'
      }}>
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <LogIn size={48} style={{ color: '#003f5c', margin: '0 auto 16px' }} />
          <h1 style={{ fontSize: '28px', fontWeight: '700', color: '#003f5c', marginBottom: '8px' }}>
            Staff Login
          </h1>
          <p style={{ color: '#64748b', fontSize: '14px' }}>
            Choose your preferred login method
          </p>
        </div>

        {/* Login Method Tabs */}
        <div style={{
          display: 'flex',
          gap: '8px',
          marginBottom: '24px',
          borderBottom: '2px solid #e2e8f0'
        }}>
          <button
            onClick={() => { setMode("pin"); setStep("input"); setMessage(""); }}
            style={{
              flex: 1,
              padding: '12px',
              background: 'none',
              border: 'none',
              borderBottom: mode === "pin" ? '3px solid #003f5c' : '3px solid transparent',
              color: mode === "pin" ? '#003f5c' : '#64748b',
              fontWeight: '600',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            <Hash size={16} style={{ marginBottom: '4px' }} />
            <div>PIN</div>
          </button>
          <button
            onClick={() => { setMode("email"); setStep("input"); setMessage(""); }}
            style={{
              flex: 1,
              padding: '12px',
              background: 'none',
              border: 'none',
              borderBottom: mode === "email" ? '3px solid #003f5c' : '3px solid transparent',
              color: mode === "email" ? '#003f5c' : '#64748b',
              fontWeight: '600',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            <Mail size={16} style={{ marginBottom: '4px' }} />
            <div>Email</div>
          </button>
          <button
            onClick={() => { setMode("phone"); setStep("input"); setMessage(""); }}
            style={{
              flex: 1,
              padding: '12px',
              background: 'none',
              border: 'none',
              borderBottom: mode === "phone" ? '3px solid #003f5c' : '3px solid transparent',
              color: mode === "phone" ? '#003f5c' : '#64748b',
              fontWeight: '600',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            <Phone size={16} style={{ marginBottom: '4px' }} />
            <div>Phone</div>
          </button>
        </div>

        {/* PIN Mode */}
        {mode === "pin" && (
          <form onSubmit={handlePinLogin}>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600', fontSize: '14px' }}>
                Enter Your PIN
              </label>
              <input
                type="password"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="4-6 digit PIN"
                maxLength="6"
                style={{
                  width: '100%',
                  padding: '12px',
                  border: '1px solid #e2e8f0',
                  borderRadius: '8px',
                  fontSize: '16px',
                  textAlign: 'center',
                  letterSpacing: '4px'
                }}
                required
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="btn"
              style={{ width: '100%', padding: '14px', fontSize: '16px' }}
            >
              {loading ? "Logging in..." : "Login"}
            </button>
          </form>
        )}

        {/* Email Mode */}
        {mode === "email" && (
          <>
            {step === "input" ? (
              <form onSubmit={handleEmailRequest}>
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600', fontSize: '14px' }}>
                    Work Email
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@company.com"
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px',
                      fontSize: '16px'
                    }}
                    required
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="btn"
                  style={{ width: '100%', padding: '14px', fontSize: '16px' }}
                >
                  {loading ? "Sending..." : "Send Login Link"}
                </button>
              </form>
            ) : (
              <div style={{ textAlign: 'center', color: '#10b981', fontSize: '14px' }}>
                <p>✓ Check your email for a login link!</p>
                <button
                  onClick={() => setStep("input")}
                  className="btn-outline"
                  style={{ marginTop: '16px' }}
                >
                  Try Again
                </button>
              </div>
            )}
          </>
        )}

        {/* Phone Mode */}
        {mode === "phone" && (
          <>
            {step === "input" ? (
              <form onSubmit={handlePhoneRequest}>
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600', fontSize: '14px' }}>
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="(555) 123-4567"
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px',
                      fontSize: '16px'
                    }}
                    required
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="btn"
                  style={{ width: '100%', padding: '14px', fontSize: '16px' }}
                >
                  {loading ? "Sending..." : "Send Code"}
                </button>
              </form>
            ) : (
              <form onSubmit={handlePhoneVerify}>
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600', fontSize: '14px' }}>
                    Enter Verification Code
                  </label>
                  <input
                    type="text"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    placeholder="123456"
                    maxLength="6"
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px',
                      fontSize: '16px',
                      textAlign: 'center',
                      letterSpacing: '4px'
                    }}
                    required
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="btn"
                  style={{ width: '100%', padding: '14px', fontSize: '16px', marginBottom: '12px' }}
                >
                  {loading ? "Verifying..." : "Verify & Login"}
                </button>
                <button
                  type="button"
                  onClick={() => setStep("input")}
                  className="btn-outline"
                  style={{ width: '100%' }}
                >
                  Try Different Number
                </button>
              </form>
            )}
          </>
        )}

        {message && (
          <div style={{
            marginTop: '20px',
            padding: '12px',
            borderRadius: '8px',
            background: message.includes("Invalid") || message.includes("Failed") ? '#fee2e2' : '#d1fae5',
            color: message.includes("Invalid") || message.includes("Failed") ? '#991b1b' : '#065f46',
            fontSize: '14px',
            textAlign: 'center'
          }}>
            {message}
          </div>
        )}

        <div style={{ marginTop: '24px', textAlign: 'center', fontSize: '14px', color: '#64748b' }}>
          <a href="/" style={{ color: '#003f5c' }}>← Back to Home</a>
        </div>
      </div>
    </div>
  );
}