// pages/AdminDashboard.jsx
import React from "react";
import NavBar from "../components/NavBar";

export default function AdminDashboard() {
  return (
    <>
      <NavBar />
      <div style={{padding:"24px 20px", maxWidth:1000, margin:"0 auto"}}>
        <h1>Admin Dashboard</h1>
        <ul style={{lineHeight:2}}>
          <li><a href="/adminevents">Manage Events</a></li>
          <li><a href="/adminparks">Parks & Fields</a></li>
          <li><a href="/adminpackages">Packages & LeaguePackages</a></li>
          <li><a href="/adminbookings">Bookings & Locks</a></li>
          <li><a href="/adminsettings">Site Settings</a></li>
          <li><a href="/adminautomations">Automations</a></li>
          <li><a href="/adminspend">Spend Map & Analytics</a></li>
          <li><a href="/inventory">Inventory Management</a></li>
          <li><a href="/adminbilling">Invoicing, Credits & Refunds</a></li>
          <li><a href="/admincrm">CRM Campaigns & Tags</a></li>
          <li><a href="/adminstaffing">Staffing & Assignments</a></li>
          <li><a href="/adminstaff">Staff Shifts & Reports</a></li>
          <li><a href="/adminrunsheets">Run Sheets</a></li>
          <li><a href="/admincogs">COGS Dashboard</a></li>
          <li><a href="/adminexports">Exports (CSV)</a></li>
          <li><a href="/adminanalytics">Analytics & Charts</a></li>
          <li><a href="/adminlockcleanup">Lock Cleanup Utility</a></li>
        </ul>
      </div>
    </>
  );
}