
import React, { useState, useEffect } from "react";
import { getCtx } from "../components/lib/ctx";
import { Calendar, MapPin, ExternalLink, Mail } from "lucide-react";
import SEO from "../components/SEO";

// Safe date formatter helper
function formatDate(dateStr) {
  if (!dateStr) return "";
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return "";
    return d.toLocaleDateString(undefined, {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric"
    });
  } catch (e) {
    return "";
  }
}

export default function Events() {
  const [allEvents, setAllEvents] = useState([]);
  const [settings, setSettings] = useState(null);
  const [selectedSport, setSelectedSport] = useState("softball");
  const [selectedType, setSelectedType] = useState("all");
  const [loading, setLoading] = useState(true);

  const navyColor = "#003f5c";
  const navyGradient = "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)";

  useEffect(() => {
    async function loadEvents() {
      try {
        setLoading(true);
        const { entities, settings } = await getCtx();
        setSettings(settings || {});
        // Filter out events that are marked as archived
        const rows = await entities.Events.filter({ isActive: true, archived: false });
        
        // Sort events by start date (earliest first), with events without dates at the end
        const sortedEvents = (rows || []).sort((a, b) => {
          if (!a.startDate && !b.startDate) return 0; // Both have no date, maintain relative order
          if (!a.startDate) return 1; // a has no date, push to end
          if (!b.startDate) return -1; // b has no date, push to end
          
          // Both have dates, compare them
          return new Date(a.startDate) - new Date(b.startDate);
        });
        
        setAllEvents(sortedEvents);
      } catch (error) {
        console.error("Failed to load events:", error);
        setAllEvents([]);
      } finally {
        setLoading(false);
      }
    }

    loadEvents();
  }, []);

  const filteredEvents = allEvents.filter(event => {
    const evSport = String(event.sport || "").toLowerCase();
    const sportMatch = evSport === selectedSport;
    const evType = String(event.eventType || "").toLowerCase();
    const typeMatch = selectedType === "all" || evType === selectedType;
    return sportMatch && typeMatch;
  });

  // Hardcoded sport images - these will never change
  const fallbackImages = {
    softball: "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/17a3ba488_cameron-cox-TZFtzfnZuzc-unsplash.jpg",
    baseball: "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/96e85a991_mike-bowman-xKShyIiTNJk-unsplash.jpg",
    soccer: "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/fc0a60797_vikram-tkv-JO19K0HDDXI-unsplash.jpg",
  };

  const sportIcons = {
    softball: "⚾",
    baseball: "⚾",
    soccer: "⚽"
  };

  const sportNames = {
    softball: "Softball",
    baseball: "Baseball",
    soccer: "Soccer"
  };

  return (
    <div className="min-h-screen">
      <SEO 
        title="Youth Sports Events & Tournaments | Sideline Setups"
        description="Browse youth baseball, softball, and soccer tournaments where Sideline Setups provides professional tent and chair rentals in East Texas. Book your game day setup today."
        keywords="youth sports tournaments, travel ball events, youth baseball tournaments, youth softball tournaments, soccer tournaments, East Texas sports events, tournament tent rental"
        canonicalUrl="https://sideline-setups.com/events"
      />

      {/* Sport Selection Section with Background */}
      <section
        className="py-12 sm:py-16 px-4"
        style={{
          backgroundImage: settings?.pageBackgroundPatternUrl
            ? `linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.92)), url('${settings.pageBackgroundPatternUrl}')`
            : undefined,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed',
          backgroundColor: '#f8fafc'
        }}
      >
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-center mb-8" style={{color: '#003f5c'}}>
            Select Your Sport
          </h2>

          {/* Sport Tabs with Images - Full size on desktop/tablet, smaller on mobile */}
          <div className="sport-tabs-grid" style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "20px",
            marginBottom: "32px"
          }}>
            {["softball", "baseball", "soccer"].map((s) => (
              <button
                key={s}
                onClick={() => setSelectedSport(s)}
                className="sport-tab"
                style={{
                  position: "relative",
                  height: "200px",
                  border: selectedSport === s ? "4px solid #003f5c" : "2px solid #e2e8f0",
                  borderRadius: "16px",
                  overflow: "hidden",
                  cursor: "pointer",
                  transition: "all 0.3s",
                  backgroundImage: `linear-gradient(rgba(0, 0, 0, ${selectedSport === s ? '0.4' : '0.3'}), rgba(0, 0, 0, ${selectedSport === s ? '0.4' : '0.3'})), url('${fallbackImages[s]}')`,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                  transform: selectedSport === s ? "scale(1.02)" : "scale(1)",
                  boxShadow: selectedSport === s ? "0 12px 24px rgba(0, 63, 92, 0.2)" : "0 4px 6px rgba(0, 0, 0, 0.1)"
                }}
              >
                <div className="sport-tab-content" style={{
                  position: "absolute",
                  bottom: "20px",
                  left: "20px",
                  right: "20px",
                  color: "white",
                  textAlign: "left",
                  display: "flex",
                  alignItems: "center",
                  gap: "12px"
                }}>
                  <h3 style={{
                    margin: 0,
                    fontSize: "28px",
                    fontWeight: "700",
                    textTransform: "capitalize",
                    textShadow: "0 2px 4px rgba(0,0,0,0.3)",
                    color: "white"
                  }}>
                    {sportNames[s]}
                  </h3>
                  {selectedSport === s && (
                    <span style={{
                      fontSize: "32px",
                      color: "white",
                      textShadow: "0 2px 4px rgba(0,0,0,0.3)"
                    }}>
                      ✓
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>

          {/* Mobile-specific smaller sport tabs */}
          <style>{`
            @media (max-width: 767px) {
              .sport-tabs-grid {
                grid-template-columns: repeat(3, 1fr) !important;
                gap: 8px !important;
              }
              .sport-tab {
                height: 120px !important;
              }
              .sport-tab h3 {
                font-size: 18px !important;
              }
              .sport-tab-content {
                flex-direction: column-reverse !important;
                align-items: center !important;
                text-align: center !important;
                gap: 4px !important;
                bottom: 10px !important;
                left: 10px !important;
                right: 10px !important;
              }
              .sport-tab-content span {
                font-size: 24px !important;
              }
            }
          `}</style>

          {/* Type Filter */}
          <div style={{
            display: "flex",
            justifyContent: "center",
            gap: 12,
            marginBottom: 32,
            flexWrap: "wrap"
          }}>
            <button
              onClick={() => setSelectedType("all")}
              className={selectedType === "all" ? "btn" : "btn-outline"}
              style={selectedType === "all"
                      ? { background: navyGradient, color: "white", border: "none", minWidth: 120 }
                      : { color: navyColor, borderColor: navyColor, minWidth: 120 }}
            >
              All Events
            </button>
            <button
              onClick={() => setSelectedType("tournament")}
              className={selectedType === "tournament" ? "btn" : "btn-outline"}
              style={selectedType === "tournament"
                      ? { background: navyGradient, color: "white", border: "none", minWidth: 120 }
                      : { color: navyColor, borderColor: navyColor, minWidth: 120 }}
            >
              Tournaments
            </button>
            <button
              onClick={() => setSelectedType("league")}
              className={selectedType === "league" ? "btn" : "btn-outline"}
              style={selectedType === "league"
                      ? { background: navyGradient, color: "white", border: "none", minWidth: 120 }
                      : { color: navyColor, borderColor: navyColor, minWidth: 120 }}
            >
              Leagues
            </button>
          </div>
        </div>
      </section>

      {/* Events List Section with Background */}
      <section
        className="py-12 px-4"
        style={{
          backgroundImage: settings?.pageBackgroundPatternUrl
            ? `linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.92)), url('${settings.pageBackgroundPatternUrl}')`
            : undefined,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed',
          backgroundColor: 'white'
        }}
      >
        <div className="max-w-7xl mx-auto">
          {/* Compact Request Banner - Always Visible */}
          <div style={{
            background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
            padding: '16px 24px',
            borderRadius: '12px',
            marginBottom: '32px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '16px',
            boxShadow: '0 4px 12px rgba(0, 63, 92, 0.2)'
          }}>
            <div style={{ color: 'white' }}>
              <div style={{ fontSize: '16px', fontWeight: '700', marginBottom: '4px' }}>
                Don't see your event?
              </div>
              <div style={{ fontSize: '14px', opacity: 0.9 }}>
                Contact us to bring Sideline Setups to your tournament or league
              </div>
            </div>
            <a
              href={`mailto:${settings?.supportEmail || "support@sideline-setups.com"}?subject=Event Request - ${sportNames[selectedSport]}&body=Hi! I'd like to request Sideline Setups for my ${selectedType === "all" ? "event" : selectedType}.%0D%0A%0D%0AEvent Name:%0D%0ALocation:%0D%0ADate:%0D%0AExpected Teams:%0D%0A%0D%0AAdditional Info:%0D%0A`}
              className="btn"
              style={{ 
                background: 'white',
                color: '#003f5c',
                border: 'none',
                padding: '10px 20px',
                whiteSpace: 'nowrap',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
            >
              <Mail size={16} />
              Request My Event
            </a>
          </div>

          {/* Loading State */}
          {loading && (
            <div style={{ textAlign: "center", padding: "60px 0" }}>
              <div className="spinner"></div>
              <p style={{ marginTop: 16, color: "var(--muted)" }}>Loading events...</p>
            </div>
          )}

          {/* Events Grid */}
          {!loading && filteredEvents.length > 0 && (
            <div className="grid grid-3" style={{ gap: 20 }}>
              {filteredEvents.map(event => {
                const evSport = String(event.sport || "").toLowerCase();
                const imgSrc = typeof event.imageUrl === "string" && event.imageUrl.trim()
                  ? event.imageUrl.trim()
                  : fallbackImages[evSport] || fallbackImages.softball;

                const startDateStr = formatDate(event.startDate);
                const endDateStr = formatDate(event.endDate);

                return (
                  <div key={event.id} className="card card-event">
                    <div className="img">
                      <img
                        src={imgSrc}
                        alt={event.name}
                      />
                    </div>
                    <div className="body">
                      <div className="kicker">
                        {event.eventType === "tournament" ? "🏆 Tournament" : "🏅 League"} • {sportNames[evSport] || event.sport}
                      </div>
                      <h3 style={{ margin: "8px 0 12px 0" }}>{event.name}</h3>

                      <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 16 }}>
                        {event.city && (
                          <div style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 14 }}>
                            <MapPin size={14} />
                            <span>{event.city}</span>
                          </div>
                        )}
                        {(startDateStr || endDateStr) && (
                          <div style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 14 }}>
                            <Calendar size={14} />
                            <span>
                              {startDateStr}
                              {endDateStr && endDateStr !== startDateStr && ` - ${endDateStr}`}
                            </span>
                          </div>
                        )}
                      </div>

                      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                        <a className="btn" href={`/book?event=${event.id}`}
                           style={{ flex: 1, textAlign: "center", background: navyGradient, color: "white", border: "none" }}>
                          Book Now
                        </a>
                        {event.website && (
                          <a
                            className="btn-outline"
                            href={event.website}
                            target="_blank"
                            rel="noopener noreferrer"
                            style={{ padding: "10px 12px", color: navyColor, borderColor: navyColor }}
                            title="Visit event website"
                          >
                            <ExternalLink size={18} />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* No Events Message - Only show if truly no events */}
          {!loading && filteredEvents.length === 0 && (
            <div className="card card-pad" style={{ maxWidth: 600, margin: "0 auto", textAlign: "center", padding: "40px" }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>{sportIcons[selectedSport]}</div>
              <h2 style={{ margin: "0 0 12px 0" }}>No {sportNames[selectedSport]} Events Yet</h2>
              <p style={{ color: "var(--muted)", marginBottom: 16, lineHeight: 1.6 }}>
                We're not scheduled for any {sportNames[selectedSport].toLowerCase()} {selectedType === "all" ? "events" : selectedType + "s"} right now.
              </p>
              <p style={{ fontSize: 14, color: "var(--muted)" }}>
                Check out our other {selectedType === "all" ? "events" : selectedType + "s"}:
              </p>
              <div style={{ display: "flex", gap: 8, justifyContent: "center", marginTop: 12, flexWrap: "wrap" }}>
                {["softball", "baseball", "soccer"].filter(s => s !== selectedSport).map(sport => (
                  <button
                    key={sport}
                    onClick={() => setSelectedSport(sport)}
                    className="btn-outline"
                    style={{ color: navyColor, borderColor: navyColor }}
                  >
                    {sportIcons[sport]} {sportNames[sport]}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
