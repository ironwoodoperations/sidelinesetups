
import React from "react";

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="max-w-4xl mx-auto px-4">
        <div className="card card-pad">
          <h1 className="text-3xl font-bold mb-6" style={{ color: '#003f5c' }}>
            Privacy Policy
          </h1>
          
          <div style={{ fontSize: "14px", lineHeight: "1.8", color: "#334155" }}>
            <p className="mb-4">
              <strong>Last Updated:</strong> {new Date().toLocaleDateString()}
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              1. Information We Collect
            </h2>
            <p className="mb-4">
              We collect information you provide directly to us when you create a booking, including:
            </p>
            <ul className="list-disc pl-6 mb-4">
              <li>Full name</li>
              <li>Email address</li>
              <li>Phone number</li>
              <li>Team name and coach information</li>
              <li>Payment information (processed securely through PayPal)</li>
              <li>Event and location preferences</li>
            </ul>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              2. How We Use Your Information
            </h2>
            <p className="mb-4">
              We use the information we collect to:
            </p>
            <ul className="list-disc pl-6 mb-4">
              <li>Process and fulfill your bookings</li>
              <li>Send booking confirmations and updates</li>
              <li>Communicate about your setup and event details</li>
              <li>Send promotional materials (only if you opt-in)</li>
              <li>Improve our services and customer experience</li>
              <li>Comply with legal obligations</li>
            </ul>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              3. SMS Communications
            </h2>
            <p className="mb-4">
              When you provide your phone number and consent to SMS communications, we may send you:
            </p>
            <ul className="list-disc pl-6 mb-4">
              <li>Booking confirmations</li>
              <li>Setup ready notifications</li>
              <li>Event reminders</li>
              <li>Important service updates</li>
            </ul>
            <p className="mb-4">
              You can opt-out of SMS communications at any time by replying STOP to any message. Message and data rates may apply.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              4. Information Sharing
            </h2>
            <p className="mb-4">
              We do not sell, trade, or rent your personal information to third parties. We may share your information with:
            </p>
            <ul className="list-disc pl-6 mb-4">
              <li>Service providers who assist in our operations (e.g., PayPal for payment processing)</li>
              <li>Law enforcement when required by law</li>
              <li>Event organizers (only name and team information as necessary for event logistics)</li>
            </ul>
            <p className="mb-4">
              <strong>Mobile Information:</strong> No mobile information will be shared with third parties/affiliates for marketing/promotional purposes. All the above categories exclude text messaging originator opt-in data and consent; this information will not be shared with any third parties.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              5. Data Security
            </h2>
            <p className="mb-4">
              We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. However, no internet transmission is completely secure, and we cannot guarantee absolute security.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              6. Data Retention
            </h2>
            <p className="mb-4">
              We retain your personal information for as long as necessary to fulfill the purposes outlined in this Privacy Policy, unless a longer retention period is required by law.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              7. Your Rights
            </h2>
            <p className="mb-4">
              You have the right to:
            </p>
            <ul className="list-disc pl-6 mb-4">
              <li>Access your personal information</li>
              <li>Correct inaccurate information</li>
              <li>Request deletion of your information</li>
              <li>Opt-out of marketing communications</li>
              <li>Withdraw consent for SMS communications</li>
            </ul>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              8. Cookies and Tracking
            </h2>
            <p className="mb-4">
              We use cookies and similar tracking technologies to improve your experience on our website, analyze usage patterns, and for marketing purposes. You can control cookies through your browser settings.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              9. Children's Privacy
            </h2>
            <p className="mb-4">
              Our services are not directed to children under 13. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and believe your child has provided us with personal information, please contact us.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              10. Changes to This Policy
            </h2>
            <p className="mb-4">
              We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              11. Contact Us
            </h2>
            <p className="mb-4">
              If you have any questions about this Privacy Policy, please contact us at:<br />
              Email: sidelinesetups@gmail.com<br />
              Phone: 903-541-9287
            </p>
          </div>

          <div className="mt-8 text-center">
            <a href="/events" className="btn-outline">
              Back to Events
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
