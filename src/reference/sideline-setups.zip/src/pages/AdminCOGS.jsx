import React from "react";
import { getCtx } from "../components/lib/ctx";
import { recordPurchase } from "../components/lib/cogs";

export default function AdminCOGS() {
  const [purchases, setPurchases] = React.useState([]);
  const [cogsRows, setCogsRows] = React.useState([]);
  const [equipment, setEquipment] = React.useState([]);
  const [form, setForm] = React.useState({ equipmentId: "", qty: 1, costUSD: 0, supplier: "", notes: "" });

  React.useEffect(() => {
    (async () => {
      const { entities } = await getCtx();
      setPurchases(await entities.Purchases.list());
      setCogsRows(await entities.COGS.list());
      setEquipment(await entities.Equipment.list());
    })();
  }, []);

  async function submitPurchase(e) {
    e.preventDefault();
    await recordPurchase({
      equipmentId: form.equipmentId,
      qty: form.qty,
      costUSD: form.costUSD,
      supplier: form.supplier,
      notes: form.notes
    });
    const { entities } = await getCtx();
    setPurchases(await entities.Purchases.list());
    setEquipment(await entities.Equipment.list());
    alert("Purchase recorded and inventory updated.");
    setForm({ equipmentId: "", qty: 1, costUSD: 0, supplier: "", notes: "" });
  }

  return (
    <>
      <div className="nav">
        <div className="container nav-inner">
          <a className="brand" href="/">
            <span className="badge">SS</span>
            <span>Sideline Setups</span>
          </a>
          <div className="nav-links">
            <a className="btn-ghost" href="/admindashboard">Dashboard</a>
            <a className="btn-ghost" href="/admincogs">COGS</a>
          </div>
        </div>
      </div>

      <div className="container section">
        <h1>COGS & Purchases</h1>

        <div className="card card-pad" style={{marginTop:24}}>
          <h2>Record New Purchase</h2>
          <form onSubmit={submitPurchase} style={{display:"grid",gap:16,marginTop:16}}>
            <div>
              <label className="label">Equipment</label>
              <select
                className="select"
                value={form.equipmentId}
                onChange={(e)=>setForm(f=>({...f, equipmentId: e.target.value}))}
                required
              >
                <option value="">Select equipment…</option>
                {equipment.map(eq => (
                  <option key={eq.id} value={eq.id}>
                    {eq.type} — {eq.name || "Unnamed"} (avail {eq.availableQty || 0}/{eq.totalQty || 0})
                  </option>
                ))}
              </select>
            </div>
            <div className="row">
              <div>
                <label className="label">Quantity</label>
                <input className="input" type="number" min="1"
                  value={form.qty}
                  onChange={(e)=>setForm(f=>({...f, qty: Number(e.target.value)}))}
                  required />
              </div>
              <div>
                <label className="label">Cost (USD)</label>
                <input className="input" type="number" min="0" step="0.01"
                  value={form.costUSD}
                  onChange={(e)=>setForm(f=>({...f, costUSD: Number(e.target.value)}))}
                  required />
              </div>
            </div>
            <div>
              <label className="label">Supplier</label>
              <input className="input" value={form.supplier}
                onChange={(e)=>setForm(f=>({...f, supplier: e.target.value}))} />
            </div>
            <div>
              <label className="label">Notes</label>
              <input className="input" value={form.notes}
                onChange={(e)=>setForm(f=>({...f, notes: e.target.value}))} />
            </div>
            <button className="btn" type="submit">Record Purchase</button>
          </form>
        </div>

        <div className="card card-pad" style={{marginTop:24}}>
          <h2>Recent Purchases</h2>
          <table className="table" style={{marginTop:16}}>
            <thead>
              <tr>
                <th>When</th>
                <th>Equipment</th>
                <th>Qty</th>
                <th>Cost</th>
                <th>Supplier</th>
              </tr>
            </thead>
            <tbody>
              {purchases.map(p => {
                const eq = equipment.find(e => e.id === p.equipmentId);
                return (
                  <tr key={p.id}>
                    <td>{new Date(p.created_date).toLocaleDateString()}</td>
                    <td>{eq ? `${eq.type} - ${eq.name}` : p.equipmentId}</td>
                    <td>{p.qty}</td>
                    <td>${Number(p.costUSD||0).toFixed(2)}</td>
                    <td>{p.supplier || "-"}</td>
                  </tr>
                );
              })}
              {purchases.length === 0 && (
                <tr><td colSpan={5} style={{textAlign:"center",color:"var(--muted)"}}>No purchases recorded yet</td></tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="card card-pad" style={{marginTop:24}}>
          <h2>COGS by Booking</h2>
          <table className="table" style={{marginTop:16}}>
            <thead>
              <tr>
                <th>When</th>
                <th>Booking</th>
                <th>Items</th>
                <th>Labor</th>
                <th>Other</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {cogsRows.map(row => (
                <tr key={row.id}>
                  <td>{new Date(row.created_date).toLocaleDateString()}</td>
                  <td>{row.bookingId.slice(0,8)}...</td>
                  <td>
                    {(row.items||[]).map((it,i)=>(
                      <div key={i}>{it.label} ×{it.qty} — ${Number(it.lineUSD||0).toFixed(2)}</div>
                    ))}
                  </td>
                  <td>${Number(row.laborUSD||0).toFixed(2)}</td>
                  <td>${Number(row.otherUSD||0).toFixed(2)}</td>
                  <td><b>${Number(row.totalUSD||0).toFixed(2)}</b></td>
                </tr>
              ))}
              {cogsRows.length === 0 && (
                <tr><td colSpan={6} style={{textAlign:"center",color:"var(--muted)"}}>No COGS records yet</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}