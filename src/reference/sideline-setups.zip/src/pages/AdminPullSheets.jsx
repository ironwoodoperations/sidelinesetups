import React from "react";
import AdminPullSheet from "../components/admin/AdminPullSheet";

export default function AdminPullSheets() {
  return <AdminPullSheet />;
}