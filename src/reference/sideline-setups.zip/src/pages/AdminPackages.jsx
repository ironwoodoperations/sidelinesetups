import React from "react";
import AdminPackages from "../components/admin/AdminPackages";

export default function AdminPackagesPage() {
  return <AdminPackages />;
}