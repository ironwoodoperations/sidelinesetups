// pages/AdminExports.jsx
import React from "react";
import NavBar from "../components/NavBar";
import { getCtx } from "../components/lib/ctx";

function toCSV(rows, columns) {
  const head = columns.join(",");
  const body = (rows || []).map(r =>
    columns.map(c => {
      const v = r?.[c];
      const s = (v == null) ? "" : String(v);
      return `"${s.replace(/"/g, '""')}"`;
    }).join(",")
  ).join("\n");
  return head + "\n" + body;
}

export default function AdminExports() {
  const [bookings, setBookings] = React.useState([]);
  const [events, setEvents] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  
  const [filterEventId, setFilterEventId] = React.useState("");
  const [filterStartDate, setFilterStartDate] = React.useState("");
  const [filterEndDate, setFilterEndDate] = React.useState("");

  React.useEffect(() => {
    (async () => {
      const { entities } = await getCtx();
      const [bookingsData, eventsData] = await Promise.all([
        entities.Bookings.list(),
        entities.Events.list()
      ]);
      setBookings(bookingsData || []);
      setEvents(eventsData || []);
      setLoading(false);
    })();
  }, []);

  function download(csv, filename) {
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename; a.click();
  }

  if (loading) {
    return (
      <>
        <NavBar/>
        <div className="container section"><h2>Loading…</h2></div>
      </>
    );
  }

  // Apply filters
  const filtered = bookings.filter(b => {
    if (filterEventId && b.eventId !== filterEventId) return false;
    if (filterStartDate && b.date < filterStartDate) return false;
    if (filterEndDate && b.date > filterEndDate) return false;
    return true;
  });

  const columns = [
    "id","created_date","status","eventType","sport","date",
    "fullName","contactEmail","phone","teamName","coachName",
    "packageId","packageMode","totals"
  ];
  const normalized = filtered.map(b => ({
    ...b,
    totals: JSON.stringify(b?.totals || {})
  }));

  return (
    <>
      <NavBar/>
      <div className="container section">
        <h1>Admin • Exports</h1>
        <p>Download CSVs for bookkeeping and quick analyses.</p>

        <div className="card" style={{ padding: 16, marginTop: 16 }}>
          <h3>Filters</h3>
          <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))" }}>
            <div>
              <label style={{ display: "block", marginBottom: 4, fontSize: 14, fontWeight: 600 }}>Event</label>
              <select className="input" value={filterEventId} onChange={e => setFilterEventId(e.target.value)}>
                <option value="">All Events</option>
                {events.map(ev => (
                  <option key={ev.id} value={ev.id}>{ev.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label style={{ display: "block", marginBottom: 4, fontSize: 14, fontWeight: 600 }}>Start Date</label>
              <input 
                type="date" 
                className="input" 
                value={filterStartDate} 
                onChange={e => setFilterStartDate(e.target.value)} 
              />
            </div>
            <div>
              <label style={{ display: "block", marginBottom: 4, fontSize: 14, fontWeight: 600 }}>End Date</label>
              <input 
                type="date" 
                className="input" 
                value={filterEndDate} 
                onChange={e => setFilterEndDate(e.target.value)} 
              />
            </div>
          </div>
          <div style={{ marginTop: 12, fontSize: 14, color: "var(--muted)" }}>
            Showing {filtered.length} of {bookings.length} bookings
          </div>
        </div>

        <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
          <button className="btn"
            onClick={() => {
              const csv = toCSV(normalized, columns);
              const suffix = filterEventId ? `-event-${filterEventId}` : "";
              const dateRange = (filterStartDate || filterEndDate) 
                ? `-${filterStartDate || "start"}-to-${filterEndDate || "end"}` 
                : "";
              download(csv, `bookings${suffix}${dateRange}-${new Date().toISOString().slice(0,10)}.csv`);
            }}
          >Download Filtered CSV ({filtered.length} rows)</button>
        </div>
      </div>
    </>
  );
}