import AdminDiscountCodes from "./AdminDiscountCodes";

export default AdminDiscountCodes;