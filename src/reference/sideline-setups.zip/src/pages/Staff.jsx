
import React, { useState, useEffect } from "react";
import useSession from "../components/auth/SessionProvider";
import { Home, Users, CheckCircle, Clock } from "lucide-react";
import UserMenu from "../components/UserMenu";

// Simple staff views - will create full components next
function StaffToday() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6" style={{ color: '#003f5c' }}>Today's Schedule</h2>
      <div className="card card-pad">
        <p style={{ color: 'var(--muted)' }}>Your shifts and bookings for today will appear here.</p>
      </div>
    </div>
  );
}

function StaffBookings() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6" style={{ color: '#003f5c' }}>Bookings</h2>
      <div className="card card-pad">
        <p style={{ color: 'var(--muted)' }}>Search and view bookings.</p>
      </div>
    </div>
  );
}

function StaffCheckin() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6" style={{ color: '#003f5c' }}>Check-In</h2>
      <div className="card card-pad">
        <p style={{ color: 'var(--muted)' }}>QR scanner and manual check-in.</p>
      </div>
    </div>
  );
}

function StaffTime() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6" style={{ color: '#003f5c' }}>Time Clock</h2>
      <div className="card card-pad">
        <p style={{ color: 'var(--muted)' }}>View your hours and clock in/out.</p>
      </div>
    </div>
  );
}

const VIEWS = {
  "#today": <StaffToday />,
  "#bookings": <StaffBookings />,
  "#checkin": <StaffCheckin />,
  "#time": <StaffTime />
};

export default function StaffPage() {
  const { session } = useSession(); // Removed 'logout' as it's now handled by UserMenu
  const [hash, setHash] = useState(window.location.hash || "#today"); // Kept useState as it's already imported directly

  // Check authentication
  useEffect(() => {
    if (!session || session.type !== "employee") {
      window.location.href = "/staff-login";
    }
  }, [session]);

  useEffect(() => {
    const handleHashChange = () => setHash(window.location.hash || "#today");
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  if (!session || session.type !== "employee") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <div style={{
        background: "white",
        borderBottom: "2px solid #e2e8f0",
        position: "sticky",
        top: 0,
        zIndex: 50
      }}>
        <div className="container" style={{ padding: "16px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "16px" }}>
            <div style={{ display: "flex", gap: 16, alignItems: "center", flexWrap: "wrap" }}>
              <a 
                href="/staff#today" 
                className={hash === "#today" ? "btn" : "btn-ghost"}
                style={{ display: "flex", alignItems: "center", gap: 8 }}
              >
                <Home size={18} />
                Today
              </a>
              <a 
                href="/staff#bookings" 
                className={hash === "#bookings" ? "btn" : "btn-ghost"}
                style={{ display: "flex", alignItems: "center", gap: 8 }}
              >
                <Users size={18} />
                Bookings
              </a>
              <a 
                href="/staff#checkin" 
                className={hash === "#checkin" ? "btn" : "btn-ghost"}
                style={{ display: "flex", alignItems: "center", gap: 8 }}
              >
                <CheckCircle size={18} />
                Check-In
              </a>
              <a 
                href="/staff#time" 
                className={hash === "#time" ? "btn" : "btn-ghost"}
                style={{ display: "flex", alignItems: "center", gap: 8 }}
              >
                <Clock size={18} />
                Time
              </a>
            </div>

            <UserMenu /> {/* Replaced existing user info and logout button with UserMenu */}
          </div>
        </div>
      </div>

      {/* Content */}
      <div>{VIEWS[hash] || VIEWS["#today"]}</div>
    </div>
  );
}
