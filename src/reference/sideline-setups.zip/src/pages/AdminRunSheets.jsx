import React from "react";
import NavBar from "../components/NavBar";
import { getCtx } from "../components/lib/ctx";
import { generateRunSheetPDF } from "../components/lib/pdf";

function downloadBlob(b, name){
  const url = URL.createObjectURL(b);
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  setTimeout(()=>URL.revokeObjectURL(url), 500);
}

export default function AdminRunSheets(){
  const [parks, setParks] = React.useState([]);
  const [parkId, setParkId] = React.useState("");
  const [date, setDate] = React.useState(new Date().toISOString().slice(0,10));
  const [items, setItems] = React.useState([]);
  const [runSheetId, setRunSheetId] = React.useState("");

  React.useEffect(()=>{ (async()=>{
    const { entities } = await getCtx();
    setParks(await entities.Parks.list() || []);
  })(); }, []);

  async function generate(){
    // This functionality needs to be implemented with backend functions
    alert("Run sheet generation coming soon");
  }

  async function toggleStatus(id, current){
    const next = current === "todo" ? "done" : "todo";
    setItems(prev => prev.map(i => i.id === id ? {...i, status: next} : i));
  }

  async function downloadPDF(){
    const parkName = parks.find(p => p.id === parkId)?.name || parkId;
    const blob = await generateRunSheetPDF({ parkName, date, items });
    downloadBlob(blob, `RunSheet-${parkName}-${date}.pdf`);
  }

  return (
    <>
      <NavBar/>
      <div className="container section">
        <h2>Admin — Run Sheets</h2>
        <div className="card" style={{padding:16, display:"grid", gridTemplateColumns:"1fr 1fr auto auto", gap:12, alignItems:"end"}}>
          <label style={{display:"flex",flexDirection:"column",gap:4}}>
            <span style={{fontWeight:600}}>Park</span>
            <select value={parkId} onChange={e=>setParkId(e.target.value)} className="input">
              <option value="">Select park...</option>
              {parks.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </label>
          <label style={{display:"flex",flexDirection:"column",gap:4}}>
            <span style={{fontWeight:600}}>Date</span>
            <input type="date" value={date} onChange={e=>setDate(e.target.value)} className="input"/>
          </label>
          <button onClick={generate} className="btn">Generate</button>
          <button onClick={downloadPDF} disabled={!items.length} className="btn secondary">Download PDF</button>
        </div>

        {items.length > 0 && (
          <div className="card" style={{padding:16, marginTop:16}}>
            <h3 style={{marginTop:0}}>Run Sheet Items</h3>
            <div style={{display:"grid",gap:8}}>
              {items.map((i, idx) => (
                <div key={i.id} style={{
                  padding:12,
                  background:"#f8fafc",
                  borderRadius:8,
                  display:"grid",
                  gridTemplateColumns:"auto 1fr auto auto",
                  gap:12,
                  alignItems:"center"
                }}>
                  <span style={{fontWeight:600}}>{idx+1}.</span>
                  <div>
                    <div style={{fontWeight:600}}>{i.task}</div>
                    <div style={{fontSize:14,color:"#64748b"}}>{i.qtySummary || ""}</div>
                    <div style={{fontSize:12,color:"#94a3b8"}}>Due: {(i.dueAt||"").slice(11,16)}</div>
                  </div>
                  <span className="badge" style={{
                    background: i.status === "done" ? "#dcfce7" : "#fef3c7",
                    color: i.status === "done" ? "#166534" : "#92400e"
                  }}>
                    {i.status}
                  </span>
                  <button onClick={()=>toggleStatus(i.id, i.status)} className="btn" style={{padding:"6px 12px",fontSize:14}}>
                    Toggle
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </>
  );
}