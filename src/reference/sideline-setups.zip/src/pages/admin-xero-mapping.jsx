
import AdminXeroMapping from "./AdminXeroMapping";

export default AdminXeroMapping;
