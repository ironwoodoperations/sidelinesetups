import AdminUpload from "./AdminUpload";

export default AdminUpload;