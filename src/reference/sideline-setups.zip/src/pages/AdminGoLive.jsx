// pages/AdminGoLive.jsx
import React from "react";
import { getCtx } from "../components/lib/ctx";

/** The canonical checklist structure (matches your plain-text list) */
const CHECKLIST = [
  {
    section: "Pre-Deployment Verification",
    items: [
      { key: "systemcheck_ok", label: "/systemcheck shows all env vars present" },
      { key: "sitesettings_ok", label: "SiteSettings record exists and is filled (brand, mode, heroes…)" },
      { key: "defaults_ok", label: "Default sport/theme set (softball, light)" },
    ],
  },
  {
    section: "Database & Seed Data",
    items: [
      { key: "parks_ready", label: "Parks imported (FieldFlex Park / Lone Star Sports Plex)" },
      { key: "fields_ready", label: "Fields created (Diamond A/B, Soccer 1)" },
      { key: "spots_ready", label: "Spots mapped with 0–100 coords" },
      { key: "packages_ready", label: "Packages active (MVP Setup / Fan Zone)" },
      { key: "events_ready", label: "Events active (Spring Classic / Soccer Showdown)" },
      { key: "equipment_ready", label: "Equipment inventory populated" },
      { key: "staff_record", label: "At least one Staff member record exists" }
    ],
  },
  {
    section: "Frontend Visual Audit",
    items: [
      { key: "home_branding", label: "Home hero + logo + colors render" },
      { key: "buttons_style", label: "Buttons styled + hover animations" },
      { key: "events_grid", label: "Events grid shows images + CTA" },
      { key: "booking_ui", label: "Booking fields & totals visible" },
      { key: "thankyou_qr", label: "Thank-You shows QR link + wallet btn" },
      { key: "checkin_page", label: "Check-In renders OK after scan" },
    ],
  },
  {
    section: "Functional Smoke Tests",
    items: [
      { key: "paypal_sandbox", label: "PayPal sandbox approves successfully" },
      { key: "booking_created", label: "Booking row created (status=pending)" },
      { key: "payment_event", label: "PaymentEvents row logged" },
      { key: "checkin_confirm", label: "Check-In sets status=confirmed" },
      { key: "staff_clock", label: "Staff Clock In creates Timeclock row" },
      { key: "setup_ready", label: "Mark Ready creates SetupUpdate + SMS log" },
      { key: "email_receipt", label: "Core.SendEmail receipt sent" },
      { key: "locks_hold", label: "Locks prevent double-book for 5 mins" },
    ],
  },
  {
    section: "COGS / Inventory",
    items: [
      { key: "rented_qty", label: "Equipment rentedQty increments" },
      { key: "cogs_dashboard", label: "COGS dashboard shows cost vs income" },
      { key: "returns_ok", label: "safeAdjustEquipment returns inventory" },
    ],
  },
  {
    section: "Mobile / Staff Readiness",
    items: [
      { key: "staff_dash_mobile", label: "Staff Dashboard works on phones" },
      { key: "clock_buttons", label: "Clock In/Out responsive" },
      { key: "mark_ready_mobile", label: "Mark Ready works on phones" },
      { key: "qr_scan_flow", label: "Phone camera opens QR check-in" },
    ],
  },
  {
    section: "Twilio & Email",
    items: [
      { key: "twilio_logs", label: "Twilio test-mode logs visible" },
      { key: "support_email", label: "Support email receives messages" },
      { key: "twilio_live_toggle", label: "Flip twilioTestMode=false after verify" },
    ],
  },
  {
    section: "Final Launch Switches",
    items: [
      { key: "paypal_live", label: "Switch paypalMode=live + live Client ID" },
      { key: "ssl_ok", label: "Domain SSL active (https on Vercel)" },
      { key: "wallet_prod", label: "Replace wallet stub with real endpoint" },
      { key: "hero_final", label: "Final hero photos in place" },
      { key: "announce_soft", label: "Soft launch announcement posted" },
    ],
  },
  {
    section: "Post-Launch Monitoring",
    items: [
      { key: "monitor_bookings", label: "Review Bookings/PaymentEvents hourly" },
      { key: "locks_expire", label: "Locks expire correctly after 5 mins" },
      { key: "email_sms_ok", label: "Email/SMS delivery healthy" },
      { key: "watch_errors", label: "Watch console for PayPal/Twilio errors" },
      { key: "staff_feedback", label: "Collect staff setup issues" },
    ],
  },
];

function Field({ label, children }) {
  return (
    <label style={{ display: "block", marginBottom: 12 }}>
      <div style={{ fontSize: 12, opacity: 0.8, marginBottom: 6 }}>{label}</div>
      {children}
    </label>
  );
}

export default function AdminGoLive() {
  const [runs, setRuns] = React.useState([]);
  const [parks, setParks] = React.useState([]);
  const [activeRun, setActiveRun] = React.useState(null);
  const [saving, setSaving] = React.useState(false);
  const [who, setWho] = React.useState("");
  const [settings, setSettings] = React.useState(null);
  const [entities, setEntities] = React.useState(null);

  React.useEffect(() => {
    (async () => {
      const { entities, settings } = await getCtx();
      setSettings(settings || {});
      setEntities(entities);
      const [p, r] = await Promise.all([
        entities.Parks.list(),
        entities.GoLiveRun.list(),
      ]);
      setParks(p || []);
      setRuns((r || []).sort((a,b) => new Date(b.created_date || 0) - new Date(a.created_date || 0)));
    })();
  }, []);

  async function createRun(e) {
    e.preventDefault();
    const { entities } = await getCtx();
    const fd = new FormData(e.currentTarget);
    const payload = {
      title: fd.get("title") || `Go-Live ${new Date().toLocaleDateString()}`,
      date: fd.get("date") || new Date().toISOString().slice(0,10),
      parkId: fd.get("parkId") || "",
      notes: fd.get("notes") || "",
      status: "in_progress",
      createdBy: fd.get("createdBy") || who || "ops",
    };
    const row = await entities.GoLiveRun.create(payload);
    setRuns([row, ...runs]);
    setActiveRun(row);
    e.target.reset();
  }

  async function toggleItem(section, item) {
    if (!activeRun) return;
    setSaving(true);
    try {
      const { entities } = await getCtx();
      const existing = await entities.GoLiveCheck.filter({ runId: activeRun.id, itemKey: item.key });
      const now = new Date().toISOString();
      
      if (existing?.length) {
        const row = existing[0];
        await entities.GoLiveCheck.update(row.id, {
          passed: !row.passed,
          timestamp: now,
          who,
        });
      } else {
        await entities.GoLiveCheck.create({
          runId: activeRun.id,
          section,
          itemKey: item.key,
          label: item.label,
          passed: true,
          comment: "",
          who,
          timestamp: now
        });
      }
    } finally {
      setSaving(false);
    }
  }

  async function saveComment(itemKey, comment) {
    if (!activeRun) return;
    const { entities } = await getCtx();
    const existing = await entities.GoLiveCheck.filter({ runId: activeRun.id, itemKey });
    const now = new Date().toISOString();
    
    if (existing?.length) {
      await entities.GoLiveCheck.update(existing[0].id, { comment, timestamp: now, who });
    } else {
      await entities.GoLiveCheck.create({
        runId: activeRun.id,
        section: "",
        itemKey,
        label: "",
        passed: false,
        comment,
        who,
        timestamp: now
      });
    }
  }

  async function markComplete() {
    if (!activeRun) return;
    const { entities } = await getCtx();
    const row = await entities.GoLiveRun.update(activeRun.id, { 
      status: "complete"
    });
    setActiveRun(row);
    setRuns(runs.map(r => r.id === row.id ? row : r));
  }

  async function selectRun(id) {
    if (!id) { setActiveRun(null); return; }
    const { entities } = await getCtx();
    const row = await entities.GoLiveRun.get({ id });
    setActiveRun(row || null);
  }

  // ======== EXPORT HELPERS ========

  async function fetchChecksByRun(runId) {
    const { entities } = await getCtx();
    const rows = await entities.GoLiveCheck.filter({ runId });
    const map = {};
    (rows || []).forEach(r => { map[r.itemKey] = r; });
    return map;
  }

  function csvEscape(val) {
    if (val == null) return "";
    const s = String(val);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }

  async function exportCSV() {
    if (!activeRun) return alert("Select a run first.");
    const checks = await fetchChecksByRun(activeRun.id);
    const header = [
      "RunTitle","RunDate","ParkId","Status","Section","ItemKey","Label","Passed","Comment","Who","Timestamp"
    ];
    const rows = [];

    CHECKLIST.forEach(sec => {
      sec.items.forEach(item => {
        const rec = checks[item.key] || {};
        rows.push([
          activeRun.title || "",
          activeRun.date || "",
          activeRun.parkId || "",
          activeRun.status || "",
          sec.section,
          item.key,
          item.label,
          rec.passed ? "YES" : "NO",
          rec.comment || "",
          rec.who || "",
          rec.timestamp || ""
        ]);
      });
    });

    const csv = [
      header.map(csvEscape).join(","),
      ...rows.map(r => r.map(csvEscape).join(","))
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `GoLive_${(activeRun.title||"run").replace(/\s+/g,"_")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  async function ensureJsPDF() {
    if (window.jspdf?.jsPDF) return window.jspdf.jsPDF;
    try {
      const mod = await import("jspdf");
      return mod.jsPDF || mod.default?.jsPDF || mod.default;
    } catch {
      alert("jsPDF not found. Add CDN script or install npm:jspdf.");
      throw new Error("jsPDF missing");
    }
  }

  async function exportPDF() {
    if (!activeRun) return alert("Select a run first.");
    const jsPDF = await ensureJsPDF();
    const doc = new jsPDF({ unit: "pt", format: "letter" });
    let y = 60;

    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.text("Sideline Setups — Game Day Go-Live Report", 50, y); y += 24;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(11);
    doc.text(`Title: ${activeRun.title || ""}`, 50, y); y += 16;
    doc.text(`Date: ${activeRun.date || ""}`, 50, y); y += 16;
    doc.text(`Park ID: ${activeRun.parkId || ""}`, 50, y); y += 16;
    doc.text(`Status: ${activeRun.status || ""}`, 50, y); y += 24;

    const checks = await fetchChecksByRun(activeRun.id);

    CHECKLIST.forEach(sec => {
      if (y > 720) { doc.addPage(); y = 60; }
      doc.setFont("helvetica", "bold");
      doc.setFontSize(13);
      doc.text(sec.section, 50, y); y += 16;

      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);

      sec.items.forEach(item => {
        if (y > 760) { doc.addPage(); y = 60; }
        const rec = checks[item.key] || {};
        const mark = rec.passed ? "☑" : "☐";
        doc.text(`${mark}  ${item.label}`, 60, y); y += 14;
        if (rec.comment) {
          const comment = `– Notes: ${rec.comment}`;
          const lines = doc.splitTextToSize(comment, 500);
          lines.forEach(line => {
            if (y > 760) { doc.addPage(); y = 60; }
            doc.text(line, 76, y); y += 14;
          });
        }
      });

      y += 8;
      doc.setDrawColor(220);
      doc.line(50, y, 560, y);
      y += 12;
    });

    doc.save(`GoLive_${(activeRun.title||"run").replace(/\s+/g,"_")}.pdf`);
  }

  function ItemRow({ section, item }) {
    const [comment, setComment] = React.useState("");
    const [checked, setChecked] = React.useState(false);
    
    React.useEffect(() => {
      (async () => {
        if (!activeRun || !entities) return;
        const m = await entities.GoLiveCheck.filter({ runId: activeRun.id, itemKey: item.key });
        if (m?.length) {
          setChecked(!!m[0].passed);
          setComment(m[0].comment || "");
        }
      })();
    }, [activeRun?.id, item.key]);

    return (
      <div style={{
        display: "grid",
        gridTemplateColumns: "28px 1fr",
        gap: 10,
        padding: "10px 12px",
        border: "1px solid var(--border)",
        borderRadius: 10,
        marginBottom: 10,
        background: "white"
      }}>
        <input
          type="checkbox"
          checked={checked}
          onChange={async () => {
            setChecked(!checked);
            await toggleItem(section, item);
          }}
          disabled={!activeRun || saving}
        />
        <div>
          <div style={{ fontWeight: 600 }}>{item.label}</div>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            onBlur={() => saveComment(item.key, comment)}
            placeholder="Notes / exceptions / links"
            rows={2}
            className="textarea"
            style={{ marginTop: 6, fontSize: 14 }}
            disabled={!activeRun}
          />
        </div>
      </div>
    );
  }

  if (!entities) {
    return (
      <>
        <div className="nav">
          <div className="container nav-inner">
            <a className="brand" href="/">
              <span className="badge">SS</span>
              <span>Sideline Setups</span>
            </a>
          </div>
        </div>
        <main>
          <div style={{ maxWidth: 1100, margin: "30px auto", padding: "0 16px" }}>
            <div className="card card-pad">Loading...</div>
          </div>
        </main>
      </>
    );
  }

  return (
    <>
      <div className="nav">
        <div className="container nav-inner">
          <a className="brand" href="/">
            <span className="badge">SS</span>
            <span>{settings?.brandName || "Sideline Setups"}</span>
          </a>
          <div className="nav-links">
            <a className="btn-ghost" href="/admindashboard">Admin</a>
          </div>
        </div>
      </div>

      <main>
        <div style={{ maxWidth: 1100, margin: "30px auto", padding: "0 16px" }}>
          <h1 style={{ fontSize: 28, fontWeight: 800, marginBottom: 6 }}>Game Day Go-Live Checklist</h1>
          <div style={{ opacity: 0.75, marginBottom: 18 }}>
            Fill on-site via phone/tablet. Auto-saves into GoLiveRun & GoLiveCheck.
          </div>

          {/* Operator header */}
          <div className="card card-pad" style={{ marginBottom: 16 }}>
            <div className="row">
              <Field label="Your Name (who)">
                <input
                  className="input"
                  value={who}
                  onChange={(e) => setWho(e.target.value)}
                  placeholder="e.g., Alex / Crew Lead"
                />
              </Field>
              <Field label="Active Run">
                <select
                  className="select"
                  value={activeRun?.id || ""}
                  onChange={(e) => selectRun(e.target.value)}
                >
                  <option value="">— Select or create a run below —</option>
                  {runs.map(r => (
                    <option key={r.id} value={r.id}>
                      {r.title} · {r.date} · {r.status}
                    </option>
                  ))}
                </select>
              </Field>
            </div>
          </div>

          {/* Create run */}
          <form onSubmit={createRun} className="card card-pad" style={{ marginBottom: 24 }}>
            <h3 style={{ margin: 0, marginBottom: 12 }}>Start a new Go-Live Run</h3>
            <div className="row">
              <Field label="Title">
                <input
                  className="input"
                  name="title"
                  placeholder="e.g., Spring Classic Day 1"
                />
              </Field>
              <Field label="Date">
                <input
                  className="input"
                  name="date"
                  type="date"
                  defaultValue={new Date().toISOString().slice(0,10)}
                />
              </Field>
            </div>
            <div className="row">
              <Field label="Park">
                <select className="select" name="parkId">
                  <option value="">— Select a Park —</option>
                  {(parks||[]).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </Field>
              <Field label="Created by (optional)">
                <input
                  className="input"
                  name="createdBy"
                  placeholder="Your name"
                  defaultValue={who}
                />
              </Field>
            </div>
            <Field label="Notes">
              <textarea
                className="textarea"
                name="notes"
                placeholder="Any special considerations for today…"
                rows={2}
              />
            </Field>
            <button type="submit" className="btn">
              Create & Set Active
            </button>
          </form>

          {/* Checklist */}
          {!activeRun ? (
            <div className="card card-pad">
              Create or select a run above to start checking items.
            </div>
          ) : (
            <div>
              {CHECKLIST.map(sec => (
                <div key={sec.section} style={{ marginBottom: 26 }}>
                  <h3 style={{ margin: 0, marginBottom: 10 }}>{sec.section}</h3>
                  {sec.items.map(item => (
                    <ItemRow
                      key={item.key}
                      section={sec.section}
                      item={item}
                    />
                  ))}
                </div>
              ))}

              <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 8 }}>
                <button onClick={exportCSV} className="btn-outline">
                  Download CSV
                </button>
                <button onClick={exportPDF} className="btn-outline">
                  Download PDF
                </button>
                <button
                  onClick={markComplete}
                  disabled={activeRun?.status === "complete"}
                  className="btn"
                  style={{
                    background: activeRun?.status === "complete" ? "var(--success)" : undefined
                  }}
                >
                  {activeRun?.status === "complete" ? "Completed ✓" : "Mark Run Complete"}
                </button>
                {saving && <div style={{ alignSelf: "center", opacity: 0.7 }}>Saving…</div>}
              </div>
            </div>
          )}
        </div>
      </main>

      <footer className="footer">
        <div className="container">
          © {new Date().getFullYear()} {settings?.brandName || "Sideline Setups"} — All rights reserved.
        </div>
      </footer>
    </>
  );
}