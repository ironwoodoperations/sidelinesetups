
import React, { useState, useEffect } from "react";
import { getCtx } from "../components/lib/ctx";
import { Calendar, MapPin, ExternalLink, Mail } from "lucide-react";

export default function Events() {
  const [allEvents, setAllEvents] = useState([]);
  const [settings, setSettings] = useState(null);
  const [selectedSport, setSelectedSport] = useState("softball");
  const [selectedType, setSelectedType] = useState("all"); // all, tournament, league
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const { entities, settings } = await getCtx();
      setSettings(settings || {});
      const rows = await entities.Events.filter({ isActive: true });
      setAllEvents(rows || []);
    } catch (error) {
      console.error("Failed to load events:", error);
      setAllEvents([]);
    } finally {
      setLoading(false);
    }
  };

  const filteredEvents = allEvents.filter(event => {
    const sportMatch = event.sport === selectedSport;
    const typeMatch = selectedType === "all" || event.eventType === selectedType;
    return sportMatch && typeMatch;
  });

  // Hardcoded sport images with provided URLs
  const fallbackImages = {
    softball: "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/17a3ba488_cameron-cox-TZFtzfnZuzc-unsplash.jpg",
    baseball: "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/96e85a991_mike-bowman-xKShyIiTNJk-unsplash.jpg",
    soccer: "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/fc0a60797_vikram-tkv-JO19K0HDDXI-unsplash.jpg",
  };

  const sportIcons = {
    softball: "⚾",
    baseball: "⚾",
    soccer: "⚽"
  };

  const sportNames = {
    softball: "Softball",
    baseball: "Baseball",
    soccer: "Soccer"
  };

  return (
    <div
      className="min-h-screen"
      style={{
        backgroundImage: settings?.pageBackgroundPatternUrl
          ? `linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.92)), url('${settings.pageBackgroundPatternUrl}')`
          : undefined,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
      <div className="max-w-7xl mx-auto px-4 py-12">
        <h1 style={{ textAlign: "center", marginBottom: 8 }}>Upcoming Events</h1>
        <p style={{ textAlign: "center", color: "var(--muted)", marginBottom: 32 }}>
          Find your event and reserve your sideline setup
        </p>

        {/* Sport Tabs */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: 16,
          maxWidth: 900,
          margin: "0 auto 32px auto"
        }}>
          {["softball", "baseball", "soccer"].map(sport => (
            <button
              key={sport}
              onClick={() => {
                setSelectedSport(sport);
                setSelectedType("all");
              }}
              style={{
                background: selectedSport === sport ? "var(--brand)" : "white",
                color: selectedSport === sport ? "white" : "var(--ink)",
                border: selectedSport === sport ? "2px solid var(--brand)" : "2px solid var(--border)",
                borderRadius: 16,
                padding: "24px 16px",
                cursor: "pointer",
                transition: "all 0.2s",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 12,
                fontSize: 16,
                fontWeight: 600
              }}
              className="sport-tab"
            >
              <div style={{ fontSize: 48 }}>{sportIcons[sport]}</div>
              <div>{sportNames[sport]}</div>
            </button>
          ))}
        </div>

        {/* Type Filter */}
        <div style={{
          display: "flex",
          justifyContent: "center",
          gap: 12,
          marginBottom: 32,
          flexWrap: "wrap"
        }}>
          <button
            onClick={() => setSelectedType("all")}
            className={selectedType === "all" ? "btn" : "btn-outline"}
            style={{ minWidth: 120 }}
          >
            All Events
          </button>
          <button
            onClick={() => setSelectedType("tournament")}
            className={selectedType === "tournament" ? "btn" : "btn-outline"}
            style={{ minWidth: 120 }}
          >
            Tournaments
          </button>
          <button
            onClick={() => setSelectedType("league")}
            className={selectedType === "league" ? "btn" : "btn-outline"}
            style={{ minWidth: 120 }}
          >
            Leagues
          </button>
        </div>

        {/* Loading State */}
        {loading && (
          <div style={{ textAlign: "center", padding: "60px 0" }}>
            <div className="spinner"></div>
            <p style={{ marginTop: 16, color: "var(--muted)" }}>Loading events...</p>
          </div>
        )}

        {/* Events Grid */}
        {!loading && filteredEvents.length > 0 && (
          <div className="grid grid-3" style={{ gap: 20 }}>
            {filteredEvents.map(event => (
              <div key={event.id} className="card card-event">
                <div className="img">
                  <img
                    src={event.imageUrl || fallbackImages[event.sport] || fallbackImages.softball}
                    alt={event.name}
                  />
                </div>
                <div className="body">
                  <div className="kicker">
                    {event.eventType === "tournament" ? "🏆 Tournament" : "🏅 League"} • {sportNames[event.sport]}
                  </div>
                  <h3 style={{ margin: "8px 0 12px 0" }}>{event.name}</h3>

                  <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 16 }}>
                    {event.city && (
                      <div style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 14 }}>
                        <MapPin size={14} />
                        <span>{event.city}</span>
                      </div>
                    )}
                    {(event.startDate || event.endDate) && (
                      <div style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 14 }}>
                        <Calendar size={14} />
                        <span>
                          {event.startDate && new Date(event.startDate).toLocaleDateString()}
                          {event.endDate && ` - ${new Date(event.endDate).toLocaleDateString()}`}
                        </span>
                      </div>
                    )}
                  </div>

                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <a className="btn" href={`/book?event=${event.id}`} style={{ flex: 1, textAlign: "center" }}>
                      Book Now
                    </a>
                    {event.website && (
                      <a
                        className="btn-outline"
                        href={event.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{ padding: "10px 12px" }}
                        title="Visit event website"
                      >
                        <ExternalLink size={18} />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* No Events - Contact Us */}
        {!loading && filteredEvents.length === 0 && (
          <div className="card card-pad" style={{ maxWidth: 600, margin: "0 auto", textAlign: "center" }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>{sportIcons[selectedSport]}</div>
            <h2 style={{ margin: "0 0 12px 0" }}>No {sportNames[selectedSport]} Events Yet</h2>
            <p style={{ color: "var(--muted)", marginBottom: 24, lineHeight: 1.6 }}>
              We're not scheduled for any {sportNames[selectedSport].toLowerCase()} {selectedType === "all" ? "events" : selectedType + "s"} right now,
              but we'd love to come to your event!
            </p>

            <div style={{
              background: "var(--bg-2)",
              padding: 24,
              borderRadius: 12,
              marginBottom: 24
            }}>
              <h3 style={{ margin: "0 0 16px 0", fontSize: 18 }}>Request Us for Your Event</h3>
              <p style={{ color: "var(--muted)", fontSize: 14, marginBottom: 16 }}>
                Contact us to bring Sideline Setups to your {selectedType === "tournament" ? "tournament" : selectedType === "league" ? "league" : "event"}.
              </p>

              <a
                href={`mailto:${settings?.supportEmail || "support@sidelinesetups.com"}?subject=Event Request - ${sportNames[selectedSport]}&body=Hi! I'd like to request Sideline Setups for my ${selectedType === "all" ? "event" : selectedType}.%0D%0A%0D%0AEvent Name:%0D%0ALocation:%0D%0ADate:%0D%0AExpected Teams:%0D%0A%0D%0AAdditional Info:%0D%0A`}
                className="btn"
                style={{ display: "inline-flex", alignItems: "center", gap: 8 }}
              >
                <Mail size={18} />
                Contact Us
              </a>
            </div>

            <p style={{ fontSize: 14, color: "var(--muted)" }}>
              Or check out our other {selectedType === "all" ? "events" : selectedType + "s"}:
            </p>
            <div style={{ display: "flex", gap: 8, justifyContent: "center", marginTop: 12, flexWrap: "wrap" }}>
              {["softball", "baseball", "soccer"].filter(s => s !== selectedSport).map(sport => (
                <button
                  key={sport}
                  onClick={() => setSelectedSport(sport)}
                  className="btn-outline"
                >
                  {sportIcons[sport]} {sportNames[sport]}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
