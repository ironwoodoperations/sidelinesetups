import React, { useState, useEffect } from "react";
import { base44 } from "../api/base44Client";
import { Calendar, Filter, Printer, ArrowLeft, RefreshCw } from "lucide-react";
import PullSheetCard from "../components/admin/PullSheetCard";

export default function PullSheets() {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [events, setEvents] = useState([]);
  const [parks, setParks] = useState([]);
  const [selectedEventId, setSelectedEventId] = useState('all');
  const [selectedParkId, setSelectedParkId] = useState('all');
  const [pullSheets, setPullSheets] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadFilters();
  }, []);

  const loadFilters = async () => {
    try {
      const [eventsData, parksData] = await Promise.all([
        base44.entities.Events.list(),
        base44.entities.Parks.list()
      ]);
      setEvents(eventsData || []);
      setParks(parksData || []);
    } catch (error) {
      console.error("Failed to load filters:", error);
    }
  };

  const loadPullSheets = async () => {
    if (!date) {
      alert("Please select a date");
      return;
    }

    setLoading(true);
    try {
      const payload = {
        date: date
      };

      if (selectedEventId && selectedEventId !== 'all') {
        payload.eventId = selectedEventId;
      }

      if (selectedParkId && selectedParkId !== 'all') {
        payload.parkId = selectedParkId;
      }

      const response = await base44.functions.invoke('generatePullSheetData', payload);

      setPullSheets(response.data || []);
    } catch (error) {
      console.error("Failed to load pull sheets:", error);
      alert("Failed to load pull sheets: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkSetup = async (bookingId, checklist) => {
    try {
      await base44.functions.invoke('markBookingSetup', { bookingId, checklist });
      alert("Setup marked and customer notified!");
      loadPullSheets(); // Reload to update statuses
    } catch (error) {
      console.error("Failed to mark setup:", error);
      alert("Failed to mark setup: " + error.message);
    }
  };

  const handleMarkReturned = async (bookingId, checklist) => {
    try {
      await base44.functions.invoke('markBookingReturned', { bookingId, checklist });
      alert("Equipment marked as returned and customer notified!");
      loadPullSheets(); // Reload to update statuses
    } catch (error) {
      console.error("Failed to mark returned:", error);
      alert("Failed to mark returned: " + error.message);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div>
      {/* Filters Section - Hidden when printing */}
      <div className="no-print" style={{ marginBottom: '24px' }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '20px'
        }}>
          <h2 style={{ margin: 0, fontSize: '24px', fontWeight: '700', color: '#003f5c' }}>
            Pull Sheets
          </h2>
          <a
            href="/staff-dashboard"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              color: '#003f5c',
              textDecoration: 'none',
              padding: '8px 16px',
              border: '1px solid #003f5c',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: '600',
              transition: 'all 0.2s'
            }}
            onMouseEnter={(e) => e.target.style.background = '#f8fafc'}
            onMouseLeave={(e) => e.target.style.background = 'transparent'}
          >
            <ArrowLeft size={16} />
            Back to Dashboard
          </a>
        </div>

        <div className="card" style={{ padding: '20px' }}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '16px',
            marginBottom: '16px'
          }}>
            <div>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontSize: '14px',
                fontWeight: '600',
                color: '#0f172a'
              }}>
                Date *
              </label>
              <input
                type="date"
                className="input"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>

            <div>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontSize: '14px',
                fontWeight: '600',
                color: '#0f172a'
              }}>
                Event
              </label>
              <select
                className="select"
                value={selectedEventId}
                onChange={(e) => setSelectedEventId(e.target.value)}
              >
                <option value="all">All Events</option>
                {events.map(event => (
                  <option key={event.id} value={event.id}>
                    {event.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontSize: '14px',
                fontWeight: '600',
                color: '#0f172a'
              }}>
                Park
              </label>
              <select
                className="select"
                value={selectedParkId}
                onChange={(e) => setSelectedParkId(e.target.value)}
              >
                <option value="all">All Parks</option>
                {parks.map(park => (
                  <option key={park.id} value={park.id}>
                    {park.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '12px' }}>
            <button
              onClick={loadPullSheets}
              disabled={loading || !date}
              className="btn"
              style={{
                background: 'linear-gradient(to right, #003f5c, #00507a)',
                color: 'white',
                border: 'none',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
            >
              {loading ? (
                <>
                  <RefreshCw size={16} className="animate-spin" />
                  Loading...
                </>
              ) : (
                <>
                  <Filter size={16} />
                  Generate Pull Sheets
                </>
              )}
            </button>

            {pullSheets.length > 0 && (
              <button
                onClick={handlePrint}
                className="btn-outline"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  color: '#003f5c',
                  borderColor: '#003f5c'
                }}
              >
                <Printer size={16} />
                Print All Pull Sheets
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Pull Sheets Display */}
      {loading && (
        <div style={{ textAlign: 'center', padding: '40px' }}>
          <div className="spinner"></div>
          <p style={{ marginTop: '16px', color: '#64748b' }}>Loading pull sheets...</p>
        </div>
      )}

      {!loading && pullSheets.length === 0 && date && (
        <div className="card" style={{ padding: '40px', textAlign: 'center' }}>
          <Calendar size={48} style={{ margin: '0 auto 16px', color: '#cbd5e1' }} />
          <h3 style={{ margin: '0 0 8px 0', color: '#64748b' }}>No Pull Sheets Found</h3>
          <p style={{ margin: 0, color: '#94a3b8', fontSize: '14px' }}>
            No bookings found for the selected date and filters.
          </p>
        </div>
      )}

      {!loading && pullSheets.length > 0 && (
        <div>
          {pullSheets.map((pullSheet, index) => (
            <PullSheetCard 
              key={index} 
              pullSheet={pullSheet}
              onMarkSetup={handleMarkSetup}
              onMarkReturned={handleMarkReturned}
              isStaffView={true}
            />
          ))}
        </div>
      )}

      {/* Print Styles */}
      <style>{`
        @media print {
          .no-print {
            display: none !important;
          }
          
          body {
            background: white;
          }
          
          @page {
            size: letter;
            margin: 0.5in;
          }
        }
      `}</style>
    </div>
  );
}