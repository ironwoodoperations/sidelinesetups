import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Save, AlertCircle, CheckCircle } from "lucide-react";

export default function AdminXeroMapping() {
  const [packages, setPackages] = useState([]);
  const [addOns, setAddOns] = useState([]);
  const [mappings, setMappings] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    try {
      const [pkgs, addons, settings] = await Promise.all([
        base44.entities.Packages.list(),
        base44.entities.AddOns.list(),
        base44.entities.SiteSettings.list()
      ]);
      
      setPackages(pkgs || []);
      setAddOns(addons || []);
      setMappings((settings[0]?.xeroAccountMappings) || {});
    } catch (error) {
      console.error("Failed to load data:", error);
      setMessage({ type: "error", text: "Failed to load data: " + error.message });
    } finally {
      setLoading(false);
    }
  }

  async function handleSave() {
    setSaving(true);
    setMessage(null);

    try {
      const settings = (await base44.entities.SiteSettings.list())[0];
      
      if (settings?.id) {
        await base44.entities.SiteSettings.update(settings.id, {
          xeroAccountMappings: mappings
        });
      } else {
        await base44.entities.SiteSettings.create({
          xeroAccountMappings: mappings
        });
      }

      setMessage({ type: "success", text: "Account mappings saved successfully!" });
    } catch (error) {
      console.error("Failed to save mappings:", error);
      setMessage({ type: "error", text: "Failed to save: " + error.message });
    } finally {
      setSaving(false);
    }
  }

  function updateMapping(id, accountCode) {
    setMappings(prev => ({
      ...prev,
      [id]: accountCode || undefined
    }));
  }

  if (loading) {
    return (
      <div style={{ padding: "40px", textAlign: "center" }}>
        <div className="spinner"></div>
        <p style={{ marginTop: "16px", color: "#64748b" }}>Loading mappings...</p>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: "24px" }}>
        <h2 style={{ margin: "0 0 8px 0", fontSize: "24px", fontWeight: "700", color: "#003f5c" }}>
          Xero Account Mapping
        </h2>
        <p style={{ margin: 0, color: "#64748b", fontSize: "14px" }}>
          Map packages and add-ons to specific Xero account codes for accurate categorization
        </p>
      </div>

      {/* Message */}
      {message && (
        <div style={{
          padding: "16px",
          marginBottom: "24px",
          borderRadius: "8px",
          background: message.type === "success" ? "#d1fae5" : "#fee2e2",
          color: message.type === "success" ? "#065f46" : "#991b1b",
          border: `1px solid ${message.type === "success" ? "#10b981" : "#ef4444"}`
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            {message.type === "success" ? <CheckCircle size={20} /> : <AlertCircle size={20} />}
            <span>{message.text}</span>
          </div>
        </div>
      )}

      {/* Info Box */}
      <div style={{
        background: "#eff6ff",
        border: "1px solid #93c5fd",
        borderRadius: "8px",
        padding: "16px",
        marginBottom: "24px"
      }}>
        <p style={{ margin: "0 0 8px 0", color: "#1e40af", fontWeight: "600", fontSize: "14px" }}>
          How Account Mapping Works:
        </p>
        <ul style={{ margin: 0, paddingLeft: "20px", color: "#1e3a8a", fontSize: "13px", lineHeight: "1.6" }}>
          <li>Leave blank to use the default account code from your site settings</li>
          <li>Enter a specific Xero account code (e.g., "200", "400") to categorize revenue</li>
          <li>Common codes: 200 (Sales), 400 (Product Sales), 460 (Service/Fee Income)</li>
        </ul>
      </div>

      {/* Packages */}
      <div style={{
        background: "white",
        borderRadius: "12px",
        border: "1px solid #e2e8f0",
        overflow: "hidden",
        marginBottom: "24px"
      }}>
        <div style={{ background: "#003f5c", padding: "16px 24px" }}>
          <h3 style={{ margin: 0, color: "white", fontSize: "18px", fontWeight: "700" }}>
            Packages
          </h3>
        </div>
        <div style={{ padding: "24px" }}>
          {packages.length === 0 ? (
            <p style={{ margin: 0, color: "#64748b", textAlign: "center" }}>No packages found</p>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ borderBottom: "2px solid #e2e8f0" }}>
                  <th style={{ padding: "12px", textAlign: "left", fontSize: "12px", fontWeight: "600", color: "#64748b", textTransform: "uppercase" }}>
                    Package Name
                  </th>
                  <th style={{ padding: "12px", textAlign: "left", fontSize: "12px", fontWeight: "600", color: "#64748b", textTransform: "uppercase" }}>
                    Xero Account Code
                  </th>
                </tr>
              </thead>
              <tbody>
                {packages.map(pkg => (
                  <tr key={pkg.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                    <td style={{ padding: "12px", fontSize: "14px", color: "#0f172a", fontWeight: "600" }}>
                      {pkg.name}
                    </td>
                    <td style={{ padding: "12px" }}>
                      <input
                        type="text"
                        value={mappings[pkg.id] || ""}
                        onChange={(e) => updateMapping(pkg.id, e.target.value)}
                        placeholder="e.g., 200 (default if blank)"
                        style={{
                          width: "200px",
                          padding: "8px 12px",
                          border: "1px solid #e2e8f0",
                          borderRadius: "6px",
                          fontSize: "14px"
                        }}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Add-Ons */}
      <div style={{
        background: "white",
        borderRadius: "12px",
        border: "1px solid #e2e8f0",
        overflow: "hidden",
        marginBottom: "24px"
      }}>
        <div style={{ background: "#003f5c", padding: "16px 24px" }}>
          <h3 style={{ margin: 0, color: "white", fontSize: "18px", fontWeight: "700" }}>
            Add-Ons
          </h3>
        </div>
        <div style={{ padding: "24px" }}>
          {addOns.length === 0 ? (
            <p style={{ margin: 0, color: "#64748b", textAlign: "center" }}>No add-ons found</p>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ borderBottom: "2px solid #e2e8f0" }}>
                  <th style={{ padding: "12px", textAlign: "left", fontSize: "12px", fontWeight: "600", color: "#64748b", textTransform: "uppercase" }}>
                    Add-On Name
                  </th>
                  <th style={{ padding: "12px", textAlign: "left", fontSize: "12px", fontWeight: "600", color: "#64748b", textTransform: "uppercase" }}>
                    Xero Account Code
                  </th>
                </tr>
              </thead>
              <tbody>
                {addOns.map(addon => (
                  <tr key={addon.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                    <td style={{ padding: "12px", fontSize: "14px", color: "#0f172a", fontWeight: "600" }}>
                      {addon.label}
                    </td>
                    <td style={{ padding: "12px" }}>
                      <input
                        type="text"
                        value={mappings[addon.id] || ""}
                        onChange={(e) => updateMapping(addon.id, e.target.value)}
                        placeholder="e.g., 200 (default if blank)"
                        style={{
                          width: "200px",
                          padding: "8px 12px",
                          border: "1px solid #e2e8f0",
                          borderRadius: "6px",
                          fontSize: "14px"
                        }}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Save Button */}
      <div style={{ display: "flex", justifyContent: "flex-end", gap: "12px" }}>
        <a
          href="/admin"
          style={{
            padding: "10px 20px",
            background: "white",
            color: "#64748b",
            border: "1px solid #e2e8f0",
            borderRadius: "8px",
            fontSize: "14px",
            fontWeight: "600",
            textDecoration: "none",
            display: "inline-block"
          }}
        >
          Back to Admin
        </a>
        <button
          onClick={handleSave}
          disabled={saving}
          style={{
            padding: "10px 20px",
            background: saving ? "#94a3b8" : "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
            color: "white",
            border: "none",
            borderRadius: "8px",
            fontSize: "14px",
            fontWeight: "600",
            cursor: saving ? "not-allowed" : "pointer",
            display: "flex",
            alignItems: "center",
            gap: "8px"
          }}
        >
          <Save size={16} />
          {saving ? "Saving..." : "Save Mappings"}
        </button>
      </div>
    </div>
  );
}