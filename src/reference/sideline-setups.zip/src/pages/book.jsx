
export { default } from "./book-new";
