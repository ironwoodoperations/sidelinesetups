// pages/SystemCheck.jsx
import React from "react";

export default function SystemCheck() {
  const [settings, setSettings] = React.useState(null);

  React.useEffect(() => {
    (async () => {
      try {
        const { getCtx } = await import("../components/lib/ctx");
        const { settings } = await getCtx();
        setSettings(settings || {});
      } catch (e) {
        console.error("Failed to load settings:", e);
      }
    })();
  }, []);

  const checks = [
    { label: "Brand Name", value: settings?.brandName, type: "setting" },
    { label: "Default Sport", value: settings?.defaultSport, type: "setting" },
    { label: "PayPal Mode", value: settings?.paypalMode, type: "setting" },
    { label: "PayPal Sandbox Client ID", value: settings?.paypalClientIdSandbox, type: "setting" },
    { label: "Support Email", value: settings?.supportEmail, type: "setting" },
    { label: "Hero Softball URL", value: settings?.heroSoftballUrl, type: "setting" },
    { label: "Hero Baseball URL", value: settings?.heroBaseballUrl, type: "setting" },
    { label: "Hero Soccer URL", value: settings?.heroSoccerUrl, type: "setting" },
    { label: "Wallet Provider URL", value: settings?.walletProviderUrl, type: "setting" },
    { label: "Twilio Test Mode", value: settings?.twilioTestMode !== undefined ? String(settings.twilioTestMode) : undefined, type: "setting" },
  ];

  return (
    <>
      <div className="nav">
        <div className="container nav-inner">
          <a className="brand" href="/">
            <span className="badge">SS</span>
            <span>{settings?.brandName || "Sideline Setups"}</span>
          </a>
          <div className="nav-links">
            <a className="btn-ghost" href="/events">Events</a>
            <a className="btn-ghost" href="/mybookings">My Bookings</a>
            <a className="btn-ghost" href="/admindashboard">Admin</a>
          </div>
        </div>
      </div>

      <main>
        <div className="container section">
          <h1>System Check</h1>
          <p className="mt-8">Verify that all settings and configurations are properly set up.</p>
          
          <div className="card card-pad mt-16">
            <h3>Site Settings</h3>
            <table className="table mt-12">
              <thead>
                <tr>
                  <th>Setting</th>
                  <th>Value</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {checks.map((check, idx) => (
                  <tr key={idx}>
                    <td>{check.label}</td>
                    <td style={{maxWidth: 300, overflow: "hidden", textOverflow: "ellipsis"}}>
                      {check.value || <span style={{color: "var(--muted)"}}>—</span>}
                    </td>
                    <td>
                      {check.value ? (
                        <span className="badge badge-success">✅ Set</span>
                      ) : (
                        <span className="badge badge-warn">⚠️ Missing</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="card card-pad mt-16">
            <h3>Quick Actions</h3>
            <div className="mt-12" style={{display:"flex", gap:12, flexWrap:"wrap"}}>
              <a className="btn-outline" href="/adminsettings">Edit Settings</a>
              <a className="btn-outline" href="/adminevents">Manage Events</a>
              <a className="btn-outline" href="/adminpackages">Manage Packages</a>
              <a className="btn-outline" href="/adminparks">Manage Parks</a>
            </div>
          </div>

          <div className="mt-16">
            <a className="btn" href="/">← Back Home</a>
          </div>
        </div>
      </main>

      <footer className="footer">
        <div className="container">
          © {new Date().getFullYear()} {settings?.brandName || "Sideline Setups"} — All rights reserved.
        </div>
      </footer>
    </>
  );
}