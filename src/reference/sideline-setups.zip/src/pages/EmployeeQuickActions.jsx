import React, { useState, useEffect } from "react";
import useSession from "../components/auth/SessionProvider";
import { getCtx } from "../components/lib/ctx";
import { CheckCircle, Search, LogOut } from "lucide-react";

export default function EmployeeQuickActions() {
  const { session, logout } = useSession();
  const [bookings, setBookings] = useState([]);
  const [parks, setParks] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    loadData();
  }, [selectedDate]);

  async function loadData() {
    if (!session?.employee) {
      setLoading(false);
      return;
    }

    try {
      const { entities } = await getCtx();
      
      const [bookingsData, parksData, eventsData] = await Promise.all([
        entities.Bookings.filter({ date: selectedDate }),
        entities.Parks.list(),
        entities.Events.list()
      ]);
      
      setBookings(bookingsData || []);
      setParks(parksData || []);
      setEvents(eventsData || []);
    } catch (error) {
      console.error("Failed to load data:", error);
    } finally {
      setLoading(false);
    }
  }

  async function handleMarkComplete(bookingId) {
    try {
      const { entities } = await getCtx();
      await entities.Bookings.update(bookingId, { status: 'setup' });
      await loadData();
    } catch (error) {
      console.error("Failed to update booking:", error);
      alert("Failed to update booking status");
    }
  }

  if (!session?.employee) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}>
        <div style={{ textAlign: "center" }}>
          <h2>Session Expired</h2>
          <p>Please log in again.</p>
          <a href="/staff-login" className="btn" style={{ marginTop: "16px" }}>
            Go to Login
          </a>
        </div>
      </div>
    );
  }

  const filteredBookings = bookings.filter(b =>
    (b.fullName || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
    (b.teamName || "").toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={{ minHeight: "100vh", background: "#f8fafc" }}>
      {/* Header */}
      <div style={{
        background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
        color: "white",
        padding: "20px",
        boxShadow: "0 2px 8px rgba(0,0,0,0.1)"
      }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "16px" }}>
          <div>
            <h1 style={{ margin: 0, fontSize: "24px", fontWeight: "700" }}>Quick Actions</h1>
            <p style={{ margin: "4px 0 0 0", opacity: 0.9, fontSize: "14px" }}>
              {session.employee.fullName || session.employee.email}
            </p>
          </div>
          
          <div style={{ display: "flex", gap: "12px" }}>
            <a href="/staff-dashboard" className="btn-outline" style={{ color: "white", borderColor: "white" }}>
              ← Back to Dashboard
            </a>
            <button
              onClick={logout}
              style={{
                background: "rgba(255,255,255,0.1)",
                border: "1px solid white",
                color: "white",
                padding: "8px 16px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "8px"
              }}
            >
              <LogOut size={18} />
              Logout
            </button>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div style={{ background: "white", borderBottom: "1px solid #e2e8f0", padding: "16px" }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto", display: "grid", gridTemplateColumns: "1fr auto", gap: "16px", alignItems: "center" }}>
          <div style={{ position: "relative" }}>
            <Search size={20} style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "#64748b" }} />
            <input
              type="text"
              placeholder="Search by customer or team name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{
                width: "100%",
                padding: "10px 12px 10px 44px",
                border: "1px solid #e2e8f0",
                borderRadius: "8px",
                fontSize: "14px"
              }}
            />
          </div>
          
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            style={{
              padding: "10px 12px",
              border: "1px solid #e2e8f0",
              borderRadius: "8px",
              fontSize: "14px"
            }}
          />
        </div>
      </div>

      {/* Bookings List */}
      <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "24px" }}>
        {loading ? (
          <div style={{ textAlign: "center", padding: "40px" }}>
            <div className="spinner"></div>
          </div>
        ) : filteredBookings.length === 0 ? (
          <div className="card" style={{ padding: "40px", textAlign: "center" }}>
            <p style={{ color: "#64748b", margin: 0 }}>
              No bookings found for this date
            </p>
          </div>
        ) : (
          <div style={{ display: "grid", gap: "16px" }}>
            {filteredBookings.map(booking => {
              const event = events.find(e => e.id === booking.eventId);
              const park = parks.find(p => p.id === booking.parkId);
              
              return (
                <div key={booking.id} className="card" style={{ padding: "20px" }}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: "16px", alignItems: "start" }}>
                    <div>
                      <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "8px" }}>
                        <h3 style={{ margin: 0, fontSize: "18px" }}>
                          {booking.fullName || "Unknown Customer"}
                        </h3>
                        <span className={`badge ${
                          booking.status === 'setup' ? 'badge-success' :
                          booking.status === 'confirmed' ? 'badge-warn' :
                          ''
                        }`}>
                          {booking.status}
                        </span>
                      </div>
                      
                      <div style={{ display: "grid", gap: "4px", fontSize: "14px", color: "#64748b" }}>
                        {booking.teamName && <div><strong>Team:</strong> {booking.teamName}</div>}
                        {event && <div><strong>Event:</strong> {event.name}</div>}
                        {park && <div><strong>Park:</strong> {park.name}</div>}
                        {booking.fieldId && <div><strong>Field:</strong> {booking.fieldId}</div>}
                        {booking.spotLabel && <div><strong>Spot:</strong> {booking.spotLabel}</div>}
                      </div>
                    </div>
                    
                    <div style={{ display: "flex", gap: "8px" }}>
                      {booking.status !== 'setup' && (
                        <button
                          onClick={() => handleMarkComplete(booking.id)}
                          className="btn"
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "8px",
                            background: "linear-gradient(135deg, #10b981 0%, #059669 100%)"
                          }}
                        >
                          <CheckCircle size={18} />
                          Mark Setup
                        </button>
                      )}
                      {booking.status === 'setup' && (
                        <div style={{
                          padding: "10px 16px",
                          background: "#d1fae5",
                          color: "#065f46",
                          borderRadius: "8px",
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                          fontSize: "14px",
                          fontWeight: "600"
                        }}>
                          <CheckCircle size={18} />
                          Setup Complete
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}