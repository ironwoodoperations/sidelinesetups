// pages/AdminEvents.jsx
import React from "react";
import NavBar from "../components/NavBar";
import { getCtx } from "../components/lib/ctx";

export default function AdminEvents() {
  const [list, setList] = React.useState([]);
  const [form, setForm] = React.useState({name:"", eventType:"tournament", sport:"softball", city:"", isActive:true});

  async function load() {
    const { entities } = await getCtx();
    setList(await entities.Events.list());
  }
  React.useEffect(()=>{ load(); }, []);

  function update(k,v){ setForm(f=>({...f,[k]:v})); }

  async function add() {
    const { entities } = await getCtx();
    await entities.Events.create(form);
    setForm({name:"", eventType:"tournament", sport:"softball", city:"", isActive:true});
    load();
  }

  async function toggle(id,val){
    const { entities } = await getCtx();
    await entities.Events.update({id,isActive:!val});
    load();
  }

  return (
    <>
      <NavBar/>
      <div style={{padding:"24px 20px",maxWidth:1100,margin:"0 auto"}}>
        <h1>Events</h1>
        <div style={{display:"grid",gap:8,gridTemplateColumns:"1fr 1fr 1fr 1fr auto"}}>
          <input placeholder="Name" value={form.name} onChange={e=>update("name",e.target.value)} />
          <select value={form.eventType} onChange={e=>update("eventType",e.target.value)}>
            <option value="tournament">Tournament</option><option value="league">League</option>
          </select>
          <select value={form.sport} onChange={e=>update("sport",e.target.value)}>
            <option>softball</option><option>baseball</option><option>soccer</option>
          </select>
          <input placeholder="City" value={form.city} onChange={e=>update("city",e.target.value)} />
          <button onClick={add}>Add</button>
        </div>

        <table style={{width:"100%",marginTop:20,borderCollapse:"collapse"}}>
          <thead><tr><th>Name</th><th>Type</th><th>Sport</th><th>City</th><th>Active</th><th></th></tr></thead>
          <tbody>
            {list.map(ev=>(
              <tr key={ev.id}>
                <td>{ev.name}</td>
                <td>{ev.eventType}</td>
                <td>{ev.sport}</td>
                <td>{ev.city}</td>
                <td>{ev.isActive?"✅":"❌"}</td>
                <td><button onClick={()=>toggle(ev.id,ev.isActive)}>Toggle</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}