import { useEffect, useState } from 'react';

export default function StaffSmsPage() {
  const [phone, setPhone] = useState('');
  const [redirectTo, setRedirectTo] = useState('/StaffDashboard');
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const sp = new URLSearchParams(window.location.search);
    const p = sp.get('phone');
    const r = sp.get('redirect');
    if (p) setPhone(p);
    if (r) setRedirectTo(r);
  }, []);

  async function handleVerify(e) {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      const res = await fetch('/functions/auth/verifySmsOtp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind: 'employee_sms', phone, code })
      });

      const data = await res.json();

      if (res.ok && data.ok && data.session) {
        // Store session in sessionStorage (auto-clears on tab close)
        sessionStorage.setItem('ss.session', JSON.stringify(data.session));
        window.location.href = redirectTo;
      } else {
        setMessage(data.error || 'Invalid code');
      }
    } catch (err) {
      setMessage('Verification failed. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-md mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Enter Your Code</h1>
      <p className="text-sm text-gray-600 mb-6">
        We sent a 6-digit code to {phone}
      </p>

      {message && (
        <div style={{
          padding: '12px',
          marginBottom: '16px',
          borderRadius: '8px',
          background: '#fee2e2',
          color: '#991b1b'
        }}>
          {message}
        </div>
      )}

      <form onSubmit={handleVerify} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Verification Code</label>
          <input
            type="text"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="w-full border rounded p-2"
            placeholder="123456"
            required
            inputMode="numeric"
            autoComplete="one-time-code"
            maxLength={6}
          />
        </div>
        <button
          type="submit"
          className="w-full rounded bg-black text-white py-2"
          disabled={loading}
        >
          {loading ? 'Verifying...' : 'Verify Code'}
        </button>
      </form>

      <div className="mt-4 text-center">
        <a href="/staff-login" className="text-sm text-blue-600 hover:underline">
          ← Back to login
        </a>
      </div>
    </div>
  );
}