import React, { useState, useEffect } from "react";
import useSession from "../components/auth/SessionProvider";
import { Clock, LogIn, LogOut as LogOutIcon, CheckCircle } from "lucide-react";

export default function Kiosk() {
  const { session, logout } = useSession();
  const [clockStatus, setClockStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (session?.employee) {
      checkClockStatus();
    }
  }, [session]);

  async function checkClockStatus() {
    if (!session?.employee) return;
    
    try {
      const res = await fetch('/functions/timeClockStatus', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ employeeId: session.employee.id })
      });
      
      const data = await res.json();
      setClockStatus(data);
    } catch (error) {
      console.error("Failed to check clock status:", error);
    }
  }

  async function handleClockIn() {
    if (!session?.employee) return;
    
    setLoading(true);
    setMessage("");
    
    try {
      const res = await fetch('/functions/timeClockIn', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ employeeId: session.employee.id })
      });
      
      const data = await res.json();
      
      if (res.ok && data.ok) {
        setMessage("✅ Clocked in successfully!");
        await checkClockStatus();
      } else {
        setMessage(data.error || "Failed to clock in");
      }
    } catch (error) {
      setMessage("Failed to clock in. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  async function handleClockOut() {
    if (!session?.employee) return;
    
    setLoading(true);
    setMessage("");
    
    try {
      const res = await fetch('/functions/timeClockOut', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ employeeId: session.employee.id })
      });
      
      const data = await res.json();
      
      if (res.ok && data.ok) {
        setMessage("✅ Clocked out successfully!");
        await checkClockStatus();
      } else {
        setMessage(data.error || "Failed to clock out");
      }
    } catch (error) {
      setMessage("Failed to clock out. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  if (!session?.employee) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}>
        <div style={{ textAlign: "center" }}>
          <h2>Session Expired</h2>
          <p>Please log in again.</p>
          <a href="/staff-login?redirect=/kiosk" className="btn" style={{ marginTop: "16px" }}>
            Go to Login
          </a>
        </div>
      </div>
    );
  }

  const isClockedIn = clockStatus?.isClockedIn;

  return (
    <div style={{ minHeight: "100vh", background: "#f8fafc" }}>
      {/* Header */}
      <div style={{
        background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
        color: "white",
        padding: "20px",
        boxShadow: "0 2px 8px rgba(0,0,0,0.1)"
      }}>
        <div style={{ maxWidth: "800px", margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <h1 style={{ margin: 0, fontSize: "24px", fontWeight: "700" }}>Time Clock</h1>
            <p style={{ margin: "4px 0 0 0", opacity: 0.9, fontSize: "14px" }}>
              {session.employee.fullName || session.employee.email}
            </p>
          </div>
          
          <div style={{ display: "flex", gap: "12px" }}>
            <a href="/staff-dashboard" className="btn-outline" style={{ color: "white", borderColor: "white" }}>
              ← Back
            </a>
            <button
              onClick={logout}
              style={{
                background: "rgba(255,255,255,0.1)",
                border: "1px solid white",
                color: "white",
                padding: "8px 16px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "8px"
              }}
            >
              <LogOutIcon size={18} />
              Logout
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div style={{ maxWidth: "800px", margin: "0 auto", padding: "40px 20px" }}>
        {message && (
          <div style={{
            padding: "16px",
            marginBottom: "24px",
            borderRadius: "12px",
            background: message.includes('✅') ? '#d1fae5' : '#fee2e2',
            color: message.includes('✅') ? '#065f46' : '#991b1b',
            fontSize: "16px",
            fontWeight: "600",
            textAlign: "center"
          }}>
            {message}
          </div>
        )}

        {/* Status Card */}
        <div className="card" style={{ padding: "40px", textAlign: "center", marginBottom: "24px" }}>
          <Clock size={64} style={{ color: isClockedIn ? "#10b981" : "#64748b", margin: "0 auto 20px" }} />
          
          <h2 style={{ margin: "0 0 12px 0", fontSize: "28px", fontWeight: "700" }}>
            {isClockedIn ? "You're Clocked In" : "You're Clocked Out"}
          </h2>
          
          {clockStatus?.clockInAt && (
            <p style={{ fontSize: "18px", color: "#64748b", margin: "0 0 24px 0" }}>
              Clock In Time: {new Date(clockStatus.clockInAt).toLocaleTimeString()}
            </p>
          )}
          
          <button
            onClick={isClockedIn ? handleClockOut : handleClockIn}
            disabled={loading}
            className="btn"
            style={{
              fontSize: "20px",
              padding: "16px 32px",
              display: "inline-flex",
              alignItems: "center",
              gap: "12px",
              background: isClockedIn 
                ? "linear-gradient(135deg, #ef4444 0%, #dc2626 100%)" 
                : "linear-gradient(135deg, #10b981 0%, #059669 100%)",
              minWidth: "200px",
              justifyContent: "center"
            }}
          >
            {loading ? (
              "Processing..."
            ) : isClockedIn ? (
              <>
                <LogOutIcon size={24} />
                Clock Out
              </>
            ) : (
              <>
                <LogIn size={24} />
                Clock In
              </>
            )}
          </button>
        </div>

        {/* Recent Activity */}
        {clockStatus?.recent && clockStatus.recent.length > 0 && (
          <div className="card" style={{ padding: "24px" }}>
            <h3 style={{ margin: "0 0 16px 0", fontSize: "18px", fontWeight: "600" }}>
              Recent Activity
            </h3>
            <div style={{ display: "grid", gap: "12px" }}>
              {clockStatus.recent.map((entry, idx) => (
                <div key={idx} style={{
                  padding: "12px",
                  background: "#f8fafc",
                  borderRadius: "8px",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  fontSize: "14px"
                }}>
                  <div>
                    <div style={{ fontWeight: "600" }}>
                      {new Date(entry.clockInAt).toLocaleDateString()}
                    </div>
                    <div style={{ color: "#64748b" }}>
                      {new Date(entry.clockInAt).toLocaleTimeString()} - 
                      {entry.clockOutAt ? new Date(entry.clockOutAt).toLocaleTimeString() : " Active"}
                    </div>
                  </div>
                  {!entry.clockOutAt && (
                    <CheckCircle size={20} style={{ color: "#10b981" }} />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}