// pages/AdminSeedData.jsx
import React from "react";

const seedData = {
  Parks: [
    {
      name: "FieldFlex Park",
      parkType: "hybrid",
      streetAddress: "100 Game Day Way",
      city: "Austin",
      state: "TX",
      zip: "78701",
      notes: "Main complex with multiple diamonds and soccer pitches"
    },
    {
      name: "Lone Star Sports Plex",
      parkType: "hybrid",
      streetAddress: "200 Sports Boulevard",
      city: "Dallas",
      state: "TX",
      zip: "75201",
      notes: "Indoor/outdoor mix"
    }
  ],
  Events: [
    {
      name: "Spring Classic Invitational",
      eventType: "tournament",
      sport: "softball",
      location: "FieldFlex Park",
      city: "Austin, TX",
      startDate: "2025-03-14",
      endDate: "2025-03-16",
      description: "Weekend fastpitch tournament at FieldFlex Park.",
      website: "https://sideline-setups.com",
      isActive: true
    },
    {
      name: "Soccer Showdown",
      eventType: "league",
      sport: "soccer",
      location: "Lone Star Sports Plex",
      city: "Dallas, TX",
      startDate: "2025-04-01",
      endDate: "2025-06-30",
      description: "Youth soccer league—every Saturday.",
      website: "https://sideline-setups.com",
      isActive: true
    },
    {
      name: "Summer Baseball Tournament",
      eventType: "tournament",
      sport: "baseball",
      location: "FieldFlex Park",
      city: "Austin, TX",
      startDate: "2025-06-15",
      endDate: "2025-06-17",
      description: "Three-day baseball tournament.",
      website: "https://sideline-setups.com",
      isActive: true
    }
  ],
  Packages: [
    {
      name: "MVP Setup",
      description: "10x10 tent + 4 GCI rocker chairs + cooler",
      basePrice: 110,
      perGameUSD: 45,
      perDayUSD: 110,
      fullWeekendUSD: 199,
      enablePerGame: true,
      enableDay: true,
      enableWeekend: true,
      baseItems: [
        { type: "tent", qty: 1 },
        { type: "chair", qty: 4 },
        { type: "cooler", qty: 1 }
      ],
      addOns: [
        { label: "Portable Fan", perGameUSD: 6, perDayUSD: 12, fullWeekendUSD: 20 },
        { label: "Sidewalls", perGameUSD: 8, perDayUSD: 16, fullWeekendUSD: 28 }
      ],
      features: ["Setup & teardown included", "GameDay Without the Haul"],
      colorTheme: "blue",
      isActive: true
    },
    {
      name: "Fan Zone Bundle",
      description: "Two 10x10 tents + 6 chairs + large cooler",
      basePrice: 199,
      perDayUSD: 199,
      fullWeekendUSD: 325,
      enableDay: true,
      enableWeekend: true,
      baseItems: [
        { type: "tent", qty: 2 },
        { type: "chair", qty: 6 },
        { type: "cooler", qty: 1 }
      ],
      addOns: [
        { label: "Extra Tent", perDayUSD: 85, fullWeekendUSD: 150 }
      ],
      features: ["Team ready area", "Perfect for families"],
      colorTheme: "green",
      isActive: true
    },
    {
      name: "Premium VIP",
      description: "Deluxe setup with premium seating",
      basePrice: 299,
      perDayUSD: 299,
      fullWeekendUSD: 525,
      enableDay: true,
      enableWeekend: true,
      baseItems: [
        { type: "tent", qty: 1 },
        { type: "chair", qty: 6 },
        { type: "cooler", qty: 1 },
        { type: "fan", qty: 2 }
      ],
      features: ["Premium chairs", "Side walls included", "Lighting package"],
      colorTheme: "purple",
      isActive: true
    }
  ],
  Equipment: [
    { name: "10x10 Tent", type: "tent", totalQty: 100, availableQty: 100, rentedQty: 0, maintenanceQty: 0, damagedQty: 0, condition: "excellent", cogsPerUseUSD: 15 },
    { name: "GCI Rocker Chair", type: "chair", totalQty: 400, availableQty: 400, rentedQty: 0, maintenanceQty: 0, damagedQty: 0, condition: "excellent", cogsPerUseUSD: 3 },
    { name: "Rolling Cooler", type: "cooler", totalQty: 75, availableQty: 75, rentedQty: 0, maintenanceQty: 0, damagedQty: 0, condition: "excellent", cogsPerUseUSD: 5 },
    { name: "Battery Fan", type: "fan", totalQty: 40, availableQty: 40, rentedQty: 0, maintenanceQty: 0, damagedQty: 0, condition: "excellent", cogsPerUseUSD: 4 },
    { name: "Tent Sidewalls", type: "sidewall", totalQty: 80, availableQty: 80, rentedQty: 0, maintenanceQty: 0, damagedQty: 0, condition: "excellent", cogsPerUseUSD: 2 },
    { name: "LED Light String", type: "lighting", totalQty: 50, availableQty: 50, rentedQty: 0, maintenanceQty: 0, damagedQty: 0, condition: "excellent", cogsPerUseUSD: 2 }
  ]
};

export default function AdminSeedData() {
  const [settings, setSettings] = React.useState(null);
  const [importing, setImporting] = React.useState(null);
  const [log, setLog] = React.useState([]);

  React.useEffect(() => {
    (async () => {
      const { getCtx } = await import("../components/lib/ctx");
      const { settings } = await getCtx();
      setSettings(settings || {});
    })();
  }, []);

  const addLog = (msg) => setLog(l => [`${new Date().toLocaleTimeString()} - ${msg}`, ...l]);

  async function importEntity(entityName) {
    setImporting(entityName);
    addLog(`Starting import for ${entityName}...`);
    
    try {
      const { getCtx } = await import("../components/lib/ctx");
      const { entities } = await getCtx();
      
      const data = seedData[entityName];
      if (!data || !Array.isArray(data)) {
        throw new Error(`No seed data found for ${entityName}`);
      }

      for (const record of data) {
        await entities[entityName].create(record);
        addLog(`✅ Created ${entityName}: ${record.name || record.label || record.id || "record"}`);
      }

      addLog(`✨ Completed ${entityName} import (${data.length} records)`);
    } catch (e) {
      addLog(`❌ Error importing ${entityName}: ${e.message}`);
    } finally {
      setImporting(null);
    }
  }

  function copyJSON(entityName) {
    const json = JSON.stringify(seedData[entityName], null, 2);
    navigator.clipboard.writeText(json);
    addLog(`📋 Copied ${entityName} JSON to clipboard`);
  }

  return (
    <>
      <div className="nav">
        <div className="container nav-inner">
          <a className="brand" href="/">
            <span className="badge">SS</span>
            <span>{settings?.brandName || "Sideline Setups"}</span>
          </a>
          <div className="nav-links">
            <a className="btn-ghost" href="/admindashboard">Admin</a>
          </div>
        </div>
      </div>

      <main>
        <div className="container section">
          <h1>Seed Data Templates</h1>
          <p className="mt-8">Quick-import sample data for testing and demos. Import in order: Parks → Events → Packages → Equipment.</p>

          <div className="card card-pad mt-16">
            <h3>⚠️ Import Order</h3>
            <ol style={{ marginTop: 12, paddingLeft: 24, lineHeight: 1.8 }}>
              <li><b>Parks</b> - No dependencies</li>
              <li><b>Events</b> - Reference park locations</li>
              <li><b>Packages</b> - No dependencies</li>
              <li><b>Equipment</b> - No dependencies</li>
              <li><i>Fields & Spots</i> - Create manually after Parks (requires Park IDs)</li>
            </ol>
          </div>

          <div className="grid grid-2 mt-16">
            {Object.keys(seedData).map(entityName => (
              <div key={entityName} className="card card-pad">
                <div className="kicker">ENTITY</div>
                <h3 style={{ marginTop: 6 }}>{entityName}</h3>
                <div className="mt-8" style={{ color: "var(--muted)", fontSize: 14 }}>
                  {seedData[entityName].length} records
                </div>
                <div className="mt-12" style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  <button 
                    className="btn"
                    onClick={() => importEntity(entityName)}
                    disabled={importing === entityName}
                  >
                    {importing === entityName ? "Importing..." : "Import Now"}
                  </button>
                  <button 
                    className="btn-outline"
                    onClick={() => copyJSON(entityName)}
                  >
                    Copy JSON
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="card card-pad mt-16">
            <h3>Activity Log</h3>
            <pre style={{ 
              background: "var(--bg-2)", 
              padding: 12, 
              borderRadius: 8, 
              maxHeight: 300, 
              overflow: "auto",
              fontSize: 13,
              marginTop: 12
            }}>
              {log.length === 0 ? "No activity yet..." : log.join("\n")}
            </pre>
          </div>

          <div className="card card-pad mt-16">
            <h3>Manual Fields & Spots Setup</h3>
            <p className="mt-8" style={{ color: "var(--muted)" }}>
              After importing Parks, go to <a href="/adminparks" className="btn-outline" style={{ marginLeft: 4, fontSize: 13 }}>Admin Parks</a> to:
            </p>
            <ol style={{ marginTop: 12, paddingLeft: 24, lineHeight: 1.8 }}>
              <li>Add Fields to each Park (e.g., "Diamond A", "Soccer Field 1")</li>
              <li>Auto-generate Spots for each Field (12-spot grid recommended)</li>
            </ol>
          </div>

          <div className="mt-16">
            <a className="btn" href="/admindashboard">← Back to Admin</a>
          </div>
        </div>
      </main>

      <footer className="footer">
        <div className="container">
          © {new Date().getFullYear()} {settings?.brandName || "Sideline Setups"} — All rights reserved.
        </div>
      </footer>
    </>
  );
}