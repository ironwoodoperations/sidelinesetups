// pages/AdminSettings.jsx
import React from "react";
import NavBar from "../components/NavBar";
import { getCtx } from "../components/lib/ctx";

export default function AdminSettings(){
  const [row,setRow]=React.useState(null);
  async function load(){
    const {entities}=await getCtx();
    const all=await entities.SiteSettings.list();
    setRow(all[0]||{});
  }
  React.useEffect(()=>{load();},[]);
  async function save(){
    const {entities}=await getCtx();
    if(row.id)await entities.SiteSettings.update(row);else await entities.SiteSettings.create(row);
    load();
  }
  function update(k,v){setRow(r=>({...r,[k]:v}));}
  if(!row)return<div>Loading…</div>;
  return(
    <>
      <NavBar/>
      <div style={{padding:"24px 20px",maxWidth:800,margin:"0 auto"}}>
        <h1>Site Settings</h1>
        {Object.keys(row).map(k=>(
          <label key={k} style={{display:"block",marginBottom:8}}>
            <div>{k}</div>
            <input value={row[k]??""} onChange={e=>update(k,e.target.value)} style={{width:"100%"}}/>
          </label>
        ))}
        <button onClick={save}>Save</button>
      </div>
    </>
  );
}