// pages/AdminAutomations.jsx
import React from "react";
import NavBar from "../components/NavBar";
import { getCtx } from "../components/lib/ctx";
import { sendEmail } from "../components/lib/notify";
import ReminderEmail from "../components/emails/ReminderEmail";
import SurveyEmail from "../components/emails/SurveyEmail";

export default function AdminAutomations() {
  const [log,setLog] = React.useState([]);

  const add = (m)=>setLog(l=>[`${new Date().toLocaleTimeString()} ${m}`,...l]);

  async function runTomorrowReminders() {
    const { entities, settings } = await getCtx();
    const now = new Date();
    const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate()+1);
    const iso = tomorrow.toISOString().slice(0,10);
    const bookings = await entities.Bookings.filter({ date: iso });

    for (const b of bookings) {
      if (!b?.contactEmail) continue;
      await sendEmail({
        to: b.contactEmail,
        subject: "Reminder: Your Sideline Setups rental is tomorrow",
        html: ReminderEmail({ brand: settings?.brandName, booking: b }),
      });
      add(`Reminder sent → ${b.contactEmail} (${b.id})`);
    }
  }

  async function runDailyStaffDigest() {
    const { entities, settings } = await getCtx();
    const ops = settings?.notifyOpsEmail;
    if (!ops) { add("Skipped: SiteSettings.notifyOpsEmail is empty"); return; }

    const today = new Date().toISOString().slice(0,10);
    const bookings = await entities.Bookings.filter({ date: today });

    const lines = bookings.map(b => `• ${b.date} ${b.teamName || b.fullName || "Customer"} — ${b.status || "pending"} — ${b.parkId || ""}/${b.fieldId || ""}/${b.spotId || ""}`).join("<br/>") || "No bookings today.";

    await sendEmail({
      to: ops,
      subject: "Daily Staff Digest",
      html: `
        <div style="font-family: system-ui, -apple-system, Segoe UI, Roboto">
          <h3>${settings?.brandName || "Sideline Setups"} — Staff Digest</h3>
          <p>${lines}</p>
        </div>
      `,
    });
    add(`Staff digest sent → ${ops}`);
  }

  async function runPostEventSurveys() {
    const { entities, settings } = await getCtx();
    const now = new Date();
    const y = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
    const iso = y.toISOString().slice(0,10);

    const bookings = await entities.Bookings.filter({ date: iso });
    for (const b of bookings) {
      if (!b?.contactEmail) continue;
      await sendEmail({
        to: b.contactEmail,
        subject: "How did we do?",
        html: SurveyEmail({ brand: settings?.brandName, booking: b }),
      });
      add(`Survey sent → ${b.contactEmail} (${b.id})`);
    }
  }

  return (
    <>
      <NavBar/>
      <div className="container section">
        <h1>Automations</h1>
        <p>Run these jobs manually or hook them to Zapier (see docs).</p>
        <div style={{display:"grid",gap:12,maxWidth:600}}>
          <button className="btn" onClick={runTomorrowReminders}>Send Tomorrow Reminders (email)</button>
          <button className="btn" onClick={runDailyStaffDigest}>Send Daily Staff Digest (email)</button>
          <button className="btn" onClick={runPostEventSurveys}>Send Post-Event Surveys (email)</button>
        </div>
        <div style={{marginTop:16}}>
          <h3>Activity</h3>
          <pre style={{background:"#f8fafc",padding:12,borderRadius:8,maxHeight:260,overflow:"auto"}}>
{log.join("\n")}
          </pre>
        </div>
      </div>
    </>
  );
}