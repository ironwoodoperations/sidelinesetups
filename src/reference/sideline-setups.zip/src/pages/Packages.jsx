
import React, { useState, useEffect } from "react";
import { getCtx } from "../components/lib/ctx";
import { Loader2 } from "lucide-react";

export default function Packages() {
  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState(null);
  const [packages, setPackages] = useState([]);
  const [allEquipment, setAllEquipment] = useState([]);
  const [events, setEvents] = useState([]);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [showEventSelection, setShowEventSelection] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const { entities, settings: fetchedSettings } = await getCtx();
        setSettings(fetchedSettings || {});

        const [pkgs, equipment, evts] = await Promise.all([
          entities.Packages.list(),
          entities.Equipment.list(),
          entities.Events.list()
        ]);

        // Filter active packages that should show on packages page, and sort by displayOrder
        const activePackages = (pkgs || [])
          .filter(p => p.isActive !== false && p.showOnPackagesPage !== false)
          .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));

        setPackages(activePackages);
        setAllEquipment(equipment || []);
        
        // Filter active, non-archived events
        const activeEvents = (evts || []).filter(e => e.isActive !== false && e.archived !== true);
        setEvents(activeEvents);
      } catch (error) {
        console.error("Failed to load packages:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleSelectPackage = (pkg) => {
    setSelectedPackage(pkg);
    setShowEventSelection(true);
  };

  const handleSelectEvent = (event) => {
    // Navigate to booking page with both package and event
    window.location.href = `/book?event=${event.id}&package=${selectedPackage.id}`;
  };

  const currency = (n) => `$${(Math.max(0, Number(n) || 0)).toFixed(2)}`;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin" size={48} />
      </div>
    );
  }

  if (showEventSelection) {
    return (
      <div 
        className="min-h-screen py-12 px-4"
        style={{
          backgroundImage: settings?.pageBackgroundPatternUrl 
            ? `linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.92)), url('${settings.pageBackgroundPatternUrl}')`
            : undefined,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      >
        <div className="max-w-6xl mx-auto">
          <button
            onClick={() => setShowEventSelection(false)}
            className="btn-outline mb-8"
          >
            ← Back to Packages
          </button>

          <h2 className="text-3xl font-bold mb-4" style={{ color: '#003f5c' }}>
            Select Your Event
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            Choose which event you'd like to book the {selectedPackage.name} for
          </p>

          <div className="grid grid-3 gap-6">
            {events.map(event => (
              <div
                key={event.id}
                onClick={() => handleSelectEvent(event)}
                className="card card-event"
                style={{ cursor: 'pointer' }}
              >
                <div className="img">
                  {event.imageUrl && (
                    <img src={event.imageUrl} alt={event.name} />
                  )}
                </div>
                <div className="body">
                  <div className="kicker">
                    {event.eventType === 'league' ? '🏅 League' : '🏆 Tournament'} • {event.sport}
                  </div>
                  <h3 style={{ margin: "8px 0 12px 0" }}>
                    {event.name}
                  </h3>
                  {event.city && (
                    <div style={{ display: "flex", alignItems: "center", gap: 6, color: "#64748b", fontSize: "14px", marginBottom: "6px" }}>
                      <span>📍 {event.city}</span>
                    </div>
                  )}
                  {event.startDate && (
                    <div style={{ display: "flex", alignItems: "center", gap: 6, color: "#64748b", fontSize: "14px" }}>
                      <span>📅 {new Date(event.startDate).toLocaleDateString(undefined, { 
                        weekday: "short", month: "short", day: "numeric", year: "numeric"
                      })}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {events.length === 0 && (
            <div className="card card-pad text-center" style={{ padding: '40px' }}>
              <p style={{ color: '#64748b' }}>No events currently available</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen py-12 px-4"
      style={{
        backgroundImage: settings?.pageBackgroundPatternUrl 
          ? `linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.92)), url('${settings.pageBackgroundPatternUrl}')`
          : undefined,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4" style={{ color: '#003f5c' }}>
            Our Packages
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choose the perfect setup for your game day. All packages include delivery, setup, and pickup.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {packages.map(pkg => {
            return (
              <div
                key={pkg.id}
                className="card"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  overflow: 'hidden',
                  border: '2px solid #e2e8f0',
                  transition: 'all 0.3s'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-4px)';
                  e.currentTarget.style.boxShadow = '0 12px 24px rgba(0, 63, 92, 0.15)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = '0 6px 18px rgba(2,8,23,.06)';
                }}
              >
                <div style={{
                  padding: '24px',
                  background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
                  color: 'white'
                }}>
                  <div style={{ display: 'flex', alignItems: 'start', gap: '12px' }}>
                    {/* Thumbnail Image - Same size and position as admin */}
                    {pkg.thumbnailUrl && (
                      <img 
                        src={pkg.thumbnailUrl} 
                        alt={pkg.name}
                        style={{
                          width: "80px",
                          height: "80px",
                          objectFit: "cover",
                          borderRadius: "8px",
                          border: "2px solid rgba(255, 255, 255, 0.3)"
                        }}
                      />
                    )}
                    
                    <div style={{ flex: 1 }}>
                      <h3 style={{
                        fontSize: '1.5rem',
                        fontWeight: '700',
                        marginBottom: '8px',
                        color: 'white'
                      }}>
                        {pkg.name}
                      </h3>
                      {pkg.description && (
                        <p style={{
                          fontSize: '14px',
                          color: 'rgba(255, 255, 255, 0.9)',
                          lineHeight: '1.5'
                        }}>
                          {pkg.description}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                <div style={{ padding: '24px', flex: 1 }}>
                  {/* Features */}
                  {pkg.features && pkg.features.length > 0 && (
                    <div style={{ marginBottom: '20px' }}>
                      <h4 style={{
                        fontSize: '14px',
                        fontWeight: '700',
                        color: '#003f5c',
                        marginBottom: '12px',
                        textTransform: 'uppercase',
                        letterSpacing: '0.5px'
                      }}>
                        Features
                      </h4>
                      <ul style={{ paddingLeft: '20px', margin: 0, listStyleType: 'disc' }}>
                        {pkg.features.map((feature, idx) => (
                          <li key={idx} style={{
                            marginBottom: '6px',
                            fontSize: '14px',
                            color: '#475569'
                          }}>
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Pricing */}
                  <div style={{
                    marginTop: 'auto',
                    paddingTop: '20px',
                    borderTop: '1px solid #e2e8f0'
                  }}>
                    <h4 style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      color: '#003f5c',
                      marginBottom: '12px',
                      textTransform: 'uppercase',
                      letterSpacing: '0.5px'
                    }}>
                      Pricing
                    </h4>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                      {pkg.perGameUSD > 0 && (
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px' }}>
                          <span style={{ color: '#64748b' }}>Per Game:</span>
                          <span style={{ fontWeight: '700', color: '#003f5c' }}>{currency(pkg.perGameUSD)}</span>
                        </div>
                      )}
                      {pkg.perDayUSD > 0 && (
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px' }}>
                          <span style={{ color: '#64748b' }}>Per Day:</span>
                          <span style={{ fontWeight: '700', color: '#003f5c' }}>{currency(pkg.perDayUSD)}</span>
                        </div>
                      )}
                      {pkg.fullWeekendUSD > 0 && (
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px' }}>
                          <span style={{ color: '#64748b' }}>Full Weekend:</span>
                          <span style={{ fontWeight: '700', color: '#003f5c' }}>{currency(pkg.fullWeekendUSD)}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => handleSelectPackage(pkg)}
                    className="btn"
                    style={{
                      width: '100%',
                      marginTop: '20px',
                      padding: '12px',
                      fontSize: '16px'
                    }}
                  >
                    Select Package
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {packages.length === 0 && (
          <div className="card card-pad text-center" style={{ padding: '40px' }}>
            <p style={{ color: '#64748b', fontSize: '18px' }}>No packages currently available</p>
          </div>
        )}
      </div>
    </div>
  );
}
