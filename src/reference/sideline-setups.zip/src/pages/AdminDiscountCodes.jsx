import React from "react";
import AdminDiscountCodes from "../components/admin/AdminDiscountCodes";

export default function AdminDiscountCodesPage() {
  return <AdminDiscountCodes />;
}