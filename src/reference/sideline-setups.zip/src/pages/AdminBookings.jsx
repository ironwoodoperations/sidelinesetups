import React, { useState, useEffect } from "react";
import { getCtx } from "../components/lib/ctx";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";
import { Eye, AlertTriangle } from "lucide-react";

export default function AdminBookings() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState(null);
  const [viewingId, setViewingId] = useState(null);

  useEffect(() => {
    loadBookings();
  }, []);

  const loadBookings = async () => {
    try {
      setLoading(true);
      const { entities } = await getCtx();
      const bookingsList = await entities.Bookings.list("-created_date");
      setBookings(bookingsList || []);
    } catch (error) {
      console.error("Error loading bookings:", error);
      alert("Failed to load bookings: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (booking, newStatus) => {
    if (processingId) return;
    
    // Validate status transitions
    if (newStatus === "closed" && booking.status !== "picked_up") {
      if (!confirm("Booking must be 'picked up' before closing. Change status to 'picked up' first?")) {
        return;
      }
      newStatus = "picked_up";
    }
    
    if (newStatus === "closed") {
      if (!confirm("Close this booking? This marks it as complete and ready for archiving. This action should only be done by admins.")) {
        return;
      }
    }
    
    setProcessingId(booking.id);
    
    try {
      const { entities } = await getCtx();
      
      // If cancelling, release inventory first
      if (newStatus === "cancelled" && booking.status !== "cancelled") {
        console.log("[AdminBookings] Releasing inventory for cancelled booking:", booking.id);
        
        try {
          const response = await base44.functions.invoke('inventoryRelease', {
            bookingId: booking.id
          });
          
          console.log("[AdminBookings] Inventory release response:", response.data);
          
          if (response.data && !response.data.success) {
            console.warn("[AdminBookings] Inventory release warning:", response.data.error);
          }
        } catch (releaseError) {
          console.error("[AdminBookings] Inventory release error:", releaseError);
          alert("Warning: Failed to release inventory, but booking will be marked as cancelled. Error: " + releaseError.message);
        }
      }
      
      // Update booking status
      await entities.Bookings.update(booking.id, { status: newStatus });
      await loadBookings();
      
    } catch (error) {
      console.error("Error updating booking:", error);
      alert("Failed to update booking: " + error.message);
    } finally {
      setProcessingId(null);
    }
  };

  const handleViewId = async (bookingId) => {
    try {
      const response = await base44.functions.invoke('viewIdPhoto', { bookingId });
      if (response.data && response.data.signed_url) {
        window.open(response.data.signed_url, '_blank');
      } else {
        alert('No ID photo found for this booking');
      }
    } catch (error) {
      console.error('Failed to view ID:', error);
      alert('Failed to load ID photo');
    }
  };

  const handleClearIdWarning = async (bookingId) => {
    if (!confirm("Mark this booking's ID as reviewed and clear the warning?")) {
      return;
    }
    
    try {
      await base44.entities.Bookings.update(bookingId, {
        needsIdReview: false
      });
      await loadBookings();
    } catch (error) {
      console.error('Failed to clear warning:', error);
      alert('Failed to clear warning');
    }
  };

  if (loading) {
    return (
      <div style={{ padding: "40px", textAlign: "center" }}>
        <div className="spinner"></div>
        <p style={{ marginTop: "16px" }}>Loading bookings...</p>
      </div>
    );
  }

  return (
    <div style={{ padding: "24px" }}>
      <h2 style={{ marginBottom: "24px" }}>Bookings Management</h2>

      <div className="card" style={{ overflow: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "#f8fafc", borderBottom: "2px solid #e2e8f0" }}>
              <th style={{ padding: "12px", textAlign: "left" }}>ID</th>
              <th style={{ padding: "12px", textAlign: "left" }}>Customer</th>
              <th style={{ padding: "12px", textAlign: "left" }}>Event</th>
              <th style={{ padding: "12px", textAlign: "left" }}>Date</th>
              <th style={{ padding: "12px", textAlign: "right" }}>Total</th>
              <th style={{ padding: "12px", textAlign: "center" }}>ID Status</th>
              <th style={{ padding: "12px", textAlign: "center" }}>Status</th>
              <th style={{ padding: "12px", textAlign: "center" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {bookings.length === 0 ? (
              <tr>
                <td colSpan="8" style={{ padding: "40px", textAlign: "center", color: "#64748b" }}>
                  No bookings yet
                </td>
              </tr>
            ) : (
              bookings.map((booking) => {
                const hasIdPhoto = !!booking.idPhotoUri;
                const idVerified = !!booking.idVerifiedBy;
                const needsReview = booking.needsIdReview;
                
                return (
                  <tr 
                    key={booking.id} 
                    style={{ 
                      borderBottom: "1px solid #e2e8f0",
                      background: needsReview ? "#fef3c7" : "white"
                    }}
                  >
                    <td style={{ padding: "12px", fontSize: "12px", fontFamily: "monospace" }}>
                      {booking.id.substring(0, 8)}...
                    </td>
                    <td style={{ padding: "12px" }}>
                      <div style={{ fontWeight: "600" }}>{booking.fullName}</div>
                      <div style={{ fontSize: "12px", color: "#64748b" }}>{booking.contactEmail}</div>
                    </td>
                    <td style={{ padding: "12px", fontSize: "13px" }}>
                      {booking.eventId?.substring(0, 12)}...
                    </td>
                    <td style={{ padding: "12px" }}>
                      {booking.date ? format(new Date(booking.date), "MMM d, yyyy") : "N/A"}
                    </td>
                    <td style={{ padding: "12px", textAlign: "right", fontWeight: "600" }}>
                      ${Number(booking.totals?.amount || 0).toFixed(2)}
                    </td>
                    <td style={{ padding: "12px", textAlign: "center" }}>
                      {needsReview ? (
                        <div style={{ display: "flex", alignItems: "center", gap: "8px", justifyContent: "center" }}>
                          <span style={{ 
                            padding: "4px 8px", 
                            background: "#fbbf24", 
                            color: "#78350f",
                            borderRadius: "6px", 
                            fontSize: "11px", 
                            fontWeight: "600",
                            display: "flex",
                            alignItems: "center",
                            gap: "4px"
                          }}>
                            <AlertTriangle size={12} />
                            NEEDS REVIEW
                          </span>
                          <button
                            onClick={() => handleClearIdWarning(booking.id)}
                            style={{
                              padding: "4px 8px",
                              background: "#10b981",
                              color: "white",
                              border: "none",
                              borderRadius: "4px",
                              fontSize: "11px",
                              cursor: "pointer"
                            }}
                          >
                            Clear
                          </button>
                        </div>
                      ) : idVerified ? (
                        <span style={{ 
                          padding: "4px 8px", 
                          background: "#d1fae5", 
                          color: "#065f46",
                          borderRadius: "6px", 
                          fontSize: "11px", 
                          fontWeight: "600" 
                        }}>
                          ✓ VERIFIED
                        </span>
                      ) : hasIdPhoto ? (
                        <span style={{ 
                          padding: "4px 8px", 
                          background: "#dbeafe", 
                          color: "#1e40af",
                          borderRadius: "6px", 
                          fontSize: "11px", 
                          fontWeight: "600" 
                        }}>
                          UPLOADED
                        </span>
                      ) : (
                        <span style={{ 
                          padding: "4px 8px", 
                          background: "#fee2e2", 
                          color: "#991b1b",
                          borderRadius: "6px", 
                          fontSize: "11px", 
                          fontWeight: "600" 
                        }}>
                          NO ID
                        </span>
                      )}
                      {hasIdPhoto && (
                        <button
                          onClick={() => handleViewId(booking.id)}
                          style={{
                            marginLeft: "8px",
                            padding: "4px 8px",
                            background: "#3b82f6",
                            color: "white",
                            border: "none",
                            borderRadius: "4px",
                            fontSize: "11px",
                            cursor: "pointer",
                            display: "inline-flex",
                            alignItems: "center",
                            gap: "4px"
                          }}
                        >
                          <Eye size={12} />
                          View
                        </button>
                      )}
                    </td>
                    <td style={{ padding: "12px", textAlign: "center" }}>
                      <select
                        className="select"
                        value={booking.status}
                        onChange={(e) => handleStatusChange(booking, e.target.value)}
                        disabled={processingId === booking.id}
                        style={{ fontSize: "12px", padding: "4px 8px" }}
                      >
                        <option value="pending">Pending</option>
                        <option value="paid">Paid</option>
                        <option value="photo_uploaded">Photo Uploaded</option>
                        <option value="setup">Setup</option>
                        <option value="checked_in">Checked In</option>
                        <option value="leaving">Leaving</option>
                        <option value="picked_up">Picked Up</option>
                        <option value="closed">Closed</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </td>
                    <td style={{ padding: "12px", textAlign: "center" }}>
                      <a 
                        href={`/thankyou?b=${booking.id}`} 
                        className="btn-outline"
                        style={{ fontSize: "11px", padding: "4px 12px" }}
                      >
                        View Receipt
                      </a>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      <div style={{ 
        marginTop: "24px", 
        padding: "16px", 
        background: "#f8fafc", 
        borderRadius: "8px",
        fontSize: "14px",
        color: "#64748b"
      }}>
        <h4 style={{ margin: "0 0 12px 0", color: "#0f172a" }}>Status Flow Guide:</h4>
        <ul style={{ margin: 0, paddingLeft: "20px" }}>
          <li><strong>Pending</strong> → Initial booking state</li>
          <li><strong>Paid</strong> → Payment received</li>
          <li><strong>Photo Uploaded</strong> → Customer uploaded ID photo</li>
          <li><strong>Setup</strong> → Equipment deployed by staff</li>
          <li><strong>Checked In</strong> → Customer arrived and ID verified by staff</li>
          <li><strong>Leaving</strong> → Customer texted they're leaving</li>
          <li><strong>Picked Up</strong> → Equipment retrieved by staff</li>
          <li><strong>Closed</strong> → Admin final review complete (Admin Only)</li>
          <li><strong>Cancelled</strong> → Booking cancelled</li>
        </ul>
        <div style={{ marginTop: "12px", padding: "12px", background: "#fef3c7", borderRadius: "6px" }}>
          <strong>⚠️ Yellow Highlight:</strong> Booking was checked in without ID verification - needs admin review before closing.
        </div>
      </div>
    </div>
  );
}