import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { 
  Home, Settings, Calendar, MapPin, Package, Users, 
  Upload, Clock, FileText, Plus, Copy, Box, Grid,
  LogOut, Menu, X, Folder, ClipboardList, Activity, Tag, CalendarDays, TrendingUp, BookOpen
} from "lucide-react";

// Lazy load admin components for better performance
const AdminHome = React.lazy(() => import("../components/admin/AdminHome"));
const AdminSiteSettings = React.lazy(() => import("../components/admin/AdminSiteSettings"));
const AdminEvents = React.lazy(() => import("../components/admin/AdminEvents"));
const AdminParksIntegrated = React.lazy(() => import("../components/admin/AdminParksIntegrated"));
const AdminPackages = React.lazy(() => import("../components/admin/AdminPackages"));
const AdminEquipment = React.lazy(() => import("../components/admin/AdminEquipment"));
const AdminBookings = React.lazy(() => import("../components/admin/AdminBookings"));
const AdminUpload = React.lazy(() => import("../components/admin/AdminUpload"));
const AdminLeagueInventory = React.lazy(() => import("../components/admin/AdminLeagueInventory"));
const AdminEmployees = React.lazy(() => import("../components/admin/AdminEmployees"));
const AdminAddOns = React.lazy(() => import("../components/admin/AdminAddOns"));
const AdminShifts = React.lazy(() => import("../components/admin/AdminShifts"));
const AdminSpotTemplates = React.lazy(() => import("../components/admin/AdminSpotTemplates"));
const AdminFutureProjects = React.lazy(() => import("../components/admin/AdminFutureProjects"));
const AdminPullSheet = React.lazy(() => import("../components/admin/AdminPullSheet"));
const AdminXero = React.lazy(() => import("../components/admin/AdminXero"));
const AdminDiscountCodes = React.lazy(() => import("../components/admin/AdminDiscountCodes"));
const AdminAnalytics = React.lazy(() => import("../components/admin/AdminAnalytics"));
const BookingCalendar = React.lazy(() => import("../components/shared/BookingCalendar"));
const AdminDocs = React.lazy(() => import("./AdminDocs"));

export default function Admin() {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [currentView, setCurrentView] = useState("home");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isMobile, setIsMobile] = useState(false);

  const navItems = [
    { key: 'home', label: 'Dashboard', icon: Home },
    { key: 'bookings', label: 'Bookings', icon: FileText },
    { key: 'pullsheet', label: 'Pull Sheet', icon: ClipboardList },
    { key: 'calendar', label: 'Booking Calendar', icon: CalendarDays },
    { key: 'parks', label: 'Parks & Fields', icon: MapPin },
    { key: 'templates', label: 'Spot Templates', icon: Copy },
    { key: 'equipment', label: 'Equipment', icon: Box },
    { key: 'packages', label: 'Packages', icon: Package },
    { key: 'addons', label: 'Add-Ons', icon: Plus },
    { key: 'events', label: 'Events', icon: Calendar },
    { key: 'employees', label: 'Employees', icon: Users },
    { key: 'shifts', label: 'Shifts', icon: Clock },
    { key: 'league', label: 'League Inventory', icon: Grid },
    { key: 'discounts', label: 'Discount Codes', icon: Tag },
    { key: 'analytics', label: 'Analytics', icon: TrendingUp },
    { key: 'settings', label: 'Settings', icon: Settings },
    { key: 'xero', label: 'Xero Integration', icon: Activity },
    { key: 'upload', label: 'Upload Files', icon: Upload },
    { key: 'futureProjects', label: 'Future Projects', icon: Folder },
    { key: 'docs', label: 'App Documentation', icon: BookOpen }
  ];

  useEffect(() => {
    (async () => {
      try {
        const u = await base44.auth.me();
        setUser(u);
      } catch (error) {
        console.warn("Base44 auth check failed:", error);
      }
      
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth <= 768;
      setIsMobile(mobile);
      if (mobile) {
        setSidebarOpen(false);
      }
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  async function handleLogout() {
    try {
      localStorage.removeItem("ss.session");
      await base44.auth.logout("/");
    } catch (e) {
      console.error("Logout error:", e);
      window.location.href = "/";
    }
  }
  
  // Render the current view component with lazy loading
  const renderCurrentView = () => {
    const viewProps = currentView === 'calendar' ? { userRole: "admin" } : {};
    
    return (
      <React.Suspense fallback={
        <div style={{ padding: "40px", textAlign: "center" }}>
          <div className="spinner"></div>
          <p style={{ marginTop: "16px", color: "#64748b" }}>Loading...</p>
        </div>
      }>
        {currentView === 'home' && <AdminHome onNavigate={setCurrentView} />}
        {currentView === 'calendar' && <BookingCalendar {...viewProps} />}
        {currentView === 'events' && <AdminEvents />}
        {currentView === 'parks' && <AdminParksIntegrated />}
        {currentView === 'packages' && <AdminPackages />}
        {currentView === 'bookings' && <AdminBookings />}
        {currentView === 'pullsheet' && <AdminPullSheet />}
        {currentView === 'equipment' && <AdminEquipment />}
        {currentView === 'employees' && <AdminEmployees />}
        {currentView === 'shifts' && <AdminShifts />}
        {currentView === 'settings' && <AdminSiteSettings />}
        {currentView === 'upload' && <AdminUpload />}
        {currentView === 'addons' && <AdminAddOns />}
        {currentView === 'templates' && <AdminSpotTemplates />}
        {currentView === 'league' && <AdminLeagueInventory />}
        {currentView === 'futureProjects' && <AdminFutureProjects />}
        {currentView === 'xero' && <AdminXero />}
        {currentView === 'discounts' && <AdminDiscountCodes />}
        {currentView === 'analytics' && <AdminAnalytics />}
        {currentView === 'docs' && <AdminDocs />}
      </React.Suspense>
    );
  };

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#f8fafc" }}>
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "#f8fafc" }}>
      {/* Top Navigation Bar */}
      <div style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        height: "64px",
        background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
        boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
        zIndex: 1000,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "0 24px"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            style={{
              background: "rgba(255,255,255,0.1)",
              border: "none",
              color: "white",
              padding: "8px",
              borderRadius: "8px",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center"
            }}
          >
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <a href="/" style={{ display: "flex", alignItems: "center", gap: "12px", textDecoration: "none" }}>
            <img 
              src="https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/efd515468_SS_Logo_White_Clean.png"
              alt="Sideline Setups"
              style={{
                height: "40px",
                width: "auto"
              }}
            />
            <div>
              <div style={{ color: "white", fontSize: "18px", fontWeight: "700", lineHeight: 1 }}>
                Sideline Setups
              </div>
              <div style={{ color: "rgba(255,255,255,0.8)", fontSize: "12px" }}>
                Admin Panel
              </div>
            </div>
          </a>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
          <a 
            href="/" 
            style={{
              color: "white",
              textDecoration: "none",
              fontSize: "14px",
              padding: "8px 16px",
              background: "rgba(255,255,255,0.1)",
              borderRadius: "8px",
              transition: "all 0.2s"
            }}
            onMouseEnter={(e) => e.target.style.background = "rgba(255,255,255,0.2)"}
            onMouseLeave={(e) => e.target.style.background = "rgba(255,255,255,0.1)"}
          >
            View Site
          </a>
          <div style={{
            color: "white",
            fontSize: "14px",
            padding: "8px 16px",
            background: "rgba(255,255,255,0.1)",
            borderRadius: "8px"
          }}>
            {user?.full_name || user?.email || 'Admin'}
          </div>
          <button
            onClick={handleLogout}
            style={{
              background: "rgba(255,255,255,0.1)",
              border: "none",
              color: "white",
              padding: "8px 16px",
              borderRadius: "8px",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: "8px",
              fontSize: "14px",
              transition: "all 0.2s"
            }}
            onMouseEnter={(e) => e.target.style.background = "rgba(255,255,255,0.2)"}
            onMouseLeave={(e) => e.target.style.background = "rgba(255,255,255,0.1)"}
          >
            <LogOut size={16} />
            Logout
          </button>
        </div>
      </div>

      {/* Overlay for mobile */}
      {isMobile && sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          style={{
            position: "fixed",
            top: "64px",
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0,0,0,0.5)",
            zIndex: 998
          }}
        />
      )}

      {/* Sidebar */}
      {sidebarOpen && (
        <div style={{
          position: isMobile ? "fixed" : "fixed",
          left: 0,
          top: "64px",
          bottom: 0,
          width: "240px",
          background: "white",
          borderRight: "1px solid #e2e8f0",
          overflowY: "scroll",
          zIndex: 999,
          boxShadow: "2px 0 8px rgba(0,0,0,0.05)",
          transform: isMobile && !sidebarOpen ? "translateX(-100%)" : "translateX(0)",
          transition: "transform 0.3s ease",
          paddingBottom: "40px"
        }}>
          <nav style={{ padding: "16px 0" }}>
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = currentView === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => {
                    setCurrentView(item.key);
                    if (isMobile) setSidebarOpen(false);
                  }}
                  style={{
                    width: "100%",
                    display: "flex",
                    alignItems: "center",
                    gap: "12px",
                    padding: "12px 20px",
                    background: isActive ? "#f0f9ff" : "transparent",
                    border: "none",
                    borderLeft: isActive ? "3px solid #003f5c" : "3px solid transparent",
                    color: isActive ? "#003f5c" : "#64748b",
                    fontSize: "14px",
                    fontWeight: isActive ? "600" : "400",
                    cursor: "pointer",
                    transition: "all 0.2s",
                    textAlign: "left"
                  }}
                  onMouseEnter={(e) => {
                    if (!isActive) {
                      e.currentTarget.style.background = "#f8fafc";
                      e.currentTarget.style.color = "#003f5c";
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isActive) {
                      e.currentTarget.style.background = "transparent";
                      e.currentTarget.style.color = "#64748b";
                    }
                  }}
                >
                  <Icon size={18} />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>
      )}

      {/* Main Content */}
      <div style={{
        marginTop: "64px",
        marginLeft: isMobile ? "0" : (sidebarOpen ? "240px" : "0"),
        padding: "24px",
        minHeight: "calc(100vh - 64px)",
        transition: isMobile ? "none" : "margin-left 0.3s ease"
      }}>
        {renderCurrentView()}
      </div>
    </div>
  );
}