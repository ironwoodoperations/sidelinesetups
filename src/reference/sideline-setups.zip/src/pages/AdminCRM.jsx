// pages/AdminCRM.jsx
import React from "react";
import NavBar from "../components/NavBar";
import { getCtx } from "../components/lib/ctx";
import { toCSV } from "../components/lib/crm";

function download(text, filename, type = "text/csv;charset=utf-8;") {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
}

export default function AdminCRM() {
  const [rows, setRows] = React.useState([]);
  const [q, setQ] = React.useState("");
  const [newTag, setNewTag] = React.useState("");
  const [selectedIds, setSelectedIds] = React.useState(new Set());
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    (async () => {
      const { entities } = await getCtx();
      const list = await entities.CRMContacts.list();
      setRows(list || []);
      setLoading(false);
    })();
  }, []);

  function toggle(id) {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedIds(next);
  }

  const filtered = (rows || []).filter(r => {
    if (!q) return true;
    const text = `${r.email || ""} ${r.phone || ""} ${(r.tags || []).join(" ")}`.toLowerCase();
    return text.includes(q.toLowerCase());
  });

  async function addTagToSelected() {
    if (!newTag) return;
    const { entities } = await getCtx();
    for (const id of selectedIds) {
      const r = rows.find(x => x.id === id);
      if (!r) continue;
      const merged = Array.from(new Set([...(r.tags || []), newTag]));
      const updated = await entities.CRMContacts.update({ id, tags: merged });
      Object.assign(r, updated);
    }
    setNewTag("");
    setSelectedIds(new Set());
    alert("Tag applied.");
  }

  return (
    <>
      <NavBar/>
      <div className="container section" style={{ maxWidth: 1100 }}>
        <h1>Admin • CRM</h1>
        <div className="card" style={{ padding: 12, display: "grid", gridTemplateColumns: "1fr auto auto", gap: 12 }}>
          <input className="input" placeholder="Search email/phone/tag…" value={q} onChange={e => setQ(e.target.value)} />
          <button
            className="btn"
            onClick={() => {
              const csv = toCSV(filtered);
              download(csv, "crm-contacts.csv");
            }}
          >
            Export CSV
          </button>
          <a className="btn secondary" href="/adminexports">Go to Booking Exports</a>
        </div>

        <div className="card" style={{ padding: 12, marginTop: 12, display: "grid", gridTemplateColumns: "1fr 120px", gap: 12, alignItems: "end" }}>
          <input className="input" placeholder="New tag (e.g., 'tournament')" value={newTag} onChange={e => setNewTag(e.target.value)} />
          <button className="btn" disabled={!selectedIds.size || !newTag} onClick={addTagToSelected}>
            Add Tag to Selected
          </button>
        </div>

        {loading ? (
          <div className="card" style={{ padding: 12, marginTop: 12 }}>Loading…</div>
        ) : (
          <div className="card" style={{ padding: 0, marginTop: 12 }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  <th style={{ width: 32, padding: 8, textAlign: "left", borderBottom: "1px solid var(--border)" }}></th>
                  <th style={{ padding: 8, textAlign: "left", borderBottom: "1px solid var(--border)" }}>Email</th>
                  <th style={{ padding: 8, textAlign: "left", borderBottom: "1px solid var(--border)" }}>Phone</th>
                  <th style={{ padding: 8, textAlign: "left", borderBottom: "1px solid var(--border)" }}>Tags</th>
                  <th style={{ padding: 8, textAlign: "left", borderBottom: "1px solid var(--border)" }}>Customer</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(r => (
                  <tr key={r.id}>
                    <td style={{ padding: 8, borderBottom: "1px solid var(--border)" }}>
                      <input type="checkbox" checked={selectedIds.has(r.id)} onChange={() => toggle(r.id)} />
                    </td>
                    <td style={{ padding: 8, borderBottom: "1px solid var(--border)" }}>{r.email}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid var(--border)" }}>{r.phone}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid var(--border)" }}>{(r.tags || []).join(", ")}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid var(--border)" }}>{r.customerId || ""}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div style={{ padding: 12, fontSize: 12, opacity: .7 }}>
              Showing {filtered.length} of {rows.length} contacts.
            </div>
          </div>
        )}
      </div>
    </>
  );
}