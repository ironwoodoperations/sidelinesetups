import React from "react";
import { base44 } from "@/api/base44Client";
import { getCtx } from "../components/lib/ctx";
import { Sparkles } from "lucide-react";
// asNum removed - using inline conversion instead
import PayPalButtons from "../components/PayPalButtons";
import { TERMS_URL, PRIVACY_URL } from "../components/lib/legal";
import { format, parseISO } from "date-fns";
import PackageDurationSelector from "../components/PackageDurationSelector";
import PackageCompactCard from "../components/PackageCompactCard";

// Time formatting utilities
const fmt12h = (timeStr) => {
  if (!timeStr) return "";
  const [hh, mm] = timeStr.split(":").map(n => parseInt(n, 10));
  const ampm = hh >= 12 ? "PM" : "AM";
  const hour = ((hh + 11) % 12) + 1;
  return `${hour}:${mm.toString().padStart(2, "0")} ${ampm}`;
};

const addMinutes = (tStr, delta) => {
  const [hh, mm] = tStr.split(":").map(n => parseInt(n, 10));
  const base = new Date(2000, 0, 1, hh, mm, 0, 0);
  const out = new Date(base.getTime() + delta * 60000);
  return `${out.getHours().toString().padStart(2,"0")}:${out.getMinutes().toString().padStart(2,"0")}`;
};

const genLeagueTimeSlots = (startTime, endTime, bufferMin) => {
  if (!startTime || !endTime || !bufferMin) return [];
  const slots = [];
  let cur = startTime;
  const maxIterations = 50;
  let iterations = 0;
  while (cur < endTime && iterations < maxIterations) {
    slots.push(cur);
    cur = addMinutes(cur, bufferMin);
    iterations++;
  }
  return slots;
};

const currency = (n) => `$${(Math.max(0, Number(n) || 0)).toFixed(2)}`;

const sportNames = {
  softball: "Softball",
  baseball: "Baseball",
  soccer: "Soccer",
  basketball: "Basketball",
  football: "Football",
  volleyball: "Volleyball",
  hockey: "Hockey",
  tennis: "Tennis",
  golf: "Golf",
  // Add other sports as needed
};

function calculatePackageInventory(pkg, allEquipment) {
  if (!pkg.baseItems || pkg.baseItems.length === 0) {
    return 999;
  }
  
  let minAvailable = Infinity;
  
  for (const item of pkg.baseItems) {
    const equipment = allEquipment.find(e => e.id === item.equipmentId);
    if (!equipment) continue;
    
    const requiredQty = Number(item.qty || 1);
    const availableQty = Number(equipment.availableQty || 0);
    
    if (requiredQty > 0) {
      const possiblePackages = Math.floor(availableQty / requiredQty);
      minAvailable = Math.min(minAvailable, possiblePackages);
    }
  }
  
  return minAvailable === Infinity ? 999 : minAvailable;
}

function calculateAddonInventory(addon, allEquipment) {
  if (!addon.equipmentId) {
    return 999; // If no equipmentId, assume unlimited or a service
  }
  
  const equipment = allEquipment.find(e => e.id === addon.equipmentId);
  if (!equipment) return 0; // If equipment not found, 0 available
  
  return Number(equipment.availableQty || 0);
}

function FieldSpotPicker({ field, spots, selectedSpotId, onSelectSpot }) {
  if (!field?.imageUrl) {
    return (
      <div className="mt-12">
        <label className="label">Available Spots</label>
        <div className="grid" style={{gridTemplateColumns:"repeat(auto-fill,minmax(120px,1fr))", gap: 8}}>
          {spots.map(sp => (
            <button key={sp.id}
              className={selectedSpotId === sp.id ? "btn" : "btn-outline"}
              style={{justifyContent:"center"}}
              onClick={() => onSelectSpot(sp.id)}>
              {sp.label}
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="mt-12">
      <div style={{
        textAlign: 'center',
        marginBottom: '16px',
        fontSize: '18px',
        fontWeight: '600',
        color: '#003f5c',
        padding: '12px 20px',
        background: 'rgba(255, 255, 255, 0.95)',
        border: '2px solid #003f5c',
        borderRadius: '8px',
        display: 'block', // Changed from 'inline-block' to 'block'
        margin: '0 auto 8px auto',
        width: '100%',
        maxWidth: '600px'
      }}>
        Where would you like us to Set you Up (Click on a Location)
      </div>
      <div style={{
        textAlign: 'center',
        marginBottom: '16px',
        fontSize: '12px',
        color: '#94a3b8'
      }}>
        These locations are an estimate and not guaranteed to be exact at your field
      </div>
      <div style={{
        position: "relative",
        width: "100%",
        maxWidth: "800px",
        margin: "0 auto",
        border: "2px solid #e2e8f0",
        borderRadius: "12px",
        overflow: "hidden",
        backgroundColor: "#f8fafc"
      }}>
        <img 
          src={field.imageUrl} 
          alt={field.name}
          style={{
            width: "100%",
            height: "auto",
            display: "block"
          }}
        />
        {spots.map(spot => {
          const isSelected = selectedSpotId === spot.id;
          return (
            <button
              key={spot.id}
              onClick={() => onSelectSpot(spot.id)}
              style={{
                position: "absolute",
                left: `${spot.x || 50}%`,
                top: `${spot.y || 50}%`,
                transform: "translate(-50%, -50%)",
                width: "clamp(30px, 4vw, 40px)",
                height: "clamp(30px, 4vw, 40px)",
                borderRadius: "50%",
                border: isSelected ? "3px solid #003f5c" : "2px solid white",
                background: isSelected 
                  ? "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)"
                  : "rgba(255, 255, 255, 0.9)",
                color: isSelected ? "white" : "#003f5c",
                fontWeight: "bold",
                fontSize: "clamp(8px, 1.5vw, 11px)",
                cursor: "pointer",
                boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
                transition: "all 0.2s",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                userSelect: "none",
                padding: 0,
                lineHeight: 1
              }}
              onMouseEnter={(e) => {
                if (!isSelected) {
                  e.currentTarget.style.transform = "translate(-50%, -50%) scale(1.1)";
                  e.currentTarget.style.boxShadow = "0 4px 12px rgba(0,0,0,0.3)";
                }
              }}
              onMouseLeave={(e) => {
                if (!isSelected) {
                  e.currentTarget.style.transform = "translate(-50%, -50%) scale(1)";
                  e.currentTarget.style.boxShadow = "0 2px 8px rgba(0,0,0,0.2)";
                }
              }}
            >
              {spot.label}
            </button>
          );
        })}
      </div>
      <div style={{ textAlign: "center", marginTop: 12, color: "#64748b", fontSize: 14 }}>
        {selectedSpotId 
          ? `Selected: ${spots.find(s => s.id === selectedSpotId)?.label}`
          : "Click a spot on the field to select"
        }
      </div>
    </div>
  );
}

function LeagueSchedulePicker({ event, onScheduleChange, timeSlots, setTimeSlots, isLoadingTimeSlots, setIsLoadingTimeSlots, loadInventoryForSlot, leagueDate, setLeagueDate, firstGameTime, setFirstGameTime, fields, selectedFieldId, selectedParkId, isWOSFieldSelected }) {
  // isWOSFieldSelected now comes as a prop, unifying logic for actual WOS fields and the generic WOS option.

  React.useEffect(() => {
    // Only load inventory if a specific field is selected AND it's not a WOS scenario
    if (event?.leagueEnabled && leagueDate && selectedParkId && selectedFieldId && !isWOSFieldSelected) {
      loadInventoryForSlot(leagueDate, selectedParkId, selectedFieldId);
    } else if (isWOSFieldSelected) {
      // If WOS is selected, ensure time slots are cleared and game time is set to WOS
      setTimeSlots([]);
      setFirstGameTime("Waiting on Schedule"); // Set game time to WOS directly
      setIsLoadingTimeSlots(false);
    }
  }, [event, leagueDate, selectedParkId, selectedFieldId, isWOSFieldSelected, loadInventoryForSlot, setTimeSlots, setFirstGameTime, setIsLoadingTimeSlots]);


  React.useEffect(() => {
    if (leagueDate && (firstGameTime || isWOSFieldSelected)) {
      onScheduleChange({
        type: "league",
        date: leagueDate,
        gameTimes: [isWOSFieldSelected ? "Waiting on Schedule" : firstGameTime],
        isWaitingOnSchedule: !!isWOSFieldSelected
      });
    } else {
      onScheduleChange(null);
    }
  }, [leagueDate, firstGameTime, isWOSFieldSelected, onScheduleChange]);

  return (
    <>
      <div>
        <label className="label">League Date *</label>
        <select
          className="select"
          value={leagueDate}
          onChange={(e) => {
            setLeagueDate(e.target.value);
            setFirstGameTime("");
          }}
        >
          <option value="">Select a date</option>
          {(event.leagueDates || []).map(d => {
            try {
              const testDate = parseISO(d);
              if (isNaN(testDate.getTime())) {
                console.warn("Skipping invalid date in dropdown:", d);
                return null;
              }
              const formattedDate = format(testDate, "EEE, MMM d yyyy");
              return <option key={d} value={d}>{formattedDate}</option>;
            } catch (e) {
              console.error("Invalid date format in dropdown:", d, e);
              return null;
            }
          }).filter(Boolean)}
        </select>
        {event.leagueDates && event.leagueDates.length === 0 && (
          <div style={{ fontSize: 12, color: '#dc2626', marginTop: 4 }}>
            No valid dates configured for this league. Please contact support.
          </div>
        )}
      </div>

      {event?.leagueEnabled && selectedParkId && selectedFieldId && leagueDate && !isWOSFieldSelected && (
        <div style={{
          border: "1px solid #e2e8f0",
          borderRadius: "12px",
          padding: "16px",
          marginTop: "20px"
        }}>
          <h4 style={{ margin: "0 0 12px 0" }}>Select Time Slot *</h4>
          {isLoadingTimeSlots ? (
            <div style={{
              padding: '12px',
              background: '#f8fafc',
              border: '1px solid #e2e8f0',
              borderRadius: '8px',
              color: '#64748b',
              fontSize: '14px',
              textAlign: 'center'
            }}>
              <div className="spinner" style={{ margin: '0 auto 8px' }}></div>
              Loading available time slots...
            </div>
          ) : timeSlots.length > 0 ? (
            <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
              {timeSlots.map(slot => {
                const disabled = slot.available <= 0;
                const selected = firstGameTime === slot.time;

                return (
                  <button
                    key={slot.time}
                    type="button"
                    className={selected ? "btn" : "btn-outline"}
                    disabled={disabled}
                    onClick={() => setFirstGameTime(slot.time)}
                    style={{
                      opacity: disabled ? 0.5 : 1,
                      cursor: disabled ? 'not-allowed' : 'pointer',
                      background: selected ? 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)' : undefined,
                      color: selected ? 'white' : disabled ? '#94a3b8' : '#003f5c',
                      borderColor: selected ? '#003f5c' : disabled ? '#e2e8f0' : '#003f5c'
                    }}
                    title={disabled ? "No spots left" : `${slot.available} spot${slot.available !== 1 ? 's' : ''} available`}
                  >
                    {fmt12h(slot.time)} {disabled ? "— Full" : `(${slot.available})`}
                  </button>
                );
              })}
            </div>
          ) : (
            <div style={{
              marginTop: '12px',
              padding: '12px',
              background: '#f8fafc',
              border: '1px solid #e2e8f0',
              borderRadius: '8px',
              color: '#64748b',
              fontSize: '14px'
            }}>
              No time slots found for the selected date and field. Please select a different date or field.
            </div>
          )}
        </div>
      )}
      {isWOSFieldSelected && ( // Changed from isWOSField to isWOSFieldSelected
        <div style={{
            marginTop: "12px",
            padding: "12px",
            background: "#eff6ff",
            border: "1px solid #bfdbfe",
            borderRadius: "8px",
            fontSize: "14px",
            color: "#1e40af"
          }}>
            You have selected "Waiting on Schedule" for this field. Your game time will also be "Waiting on Schedule".
        </div>
      )}
    </>
  );
}

function TournamentSchedulePicker({ onScheduleChange, initialSchedule, isLeagueEventType, leagueSlots, event }) {
  const [date, setDate] = React.useState(initialSchedule?.date || (event?.startDate || ""));
  const [timeScheduleMode, setTimeScheduleMode] = React.useState(initialSchedule?.timeScheduleMode || "waiting");
  const [firstGameTime, setFirstGameTime] = React.useState(initialSchedule?.gameTimes?.[0] || "");
  const [secondGameTime, setSecondGameTime] = React.useState(initialSchedule?.gameTimes?.[1] || "");
  const [thirdGameTime, setThirdGameTime] = React.useState(initialSchedule?.gameTimes?.[2] || "");

  React.useEffect(() => {
    if (isLeagueEventType) {
      if (date && firstGameTime) {
        onScheduleChange({
          type: "league-manual",
          date,
          gameTimes: [firstGameTime]
        });
      } else {
        onScheduleChange(null);
      }
    } else {
      const gameTimes = [];
      if (timeScheduleMode === "waiting") {
        gameTimes.push("Waiting on Schedule");
      } else {
        if (firstGameTime) gameTimes.push(firstGameTime);
        if (secondGameTime) gameTimes.push(secondGameTime);
        if (thirdGameTime) gameTimes.push(thirdGameTime); 
      }
      if (date && gameTimes.length > 0) {
        onScheduleChange({
          type: "tournament",
          date,
          gameTimes,
          timeScheduleMode,
          isWaitingOnSchedule: timeScheduleMode === "waiting"
        });
      } else {
        onScheduleChange(null);
      }
    }
  }, [date, timeScheduleMode, firstGameTime, secondGameTime, thirdGameTime, isLeagueEventType, onScheduleChange]);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "12px" }}>
      <div>
        <label className="label">Date *</label>
        <input
          type="date"
          className="input"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
      </div>

      {isLeagueEventType ? (
        <div>
          <label className="label">Choose your game time *</label>
          <select
            className="select"
            value={firstGameTime}
            onChange={(e) => setFirstGameTime(e.target.value)}
          >
            <option value="">Select time</option>
            {(leagueSlots || []).map(t => (
              <option key={t} value={t}>{fmt12h(t)}</option>
            ))}
          </select>
        </div>
      ) : (
        <div style={{ gridColumn: "1 / -1" }}>
          <label className="label">Game Times *</label>
          <select
            className="select"
            value={timeScheduleMode}
            onChange={(e) => setTimeScheduleMode(e.target.value)}
            style={{ marginBottom: "12px" }}
          >
            <option value="waiting">Waiting on Schedule</option>
            <option value="enter">Enter Game Times</option>
          </select>

          {timeScheduleMode === "waiting" && (
            <div style={{
              padding: "12px",
              background: "#eff6ff",
              border: "1px solid #bfdbfe",
              borderRadius: "8px",
              fontSize: "14px",
              color: "#1e40af",
              marginTop: "12px"
            }}>
              If your game times haven't been announced yet, we'll set up your equipment based on the schedule when it's available. If you do have them please select all of the ones you have.
            </div>
          )}

          {timeScheduleMode === "enter" && (
            <div style={{ display: "grid", gap: "12px" }}>
              <div>
                <label className="label">1st Game Time (Optional)</label>
                <input
                  type="time"
                  className="input"
                  value={firstGameTime}
                  onChange={(e) => setFirstGameTime(e.target.value)}
                />
              </div>

              <div>
                <label className="label">2nd Game Time (Optional)</label>
                <input
                  type="time"
                  className="input"
                  value={secondGameTime}
                  onChange={(e) => setSecondGameTime(e.target.value)}
                />
              </div>

              <div>
                <label className="label">3rd Game Time (Optional)</label>
                <input
                  type="time"
                  className="input"
                  value={thirdGameTime} 
                  onChange={(e) => setThirdGameTime(e.target.value)}
                />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function LineItemsTable({ lineItems, subtotalUSD, taxUSD, serviceFeeUSD, totalUSD }) {
  return (
    <div style={{ fontSize: "14px", color: "#334155" }}>
      <div style={{ marginBottom: "12px", borderBottom: "1px solid #e2e8f0", paddingBottom: "8px" }}>
        {lineItems.map((item, idx) => (
          <div key={idx} style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
            <span>{item.name} {item.qty > 1 ? `(x${item.qty})` : ''}</span>
            <span>{currency(item.totalUSD)}</span>
          </div>
        ))}
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
        <span>Subtotal</span>
        <span>{currency(subtotalUSD)}</span>
      </div>
      {taxUSD > 0 && (
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
          <span>Tax</span>
          <span>{currency(taxUSD)}</span>
        </div>
      )}
      {serviceFeeUSD > 0 && (
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
          <span>Service Fee</span>
          <span>{currency(serviceFeeUSD)}</span>
        </div>
      )}
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: "12px", paddingTop: "12px", borderTop: "1px dashed #cbd5e1", fontWeight: "700", fontSize: "16px" }}>
        <span>Total</span>
        <span>{currency(totalUSD)}</span>
      </div>
    </div>
  );
}


export default function Book() {
  const [loading, setLoading] = React.useState(true);
  const [settings, setSettings] = React.useState(null);
  const [event, setEvent] = React.useState(null);
  const [allParks, setAllParks] = React.useState([]);
  const [allFields, setAllFields] = React.useState([]);
  const [allSpots, setAllSpots] = React.useState([]);
  const [packages, setPackages] = React.useState([]);
  const [allAddOns, setAllAddOns] = React.useState([]); 
  const [allEquipment, setAllEquipment] = React.useState([]); 
  
  const [selectedPackage, setSelectedPackage] = React.useState(null);
  const [selectedAddOns, setSelectedAddOns] = React.useState([]); // This now tracks only {id, quantity}
  const [addOnSelections, setAddOnSelections] = React.useState({}); // New state for add-on duration choices

  const [selectedSchedule, setSelectedSchedule] = React.useState(null);
  const [leagueDate, setLeagueDate] = React.useState("");
  const [firstGameTime, setFirstGameTime] = React.useState("");
  const [timeSlots, setTimeSlots] = React.useState([]);
  const [isLoadingTimeSlots, setIsLoadingTimeSlots] = React.useState(false);
  const [packageSelection, setPackageSelection] = React.useState({}); // Renamed from pkgDurationSelection

  const [selectedParkId, setSelectedParkId] = React.useState("");
  const [selectedFieldId, setSelectedFieldId] = React.useState("");
  const [selectedSpotId, setSelectedSpotId] = React.useState("");

  const [formData, setFormData] = React.useState({ 
    fullName:"", contactEmail:"", phone:"", teamName:"", coachName:"", notes:"" 
  });

  const [paypalClientId, setPaypalClientId] = React.useState(null);
  const [isProcessingPayment, setIsProcessingPayment] = React.useState(false);
  const [agreedToTerms, setAgreedToTerms] = React.useState(false);
  const [smsConsent, setSmsConsent] = React.useState(false);

  const [currentValidationErrors, setCurrentValidationErrors] = React.useState([]);

  // Coupon state
  const [couponCode, setCouponCode] = React.useState("");
  const [appliedDiscount, setAppliedDiscount] = React.useState(null);
  const [couponError, setCouponError] = React.useState("");
  const [applyingCoupon, setApplyingCoupon] = React.useState(false);

  // New states for detailed calculation results
  const [calculatedBaseCents, setCalculatedBaseCents] = React.useState(0);
  const [calculatedAddOnCents, setCalculatedAddOnCents] = React.useState(0);
  const [calculatedDetailedLineItems, setCalculatedDetailedLineItems] = React.useState([]);

  const [showBestDealModal, setShowBestDealModal] = React.useState(false);
  const [bestDealAnalysis, setBestDealAnalysis] = React.useState(null);
  const [checkingBestDeal, setCheckingBestDeal] = React.useState(false);

  React.useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        const { entities, settings } = await getCtx();
        setSettings(settings || {});
        
        const { data: clientIdData } = await base44.functions.invoke('getPayPalClientId');
        setPaypalClientId(clientIdData?.clientId);
        
        const sp = new URLSearchParams(location.search);
        const eventId = sp.get("event");
        const packageId = sp.get("package");
        
        let ev = null;
        if (eventId) {
          ev = await entities.Events.get(eventId);
          
          if (ev?.leagueDates && Array.isArray(ev.leagueDates)) {
            const validDates = ev.leagueDates.filter(dateStr => {
              try {
                const d = parseISO(dateStr);
                return !isNaN(d.getTime()) && dateStr.match(/^\d{4}-\d{2}-\d{2}$/);
              } catch (e) {
                console.warn("Skipping invalid league date:", dateStr, e);
                return false;
              }
            });
            ev.leagueDates = validDates;
          }
          
          setEvent(ev);
          
          const allParksList = await entities.Parks.list();
          setAllParks(allParksList || []);
          
          if (ev?.parkIds && ev.parkIds.length > 0) {
            const eventParks = allParksList.filter(p => ev.parkIds.includes(p.id));
            if (eventParks.length === 1) {
              setSelectedParkId(eventParks[0].id);
            }
          }
        }
        
        const equipmentList = await entities.Equipment.list();
        setAllEquipment(equipmentList || []);

        const allPkgs = await entities.Packages.list();
        const activePkgs = (allPkgs || []).filter(p => p?.isActive !== false);
        
        if (ev) {
          const eventType = String(ev.eventType || "").toLowerCase();
          
          let filteredPkgs = activePkgs.filter(pkg => {
            if (eventType === "tournament") {
              return pkg.showForTournament !== false;
            } else if (eventType === "league") {
              return pkg.showForLeague === true;
            }
            return pkg.showForTournament !== false || pkg.showForLeague === true;
          });
          
          if (ev.packageIds && ev.packageIds.length > 0) {
            filteredPkgs = filteredPkgs.filter(pkg => ev.packageIds.includes(pkg.id));
          }
          
          setPackages(filteredPkgs);
          
          // Pre-select package if packageId is in URL
          if (packageId) {
            const preSelectedPkg = filteredPkgs.find(p => p.id === packageId);
            if (preSelectedPkg) {
              setSelectedPackage(preSelectedPkg);
            }
          }
        } else {
          setPackages(activePkgs);
        }
        
        // Removed addOnsList fetch and set from here as per instructions, it will be handled by a dedicated useEffect below
        
        const fieldsList = await entities.Fields.list();
        setAllFields(fieldsList || []);

        const spotsList = await entities.Spots.list();
        setAllSpots(spotsList || []);
        
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  React.useEffect(() => {
    (async () => {
      try {
        const { entities } = await getCtx();
        
        // Fetch active add-ons and sort by displayOrder
        let addOnsList = await entities.AddOns.filter({ isActive: true });
        
        // Sort by displayOrder (lower values first)
        addOnsList = (addOnsList || []).sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
        
        setAllAddOns(addOnsList);
      } catch (error) {
        console.error("[Book] Failed to load add-ons:", error);
        setAllAddOns([]);
      }
    })();
  }, []);

  const isLeagueEventType = event?.eventType === "league";

  const availableParks = React.useMemo(() => {
    if (!event) return allParks;
    if (event.parkIds && event.parkIds.length > 0) {
      return allParks.filter(p => event.parkIds.includes(p.id));
    }
    return allParks;
  }, [allParks, event]);

  const availableFields = React.useMemo(() => {
    if (!selectedParkId) return [];
    return allFields.filter(f => f.parkId === selectedParkId);
  }, [allFields, selectedParkId]);

  const availableSpots = React.useMemo(() => {
    // If generic "waiting-on-schedule" is selected, show spots from the first available field
    if (selectedFieldId === "waiting-on-schedule") {
      const firstField = availableFields[0];
      if (firstField) {
        return allSpots.filter(s => s.fieldId === firstField.id);
      }
      return [];
    }
    
    // Otherwise, show spots for the selected field
    if (!selectedFieldId) return [];
    return allSpots.filter(s => s.fieldId === selectedFieldId);
  }, [allSpots, selectedFieldId, availableFields]);

  React.useEffect(() => {
    if (selectedParkId) {
      if (availableFields.length === 0) {
        setSelectedFieldId("");
      } else if (!availableFields.some(f => f.id === selectedFieldId) && selectedFieldId !== "waiting-on-schedule") { // Added check for "waiting-on-schedule"
        const waitingField = availableFields.find(f => f.name && f.name.toLowerCase().includes("waiting on schedule"));
        if (waitingField) {
          setSelectedFieldId(waitingField.id);
        } else if (availableFields.length === 1) {
          setSelectedFieldId(availableFields[0].id);
        } else {
          setSelectedFieldId("");
        }
      }
    } else {
      setSelectedFieldId("");
    }
  }, [selectedParkId, availableFields, selectedFieldId]);

  React.useEffect(() => {
    if (selectedFieldId && selectedFieldId !== "waiting-on-schedule") { // Only check for spots if not generic WOS option
      if (availableSpots.length === 0) {
        setSelectedSpotId("");
      } else if (!availableSpots.some(s => s.id === selectedSpotId)) {
        setSelectedSpotId("");
      }
    } else {
      setSelectedSpotId("");
    }
  }, [selectedFieldId, availableSpots, selectedSpotId]);


  const leagueSlots = React.useMemo(() => {
    if (!event?.leagueStartTime || !event?.leagueEndTime || !event?.leagueBufferMinutes) return [];
    return genLeagueTimeSlots(
      event.leagueStartTime, 
      event.leagueEndTime, 
      Number(event.leagueBufferMinutes || 60)
    );
  }, [event]);


  async function loadInventoryForSlot(dateStr, parkId, fieldId) {
    // Only proceed if it's a specific field ID and not the generic "waiting-on-schedule" option
    if (!event?.id || !dateStr || !parkId || !fieldId || !event.leagueEnabled || fieldId === "waiting-on-schedule") {
      setTimeSlots([]);
      setFirstGameTime("");
      setIsLoadingTimeSlots(false);
      return;
    }

    setIsLoadingTimeSlots(true);
    try {
      const ts = genLeagueTimeSlots(
        event.leagueStartTime,
        event.leagueEndTime,
        Number(event.leagueBufferMinutes || 60)
      );

      const response = await base44.functions.invoke('leagueListInventory', {
        eventId: event.id,
        date: dateStr,
        parkId
      });

      const rows = response.data?.rows || [];
      const byTime = Object.fromEntries(
        rows
          .filter(r => r.fieldId === fieldId)
          .map(r => [r.time, r])
      );

      const enriched = ts.map(t => {
        const r = byTime[t];
        return { time: t, available: r ? Number(r.availableSpots || 0) : 0 };
      });

      setTimeSlots(enriched);
      if (firstGameTime && !enriched.some(slot => slot.time === firstGameTime && slot.available > 0)) {
        setFirstGameTime("");
      }
    } catch (error) {
      console.error("Failed to load inventory:", error);
      setTimeSlots([]);
      setFirstGameTime("");
    } finally {
      setIsLoadingTimeSlots(false);
    }
  }

  const onPickPackage = (pkg) => {
    setSelectedPackage(pkg);
    setSelectedAddOns([]); // Clear selected add-ons
    setAddOnSelections({}); // Clear add-on duration selections
    setPackageSelection({}); // Clear package duration selections (renamed from pkgDurationSelection)
    setSelectedSchedule(null);
    setLeagueDate("");
    setFirstGameTime("");
    setAppliedDiscount(null); // Clear discount when package changes
    setCouponCode("");
    setCouponError("");

    if (window.innerWidth < 768) {
      setTimeout(() => {
        const formElement = document.getElementById('booking-form');
        if (formElement) {
          formElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 100);
    }
  };

  const handlePackageDurationChange = (summary) => {
    setPackageSelection(summary); // Renamed setPkgDurationSelection
  };
  
  function handleAddOnChange(addonId, checked, quantity = 1) {
    if (checked) {
      // When checking an add-on, initialize its selection state
      setSelectedAddOns(prev => [...prev, { id: addonId, quantity }]);
      setAddOnSelections(prev => ({
        ...prev,
        [addonId]: {
          mode: 'per_game', // New default mode
          satGames: 0,
          sunGames: 0,
          satFullDay: false,
          sunFullDay: false
        }
      }));
    } else {
      setSelectedAddOns(prev => prev.filter(a => a.id !== addonId));
      setAddOnSelections(prev => {
        const newState = { ...prev };
        delete newState[addonId];
        return newState;
      });
    }
  }

  function handleAddOnSelectionChange(addonId, field, value) {
    setAddOnSelections(prev => {
      const currentSelection = prev[addonId];
      if (!currentSelection) return prev; // Should not happen if `isSelected` is true

      let newStateForAddon = { ...currentSelection, [field]: value };

      // Logic to ensure only one of satFullDay/satGames is active, and same for Sun
      if (field === 'satFullDay') {
        if (value) newStateForAddon.satGames = 0; // If full day, no games
      } else if (field === 'satGames') {
        if (value > 0) newStateForAddon.satFullDay = false; // If games, not full day
      } else if (field === 'sunFullDay') {
        if (value) newStateForAddon.sunGames = 0; // If full day, no games
      } else if (field === 'sunGames') {
        if (value > 0) newStateForAddon.sunFullDay = false; // If games, not full day
      }
      
      // If mode changes, reset other duration selections for clarity
      if (field === 'mode') {
        if (value === 'weekend') {
          newStateForAddon.satGames = 0;
          newStateForAddon.sunGames = 0;
          newStateForAddon.satFullDay = false;
          newStateForAddon.sunFullDay = false;
        } else if (value === 'per_game') {
          // No automatic reset needed here, as per_game should allow individual day/game selection
        }
      }

      return {
        ...prev,
        [addonId]: newStateForAddon
      };
    });
  }

  React.useEffect(() => {
    // If selectedPackage is null, or event is null, or it's a league event that hasn't selected a date/time yet,
    // or if it's a non-league/non-WYO package and no duration is selected,
    // then reset calculations.
    if (!selectedPackage || !event || (event.leagueEnabled && !selectedSchedule?.date && !selectedSchedule?.isWaitingOnSchedule)) {
      setCalculatedBaseCents(0);
      setCalculatedAddOnCents(0);
      setCalculatedDetailedLineItems([]);
      return;
    }
    
    let newBaseCents = 0;
    let newAddOnCents = 0;
    const items = []; // This will contain detailed line items for display

    // --- PACKAGE PRICING ---
    // If it's a league-enabled event or manually marked as league event type, package is per game, 1 game assumed.
    if (event.leagueEnabled || isLeagueEventType) {
      const gameCost = (selectedPackage.perGameUSD || 0) * 100;
      newBaseCents += gameCost;
      items.push({
        itemName: selectedPackage.name,
        label: `${selectedPackage.name} (League Game)`,
        qty: 1, // 1 duration unit (game)
        unitCents: gameCost, // cost for 1 duration unit
        totalCents: gameCost, // total for this line item
        dayLabel: "League Date",
        durationLabel: "1 Game",
        meta: { type: "PACKAGE", packageId: selectedPackage.id }
      });
    } else { // Tournament/Regular event with package duration selector
      // Check if packageSelection exists and has a totalUSD, indicating a duration was selected
      if (packageSelection && packageSelection.totalUSD > 0) {
        // Use packageSelection.duration to determine the mode and calculate
        const mode = packageSelection.duration;
        const satFullDay = packageSelection.sat?.fullDay || false;
        const sunFullDay = packageSelection.sun?.fullDay || false;
        const satGames = packageSelection.sat?.games || 0;
        const sunGames = packageSelection.sun?.games || 0;

        if (mode === "WEEKEND") {
          const weekendCost = (selectedPackage.fullWeekendUSD || 0) * 100;
          newBaseCents += weekendCost;
          items.push({
            itemName: selectedPackage.name,
            label: `${selectedPackage.name} (Full Weekend)`,
            qty: 1, // 1 duration unit (weekend)
            unitCents: weekendCost,
            totalCents: weekendCost,
            dayLabel: "Sat & Sun",
            durationLabel: "Full Weekend",
            meta: { type: "PACKAGE", packageId: selectedPackage.id }
          });
        } else {
          // Game/Day mode
          if (satFullDay) {
            const dayCost = (selectedPackage.perDayUSD || 0) * 100;
            newBaseCents += dayCost;
            items.push({
              itemName: selectedPackage.name,
              label: `${selectedPackage.name} (Full Day - Sat)`,
              qty: 1, // 1 duration unit (day)
              unitCents: dayCost,
              totalCents: dayCost,
              dayLabel: "Saturday",
              durationLabel: "Full Day",
              meta: { type: "PACKAGE", packageId: selectedPackage.id }
            });
          } else if (satGames > 0) {
            const gameCost = (selectedPackage.perGameUSD || 0) * 100;
            const satTotalCost = gameCost * satGames;
            newBaseCents += satTotalCost;
            items.push({
              itemName: selectedPackage.name,
              label: `${selectedPackage.name} (${satGames} game${satGames > 1 ? 's' : ''} - Sat)`,
              qty: satGames, // Number of duration units (games)
              unitCents: gameCost, // Cost per duration unit (per game)
              totalCents: satTotalCost, // Total for this line item (games * cost_per_game)
              dayLabel: "Saturday",
              durationLabel: `${satGames} Game${satGames > 1 ? 's' : ''}`,
              meta: { type: "PACKAGE", packageId: selectedPackage.id }
            });
          }

          if (sunFullDay) {
            const dayCost = (selectedPackage.perDayUSD || 0) * 100;
            newBaseCents += dayCost;
            items.push({
              itemName: selectedPackage.name,
              label: `${selectedPackage.name} (Full Day - Sun)`,
              qty: 1, // 1 duration unit (day)
              unitCents: dayCost,
              totalCents: dayCost,
              dayLabel: "Sunday",
              durationLabel: "Full Day",
              meta: { type: "PACKAGE", packageId: selectedPackage.id }
            });
          } else if (sunGames > 0) {
            const gameCost = (selectedPackage.perGameUSD || 0) * 100;
            const sunTotalCost = gameCost * sunGames;
            newBaseCents += sunTotalCost;
            items.push({
              itemName: selectedPackage.name,
              label: `${selectedPackage.name} (${sunGames} game${sunGames > 1 ? 's' : ''} - Sun)`,
              qty: sunGames, // Number of duration units (games)
              unitCents: gameCost, // Cost per duration unit (per game)
              totalCents: sunTotalCost, // Total for this line item (games * cost_per_game)
              dayLabel: "Sunday",
              durationLabel: `${sunGames} Game${sunGames > 1 ? 's' : ''}`,
              meta: { type: "PACKAGE", packageId: selectedPackage.id }
            });
          }
        }
      }
    }

    // --- ADD-ON PRICING ---
    selectedAddOns.forEach(selectedAddon => {
      const addon = allAddOns.find(a => a.id === selectedAddon.id);
      if (!addon) return;

      const addonQty = selectedAddon.quantity || 1; // Actual number of physical add-on items

      // If it's a league/manual league event, add-ons are per game, 1 game assumed
      if (event.leagueEnabled || isLeagueEventType) {
        const gameCostPerItem = (addon.perGameUSD || 0) * 100;
        const totalAddonCost = gameCostPerItem * addonQty;
        newAddOnCents += totalAddonCost;
        items.push({
          itemName: addon.label,
          label: `${addon.label} (League Game x${addonQty})`,
          qty: addonQty, // Physical item quantity
          unitCents: gameCostPerItem, // Unit cost per item for 1 game
          totalCents: totalAddonCost, // Total for this specific line item
          dayLabel: "League Date",
          durationLabel: "1 Game",
          meta: { type: "ADDON", addonId: addon.id }
        });
        return; // Skip complex duration logic for league
      }

      const selection = addOnSelections[addon.id];
      if (!selection) return;

      let currentAddonUnitTotalPerItem = 0; // Cost for one add-on item based on its duration selection

      if (selection.mode === 'weekend' && addon.fullWeekendUSD > 0) {
        currentAddonUnitTotalPerItem = (addon.fullWeekendUSD || 0) * 100;
        newAddOnCents += currentAddonUnitTotalPerItem * addonQty;
        items.push({
          itemName: addon.label,
          label: `${addon.label} (Full Weekend x${addonQty})`,
          qty: addonQty,
          unitCents: currentAddonUnitTotalPerItem,
          totalCents: currentAddonUnitTotalPerItem * addonQty,
          dayLabel: "Sat & Sun",
          durationLabel: "Full Weekend",
          meta: { type: "ADDON", addonId: addon.id }
        });
      } else if (selection.mode === 'per_game') {
        const addonSatGames = selection.satGames || 0;
        const addonSunGames = selection.sunGames || 0;
        const addonSatFullDay = selection.satFullDay || false;
        const addonSunFullDay = selection.sunFullDay || false;

        // Saturday add-on
        if (addonSatFullDay) {
          const dayCostPerItem = (addon.perDayUSD || 0) * 100;
          currentAddonUnitTotalPerItem += dayCostPerItem;
          items.push({
            itemName: addon.label,
            label: `${addon.label} (Full Day - Sat x${addonQty})`,
            qty: addonQty,
            unitCents: dayCostPerItem,
            totalCents: dayCostPerItem * addonQty,
            dayLabel: "Saturday",
            durationLabel: "Full Day",
            meta: { type: "ADDON", addonId: addon.id }
          });
        } else if (addonSatGames > 0) {
          const gameCostPerGamePerItem = (addon.perGameUSD || 0) * 100;
          const totalLineItemCostPerUnit = gameCostPerGamePerItem * addonSatGames;
          currentAddonUnitTotalPerItem += totalLineItemCostPerUnit;
          items.push({
            itemName: addon.label,
            label: `${addon.label} (${addonSatGames} game${addonSatGames > 1 ? 's' : ''} - Sat x${addonQty})`,
            qty: addonQty,
            unitCents: totalLineItemCostPerUnit,
            totalCents: totalLineItemCostPerUnit * addonQty,
            dayLabel: "Saturday",
            durationLabel: `${addonSatGames} Game${addonSatGames > 1 ? 's' : ''}`,
            meta: { type: "ADDON", addonId: addon.id }
          });
        }

        // Sunday add-on
        if (addonSunFullDay) {
          const dayCostPerItem = (addon.perDayUSD || 0) * 100;
          currentAddonUnitTotalPerItem += dayCostPerItem;
          items.push({
            itemName: addon.label,
            label: `${addon.label} (Full Day - Sun x${addonQty})`,
            qty: addonQty,
            unitCents: dayCostPerItem,
            totalCents: dayCostPerItem * addonQty,
            dayLabel: "Sunday",
            durationLabel: "Full Day",
            meta: { type: "ADDON", addonId: addon.id }
          });
        } else if (addonSunGames > 0) {
          const gameCostPerGamePerItem = (addon.perGameUSD || 0) * 100;
          const totalLineItemCostPerUnit = gameCostPerGamePerItem * addonSunGames;
          currentAddonUnitTotalPerItem += totalLineItemCostPerUnit;
          items.push({
            itemName: addon.label,
            label: `${addon.label} (${addonSunGames} game${addonSunGames > 1 ? 's' : ''} - Sun x${addonQty})`,
            qty: addonQty,
            unitCents: totalLineItemCostPerUnit,
            totalCents: totalLineItemCostPerUnit * addonQty,
            dayLabel: "Sunday",
            durationLabel: `${addonSunGames} Game${addonSunGames > 1 ? 's' : ''}`,
            meta: { type: "ADDON", addonId: addon.id }
          });
        }
        newAddOnCents += currentAddonUnitTotalPerItem * addonQty; // Sum of all per_game costs for this add-on
      }
    });

    setCalculatedBaseCents(newBaseCents);
    setCalculatedAddOnCents(newAddOnCents);
    setCalculatedDetailedLineItems(items);
  }, [selectedPackage, packageSelection, selectedAddOns, addOnSelections, allAddOns, event, isLeagueEventType, selectedSchedule]);


  const handleScheduleChange = (scheduleDetails) => {
    setSelectedSchedule(scheduleDetails);
  };
  
  const handleLeagueScheduleChange = (scheduleDetails) => {
    setSelectedSchedule(scheduleDetails);
  };

  const currentSelectedField = allFields.find(f => f.id === selectedFieldId);
  
  // For WOS scenarios, use the first available field for spot display
  const fieldForSpotDisplay = selectedFieldId === "waiting-on-schedule" 
    ? availableFields[0] 
    : currentSelectedField;
  
  const isActualFieldWOSNamed = currentSelectedField?.name?.toLowerCase().includes("waiting on schedule");
  const isGenericWOSOptionSelected = selectedFieldId === "waiting-on-schedule";

  // This flag determines if *any* "Waiting on Schedule" scenario is active for the field
  const isWOSFieldSelected = isActualFieldWOSNamed || isGenericWOSOptionSelected;

  const calculateCurrentOrderSummary = React.useMemo(() => {
    if (!selectedPackage || !event) return null;

    const packageTotalUSD = calculatedBaseCents / 100;
    const addOnsTotalUSD = calculatedAddOnCents / 100;

    // Construct lineItems for display from calculatedDetailedLineItems
    const lineItemsForDisplay = calculatedDetailedLineItems.map(item => ({
      type: item.meta.type.toLowerCase(),
      name: item.label, // Use the detailed label
      qty: item.qty, // This `qty` depends on how you defined it in calculatedDetailedLineItems
      unitPriceUSD: item.unitCents / 100, // Unit price for whatever 'qty' represents
      totalUSD: item.totalCents / 100,
      // durationSummary is not directly derived here for booking data separately
    }));
    
    const subtotalUSD = packageTotalUSD + addOnsTotalUSD;
    const taxPct = Number(settings?.taxPct || 0) / 100;
    const serviceFeePct = Number(settings?.serviceFeePct || 0) / 100;

    const taxUSD = subtotalUSD * taxPct;
    const serviceFeeUSD = subtotalUSD * serviceFeePct;
    
    let discountUSD = 0;
    if (appliedDiscount) {
      discountUSD = appliedDiscount.discountCents / 100;
    }
    
    const totalUSD = subtotalUSD + taxUSD + serviceFeeUSD - discountUSD;

    // --- Re-construct packageDurationSummary for booking data ---
    let packageDurationSummary = null;
    if (event.leagueEnabled || isLeagueEventType) {
      // League event, hardcode 1 game
      packageDurationSummary = { duration: "GAME", baseUSD: selectedPackage.perGameUSD || 0, totalUSD: selectedPackage.perGameUSD || 0, sat: {fullDay: false, games: 1}, sun: {fullDay: false, games: 0} };
    } else if (packageSelection?.totalUSD) {
      packageDurationSummary = packageSelection; // Use the value directly from packageSelector
    } else {
      // Fallback for packages that might not use duration selector (e.g., 'build your own')
      // Or if nothing is selected yet, provide a sensible default if the package has a default game price
      packageDurationSummary = { duration: "GAME", baseUSD: selectedPackage.perGameUSD || 0, totalUSD: selectedPackage.perGameUSD || 0, sat: {fullDay: false, games: 1}, sun: {fullDay: false, games: 0} };
    }

    // --- Re-construct selectedAddOnLineItems for booking data ---
    const allAddonsById = Object.fromEntries(allAddOns.map(a => [a.id, a]));
    const selectedAddOnLineItemsForBooking = selectedAddOns.map(selItem => {
      const addon = allAddonsById[selItem.id];
      if (!addon) return null;

      const quantity = Math.max(1, parseInt(selItem.quantity) || 1);
      const selection = addOnSelections[selItem.id]; // Use selItem.id here
      
      let addonPricePerUnit = 0; // Price for one physical add-on item for its selected duration
      let addonDurationSummary = { mode: 'per_game', sat: { fullDay: false, games: 0 }, sun: { fullDay: false, games: 0 }, duration: "NONE", baseUSD: 0, totalUSD: 0 };
      
      if (event.leagueEnabled || isLeagueEventType) {
        addonPricePerUnit = (addon.perGameUSD || 0); // Per game per item
        addonDurationSummary = { mode: 'per_game', duration: "GAME", baseUSD: addonPricePerUnit, totalUSD: addonPricePerUnit, sat: {fullDay: false, games: 1}, sun: {fullDay: false, games: 0} };
      } else if (selection) {
        addonDurationSummary.mode = selection.mode;
        if (selection.mode === 'weekend' && addon.fullWeekendUSD > 0) {
          addonPricePerUnit = addon.fullWeekendUSD;
          addonDurationSummary.duration = "WEEKEND";
          addonDurationSummary.baseUSD = addon.fullWeekendUSD;
          addonDurationSummary.totalUSD = addon.fullWeekendUSD;
        } else if (selection.mode === 'per_game') {
          let currentAddonUnitTotalPerItem = 0;
          let satDetails = { fullDay: selection.satFullDay, games: selection.satGames };
          let sunDetails = { fullDay: selection.sunFullDay, games: selection.sunGames };

          // Calculate for Saturday
          if (selection.satFullDay) {
            currentAddonUnitTotalPerItem += addon.perDayUSD || 0;
          } else {
            currentAddonUnitTotalPerItem += (addon.perGameUSD || 0) * selection.satGames;
          }

          // Calculate for Sunday
          if (selection.sunFullDay) {
            currentAddonUnitTotalPerItem += addon.perDayUSD || 0;
          } else {
            currentAddonUnitTotalPerItem += (addon.perGameUSD || 0) * selection.sunGames;
          }
          
          addonPricePerUnit = currentAddonUnitTotalPerItem;
          let durationType = "NONE";
          if (selection.satFullDay || selection.sunFullDay) durationType = "DAY";
          if (selection.satGames > 0 || selection.sunGames > 0) durationType = "GAME";
          if ((selection.satFullDay || selection.satGames > 0) && (selection.sunFullDay || selection.sunGames > 0)) durationType = "WEEKEND_MIXED"; 

          addonDurationSummary = {
            mode: 'per_game',
            sat: satDetails,
            sun: sunDetails,
            duration: durationType,
            baseUSD: currentAddonUnitTotalPerItem,
            totalUSD: currentAddonUnitTotalPerItem
          };
        }
      }
      return { addon: addon, quantity: quantity, durationSummary: addonDurationSummary };
    }).filter(Boolean);

    return {
      lineItems: lineItemsForDisplay, // For display
      packageTotalUSD,
      addOnsTotalUSD,
      subtotalUSD,
      taxUSD,
      serviceFeeUSD,
      discountUSD,
      totalUSD,
      packageDurationSummary, // For booking data
      selectedAddOnLineItems: selectedAddOnLineItemsForBooking // For booking data
    };
  }, [
    selectedPackage, event, settings, appliedDiscount,
    calculatedBaseCents, calculatedAddOnCents, calculatedDetailedLineItems,
    packageSelection, selectedAddOns, addOnSelections, allAddOns,
    isLeagueEventType
  ]);

  async function handleCheckBestDeal() {
    if (!selectedPackage || !event || !calculateCurrentOrderSummary) {
      alert("Please select a package and ensure event details are loaded first.");
      return;
    }

    setCheckingBestDeal(true);
    setShowBestDealModal(true);
    
    try {
      const addOnsData = selectedAddOns.map(addon => ({
        id: addon.id,
        quantity: addon.quantity || 1,
        selections: addOnSelections[addon.id] || {}
      }));

      const response = await base44.functions.invoke('checkBestDeal', {
        currentPackageId: selectedPackage.id,
        currentAddOns: addOnsData,
        eventId: event.id,
        packageSelection: packageSelection,
        addOnSelections: addOnSelections, // Pass all add-on selections
        isLeagueEventType: isLeagueEventType,
        eventLeagueEnabled: event.leagueEnabled,
      });

      setBestDealAnalysis(response.data);
    } catch (error) {
      console.error('Failed to check best deal:', error);
      setBestDealAnalysis({
        hasAlternative: false,
        message: "We couldn't check for alternatives right now, but you can proceed with your booking!",
        analysis: ""
      });
    } finally {
      setCheckingBestDeal(false);
    }
  }

  function handleSwitchToRecommended() {
    if (!bestDealAnalysis?.recommendedPackage) return;
    
    const recommendedPkg = packages.find(p => p.id === bestDealAnalysis.recommendedPackage.id);
    if (!recommendedPkg) return;
    
    // Switch to recommended package
    setSelectedPackage(recommendedPkg);
    
    // Preserve the original package duration selection
    // The packageSelection state already contains the customer's choice (weekend, sat games, sun games, etc.)
    // We keep it as-is so the new package uses the same duration
    // No need to reset packageSelection - keep the customer's original choice
    
    // If there are missing items, convert them to add-ons WITH THE SAME DURATION
    const newAddOns = [];
    const newAddOnSelections = {};
    
    if (bestDealAnalysis.missingItems && bestDealAnalysis.missingItems.length > 0) {
      // The bestDealAnalysis should contain the original selection info
      // We'll use the package selection to infer what the customer wanted
      
      bestDealAnalysis.missingItems.forEach(item => {
        if (item.addon) {
          newAddOns.push({
            id: item.addon.id,
            quantity: item.quantity
          });
          
          // Use the customer's original package duration selection for the add-ons
          if (packageSelection.duration === 'WEEKEND') {
            // Customer chose full weekend
            newAddOnSelections[item.addon.id] = {
              mode: 'weekend',
              satGames: 0,
              sunGames: 0,
              satFullDay: false,
              sunFullDay: false
            };
          } else {
            // Customer chose game/day mode - preserve their sat/sun selections
            newAddOnSelections[item.addon.id] = {
              mode: 'per_game',
              satGames: packageSelection.sat?.games || 0,
              sunGames: packageSelection.sun?.games || 0,
              satFullDay: packageSelection.sat?.fullDay || false,
              sunFullDay: packageSelection.sun?.fullDay || false
            };
          }
        }
      });
    }
    
    setSelectedAddOns(newAddOns);
    setAddOnSelections(newAddOnSelections);
    setShowBestDealModal(false);
    
    if (window.innerWidth < 768) {
      setTimeout(() => {
        const packageElement = document.getElementById('booking-form');
        if (packageElement) {
            packageElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 100);
    }
  }

  // Apply coupon function
  async function handleApplyCoupon() {
    if (!couponCode.trim()) {
      setCouponError("Please enter a discount code");
      return;
    }

    if (!formData.contactEmail) {
      setCouponError("Please enter your email first");
      return;
    }

    setCouponError("");
    setApplyingCoupon(true);
    
    try {
      const subtotalCents = Math.round((calculateCurrentOrderSummary.subtotalUSD || 0) * 100);
      
      const response = await base44.functions.invoke('validateDiscountCode', {
        code: couponCode.trim(),
        subtotalCents: subtotalCents,
        customerEmail: formData.contactEmail,
        packageId: selectedPackage?.id,
        eventId: event?.id
      });
      
      if (response.data.valid) {
        setAppliedDiscount(response.data.discountCode);
        setCouponError("");
      } else {
        setCouponError(response.data.error || "Invalid discount code");
        setAppliedDiscount(null);
      }
    } catch (error) {
      console.error("Failed to validate coupon:", error);
      setCouponError("Failed to validate code. Please try again.");
      setAppliedDiscount(null);
    } finally {
      setApplyingCoupon(false);
    }
  }

  function handleRemoveCoupon() {
    setCouponCode("");
    setAppliedDiscount(null);
    setCouponError("");
  }

  React.useEffect(() => {
    const errors = [];

    if (!formData.fullName) errors.push("Please enter your full name.");
    if (!formData.contactEmail) errors.push("Please enter your email address.");
    if (!formData.phone) errors.push("Please enter your phone number.");
    if (!formData.teamName) errors.push("Please enter your team name.");
    
    if (!selectedPackage) errors.push("Please select a package.");
    
    if (!selectedParkId) errors.push("Please select a park.");
    if (!selectedFieldId) errors.push("Please select a field.");
    
    // Only validate spot selection if a specific field is chosen and it has spots
    if (selectedFieldId && availableSpots.length > 0 && !selectedSpotId) {
      errors.push("Please select a spot on the field.");
    }

    if (event) { 
      if (!selectedSchedule) {
        errors.push("Please complete the schedule selection.");
      } else {
        if (!selectedSchedule.date && !selectedSchedule.isWaitingOnSchedule) errors.push("Please select a date for your booking.");
        
        // This logic now accounts for both actual WOS fields and the generic WOS option via isWOSFieldSelected
        if (event.leagueEnabled) {
          if (!selectedSchedule.isWaitingOnSchedule && !firstGameTime) {
            errors.push("Please select a game time from the available slots.");
          }
        } else if (isLeagueEventType) {
          if (!selectedSchedule.date || selectedSchedule.gameTimes.length === 0) {
            errors.push("Please select a date and game time for your league booking.");
          }
        } else {
          if (!selectedSchedule.isWaitingOnSchedule && selectedSchedule.gameTimes.filter(t => t !== "Waiting on Schedule").length === 0) {
            errors.push("Please enter at least one game time, or select 'Waiting on Schedule'.");
          }
        }
      }
      
      // Validate package duration selection for non-league/tournament and non-build-your-own
      if (!event.leagueEnabled && !isLeagueEventType && selectedPackage && !selectedPackage.name.toLowerCase().includes("build your own") && !selectedPackage.name.toLowerCase().includes("create your own") && !packageSelection?.totalUSD) {
        errors.push("Please specify the duration for your package.");
      }

      // Validate add-on duration selections
      const allAddonsById = Object.fromEntries((allAddOns || []).map(a => [a.id, a]));
      for (const selAddon of (selectedAddOns || [])) {
        const addon = allAddonsById[selAddon.id];
        
        // Skip if addon doesn't exist (was deleted or not loaded yet)
        if (!addon) continue;
        
        const selection = addOnSelections[addon.id];
        
        // If it's a league/manual league event, add-ons are per game, no specific duration selection needed
        if (event.leagueEnabled || isLeagueEventType) continue; 
        
        if (!selection) {
          errors.push(`Please specify duration for selected add-on: ${addon.label}.`);
          continue;
        }

        if (selection.mode === 'weekend') {
          if ((addon.fullWeekendUSD || 0) <= 0) {
            errors.push(`Full Weekend option not available for ${addon.label}. Please select Game/Day option.`);
          }
        } else if (selection.mode === 'per_game') {
          if (selection.satGames === 0 && !selection.satFullDay && selection.sunGames === 0 && !selection.sunFullDay) {
            errors.push(`Please specify at least one day/game for selected add-on: ${addon.label}.`);
          }
        } else {
          // If mode is not set or invalid
          errors.push(`Please specify duration mode for selected add-on: ${addon.label}.`);
        }
      }

    } else {
      errors.push("Event details are not fully loaded.");
    }

    if (!agreedToTerms) { // Check separately
      errors.push("Please agree to the Terms & Conditions and Privacy Policy.");
    }
    // SMS consent is now optional and does not block validation
    // if (!smsConsent) { // Check separately
    //   errors.push("Please provide SMS consent.");
    // }

    setCurrentValidationErrors(errors);
  }, [
    formData, selectedPackage, selectedParkId, selectedFieldId, selectedSpotId, availableSpots.length, 
    selectedSchedule, event, agreedToTerms, isLeagueEventType, packageSelection, allFields, firstGameTime,
    isWOSFieldSelected, selectedAddOns, addOnSelections, allAddOns
  ]);

  const canShowFieldSelection = !!selectedPackage;

  async function handlePaymentSuccess(paypalOrderId) {
    if (currentValidationErrors.length > 0 || !agreedToTerms || !selectedSchedule || !event || !calculateCurrentOrderSummary) {
      alert("Please correct validation errors before proceeding.");
      return;
    }
    
    setIsProcessingPayment(true);
    
    try {
      console.log("[book-new.js] Payment succeeded, creating booking with orderID:", paypalOrderId);

      // Use the unified isWOSFieldSelected flag here
      if (event?.leagueEnabled && !isWOSFieldSelected && selectedSchedule?.gameTimes?.[0] !== "Waiting on Schedule") {
        try {
          const reserveResult = await base44.functions.invoke('leagueReserveSlotCAS', {
            eventId: event.id,
            date: leagueDate,
            parkId: selectedParkId,
            fieldId: selectedFieldId,
            time: firstGameTime
          });
        } catch (reserveError) {
          console.error("[Book] League slot reservation failed:", reserveError);
          const errorMessage = reserveError.response?.data?.error 
            || reserveError.message 
            || 'Failed to reserve time slot';
          
          if (errorMessage.includes('No spots left') || errorMessage.includes('just booked')) {
            alert("Sorry, this time slot was just booked by someone else. Please select another time or refresh the page.");
            await loadInventoryForSlot(leagueDate, selectedParkId, selectedFieldId);
            setIsProcessingPayment(false);
            return;
          }
          
          if (errorMessage.includes('not found')) {
            alert("This time slot is no longer available. Please refresh the page and select another time.");
            await loadInventoryForSlot(leagueDate, selectedParkId, selectedFieldId);
            setIsProcessingPayment(false);
            return;
          }
          
          alert(`Unable to reserve this time slot: ${errorMessage}\n\nPlease try again or contact support.`);
          setIsProcessingPayment(false);
          return;
        }
      }

      const selectedPark = allParks.find(p => p.id === selectedParkId);
      const selectedSpot = allSpots.find(s => s.id === selectedSpotId);

      const pkgDuration = calculateCurrentOrderSummary.packageDurationSummary;
      const packageMode = pkgDuration?.duration || "GAME"; // Default to GAME
      const packageGameDayChoice = (pkgDuration?.sat?.fullDay || pkgDuration?.sat?.games > 0) ? "sat" : ((pkgDuration?.sun?.fullDay || pkgDuration?.sun?.games > 0) ? "sun" : null); // Simple day choice
      const packageGameCountChoice = String((pkgDuration?.sat?.games || 0) + (pkgDuration?.sun?.games || 0)); // Total games

      // Create the booking with status "paid" instead of "confirmed"
      const bookingData = {
        fullName: formData.fullName,
        contactEmail: formData.contactEmail,
        phone: formData.phone,
        teamName: formData.teamName || "",
        coachName: formData.coachName || "",
        eventId: event?.id,
        eventType: event?.eventType,
        sport: event?.sport,
        date: selectedSchedule?.date,
        gameTimes: selectedSchedule?.gameTimes,
        parkId: selectedParkId,
        parkName: selectedPark?.name,
        fieldId: selectedFieldId,
        fieldName: currentSelectedField?.name,
        spotId: selectedSpotId,
        setupSideLabel: selectedSpot?.label || "",
        packageId: selectedPackage?.id,
        packageName: selectedPackage?.name,
        packageMode: packageMode,
        packageGameDayChoice: packageGameDayChoice,
        packageGameCountChoice: packageGameCountChoice,
        addOns: calculateCurrentOrderSummary.selectedAddOnLineItems.map(item => ({
          id: item.addon.id,
          label: item.addon.label,
          quantity: item.quantity,
          durationSummary: item.durationSummary
        })),
        quantitySummary: { items: [] }, 
        notes: formData.notes,
        totals: { amount: calculateCurrentOrderSummary.totalUSD },
        payment: {
          provider: "paypal",
          status: "captured",
          orderId: paypalOrderId,
        },
        status: "paid", // Changed from "confirmed" to "paid"
        selectionJson: {
          dateISO: selectedSchedule?.date,
          times: selectedSchedule?.gameTimes,
          gameDay: packageGameDayChoice,
          mode: packageMode,
        },
        lineItemsJson: calculateCurrentOrderSummary.lineItems,
        baseCents: Math.round((calculateCurrentOrderSummary.packageTotalUSD || 0) * 100),
        addOnCents: Math.round((calculateCurrentOrderSummary.addOnsTotalUSD || 0) * 100),
        discountCodeId: appliedDiscount?.id || null,
        discountCodeUsed: appliedDiscount?.code || null,
        discountAmountCents: appliedDiscount?.discountCents || 0,
        discountType: appliedDiscount?.type || null,
        loyaltyPointsEarned: 0,
        loyaltyPointsRedeemed: 0, 
        loyaltyDiscountCents: 0,
        totalCents: Math.round((calculateCurrentOrderSummary.totalUSD || 0) * 100),
        agreedToTerms: agreedToTerms,
        smsConsentGiven: smsConsent,
        smsConsentAt: smsConsent ? new Date().toISOString() : null,
        consentIp: "",
        consentUa: navigator.userAgent || "",
      };

      console.log("[book-new.js] Creating booking with data:", bookingData);
      const createdBooking = await base44.entities.Bookings.create(bookingData);
      console.log("[book-new.js] Booking created successfully:", createdBooking.id);

      // Increment discount code usage count
      if (appliedDiscount?.id) {
        try {
          const discountCode = await base44.entities.DiscountCodes.get(appliedDiscount.id);
          await base44.entities.DiscountCodes.update(appliedDiscount.id, {
            usageCount: (discountCode.usageCount || 0) + 1
          });
        } catch (error) {
          console.error("Failed to increment discount usage:", error);
        }
      }
      
      location.href = `/thankyou?b=${encodeURIComponent(createdBooking.id)}`;
    } catch (e) {
      console.error(e);
      alert(e.message || "Booking failed");
      setIsProcessingPayment(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">No Event Selected</h2>
          <a href="/events" className="btn">Browse Events</a>
        </div>
      </div>
    );
  }

  const fallbackImages = {
    softball: "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/eb3b03633_brandon-mowinkel-3_JwPJwq6CI-unsplash.jpg",
    baseball: "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/96e85a991_mike-bowman-xKShyIiTNJk-unsplash.jpg",
    soccer: "https://base44.app/api/apps/68ed15e6afeaf6ac7473f87c/files/public/68ed15e6afeaf6ac7473f87c/fc0a60797_vikram-tkv-JO19K0HDDXI-unsplash.jpg",
  };
  
  const brandName = settings?.brandName || "Sideline Setups";
  const supportNumber = settings?.supportPhone || "+19035419287";
  
  return (
    <div 
      className="min-h-screen"
      style={{
        backgroundImage: settings?.pageBackgroundPatternUrl 
          ? `linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.92)), url('${settings.pageBackgroundPatternUrl}')`
          : undefined,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
        backgroundColor: '#f0f2f5'
      }}
    >
      {/* Best Deal Check Modal */}
      {showBestDealModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 2000,
          padding: '20px'
        }}>
          <div style={{
            background: 'white',
            borderRadius: '16px',
            padding: '32px',
            maxWidth: '700px',
            width: '100%',
            maxHeight: '90vh',
            overflow: 'auto',
            boxShadow: '0 20px 60px rgba(0,0,0,0.3)'
          }}>
            {checkingBestDeal ? (
              <div style={{ textAlign: 'center', padding: '40px 20px' }}>
                <Sparkles 
                  size={48} 
                  style={{ 
                    margin: '0 auto 24px', 
                    color: '#003f5c',
                    animation: 'pulse 2s ease-in-out infinite'
                  }} 
                />
                <style>{`
                  @keyframes pulse {
                    0%, 100% { opacity: 1; transform: scale(1); }
                    50% { opacity: 0.5; transform: scale(1.1); }
                  }
                `}</style>
                <h3 style={{ margin: '0 0 12px 0', fontSize: '24px', color: '#003f5c' }}>
                  Checking for Better Deals...
                </h3>
                <p style={{ color: '#64748b', margin: 0 }}>
                  Our AI is analyzing all package options to make sure you're getting the best value
                </p>
              </div>
            ) : bestDealAnalysis ? (
              <div>
                {bestDealAnalysis.hasAlternative ? (
                  <>
                    <div style={{ textAlign: 'center', marginBottom: '24px' }}>
                      <div style={{
                        width: '64px',
                        height: '64px',
                        background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                        borderRadius: '50%',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto 16px'
                      }}>
                        <Sparkles size={32} color="white" />
                      </div>
                      <h3 style={{ margin: '0 0 8px 0', fontSize: '28px', color: '#003f5c' }}>
                        Great News!
                      </h3>
                      <p style={{ 
                        fontSize: '18px', 
                        color: '#10b981', 
                        fontWeight: '600',
                        margin: '0 0 16px 0'
                      }}>
                        We Found You a Better Deal
                      </p>
                    </div>

                    <div style={{
                      background: '#f0fdf4',
                      border: '2px solid #10b981',
                      borderRadius: '12px',
                      padding: '20px',
                      marginBottom: '24px'
                    }}>
                      <p style={{ 
                        fontSize: '16px', 
                        lineHeight: '1.6',
                        color: '#064e3b',
                        margin: '0 0 16px 0'
                      }}>
                        {bestDealAnalysis.message}
                      </p>
                      
                      {/* Coverage Badge */}
                      <div style={{
                        display: 'inline-block',
                        padding: '8px 16px',
                        background: '#dcfce7',
                        borderRadius: '999px',
                        fontSize: '14px',
                        fontWeight: '600',
                        color: '#065f46',
                        marginBottom: '16px'
                      }}>
                        ✓ {bestDealAnalysis.coveragePercent}% coverage
                      </div>

                      <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        padding: '16px',
                        background: 'white',
                        borderRadius: '8px',
                        marginBottom: '12px'
                      }}>
                        <div>
                          <div style={{ fontSize: '14px', color: '#64748b', marginBottom: '4px' }}>
                            Your Current Selection:
                          </div>
                          <div style={{ fontSize: '18px', fontWeight: '600', color: '#0f172a' }}>
                            ${bestDealAnalysis.currentSelection.totalPrice.toFixed(2)}
                          </div>
                        </div>
                        <div style={{ fontSize: '24px', color: '#64748b' }}>→</div>
                        <div>
                          <div style={{ fontSize: '14px', color: '#10b981', marginBottom: '4px' }}>
                            New Total:
                          </div>
                          <div style={{ fontSize: '18px', fontWeight: '600', color: '#10b981' }}>
                            ${bestDealAnalysis.newTotal.toFixed(2)}
                          </div>
                        </div>
                      </div>
                      
                      {bestDealAnalysis.savings !== undefined && (
                        <div style={{
                          textAlign: 'center',
                          padding: '12px',
                          background: '#dcfce7',
                          borderRadius: '8px'
                        }}>
                          <div style={{ fontSize: '14px', color: '#065f46', marginBottom: '4px' }}>
                            {bestDealAnalysis.savings >= 0 ? 'You Save:' : 'Small Upgrade Cost:'}
                          </div>
                          <div style={{ fontSize: '24px', fontWeight: '700', color: '#10b981' }}>
                            {bestDealAnalysis.savings >= 0 ? `$${bestDealAnalysis.savings.toFixed(2)}` : `$${Math.abs(bestDealAnalysis.savings).toFixed(2)}`}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Upgraded Items - NEW */}
                    {bestDealAnalysis.upgradedItems && bestDealAnalysis.upgradedItems.length > 0 && (
                      <div style={{
                        background: '#fef3c7',
                        border: '2px solid #fbbf24',
                        borderRadius: '12px',
                        padding: '16px',
                        marginBottom: '16px'
                      }}>
                        <h4 style={{ margin: '0 0 8px 0', fontSize: '14px', color: '#92400e', display: 'flex', alignItems: 'center', gap: '8px' }}>
                          ⭐ Premium Upgrades Included:
                        </h4>
                        <ul style={{ 
                          margin: '0', 
                          paddingLeft: '24px',
                          color: '#92400e',
                          fontSize: '14px'
                        }}>
                          {bestDealAnalysis.upgradedItems.map((item, idx) => (
                            <li key={idx} style={{ marginBottom: '4px' }}>
                              <strong>{item.qty}x {item.name}</strong> (upgraded from {item.replacesName})
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* What's Included */}
                    <div style={{
                      background: '#f8fafc',
                      borderRadius: '12px',
                      padding: '20px',
                      marginBottom: '16px'
                    }}>
                      <h4 style={{ margin: '0 0 12px 0', fontSize: '16px', color: '#003f5c' }}>
                        "{bestDealAnalysis.recommendedPackage.name}" includes:
                      </h4>
                      <ul style={{ 
                        margin: '0', 
                        paddingLeft: '24px',
                        color: '#475569'
                      }}>
                        {bestDealAnalysis.packageIncludes?.map((item, idx) => (
                          <li key={idx} style={{ marginBottom: '6px' }}>
                            <span style={{ color: '#10b981', marginRight: '8px' }}>✓</span>
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Bonus Items */}
                    {bestDealAnalysis.bonusItems && bestDealAnalysis.bonusItems.length > 0 && (
                      <div style={{
                        background: '#fef3c7',
                        border: '2px solid #fbbf24',
                        borderRadius: '12px',
                        padding: '16px',
                        marginBottom: '16px'
                      }}>
                        <h4 style={{ margin: '0 0 8px 0', fontSize: '14px', color: '#92400e' }}>
                          🎁 Bonus - You'll also get:
                        </h4>
                        <ul style={{ 
                          margin: '0', 
                          paddingLeft: '24px',
                          color: '#92400e',
                          fontSize: '14px'
                        }}>
                          {bestDealAnalysis.bonusItems.map((item, idx) => (
                            <li key={idx} style={{ marginBottom: '4px' }}>{item}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Missing Items to Add */}
                    {bestDealAnalysis.missingItems && bestDealAnalysis.missingItems.length > 0 && (
                      <div style={{
                        background: '#eff6ff',
                        border: '2px solid #3b82f6',
                        borderRadius: '12px',
                        padding: '16px',
                        marginBottom: '24px'
                      }}>
                        <h4 style={{ margin: '0 0 8px 0', fontSize: '14px', color: '#1e40af' }}>
                          You'll need to add as extras:
                        </h4>
                        <ul style={{ 
                          margin: '0', 
                          paddingLeft: '24px',
                          color: '#1e40af',
                          fontSize: '14px'
                        }}>
                          {bestDealAnalysis.missingItems.map((item, idx) => (
                            <li key={idx} style={{ marginBottom: '4px' }}>
                              {item.quantity}x {item.equipment} (${item.cost.toFixed(2)})
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div style={{ display: 'flex', gap: '12px' }}>
                      <button
                        onClick={handleSwitchToRecommended}
                        style={{
                          flex: 1,
                          padding: '16px',
                          background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                          color: 'white',
                          border: 'none',
                          borderRadius: '12px',
                          fontSize: '16px',
                          fontWeight: '600',
                          cursor: 'pointer',
                          boxShadow: '0 4px 12px rgba(16, 185, 129, 0.3)'
                        }}
                      >
                        Switch to This Deal
                      </button>
                      <button
                        onClick={() => setShowBestDealModal(false)}
                        style={{
                          flex: 1,
                          padding: '16px',
                          background: 'white',
                          color: '#64748b',
                          border: '2px solid #e2e8f0',
                          borderRadius: '12px',
                          fontSize: '16px',
                          fontWeight: '600',
                          cursor: 'pointer'
                        }}
                      >
                        Keep My Selection
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <div style={{ textAlign: 'center', marginBottom: '24px' }}>
                      <div style={{
                        width: '64px',
                        height: '64px',
                        background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
                        borderRadius: '50%',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto 16px'
                      }}>
                        <Sparkles size={32} color="white" />
                      </div>
                      <h3 style={{ margin: '0 0 8px 0', fontSize: '28px', color: '#003f5c' }}>
                        You're All Set!
                      </h3>
                    </div>

                    <div style={{
                      background: '#f0f9ff',
                      border: '2px solid #003f5c',
                      borderRadius: '12px',
                      padding: '20px',
                      marginBottom: '24px',
                      textAlign: 'center'
                    }}>
                      <p style={{ 
                        fontSize: '16px', 
                        lineHeight: '1.6',
                        color: '#003f5c',
                        margin: 0
                      }}>
                        {bestDealAnalysis.message}
                      </p>
                    </div>

                    <button
                      onClick={() => setShowBestDealModal(false)}
                      style={{
                        width: '100%',
                        padding: '16px',
                        background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
                        color: 'white',
                        border: 'none',
                        borderRadius: '12px',
                        fontSize: '16px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        boxShadow: '0 4px 12px rgba(0, 63, 92, 0.3)'
                      }}
                    >
                      Continue with My Booking
                    </button>
                  </>
                )}
              </div>
            ) : null}
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 py-8">
        
        <div className="md:hidden mb-6">
          <div 
            className="card card-event" 
            style={{ 
              overflow: "hidden"
            }}
          >
            <div className="img">
              <img 
                src={event.imageUrl || fallbackImages[event.sport] || fallbackImages.softball} 
                alt={event.name}
              />
            </div>
            <div className="body">
              <div className="kicker">
                {isLeagueEventType ? "🏅 League" : "🏆 Tournament"} • {sportNames[event.sport] || event.sport}
              </div>
              <h3 style={{ margin: "8px 0 12px 0" }}>{event.name}</h3>
              
              {event.city && (
                <div style={{ display: "flex", alignItems: "center", gap: 6, color: "#64748b", fontSize: "14px", marginBottom: "6px" }}>
                  <span>📍 {event.city}</span>
                </div>
              )}
              {event.startDate && (
                <div style={{ display: "flex", alignItems: "center", gap: 6, color: "#64748b", fontSize: "14px" }}>
                  <span>📅 {new Date(event.startDate).toLocaleDateString(undefined, { 
                    weekday: "short", month: "short", day: "numeric", year: "numeric"
                  })}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="md:hidden mb-6">
          <div className="card card-pad">
            <h3 style={{ marginBottom: "16px", fontSize: "1.25rem", fontWeight: "bold", color: "#003f5c" }}>
              Choose Your Package
            </h3>
            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
              {packages.map(pkg => (
                <PackageCompactCard
                  key={pkg.id}
                  pkg={pkg}
                  allEquipment={allEquipment}
                  isSelected={selectedPackage?.id === pkg.id}
                  onClick={() => onPickPackage(pkg)}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2" style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            
            <div 
              className="card card-event" 
              style={{ 
                overflow: "hidden",
                display: "none"
              }}
              data-mobile-hidden="true"
            >
              <style>{`
                @media (min-width: 768px) {
                  [data-mobile-hidden="true"] {
                    display: block !important;
                  }
                }
              `}</style>
              <div className="img">
                <img 
                  src={event.imageUrl || fallbackImages[event.sport] || fallbackImages.softball} 
                  alt={event.name}
                />
              </div>
              <div className="body">
                <div className="kicker">
                  {isLeagueEventType ? "🏅 League" : "🏆 Tournament"} • {sportNames[event.sport] || event.sport}
                </div>
                <h3 style={{ margin: "8px 0 12px 0" }}>{event.name}</h3>
                
                {event.city && (
                  <div style={{ display: "flex", alignItems: "center", gap: 6, color: "#64748b", fontSize: "14px", marginBottom: "6px" }}>
                    <span>📍 {event.city}</span>
                  </div>
                )}
                {event.startDate && (
                  <div style={{ display: "flex", alignItems: "center", gap: 6, color: "#64748b", fontSize: "14px" }}>
                    <span>📅 {new Date(event.startDate).toLocaleDateString(undefined, { 
                      weekday: "short", month: "short", day: "numeric", year: "numeric"
                    })}</span>
                  </div>
                )}
              </div>
            </div>

            {selectedPackage && (
              <div id="booking-form" className="card card-pad">
                <h2 style={{ marginBottom: 24, fontSize: "1.5rem", fontWeight: "bold", color: "#003f5c" }}>
                  Your {selectedPackage.name} Details
                </h2>

                <div style={{ marginBottom: 32 }}>
                  {/* Hide "What's Included" section for Create Your Own Package */}
                  {!selectedPackage.name.toLowerCase().includes("build your own") && !selectedPackage.name.toLowerCase().includes("create your own") && (
                    <>
                      <h3 style={{ marginBottom: 16, fontSize: "1.25rem", fontWeight: "bold", color: "#003f5c" }}>
                        What's Included with {selectedPackage.name}
                      </h3>
                      {selectedPackage.features && selectedPackage.features.length > 0 ? (
                        <ul style={{ paddingLeft: 24, margin: 0, listStyleType: "disc", color: "#475569" }}>
                          {selectedPackage.features.map((feature, idx) => (
                            <li key={idx} style={{ marginBottom: 8, fontSize: "14px" }}>{feature}</li>
                          ))}
                        </ul>
                      ) : (
                        <p style={{ color: '#64748b', fontSize: "14px" }}>No features listed for this package.</p>
                      )}
                    </>
                  )}

                  {/* Hide package pricing for Create Your Own Package */}
                  {!event.leagueEnabled && !isLeagueEventType && !selectedPackage.name.toLowerCase().includes("build your own") && !selectedPackage.name.toLowerCase().includes("create your own") && (
                    <div style={{ 
                      marginTop: "20px",
                      fontSize: "13px", 
                      color: "#003f5c", 
                      padding: "12px 16px",
                      background: "white",
                      border: "2px solid #003f5c",
                      borderRadius: "8px",
                      fontWeight: "600"
                    }}>
                      <div style={{ 
                        marginBottom: "6px", 
                        fontSize: "11px", 
                        textTransform: "uppercase", 
                        letterSpacing: "0.5px",
                        color: "#003f5c",
                        fontWeight: "700"
                      }}>
                        Package Pricing
                      </div>
                      <div style={{ display: "flex", gap: "12px", flexWrap: "wrap", fontSize: "14px" }}>
                        <span>Game: {currency(selectedPackage.perGameUSD || 0)}</span>
                        <span>•</span>
                        <span>Day: {currency(selectedPackage.perDayUSD || 0)}</span>
                        <span>•</span>
                        <span>Weekend: {currency(selectedPackage.fullWeekendUSD || 0)}</span>
                      </div>
                    </div>
                  )}

                  {/* Hide package duration selector for Create Your Own Package */}
                  {!event.leagueEnabled && !isLeagueEventType && !selectedPackage.name.toLowerCase().includes("build your own") && !selectedPackage.name.toLowerCase().includes("create your own") && (
                    <div style={{ marginTop: "20px" }}>
                      <PackageDurationSelector
                        pkg={selectedPackage}
                        onChange={handlePackageDurationChange}
                        initialSelection={packageSelection}
                      />
                    </div>
                  )}

                  {/* Available Add-Ons */}
                  {allAddOns.length > 0 && selectedPackage && (
                    <div style={{ marginTop: "24px", width: "100%", maxWidth: "100%", overflow: "hidden" }}>
                      {/* Hide "Available Add-Ons" heading for Create Your Own / Build Your Own packages */}
                      {!selectedPackage.name.toLowerCase().includes("build your own") && !selectedPackage.name.toLowerCase().includes("create your own") && (
                        <h3 style={{ marginBottom: "16px", fontSize: "18px", fontWeight: "700", color: "#003f5c" }}>
                          Available Add-Ons
                        </h3>
                      )}
                      <div style={{ display: "grid", gap: "16px", width: "100%", maxWidth: "100%" }}>
                        {allAddOns.filter(a => selectedPackage?.addOnIds?.includes(a.id)).map(addon => {
                          const isSelected = selectedAddOns.some(a => a.id === addon.id);
                          const selection = addOnSelections[addon.id];
                          const addonInventory = calculateAddonInventory(addon, allEquipment);

                          return (
                            <div 
                              key={addon.id}
                              style={{ 
                                border: isSelected ? '2px solid #003f5c' : '1px solid #e2e8f0', 
                                borderRadius: 12, 
                                background: isSelected ? '#f0f9ff' : 'white', 
                                transition: 'all 0.2s',
                                padding: "16px",
                                width: "100%",
                                maxWidth: "100%",
                                overflow: "hidden"
                              }}
                            >
                              <label
                                style={{
                                  display: "flex",
                                  alignItems: "start",
                                  gap: "12px",
                                  cursor: "pointer",
                                  width: "100%",
                                  maxWidth: "100%"
                                }}
                              >
                                <input
                                  type="checkbox"
                                  checked={isSelected}
                                  onChange={(e) => handleAddOnChange(addon.id, e.target.checked)}
                                  style={{ marginTop: "4px", flexShrink: 0, width: "18px", height: "18px" }}
                                />
                                <div style={{ flex: 1, minWidth: 0, width: "100%", maxWidth: "100%", overflow: "hidden" }}>
                                  <div style={{ marginBottom: "12px" }}>
                                    <strong style={{ fontSize: "16px", color: "#0f172a", display: "block", marginBottom: "4px", wordBreak: "break-word" }}>{addon.label}</strong>
                                    {addon.description && (
                                      <p style={{ margin: "0", color: "#64748b", fontSize: "14px", wordBreak: "break-word" }}>
                                        {addon.description}
                                      </p>
                                    )}
                                  </div>
                                  
                                  <div style={{ display: "flex", gap: "12px", flexWrap: "wrap", alignItems: "start", width: "100%", maxWidth: "100%" }}>
                                    <div className="addon-price-card" style={{ 
                                      textAlign: "left", 
                                      padding: "8px 12px",
                                      background: "#f8fafc",
                                      border: "1px solid #e2e8f0",
                                      borderRadius: "8px",
                                      flex: "1 1 auto",
                                      minWidth: "0"
                                    }}>
                                      <div style={{ fontSize: "11px", color: "#64748b", marginBottom: "4px", textTransform: "uppercase", fontWeight: "600" }}>
                                        Pricing
                                      </div>
                                      {addon.perGameUSD > 0 && (
                                        <div className="price-line" style={{ fontSize: "13px", color: "#64748b", marginBottom: "2px" }}>
                                          Game: <strong style={{ color: "#003f5c" }}>${addon.perGameUSD.toFixed(2)}</strong>
                                        </div>
                                      )}
                                      {addon.perDayUSD > 0 && (
                                        <div className="price-line" style={{ fontSize: "13px", color: "#64748b", marginBottom: "2px" }}>
                                          Day: <strong style={{ color: "#003f5c" }}>${addon.perDayUSD.toFixed(2)}</strong>
                                        </div>
                                      )}
                                      {addon.fullWeekendUSD > 0 && (
                                        <div className="price-line" style={{ fontSize: "13px", color: "#64748b" }}>
                                          Weekend: <strong style={{ color: "#003f5c" }}>${addon.fullWeekendUSD.toFixed(2)}</strong>
                                        </div>
                                      )}
                                    </div>
                                    
                                    {addon.thumbnailUrl && (
                                      <img 
                                        src={addon.thumbnailUrl} 
                                        alt={addon.label}
                                        className="addon-thumbnail"
                                        style={{
                                          width: "80px",
                                          height: "80px",
                                          objectFit: "cover",
                                          borderRadius: "8px",
                                          border: "1px solid #e2e8f0",
                                          flexShrink: 0
                                        }}
                                      />
                                    )}
                                  </div>
                                </div>
                              </label>

                              {/* Mobile-specific responsive styles */}
                              <style>{`
                                @media (max-width: 767px) {
                                  .addon-header {
                                    flex-wrap: wrap;
                                  }
                                  .addon-price-card {
                                    min-width: 90px !important;
                                    padding: 6px 8px !important;
                                    font-size: 10px !important;
                                  }
                                  .addon-price-card .price-line {
                                    font-size: 11px !important;
                                  }
                                  .addon-price-card strong {
                                    font-size: 11px !important;
                                  }
                                  .addon-thumbnail {
                                    width: 50px !important;
                                    height: 50px !important;
                                  }
                                  .addon-duration-box {
                                    padding: 12px !important;
                                  }
                                  .addon-duration-box h4 {
                                    font-size: 13px !important;
                                  }
                                  .addon-duration-box .duration-mode-btn {
                                    padding: 8px !important;
                                    font-size: 12px !important;
                                  }
                                  .addon-duration-box .day-section strong {
                                    font-size: 14px !important;
                                  }
                                  .addon-duration-box .day-section label {
                                    font-size: 12px !important;
                                  }
                                  .addon-duration-box .game-count-btn {
                                    padding: 6px 12px !important;
                                    font-size: 12px !important;
                                  }
                                }
                              `}</style>

                              {/* Add-On Duration Selection */}
                              {isSelected && selection && (!event.leagueEnabled && !isLeagueEventType) && (
                                <div className="addon-duration-box" style={{
                                  marginTop: "12px",
                                  padding: "16px",
                                  borderTop: "1px solid #e2e8f0",
                                  background: "white"
                                }}>
                                  {/* Duration Mode Toggle */}
                                  <div style={{ marginBottom: "16px" }}>
                                    <h4 style={{ margin: "0 0 12px 0", fontSize: "14px", color: "#003f5c", fontWeight: "600" }}>
                                      Duration
                                    </h4>
                                    <div style={{ display: "flex", gap: "8px" }}>
                                      <button
                                        type="button"
                                        className="duration-mode-btn"
                                        onClick={() => handleAddOnSelectionChange(addon.id, 'mode', 'per_game')}
                                        style={{
                                          flex: 1,
                                          padding: "10px",
                                          border: selection.mode === 'per_game' ? "2px solid #003f5c" : "1px solid #e2e8f0",
                                          borderRadius: "8px",
                                          background: selection.mode === 'per_game' ? "#003f5c" : "white",
                                          color: selection.mode === 'per_game' ? "white" : "#0f172a",
                                          cursor: "pointer",
                                          fontWeight: selection.mode === 'per_game' ? "600" : "400",
                                          fontSize: "14px",
                                          transition: "all 0.2s"
                                        }}
                                      >
                                        Game/Day
                                      </button>
                                      {addon.fullWeekendUSD > 0 && (
                                        <button
                                          type="button"
                                          className="duration-mode-btn"
                                          onClick={() => handleAddOnSelectionChange(addon.id, 'mode', 'weekend')}
                                          style={{
                                            flex: 1,
                                            padding: "10px",
                                            border: selection.mode === 'weekend' ? "2px solid #003f5c" : "1px solid #e2e8f0",
                                            borderRadius: "8px",
                                            background: selection.mode === 'weekend' ? "#003f5c" : "white",
                                            color: selection.mode === 'weekend' ? "white" : "#0f172a",
                                            cursor: "pointer",
                                            fontWeight: selection.mode === 'weekend' ? "600" : "400",
                                            fontSize: "14px",
                                          }}
                                        >
                                          Full Weekend
                                        </button>
                                      )}
                                    </div>
                                  </div>

                                  {selection.mode === 'per_game' ? (
                                    <>
                                      {/* Saturday */}
                                      <div className="day-section" style={{ marginBottom: "16px" }}>
                                        <div style={{
                                          display: "flex",
                                          justifyContent: "space-between",
                                          alignItems: "center",
                                          marginBottom: "12px"
                                        }}>
                                          <strong style={{ fontSize: "15px", color: "#0f172a" }}>Saturday</strong>
                                        </div>
                                        <div style={{ display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap" }}>
                                          <label style={{
                                            display: "flex",
                                            alignItems: "center",
                                            gap: "8px",
                                            cursor: (selection.satGames > 0 ? "not-allowed" : "pointer")
                                          }}>
                                            <input
                                              type="checkbox"
                                              checked={selection.satFullDay}
                                              onChange={(e) => handleAddOnSelectionChange(
                                                addon.id,
                                                'satFullDay',
                                                e.target.checked
                                              )}
                                              disabled={selection.satGames > 0} 
                                            />
                                            <span style={{ fontSize: "14px", color: (selection.satGames > 0 ? "#94a3b8" : "#0f172a") }}>Full Day (more than 2 games choose this)</span>
                                          </label>
                                          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                                            <span style={{ fontSize: "14px", color: "#64748b" }}>Games:</span>
                                            {[0, 1, 2].map(num => (
                                              <button
                                                key={num}
                                                type="button"
                                                className="game-count-btn"
                                                onClick={() => handleAddOnSelectionChange(
                                                  addon.id,
                                                  'satGames',
                                                  num
                                                )}
                                                disabled={selection.satFullDay} 
                                                style={{
                                                  padding: "8px 16px",
                                                  border: selection.satGames === num ? "2px solid #003f5c" : "1px solid #e2e8f0",
                                                  borderRadius: "8px",
                                                  background: selection.satGames === num ? "#003f5c" : "white",
                                                  color: selection.satGames === num ? "white" : "#0f172a",
                                                  cursor: (selection.satFullDay ? "not-allowed" : "pointer"),
                                                  opacity: (selection.satFullDay ? 0.6 : 1),
                                                  fontWeight: selection.satGames === num ? "600" : "400",
                                                  fontSize: "14px",
                                                  transition: "all 0.2s"
                                                }}
                                              >
                                                {num}
                                              </button>
                                            ))}
                                          </div>
                                        </div>
                                      </div>

                                      {/* Sunday */}
                                      <div className="day-section">
                                        <div style={{
                                          display: "flex",
                                          justifyContent: "space-between",
                                          alignItems: "center",
                                          marginBottom: "12px"
                                        }}>
                                          <strong style={{ fontSize: "15px", color: "#0f172a" }}>Sunday</strong>
                                        </div>
                                        <div style={{ display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap" }}>
                                          <label style={{
                                            display: "flex",
                                            alignItems: "center",
                                            gap: "8px",
                                            cursor: (selection.sunGames > 0 ? "not-allowed" : "pointer")
                                          }}>
                                            <input
                                              type="checkbox"
                                              checked={selection.sunFullDay}
                                              onChange={(e) => handleAddOnSelectionChange(
                                                addon.id,
                                                'sunFullDay',
                                                e.target.checked
                                              )}
                                              disabled={selection.sunGames > 0} 
                                            />
                                            <span style={{ fontSize: "14px", color: (selection.sunGames > 0 ? "#94a3b8" : "#0f172a") }}>Full Day (more than 2 games choose this)</span>
                                          </label>
                                          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                                            <span style={{ fontSize: "14px", color: "#64748b" }}>Games:</span>
                                            {[0, 1, 2].map(num => (
                                              <button
                                                key={num}
                                                type="button"
                                                className="game-count-btn"
                                                onClick={() => handleAddOnSelectionChange(
                                                  addon.id,
                                                  'sunGames',
                                                  num
                                                )}
                                                disabled={selection.sunFullDay} 
                                                style={{
                                                  padding: "8px 16px",
                                                  border: selection.sunGames === num ? "2px solid #003f5c" : "1px solid #e2e8f0",
                                                  borderRadius: "8px",
                                                  background: selection.sunGames === num ? "#003f5c" : "white",
                                                  color: selection.sunGames === num ? "white" : "#0f172a",
                                                  cursor: (selection.sunFullDay ? "not-allowed" : "pointer"),
                                                  opacity: (selection.sunFullDay ? 0.6 : 1),
                                                  fontWeight: selection.sunGames === num ? "600" : "400",
                                                  fontSize: "14px",
                                                  transition: "all 0.2s"
                                                }}
                                              >
                                                {num}
                                              </button>
                                            ))}
                                          </div>
                                        </div>
                                      </div>

                                      {/* Selection Summary */}
                                      <div style={{
                                        marginTop: "12px",
                                        padding: "12px",
                                        background: "#f0f9ff",
                                        borderRadius: "8px",
                                        fontSize: "14px",
                                        color: "#003f5c"
                                      }}>
                                        <strong>Selected:</strong>{" "}
                                        {(() => {
                                          const parts = [];
                                          if (selection.satFullDay) parts.push("Saturday Full Day");
                                          else if (selection.satGames > 0) parts.push(`${selection.satGames} game${selection.satGames > 1 ? 's' : ''} Saturday`);
                                          
                                          if (selection.sunFullDay) parts.push("Sunday Full Day");
                                          else if (selection.sunGames > 0) parts.push(`${selection.sunGames} game${selection.sunGames > 1 ? 's' : ''} Sunday`);
                                          
                                          return parts.length > 0 ? parts.join(", ") : "No days selected";
                                        })()}
                                      </div>
                                    </>
                                  ) : (
                                    <div style={{
                                      padding: "16px",
                                      background: "#f0f9ff",
                                      borderRadius: "8px",
                                      textAlign: "center"
                                    }}>
                                      <div style={{ fontSize: "16px", fontWeight: "600", color: "#003f5c", marginBottom: "4px" }}>
                                        Full Weekend Selected
                                      </div>
                                      <div style={{ fontSize: "14px", color: "#64748b" }}>
                                        Saturday & Sunday - ${addon.fullWeekendUSD.toFixed(2)}
                                      </div>
                                    </div>
                                  )}

                                  {/* Quantity selector for add-on */}
                                  <div style={{ display: "flex", alignItems: "center", gap: "12px", marginTop: "16px", paddingTop: "12px", borderTop: "1px dashed #e2e8f0" }}>
                                    <div style={{ fontSize: "11px", color: "#64748b", flexShrink: 0 }}>Quantity:</div>
                                    <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                                      <button
                                        type="button"
                                        onClick={() => {
                                          const currentQty = selectedAddOns.find(a => a.id === addon.id)?.quantity || 1;
                                          const newQty = Math.max(1, currentQty - 1);
                                          setSelectedAddOns(prev => prev.map(item =>
                                            item.id === addon.id ? { ...item, quantity: newQty } : item
                                          ));
                                        }}
                                        disabled={(selectedAddOns.find(a => a.id === addon.id)?.quantity || 1) <= 1}
                                        style={{
                                          width: "32px",
                                          height: "32px",
                                          padding: "0",
                                          display: "flex",
                                          alignItems: "center",
                                          justifyContent: "center",
                                          border: "1px solid #e2e8f0",
                                          borderRadius: "6px",
                                          background: "white",
                                          cursor: "pointer",
                                          fontSize: "18px",
                                          fontWeight: "600",
                                          color: "#003f5c",
                                          opacity: (selectedAddOns.find(a => a.id === addon.id)?.quantity || 1) <= 1 ? 0.3 : 1
                                        }}
                                      >
                                        −
                                      </button>
                                      <input
                                        type="number"
                                        min="1"
                                        max={addonInventory}
                                        value={selectedAddOns.find(a => a.id === addon.id)?.quantity || 1}
                                        onChange={(e) => {
                                          const newQty = Math.max(1, Math.min(addonInventory, parseInt(e.target.value) || 1));
                                          setSelectedAddOns(prev => prev.map(item =>
                                            item.id === addon.id ? { ...item, quantity: newQty } : item
                                          ));
                                        }}
                                        className="input"
                                        style={{ 
                                          fontSize: "14px", 
                                          padding: "8px 12px", 
                                          width: "60px",
                                          textAlign: "center",
                                          fontWeight: "600"
                                        }}
                                      />
                                      <button
                                        type="button"
                                        onClick={() => {
                                          const currentQty = selectedAddOns.find(a => a.id === addon.id)?.quantity || 1;
                                          const newQty = Math.min(addonInventory, currentQty + 1);
                                          setSelectedAddOns(prev => prev.map(item =>
                                            item.id === addon.id ? { ...item, quantity: newQty } : item
                                          ));
                                        }}
                                        disabled={(selectedAddOns.find(a => a.id === addon.id)?.quantity || 1) >= addonInventory}
                                        style={{
                                          width: "32px",
                                          height: "32px",
                                          padding: "0",
                                          display: "flex",
                                          alignItems: "center",
                                          justifyContent: "center",
                                          border: "1px solid #e2e8f0",
                                          borderRadius: "6px",
                                          background: "white",
                                          cursor: "pointer",
                                          fontSize: "18px",
                                          fontWeight: "600",
                                          color: "#003f5c",
                                          opacity: (selectedAddOns.find(a => a.id === addon.id)?.quantity || 1) >= addonInventory ? 0.3 : 1
                                        }}
                                      >
                                        +
                                      </button>
                                    </div>
                                    <div style={{
                                      fontSize: "12px",
                                      color: "#64748b",
                                      marginLeft: "auto"
                                    }}>
                                      Max: {addonInventory}
                                    </div>
                                  </div>
                                  <div style={{
                                    fontSize: "14px",
                                    fontWeight: "600",
                                    color: "#003f5c",
                                    marginTop: "12px",
                                    paddingTop: "12px",
                                    borderTop: "1px dashed #e2e8f0",
                                    textAlign: "right"
                                  }}>
                                    Total for {addon.label}: {currency(
                                      (calculateCurrentOrderSummary?.lineItems || []).filter(li => li.type === 'addon' && li.name.startsWith(addon.label)).reduce((sum, li) => sum + li.totalUSD, 0)
                                    )}
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                {/* Add Best Deal Check Button - Insert before "Select Your Schedule" section */}
                {!event.leagueEnabled && !isLeagueEventType && (
                  <div style={{
                    marginBottom: '32px',
                    padding: '24px',
                    background: 'linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%)',
                    border: '2px solid #003f5c',
                    borderRadius: '16px',
                    textAlign: 'center'
                  }}>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '12px',
                      marginBottom: '12px'
                    }}>
                      <Sparkles size={24} style={{ color: '#003f5c' }} />
                      <h3 style={{ 
                        margin: 0, 
                        fontSize: '20px', 
                        fontWeight: '700', 
                        color: '#003f5c' 
                      }}>
                        Want to Make Sure You're Getting the Best Deal?
                      </h3>
                    </div>
                    <p style={{ 
                      color: '#475569', 
                      fontSize: '16px',
                      margin: '0 0 20px 0',
                      lineHeight: '1.5'
                    }}>
                      Our AI can quickly analyze your selection and compare it to all our packages to ensure you're getting the best value
                    </p>
                    <button
                      onClick={handleCheckBestDeal}
                      disabled={checkingBestDeal}
                      style={{
                        padding: '14px 32px',
                        background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
                        color: 'white',
                        border: 'none',
                        borderRadius: '12px',
                        fontSize: '16px',
                        fontWeight: '600',
                        cursor: checkingBestDeal ? 'not-allowed' : 'pointer',
                        boxShadow: '0 4px 12px rgba(0, 63, 92, 0.3)',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '8px',
                        opacity: checkingBestDeal ? 0.7 : 1
                      }}
                    >
                      <Sparkles size={20} />
                      {checkingBestDeal ? 'Checking...' : 'Check for Better Deals'}
                    </button>
                    <p style={{
                      fontSize: '13px',
                      color: '#64748b',
                      margin: '12px 0 0 0',
                      fontStyle: 'italic'
                    }}>
                      Takes just a few seconds • 100% free • No obligations
                    </p>
                  </div>
                )}


                <div style={{ marginBottom: 32, borderTop: "1px solid #e2e8f0", paddingTop: "32px" }}>
                  <h3 style={{ marginBottom: 16, fontSize: "1.25rem", fontWeight: "bold", color: "#003f5c" }}>
                    Select Your Schedule
                  </h3>
                  {event.leagueEnabled ? (
                    <LeagueSchedulePicker
                      event={event}
                      onScheduleChange={handleLeagueScheduleChange}
                      timeSlots={timeSlots}
                      setTimeSlots={setTimeSlots} // Pass setter for internal state management
                      isLoadingTimeSlots={isLoadingTimeSlots}
                      setIsLoadingTimeSlots={setIsLoadingTimeSlots} // Pass setter for internal state management
                      loadInventoryForSlot={loadInventoryForSlot}
                      leagueDate={leagueDate}
                      setLeagueDate={setLeagueDate}
                      firstGameTime={firstGameTime}
                      setFirstGameTime={setFirstGameTime}
                      fields={allFields}
                      selectedFieldId={selectedFieldId}
                      selectedParkId={selectedParkId}
                      isWOSFieldSelected={isWOSFieldSelected} // Pass the unified WOS flag
                    />
                  ) : (
                    <TournamentSchedulePicker
                      onScheduleChange={handleScheduleChange}
                      initialSchedule={selectedSchedule}
                      isLeagueEventType={isLeagueEventType}
                      leagueSlots={leagueSlots}
                      event={event}
                    />
                  )}
                </div>

                {canShowFieldSelection && (
                  <div style={{ marginBottom: 32, borderTop: "1px solid #e2e8f0", paddingTop: "32px" }}>
                    <h3 style={{ marginBottom: 16, fontSize: "1.25rem", fontWeight: "bold", color: "#003f5c" }}>
                      Select Your Location
                    </h3>
                    
                    {/* Always show park info - either as dropdown or display */}
                    {availableParks.length > 1 ? (
                      <div style={{ marginBottom: 20 }}>
                        <label className="label">Park / Ballpark *</label>
                        <select
                          className="select"
                          value={selectedParkId}
                          onChange={(e) => {
                            setSelectedParkId(e.target.value);
                            setSelectedFieldId("");
                            setSelectedSpotId("");
                          }}
                        >
                          <option value="">Select a park...</option>
                          {availableParks.map(park => (
                            <option key={park.id} value={park.id}>{park.name}</option>
                          ))}
                        </select>
                      </div>
                    ) : availableParks.length === 1 ? (
                      <div style={{ marginBottom: 20 }}>
                        <label className="label">Park / Ballpark</label>
                        <div style={{
                          padding: "12px 16px",
                          background: "#f8fafc",
                          border: "2px solid #003f5c",
                          borderRadius: "8px",
                          fontSize: "16px",
                          fontWeight: "600",
                          color: "#003f5c"
                        }}>
                          📍 {availableParks[0].name}
                        </div>
                      </div>
                    ) : null}

                    {selectedParkId && availableFields.length > 0 && (
                      <div style={{ marginBottom: 20 }}>
                        <label className="label">Field *</label>
                        <select
                          className="select"
                          value={selectedFieldId}
                          onChange={(e) => {
                            setSelectedFieldId(e.target.value);
                            setSelectedSpotId("");
                          }}
                        >
                          <option value="">Select a field...</option>
                          <option value="waiting-on-schedule">Waiting on Schedule</option> {/* Added new option */}
                          {availableFields.map(field => (
                            <option key={field.id} value={field.id}>{field.name}</option>
                          ))}
                        </select>
                        
                        {/* New message block for generic "waiting-on-schedule" option */}
                        {selectedFieldId === "waiting-on-schedule" && (
                          <div style={{
                            marginTop: "12px",
                            padding: "12px",
                            background: "#eff6ff",
                            border: "1px solid #bfdbfe",
                            borderRadius: "8px",
                            fontSize: "14px",
                            color: "#1e40af"
                          }}>
                            If your field assignment hasn't been announced yet, we'll set up your equipment at the correct field once the schedule is available. You can still select your preferred setup location below.
                          </div>
                        )}
                      </div>
                    )}

                    {/* Existing message block, now uses unified isWOSFieldSelected */}
                    {isWOSFieldSelected && selectedFieldId !== "waiting-on-schedule" && (
                      <div style={{
                        marginTop: "12px",
                        padding: "12px",
                        background: "#eff6ff",
                        border: "1px solid #bfdbfe",
                        borderRadius: "8px",
                        fontSize: "14px",
                        color: "#1e40af"
                      }}>
                        You have selected "Waiting on Schedule" for this field. Your game time will also be "Waiting on Schedule".
                      </div>
                    )}

                    {selectedFieldId && availableSpots.length > 0 && ( // Conditional render for spot picker
                      <div style={{ marginTop: "20px" }}>
                        <FieldSpotPicker
                          field={fieldForSpotDisplay}
                          spots={availableSpots}
                          selectedSpotId={selectedSpotId}
                          onSelectSpot={setSelectedSpotId}
                        />
                      </div>
                    )}
                    {selectedFieldId && availableSpots.length === 0 && (
                      <div style={{
                        marginTop: "16px",
                        padding: "12px",
                        background: "#f8fafc",
                        border: "1px solid #e2e8f0",
                        borderRadius: "8px",
                        color: "#64748b",
                        fontSize: "14px"
                      }}>
                        No spots available for selection on this field.
                      </div>
                    )}
                  </div>
                )}

                <div style={{ marginBottom: 32, borderTop: "1px solid #e2e8f0", paddingTop: "32px" }}>
                  <h3 style={{ marginBottom: 16, fontSize: "1.25rem", fontWeight: "bold", color: "#003f5c" }}>
                    Your Information
                  </h3>
                  
                  <div className="form-group" style={{ marginBottom: "12px" }}>
                    <label className="label">Full Name *</label>
                    <input
                      type="text"
                      className="input"
                      value={formData.fullName}
                      onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                      placeholder="John Doe"
                      required
                    />
                  </div>

                  <div className="form-group" style={{ marginBottom: "12px" }}>
                    <label className="label">Email *</label>
                    <input
                      type="email"
                      className="input"
                      value={formData.contactEmail}
                      onChange={(e) => setFormData({...formData, contactEmail: e.target.value})}
                      placeholder="john@example.com"
                      required
                    />
                  </div>

                  <div className="form-group" style={{ marginBottom: "12px" }}>
                    <label className="label">Phone *</label>
                    <input
                      type="tel"
                      className="input"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      placeholder="(555) 123-4567"
                      required
                    />
                  </div>

                  <div className="form-group" style={{ marginBottom: "12px" }}>
                    <label className="label">Team Name *</label>
                    <input
                      type="text"
                      className="input"
                      value={formData.teamName}
                      onChange={(e) => setFormData({...formData, teamName: e.target.value})}
                      placeholder="Warriors"
                      required
                    />
                  </div>

                  <div className="form-group" style={{ marginBottom: "12px" }}>
                    <label className="label">Coach Name (Optional)</label>
                    <input
                      type="text"
                      className="input"
                      value={formData.coachName}
                      onChange={(e) => setFormData({...formData, coachName: e.target.value})}
                      placeholder="Coach Smith"
                    />
                  </div>

                  <div className="form-group" style={{ marginBottom: "12px" }}>
                    <label className="label">Special Requests or Notes (Optional)</label>
                    <textarea
                      className="textarea"
                      rows={3}
                      value={formData.notes}
                      onChange={(e) => setFormData({...formData, notes: e.target.value})}
                      placeholder="Any special requests or information we should know?"
                    />
                    <div style={{ 
                      marginTop: "8px", 
                      padding: "12px", 
                      background: "#f8fafc", 
                      border: "1px solid #e2e8f0", 
                      borderRadius: "8px",
                      fontSize: "12px",
                      color: "#64748b"
                    }}>
                      This is a good place to put other game times for any extra add-on items you purchased to be delivered. 
                      If your ordered items are for other than your first game of the day, 
                      you can pick them up at our Sideline Setups kiosk at the event.
                    </div>
                  </div>
                </div>

                <div style={{ marginBottom: 24, borderTop: "1px solid #e2e8f0", paddingTop: "32px" }}>
                  <label style={{ 
                    display: 'flex', 
                    alignItems: 'flex-start', 
                    gap: 12, 
                    cursor: 'pointer',
                    marginBottom: "16px"
                  }}>
                    <input
                      type="checkbox"
                      checked={agreedToTerms}
                      onChange={(e) => setAgreedToTerms(e.target.checked)}
                      style={{ marginTop: 4, width: "18px", height: "18px", flexShrink: 0 }}
                      required
                    />
                    <span style={{ fontSize: 14, lineHeight: "1.6", color: "#475569" }}>
                      I have read and agree to the{" "}
                      <a 
                        href={TERMS_URL} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        style={{ color: "#003f5c", textDecoration: "underline", fontWeight: "600" }}
                      >
                        Terms & Conditions
                      </a>
                      {" "}and{" "}
                      <a 
                        href={PRIVACY_URL} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        style={{ color: "#003f5c", textDecoration: "underline", fontWeight: "600" }}
                      >
                        Privacy Policy
                      </a>
                      . *
                    </span>
                  </label>

                  <label style={{ 
                    display: 'flex', 
                    alignItems: 'flex-start', 
                    gap: 12, 
                    cursor: 'pointer',
                    marginBottom: "12px"
                  }}>
                    <input
                      type="checkbox"
                      checked={smsConsent}
                      onChange={(e) => setSmsConsent(e.target.checked)}
                      style={{ marginTop: 4, width: "18px", height: "18px", flexShrink: 0 }}
                      // Removed `required` attribute
                    />
                    <span style={{ fontSize: 14, lineHeight: "1.6", color: "#475569" }}>
                      To receive booking updates and important messages via text including ones sent via an autodialer, check this box. I consent to receive booking-related text messages from Sideline Setups at the provided phone number. Message frequency varies. Message & data rates may apply. Reply STOP to opt-out, HELP for assistance. Consent is not a condition of purchase.
                    </span>
                  </label>

                  <div style={{ marginTop: "12px", fontSize: "12px", color: "#64748b", paddingLeft: "30px" }}>
                    Need help?{" "}
                    <a 
                      href={`sms:${supportNumber}?&body=${encodeURIComponent("Hi " + brandName + " — I have a question about my booking.")}`}
                      style={{ color: "#003f5c", textDecoration: "underline" }}
                    >
                      Text us
                    </a>
                    {" "}or call{" "}
                    <a 
                      href={`tel:${supportNumber}`}
                      style={{ color: "#003f5c", textDecoration: "underline" }}
                    >
                      {supportNumber}
                    </a>
                  </div>
                </div>

                {/* COUPON CODE SECTION */}
              {calculateCurrentOrderSummary && (
                <div style={{ 
                  marginBottom: "24px", 
                  padding: "20px", 
                  background: "#f8fafc", 
                  borderRadius: "12px",
                  border: "1px solid #e2e8f0"
                }}>
                  <h3 style={{ 
                    margin: "0 0 12px 0", 
                    fontSize: "16px", 
                    fontWeight: "600", 
                    color: "#003f5c" 
                  }}>
                    Have a Discount Code?
                  </h3>
                  
                  {!appliedDiscount ? (
                    <div>
                      <div style={{ display: "flex", gap: "8px", marginBottom: "8px" }}>
                        <input
                          type="text"
                          className="input"
                          placeholder="Enter code"
                          value={couponCode}
                          onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleApplyCoupon();
                            }
                          }}
                          disabled={applyingCoupon}
                          style={{ 
                            flex: 1, 
                            textTransform: "uppercase",
                            fontFamily: "monospace",
                            fontSize: "14px"
                          }}
                        />
                        <button 
                          onClick={handleApplyCoupon} 
                          disabled={applyingCoupon || !couponCode.trim()}
                          className="btn"
                          style={{
                            padding: "10px 20px",
                            opacity: (applyingCoupon || !couponCode.trim()) ? 0.5 : 1,
                            cursor: (applyingCoupon || !couponCode.trim()) ? "not-allowed" : "pointer"
                          }}
                        >
                          {applyingCoupon ? "Checking..." : "Apply"}
                        </button>
                      </div>
                      
                      {couponError && (
                        <div style={{ 
                          padding: "12px", 
                          background: "#fef2f2", 
                          border: "1px solid #fecaca",
                          borderRadius: "8px",
                          color: "#991b1b",
                          fontSize: "14px"
                        }}>
                          ⚠️ {couponError}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div style={{
                      padding: "12px 16px",
                      background: "#d1fae5",
                      border: "1px solid #6ee7b7",
                      borderRadius: "8px",
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center"
                    }}>
                      <div>
                        <div style={{ 
                          color: "#065f46", 
                          fontWeight: "600",
                          fontSize: "15px",
                          marginBottom: "4px"
                        }}>
                          ✓ Code "{appliedDiscount.code}" applied!
                        </div>
                        <div style={{ color: "#047857", fontSize: "13px" }}>
                          Saving {currency(appliedDiscount.discountCents / 100)}
                        </div>
                      </div>
                      <button
                        onClick={handleRemoveCoupon}
                        style={{
                          background: "transparent",
                          border: "none",
                          color: "#047857",
                          fontSize: "14px",
                          fontWeight: "600",
                          cursor: "pointer",
                          textDecoration: "underline"
                        }}
                      >
                        Remove
                      </button>
                    </div>
                  )}
                </div>
              )}

                {currentValidationErrors.length > 0 && (
                  <div style={{
                    marginBottom: "20px",
                    padding: "20px",
                    background: "#fef2f2",
                    border: "2px solid #ef4444",
                    borderRadius: "12px"
                  }}>
                    <div style={{ 
                      fontWeight: "700", 
                      color: "#991b1b", 
                      marginBottom: "12px",
                      fontSize: "16px",
                      display: "flex",
                      alignItems: "center",
                      gap: "8px"
                    }}>
                      <span style={{ fontSize: "24px" }}>⚠️</span>
                      Please complete the following before payment:
                    </div>
                    <ul style={{ margin: 0, paddingLeft: "28px", color: "#991b1b", fontSize: "14px", lineHeight: "1.8" }}>
                      {currentValidationErrors.map((error, idx) => (
                        <li key={idx} style={{ marginBottom: "4px" }}>{error}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {calculateCurrentOrderSummary && (
                  <div style={{ 
                    display: "flex", 
                    flexDirection: "column",
                    gap: "20px",
                    paddingTop: "20px",
                    borderTop: "2px solid #e2e8f0"
                  }}>
                    <h3 style={{ fontSize: "1.25rem", fontWeight: "bold", color: "#003f5c" }}>Order Summary</h3>
                    
                    {/* Updated LineItemsTable with discount */}
                    <div style={{ fontSize: "14px", color: "#334155" }}>
                      <div style={{ marginBottom: "12px", borderBottom: "1px solid #e2e8f0", paddingBottom: "8px" }}>
                        {calculateCurrentOrderSummary.lineItems.map((item, idx) => (
                          <div key={idx} style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                            <span>{item.name} {item.qty > 1 ? `(x${item.qty})` : ''}</span>
                            <span>{currency(item.totalUSD)}</span>
                          </div>
                        ))}
                      </div>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                        <span>Subtotal</span>
                        <span>{currency(calculateCurrentOrderSummary.subtotalUSD)}</span>
                      </div>
                      {calculateCurrentOrderSummary.taxUSD > 0 && (
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                          <span>Tax</span>
                          <span>{currency(calculateCurrentOrderSummary.taxUSD)}</span>
                        </div>
                      )}
                      {calculateCurrentOrderSummary.serviceFeeUSD > 0 && (
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                          <span>Service Fee</span>
                          <span>{currency(calculateCurrentOrderSummary.serviceFeeUSD)}</span>
                        </div>
                      )}
                      {appliedDiscount && calculateCurrentOrderSummary.discountUSD > 0 && (
                        <div style={{ 
                          display: "flex", 
                          justifyContent: "space-between", 
                          marginBottom: "4px",
                          color: "#059669",
                          fontWeight: "600"
                        }}>
                          <span>Discount ({appliedDiscount.code})</span>
                          <span>-{currency(calculateCurrentOrderSummary.discountUSD)}</span>
                        </div>
                      )}
                      <div style={{ 
                        display: "flex", 
                        justifyContent: "space-between", 
                        marginTop: "12px", 
                        paddingTop: "12px", 
                        borderTop: "1px dashed #cbd5e1", 
                        fontWeight: "700", 
                        fontSize: "16px" 
                      }}>
                        <span>Total</span>
                        <span>{currency(calculateCurrentOrderSummary.totalUSD)}</span>
                      </div>
                    </div>

                    {currentValidationErrors.length === 0 && agreedToTerms && paypalClientId && !isProcessingPayment && calculateCurrentOrderSummary.totalUSD > 0 ? (
                      <div style={{ minWidth: "200px" }}>
                        <PayPalButtons
                          clientId={paypalClientId}
                          amount={calculateCurrentOrderSummary.totalUSD}
                          currency="USD"
                          onSuccess={handlePaymentSuccess}
                          onError={(err) => {
                            console.error("PayPal error:", err);
                            alert("Payment failed. Please try again.");
                            setIsProcessingPayment(false);
                          }}
                        />
                      </div>
                    ) : (
                      <button 
                        className="btn" 
                        disabled 
                        style={{ 
                          opacity: 0.6, 
                          cursor: "not-allowed", 
                          minWidth: "200px",
                          background: "#94a3b8"
                        }}
                      >
                        {isProcessingPayment 
                          ? <div className="spinner" style={{margin: '0 auto'}}></div> 
                          : "Complete Form to Continue"
                        }
                      </button>
                    )}
                    
                    {!paypalClientId && !isProcessingPayment && (
                      <div style={{ color: "#64748b", fontSize: "14px", textAlign: "center" }}>Loading payment options...</div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="hidden md:block md:col-span-1">
            <div className="card card-pad" style={{ position: 'sticky', top: '20px' }}>
              <h3 style={{ marginBottom: "16px", fontSize: "1.25rem", fontWeight: "bold", color: "#003f5c" }}>
                Choose Your Package
              </h3>
              <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                {packages.map(pkg => (
                  <PackageCompactCard
                    key={pkg.id}
                    pkg={pkg}
                    allEquipment={allEquipment}
                    isSelected={selectedPackage?.id === pkg.id}
                    onClick={() => onPickPackage(pkg)}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}