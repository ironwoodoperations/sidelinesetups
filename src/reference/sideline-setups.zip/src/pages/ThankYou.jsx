
import React from "react";
import { getCtx } from "../components/lib/ctx";
// Removed generateBookingReceiptPDF, downloadPDF as they are no longer used by a button
// import { generateBookingReceiptPDF, downloadPDF } from "../components/lib/pdf";
import { sendEmail } from "../components/lib/email";
import { getQRImageUrl } from "../components/lib/qr";
import LineItemsTable from "../components/LineItemsTable";
import { FileText } from "lucide-react"; // Added for the new Print Receipt button icon

export default function ThankYou() {
  const [booking, setBooking] = React.useState(null);
  const [event, setEvent] = React.useState(null);
  const [packageData, setPackageData] = React.useState(null);
  const [packageEquipment, setPackageEquipment] = React.useState([]);
  const [park, setPark] = React.useState(null);
  const [field, setField] = React.useState(null);
  const [spot, setSpot] = React.useState(null);
  const [status, setStatus] = React.useState("Preparing your receipt…");
  const [settings, setSettings] = React.useState(null);
  // Removed downloadingPDF and downloadSuccess states as the download PDF button is removed
  // const [downloadingPDF, setDownloadingPDF] = React.useState(false);
  // const [downloadSuccess, setDownloadSuccess] = React.useState(false);

  React.useEffect(() => {
    (async () => {
      const sp = new URLSearchParams(location.search);
      const id = sp.get("b") || sp.get("booking") || "";
      const { entities, settings } = await getCtx();
      setSettings(settings || {});
      
      if (!id) { 
        setStatus("Missing booking id"); 
        return; 
      }
      
      const b = await entities.Bookings.get(id);
      setBooking(b);

      if (b?.eventId) {
        try {
          const eventData = await entities.Events.get(b.eventId);
          setEvent(eventData);
        } catch (e) {
          console.error("Failed to load event:", e);
        }
      }

      if (b?.packageId) {
        try {
          const pkgData = await entities.Packages.get(b.packageId);
          setPackageData(pkgData);
          
          // Fetch equipment details for package baseItems
          if (pkgData?.baseItems && pkgData.baseItems.length > 0) {
            const equipmentPromises = pkgData.baseItems.map(async (item) => {
              try {
                const equipment = await entities.Equipment.get(item.equipmentId);
                return { ...equipment, qty: item.qty };
              } catch (e) {
                console.error("Failed to load equipment:", e);
                return null;
              }
            });
            const equipmentList = (await Promise.all(equipmentPromises)).filter(Boolean);
            setPackageEquipment(equipmentList);
          }
        } catch (e) {
          console.error("Failed to load package:", e);
        }
      }

      if (b?.parkId) {
        try {
          const parkData = await entities.Parks.get(b.parkId);
          setPark(parkData);
        } catch (e) {
          console.error("Failed to load park:", e);
        }
      }

      if (b?.fieldId) {
        try {
          const fieldData = await entities.Fields.get(b.fieldId);
          setField(fieldData);
        } catch (e) {
          console.error("Failed to load field:", e);
        }
      }

      if (b?.spotId) {
        try {
          const spotData = await entities.Spots.get(b.spotId);
          setSpot(spotData);
        } catch (e) {
          console.error("Failed to load spot:", e);
        }
      }

      setStatus("Ready");
    })();
  }, []);

  // Removed onDownloadPDF function as the download PDF button is removed
  // async function onDownloadPDF() {
  //   setDownloadingPDF(true);
  //   setDownloadSuccess(false);
      
  //   try {
  //     const response = await generateBookingReceiptPDF({
  //       booking,
  //       event,
  //       park,
  //       field,
  //       spot,
  //       totals: booking.totals,
  //       brand: {
  //         name: settings?.brandName || "Sideline Setups",
  //         email: settings?.supportEmail || "support@sidelinesetups.com",
  //         phone: settings?.supportPhone || ""
  //       },
  //       logoDataUrl: settings?.logoUrl || null
  //     });
      
  //     downloadPDF(response.data, response.filename);
      
  //     setDownloadSuccess(true);
  //     setTimeout(() => setDownloadSuccess(false), 3000);
  //   } catch (error) {
  //     console.error('Error downloading PDF:', error);
  //     alert('Failed to generate PDF. Please try again.');
  //   } finally {
  //     setDownloadingPDF(false);
  //   }
  // }

  async function emailReceipt() {
    const to = booking.contactEmail || "";
    if (!to) { 
      alert("No email on file for this booking."); 
      return; 
    }
    const subject = `Your ${settings?.brandName || "Sideline Setups"} Receipt — ${booking.id}`;
    const body = `Thanks for your booking!

Reservation Number: ${booking.id}
Event: ${event?.name || booking.eventId}
Date: ${booking.date}
1st Game Time: ${Array.isArray(booking.gameTimes) && booking.gameTimes.length ? booking.gameTimes[0] : "TBD"}
Package: ${packageData?.name || booking.packageId}
Total: $${Number(booking?.totals?.amount ?? 0).toFixed(2)}

Check-in QR:
${location.origin}/checkin?b=${encodeURIComponent(booking.id)}

To view your receipt online, visit this page:
${location.href}

See you on game day!`;

    await sendEmail({ to, subject, body });
    alert("Receipt email sent.");
  }

  if (!booking) {
    return (
      <div className="container section">
        <h2>{status}</h2>
      </div>
    );
  }

  const brandName = settings?.brandName || "Sideline Setups";
  const supportNumber = settings?.supportPhone || "+19182858151";

  const qrUrl = `${location.origin}/checkin?b=${encodeURIComponent(booking.id)}`;
  const qrImg = getQRImageUrl(qrUrl, 220);

  const hasLineItems = booking.lineItemsJson && booking.lineItemsJson.length > 0;

  // Format date as MM-DD-YYYY
  const formatDate = (dateStr) => {
    if (!dateStr) return "";
    const date = new Date(dateStr);
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const year = date.getFullYear();
    return `${month}-${day}-${year}`;
  };

  return (
    <div className="min-h-screen bg-slate-50" style={{ padding: "32px 16px" }}>
      <div className="container" style={{ maxWidth: 920, margin: "0 auto" }}>
        <div style={{
          background: 'white',
          border: "1px solid #e2e8f0",
          borderRadius: "12px",
          padding: "24px",
          marginBottom: "24px",
          textAlign: "left"
        }}>
          <h2 style={{ 
            fontSize: "1.5rem", 
            fontWeight: "bold", 
            marginBottom: "20px",
            color: "#003f5c",
            borderBottom: "2px solid #e2e8f0",
            paddingBottom: "12px"
          }}>
            Booking Details
          </h2>
          
          <div style={{ display: "grid", gap: "16px", marginBottom: "24px" }}>
            <div style={{ display: "grid", gridTemplateColumns: "140px 1fr", gap: "8px" }}>
              <span style={{ fontWeight: "600", color: "#64748b" }}>Reservation Number:</span>
              <span style={{ color: "#0f172a" }}>{booking.id}</span>
            </div>

            <div style={{ 
              borderTop: "2px solid #e2e8f0", 
              paddingTop: "12px", 
              marginTop: "8px" 
            }}>
              <div style={{ fontWeight: "700", color: "#003f5c", marginBottom: "12px" }}>
                Event Information:
              </div>

              <div style={{ display: "grid", gap: "12px", paddingLeft: "12px" }}>
                <div style={{ display: "grid", gridTemplateColumns: "140px 1fr", gap: "8px" }}>
                  <span style={{ fontWeight: "600", color: "#64748b" }}>Event:</span>
                  <span style={{ color: "#0f172a" }}>{event?.name || "Event"}</span>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "140px 1fr", gap: "8px" }}>
                  <span style={{ fontWeight: "600", color: "#64748b" }}>Date:</span>
                  <span style={{ color: "#0f172a" }}>{formatDate(booking.date)}</span>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "140px 1fr", gap: "8px" }}>
                  <span style={{ fontWeight: "600", color: "#64748b" }}>1st Game Time:</span>
                  <span style={{ color: "#0f172a" }}>
                    {Array.isArray(booking.gameTimes) && booking.gameTimes.length ? booking.gameTimes[0] : "TBD"}
                  </span>
                </div>

                {park && (
                  <div style={{ display: "grid", gridTemplateColumns: "140px 1fr", gap: "8px" }}>
                    <span style={{ fontWeight: "600", color: "#64748b" }}>Park:</span>
                    <span style={{ color: "#0f172a" }}>{park.name}</span>
                  </div>
                )}

                {field && (
                  <div style={{ display: "grid", gridTemplateColumns: "140px 1fr", gap: "8px" }}>
                    <span style={{ fontWeight: "600", color: "#64748b" }}>Field:</span>
                    <span style={{ color: "#0f172a" }}>{field.name}</span>
                  </div>
                )}

                {spot && (
                  <div style={{ display: "grid", gridTemplateColumns: "140px 1fr", gap: "8px" }}>
                    <span style={{ fontWeight: "600", color: "#64748b" }}>Location:</span>
                    <span style={{ color: "#0f172a" }}>{spot.label}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Package Contents Section - NEW */}
          {packageData && packageEquipment.length > 0 && (
            <div style={{ 
              marginTop: "24px",
              padding: "16px",
              background: "#f8fafc",
              borderRadius: "8px",
              border: "1px solid #e2e8f0"
            }}>
              <h3 style={{ 
                fontSize: "1.125rem", 
                fontWeight: "600", 
                marginBottom: "12px",
                color: "#003f5c",
                display: "flex",
                alignItems: "center",
                gap: "8px"
              }}>
                📦 Included in Package: {packageData.name}
              </h3>
              <ul style={{ 
                margin: 0, 
                paddingLeft: "24px", 
                fontSize: "14px", 
                color: "#475569",
                lineHeight: "1.8"
              }}>
                {packageEquipment.map((equip, idx) => (
                  <li key={idx}>
                    <strong>{equip.qty}x</strong> {equip.name}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Line Items Table */}
          {hasLineItems ? (
            <div style={{ marginTop: "24px" }}>
              <h3 style={{ 
                fontSize: "1.125rem", 
                fontWeight: "600", 
                marginBottom: "16px",
                color: "#003f5c"
              }}>
                Order Summary
              </h3>
              <LineItemsTable
                items={booking.lineItemsJson}
                baseCents={booking.baseCents}
                addOnCents={booking.addOnCents}
                totalCents={booking.totalCents}
              />
              
              {/* NEW: Pickup Note */}
              <div style={{
                marginTop: "20px",
                padding: "16px",
                background: "#eff6ff",
                border: "1px solid #bfdbfe",
                borderRadius: "8px",
                fontSize: "14px",
                color: "#1e40af",
                lineHeight: "1.6"
              }}>
                <strong>📦 Per-Game Item Pickup:</strong> If you ordered items by the game, please text or email us what times you will want those, or come by the Kiosk to pick them up.
              </div>
            </div>
          ) : (
            // Fallback for old bookings without line items
            <div style={{ marginTop: "24px" }}>
              <div style={{ display: "grid", gridTemplateColumns: "140px 1fr", gap: "8px", alignItems: "start" }}>
                <span style={{ fontWeight: "600", color: "#64748b" }}>Package:</span>
                <div>
                  <div style={{ color: "#0f172a", fontWeight: "600" }}>
                    {packageData?.name || "Package"}
                  </div>
                </div>
              </div>

              {booking.addOns && booking.addOns.length > 0 && (
                <div style={{ display: "grid", gridTemplateColumns: "140px 1fr", gap: "8px", alignItems: "start", marginTop: "12px" }}>
                  <span style={{ fontWeight: "600", color: "#64748b" }}>Add-ons:</span>
                  <div>
                    <ul style={{ margin: 0, paddingLeft: "20px", fontSize: "14px", color: "#0f172a" }}>
                      {booking.addOns.map((addon, idx) => (
                        <li key={idx}>{addon.label || "Add-on"}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              <div style={{ 
                display: "grid", 
                gridTemplateColumns: "140px 1fr", 
                gap: "8px",
                marginTop: "16px",
                paddingTop: "16px",
                borderTop: "2px solid #e2e8f0"
              }}>
                <span style={{ fontWeight: "600", color: "#64748b" }}>Total:</span>
                <span style={{ color: "#003f5c", fontSize: "1.5rem", fontWeight: "700" }}>
                  ${Number(booking?.totals?.amount ?? 0).toFixed(2)}
                </span>
              </div>
            </div>
          )}
        </div>

        <div className="card card-pad" style={{ maxWidth: 420, margin: "0 auto 24px auto" }}>
          <h3 style={{ marginBottom: "16px", textAlign: "center" }}>Event Check-In QR</h3>
          <img 
            src={qrImg} 
            alt="Check-in QR" 
            style={{ width: 220, height: 220, margin: "16px auto", display: "block" }} 
          />
          <div style={{ display: "flex", gap: 8, marginTop: 16, justifyContent: "center" }}>
            <a className="btn-outline" href={qrImg} download={`booking-${booking.id}-qr.png`}>
              Download QR
            </a>
            <button className="btn-outline" onClick={() => window.print()}>
              Print
            </button>
          </div>
        </div>

        {/* Text/Call Help Section */}
        <div style={{ 
          marginTop: "24px",
          padding: "16px", 
          background: "#f8fafc", 
          border: "1px solid #e2e8f0", 
          borderRadius: "12px",
          textAlign: "center"
        }}>
          <div style={{ fontSize: "14px", color: "#64748b", marginBottom: "8px" }}>
            Need help with your setup?
          </div>
          <div style={{ display: "flex", gap: "12px", justifyContent: "center", flexWrap: "wrap" }}>
            <a 
              href={`sms:${supportNumber}?&body=${encodeURIComponent("Hi " + brandName + " — I have a question about booking #" + (booking?.id || ""))}`}
              className="btn-outline"
              style={{ fontSize: "14px" }}
            >
              💬 Text Us
            </a>
            <a 
              href={`tel:${supportNumber}`}
              className="btn-outline"
              style={{ fontSize: "14px" }}
            >
              📞 Call Us
            </a>
          </div>
        </div>

        {/* Action Buttons */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '16px',
          marginTop: '24px', // Adjusted margin to match original layout
          marginBottom: '32px'
        }}>
          <button
            onClick={() => window.print()}
            style={{
              padding: '16px',
              background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '16px',
              fontWeight: '600',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
              transition: 'all 0.2s',
              minWidth: '200px' // Ensure consistent sizing with grid minmax
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 8px 16px rgba(0,63,92,0.3)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            <FileText size={20} />
            Print Receipt
          </button>
          <button 
            className="btn-outline" 
            onClick={emailReceipt} 
            style={{ 
              minWidth: "200px", // Ensure consistent sizing with grid minmax
              padding: '16px', // Match padding of other button
              fontSize: '16px', // Match font size of other button
              borderRadius: '12px', // Match border radius of other button
              fontWeight: '600', // Match font weight
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
            }}
          >
            📧 Email Receipt
          </button>
        </div>

        <div className="mt-16" style={{ textAlign: "center", marginTop: "32px" }}>
          <a className="btn" href="/mybookings" style={{ marginRight: 8 }}>
            View My Bookings
          </a>
          <a className="btn-outline" href="/events">
            Back to Events
          </a>
        </div>
      </div>
    </div>
  );
}
