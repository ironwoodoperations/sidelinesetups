// pages/AdminStaff.jsx
import React from "react";
import NavBar from "../components/NavBar";
import { getCtx } from "../components/lib/ctx";
import { fetchShifts, summarizeByStaff, toCSV } from "../components/lib/staffReports";

function download(text, filename, type = "text/csv;charset=utf-8;") {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
}

export default function AdminStaff() {
  const [staffIds, setStaffIds] = React.useState([]);
  const [rows, setRows] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [staffId, setStaffId] = React.useState("");
  const [from, setFrom] = React.useState("");
  const [to, setTo] = React.useState("");

  React.useEffect(() => {
    (async () => {
      const { entities } = await getCtx();
      const all = await entities.Timeclock.list();
      const unique = Array.from(new Set((all || []).map(r => r.staffId).filter(Boolean)));
      setStaffIds(unique);
      setLoading(false);
    })();
  }, []);

  async function run() {
    setLoading(true);
    const data = await fetchShifts({ from, to, staffId });
    setRows(data);
    setLoading(false);
  }

  const summary = summarizeByStaff(rows);

  return (
    <>
      <NavBar/>
      <div className="container section" style={{ maxWidth: 1000 }}>
        <h1>Admin • Staff Shifts</h1>
        <div className="card" style={{ padding: 12, display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 12, alignItems: "end" }}>
          <div>
            <label style={{ fontSize: 12, opacity: .7 }}>Staff</label>
            <select className="input" value={staffId} onChange={e => setStaffId(e.target.value)}>
              <option value="">All staff</option>
              {staffIds.map(id => <option key={id} value={id}>{id}</option>)}
            </select>
          </div>
          <div>
            <label style={{ fontSize: 12, opacity: .7 }}>From</label>
            <input type="date" className="input" value={from} onChange={e => setFrom(e.target.value)} />
          </div>
          <div>
            <label style={{ fontSize: 12, opacity: .7 }}>To</label>
            <input type="date" className="input" value={to} onChange={e => setTo(e.target.value)} />
          </div>
          <div>
            <button className="btn" onClick={run}>{loading ? "Loading…" : "Run Report"}</button>
          </div>
        </div>

        {/* Summary table */}
        <div className="card" style={{ marginTop: 16, padding: 12 }}>
          <h3 style={{ marginBottom: 8 }}>Summary by Staff</h3>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                <th style={{ textAlign: "left", padding: 8, borderBottom: "1px solid var(--border)" }}>Staff</th>
                <th style={{ textAlign: "left", padding: 8, borderBottom: "1px solid var(--border)" }}>Shifts</th>
                <th style={{ textAlign: "left", padding: 8, borderBottom: "1px solid var(--border)" }}>Hours</th>
              </tr>
            </thead>
            <tbody>
              {summary.map(r => (
                <tr key={r.staffId}>
                  <td style={{ padding: 8, borderBottom: "1px solid var(--border)" }}>{r.staffId}</td>
                  <td style={{ padding: 8, borderBottom: "1px solid var(--border)" }}>{r.shifts}</td>
                  <td style={{ padding: 8, borderBottom: "1px solid var(--border)" }}>{r.hours}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div style={{ marginTop: 12 }}>
            <button
              className="btn"
              onClick={() => {
                const csv = toCSV(summary, ["staffId", "shifts", "hours"]);
                const label = `${from || "start"}_to_${to || "end"}${staffId ? "_"+staffId : ""}`;
                download(csv, `staff-summary-${label}.csv`);
              }}
            >
              Download Summary CSV
            </button>
          </div>
        </div>

        {/* Raw shifts */}
        <div className="card" style={{ marginTop: 16, padding: 12 }}>
          <h3 style={{ marginBottom: 8 }}>Raw Shifts</h3>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                <th style={{ textAlign: "left", padding: 8, borderBottom: "1px solid var(--border)" }}>Staff</th>
                <th style={{ textAlign: "left", padding: 8, borderBottom: "1px solid var(--border)" }}>Park</th>
                <th style={{ textAlign: "left", padding: 8, borderBottom: "1px solid var(--border)" }}>Clock In</th>
                <th style={{ textAlign: "left", padding: 8, borderBottom: "1px solid var(--border)" }}>Clock Out</th>
                <th style={{ textAlign: "left", padding: 8, borderBottom: "1px solid var(--border)" }}>Hours</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(r => (
                <tr key={r.id}>
                  <td style={{ padding: 8, borderBottom: "1px solid var(--border)" }}>{r.staffId}</td>
                  <td style={{ padding: 8, borderBottom: "1px solid var(--border)" }}>{r.parkId}</td>
                  <td style={{ padding: 8, borderBottom: "1px solid var(--border)" }}>{r.clockIn}</td>
                  <td style={{ padding: 8, borderBottom: "1px solid var(--border)" }}>{r.clockOut || <i>open</i>}</td>
                  <td style={{ padding: 8, borderBottom: "1px solid var(--border)" }}>{r.hours}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div style={{ marginTop: 12 }}>
            <button
              className="btn"
              onClick={() => {
                const csv = toCSV(rows, ["staffId", "parkId", "clockIn", "clockOut", "hours"]);
                const label = `${from || "start"}_to_${to || "end"}${staffId ? "_"+staffId : ""}`;
                download(csv, `staff-shifts-${label}.csv`);
              }}
            >
              Download Shifts CSV
            </button>
          </div>
        </div>
      </div>
    </>
  );
}