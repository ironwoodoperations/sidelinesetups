import React from "react";

export default function TermsAndConditions() {
  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="max-w-4xl mx-auto px-4">
        <div className="card card-pad">
          <h1 className="text-3xl font-bold mb-6" style={{ color: '#003f5c' }}>
            Terms and Conditions
          </h1>
          
          <div style={{ fontSize: "14px", lineHeight: "1.8", color: "#334155" }}>
            <p className="mb-4">
              <strong>Last Updated:</strong> {new Date().toLocaleDateString()}
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              1. Acceptance of Terms
            </h2>
            <p className="mb-4">
              By accessing and using Sideline Setups' services, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              2. Service Description
            </h2>
            <p className="mb-4">
              Sideline Setups provides equipment rental services for youth sports events, including but not limited to tents, chairs, coolers, and related equipment. All equipment remains the property of Sideline Setups and must be returned in the same condition as provided.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              3. Booking and Payment
            </h2>
            <p className="mb-4">
              - All bookings must be made through our online platform<br />
              - Payment is required at the time of booking<br />
              - Prices are subject to change without notice<br />
              - All transactions are processed securely through PayPal
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              4. Cancellation Policy
            </h2>
            <p className="mb-4">
              - Cancellations made 48+ hours before the event receive a full refund<br />
              - Cancellations within 48 hours are eligible for a credit toward future bookings<br />
              - Weather-related cancellations follow the same policy<br />
              - Rescheduling is always free with advance notice
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              5. Equipment Use and Liability
            </h2>
            <p className="mb-4">
              - You are responsible for the equipment during your rental period<br />
              - Normal wear and tear is expected and covered<br />
              - Intentional damage or loss may result in replacement charges<br />
              - Sideline Setups is not liable for personal injury or property damage during equipment use
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              6. Setup and Breakdown
            </h2>
            <p className="mb-4">
              - Our team will set up equipment before your first game<br />
              - Breakdown occurs after your last game<br />
              - You are not required to wait for breakdown<br />
              - Do not move or alter the setup without permission
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              7. SMS Communications
            </h2>
            <p className="mb-4">
              By providing your phone number, you consent to receive booking-related text messages from Sideline Setups. Message and data rates may apply. Reply STOP to opt-out at any time. Consent is not a condition of purchase.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              8. Modifications to Service
            </h2>
            <p className="mb-4">
              Sideline Setups reserves the right to modify or discontinue services at any time without notice. We are not liable to you or any third party for any modification, suspension, or discontinuance of service.
            </p>

            <h2 className="text-xl font-bold mt-6 mb-3" style={{ color: '#003f5c' }}>
              9. Contact Information
            </h2>
            <p className="mb-4">
              For questions about these Terms and Conditions, please contact us at:<br />
              Email: sidelinesetups@gmail.com<br />
              Phone: (918) 285-8151
            </p>
          </div>

          <div className="mt-8 text-center">
            <a href="/events" className="btn-outline">
              Back to Events
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}