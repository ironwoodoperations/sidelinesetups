import React, { useState, useEffect } from "react";
import useSession from "../components/auth/SessionProvider";
import { getCtx } from "../components/lib/ctx";
import { Calendar, Clock, MapPin, Package, LogOut, Menu, X, CalendarDays } from "lucide-react";
import BookingCalendar from "../components/shared/BookingCalendar";

export default function StaffDashboard() {
  const { session, logout } = useSession();
  const [upcomingShifts, setUpcomingShifts] = useState([]);
  const [todayBookings, setTodayBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);

  useEffect(() => {
    loadDashboardData();
  }, []);

  async function loadDashboardData() {
    if (!session?.employee) {
      setLoading(false);
      return;
    }

    try {
      const { entities } = await getCtx();
      const today = new Date().toISOString().split('T')[0];
      
      // Load shifts for this employee
      const shifts = await entities.Shifts.filter({ 
        employeeId: session.employee.id,
        date: today
      });
      
      // Load today's bookings
      const bookings = await entities.Bookings.filter({ 
        date: today,
        status: ['confirmed', 'setup', 'pending']
      });
      
      setUpcomingShifts(shifts || []);
      setTodayBookings(bookings || []);
    } catch (error) {
      console.error("Failed to load dashboard data:", error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div className="spinner"></div>
      </div>
    );
  }

  if (!session?.employee) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}>
        <div style={{ textAlign: "center" }}>
          <h2>Session Expired</h2>
          <p>Please log in again.</p>
          <a href="/staff-login" className="btn" style={{ marginTop: "16px" }}>
            Go to Login
          </a>
        </div>
      </div>
    );
  }

  const employee = session.employee;

  // If showing calendar, render it full-screen
  if (showCalendar) {
    return (
      <div style={{ minHeight: "100vh", background: "#f8fafc" }}>
        {/* Header */}
        <div style={{
          background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
          color: "white",
          padding: "20px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.1)"
        }}>
          <div style={{ maxWidth: "1200px", margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <h1 style={{ margin: 0, fontSize: "32px", fontWeight: "700" }}>
                Staff Dashboard
              </h1>
              <p style={{ margin: "8px 0 0 0", opacity: 0.9, fontSize: "16px" }}>
                Welcome, {employee.fullName || employee.email}!
              </p>
            </div>
            
            <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
              <button
                onClick={() => setShowCalendar(false)}
                style={{
                  background: "rgba(255,255,255,0.1)",
                  border: "none",
                  color: "white",
                  padding: "8px 16px",
                  borderRadius: "8px",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px"
                }}
              >
                <X size={18} />
                Close Calendar
              </button>
              
              <button
                onClick={logout}
                style={{
                  background: "rgba(255,255,255,0.1)",
                  border: "none",
                  color: "white",
                  padding: "8px 16px",
                  borderRadius: "8px",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px"
                }}
              >
                <LogOut size={18} />
                Logout
              </button>
            </div>
          </div>
        </div>

        {/* Calendar Component */}
        <BookingCalendar userRole="staff" />
      </div>
    );
  }

  // Regular dashboard view
  return (
    <div style={{ minHeight: "100vh", background: "#f8fafc" }}>
      {/* Header */}
      <div style={{
        background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
        color: "white",
        padding: "20px",
        boxShadow: "0 2px 8px rgba(0,0,0,0.1)"
      }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <h1 style={{ margin: 0, fontSize: "32px", fontWeight: "700" }}>
              Staff Dashboard
            </h1>
            <p style={{ margin: "8px 0 0 0", opacity: 0.9, fontSize: "16px" }}>
              Welcome, {employee.fullName || employee.email}!
            </p>
          </div>
          
          <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              style={{
                background: "rgba(255,255,255,0.1)",
                border: "none",
                color: "white",
                padding: "8px 12px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "8px"
              }}
            >
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
              Menu
            </button>
            
            <button
              onClick={logout}
              style={{
                background: "rgba(255,255,255,0.1)",
                border: "none",
                color: "white",
                padding: "8px 16px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "8px"
              }}
            >
              <LogOut size={18} />
              Logout
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div style={{
          position: "fixed",
          top: "80px",
          right: "20px",
          background: "white",
          borderRadius: "12px",
          boxShadow: "0 8px 24px rgba(0,0,0,0.15)",
          padding: "12px",
          zIndex: 1000,
          minWidth: "200px"
        }}>
          <a href="/employee-quick-actions" style={{ display: "block", padding: "12px", color: "#003f5c", textDecoration: "none", borderRadius: "8px" }} onMouseEnter={(e) => e.target.style.background = "#f8fafc"} onMouseLeave={(e) => e.target.style.background = "transparent"}>
            Quick Actions
          </a>
          <a href="/pullsheets" style={{ display: "block", padding: "12px", color: "#003f5c", textDecoration: "none", borderRadius: "8px" }} onMouseEnter={(e) => e.target.style.background = "#f8fafc"} onMouseLeave={(e) => e.target.style.background = "transparent"}>
            Pull Sheets
          </a>
          <a href="/kiosk" style={{ display: "block", padding: "12px", color: "#003f5c", textDecoration: "none", borderRadius: "8px" }} onMouseEnter={(e) => e.target.style.background = "#f8fafc"} onMouseLeave={(e) => e.target.style.background = "transparent"}>
            Time Clock
          </a>
          <button 
            onClick={() => setShowCalendar(true)} 
            style={{ display: "block", width: "100%", padding: "12px", color: "#003f5c", textDecoration: "none", borderRadius: "8px", background: "transparent", border: "none", textAlign: "left", cursor: "pointer" }} 
            onMouseEnter={(e) => e.target.style.background = "#f8fafc"} 
            onMouseLeave={(e) => e.target.style.background = "transparent"}
          >
            <CalendarDays size={16} style={{ marginRight: "8px", display: "inline" }} />
            Booking Calendar
          </button>
        </div>
      )}

      {/* Main Content */}
      <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "24px" }}>
        {/* Quick Action Cards */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
          gap: "20px",
          marginBottom: "32px"
        }}>
          <button 
            onClick={() => setShowCalendar(true)}
            className="card" 
            style={{
              padding: "24px",
              textDecoration: "none",
              color: "inherit",
              transition: "transform 0.2s, box-shadow 0.2s",
              cursor: "pointer",
              border: "none",
              background: "white",
              textAlign: "left"
            }} 
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = "translateY(-4px)";
              e.currentTarget.style.boxShadow = "0 12px 24px rgba(0,0,0,0.1)";
            }} 
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = "translateY(0)";
              e.currentTarget.style.boxShadow = "";
            }}
          >
            <CalendarDays size={32} style={{ color: "#8b5cf6", marginBottom: "12px" }} />
            <h3 style={{ margin: "0 0 8px 0", fontSize: "18px" }}>Booking Calendar</h3>
            <p style={{ margin: 0, color: "#64748b", fontSize: "14px" }}>
              View all bookings in calendar format
            </p>
          </button>

          <a href="/employee-quick-actions" className="card" style={{
            padding: "24px",
            textDecoration: "none",
            color: "inherit",
            transition: "transform 0.2s, box-shadow 0.2s",
            cursor: "pointer"
          }} onMouseEnter={(e) => {
            e.currentTarget.style.transform = "translateY(-4px)";
            e.currentTarget.style.boxShadow = "0 12px 24px rgba(0,0,0,0.1)";
          }} onMouseLeave={(e) => {
            e.currentTarget.style.transform = "translateY(0)";
            e.currentTarget.style.boxShadow = "";
          }}>
            <Package size={32} style={{ color: "#003f5c", marginBottom: "12px" }} />
            <h3 style={{ margin: "0 0 8px 0", fontSize: "18px" }}>Quick Actions</h3>
            <p style={{ margin: 0, color: "#64748b", fontSize: "14px" }}>
              Mark setups complete, update status
            </p>
          </a>

          <a href="/pullsheets" className="card" style={{
            padding: "24px",
            textDecoration: "none",
            color: "inherit",
            transition: "transform 0.2s, box-shadow 0.2s",
            cursor: "pointer"
          }} onMouseEnter={(e) => {
            e.currentTarget.style.transform = "translateY(-4px)";
            e.currentTarget.style.boxShadow = "0 12px 24px rgba(0,0,0,0.1)";
          }} onMouseLeave={(e) => {
            e.currentTarget.style.transform = "translateY(0)";
            e.currentTarget.style.boxShadow = "";
          }}>
            <Calendar size={32} style={{ color: "#10b981", marginBottom: "12px" }} />
            <h3 style={{ margin: "0 0 8px 0", fontSize: "18px" }}>Pull Sheets</h3>
            <p style={{ margin: 0, color: "#64748b", fontSize: "14px" }}>
              View setup assignments for today
            </p>
          </a>

          <a href="/kiosk" className="card" style={{
            padding: "24px",
            textDecoration: "none",
            color: "inherit",
            transition: "transform 0.2s, box-shadow 0.2s",
            cursor: "pointer"
          }} onMouseEnter={(e) => {
            e.currentTarget.style.transform = "translateY(-4px)";
            e.currentTarget.style.boxShadow = "0 12px 24px rgba(0,0,0,0.1)";
          }} onMouseLeave={(e) => {
            e.currentTarget.style.transform = "translateY(0)";
            e.currentTarget.style.boxShadow = "";
          }}>
            <Clock size={32} style={{ color: "#f59e0b", marginBottom: "12px" }} />
            <h3 style={{ margin: "0 0 8px 0", fontSize: "18px" }}>Time Clock</h3>
            <p style={{ margin: 0, color: "#64748b", fontSize: "14px" }}>
              Clock in/out for your shift
            </p>
          </a>
        </div>

        {/* Today's Information */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "20px" }}>
          {/* Your Shifts */}
          <div className="card" style={{ padding: "20px" }}>
            <h3 style={{ margin: "0 0 16px 0", display: "flex", alignItems: "center", gap: "8px" }}>
              <Clock size={20} style={{ color: "#003f5c" }} />
              Your Shifts Today
            </h3>
            {upcomingShifts.length === 0 ? (
              <p style={{ color: "#64748b", fontSize: "14px" }}>No shifts scheduled for today</p>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                {upcomingShifts.map(shift => (
                  <div key={shift.id} style={{
                    padding: "12px",
                    background: "#f8fafc",
                    borderRadius: "8px",
                    fontSize: "14px"
                  }}>
                    <div style={{ fontWeight: "600", marginBottom: "4px" }}>
                      {shift.startTime} - {shift.endTime}
                    </div>
                    {shift.parkId && (
                      <div style={{ color: "#64748b" }}>
                        <MapPin size={14} style={{ display: "inline", marginRight: "4px" }} />
                        Park: {shift.parkId}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Today's Bookings */}
          <div className="card" style={{ padding: "20px" }}>
            <h3 style={{ margin: "0 0 16px 0", display: "flex", alignItems: "center", gap: "8px" }}>
              <Package size={20} style={{ color: "#10b981" }} />
              Today's Bookings
            </h3>
            {todayBookings.length === 0 ? (
              <p style={{ color: "#64748b", fontSize: "14px" }}>No bookings for today</p>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                {todayBookings.slice(0, 5).map(booking => (
                  <div key={booking.id} style={{
                    padding: "12px",
                    background: "#f8fafc",
                    borderRadius: "8px",
                    fontSize: "14px"
                  }}>
                    <div style={{ fontWeight: "600", marginBottom: "4px" }}>
                      {booking.fullName || "Unknown"}
                    </div>
                    <div style={{ color: "#64748b" }}>
                      Status: {booking.status}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}