// pages/RunAutomation.jsx
import React from "react";
import AdminAutomations from "./AdminAutomations";

export default function RunAutomation(){
  // We reuse the same functions by programmatically clicking buttons.
  React.useEffect(()=>{
    const sp = new URLSearchParams(location.search);
    const name = sp.get("name");
    const clickByIndex = (i) => {
      const btns = document.querySelectorAll("button");
      if (btns[i]) btns[i].click();
    };
    if (name==="tomorrow") clickByIndex(0);
    if (name==="digest")   clickByIndex(1);
    if (name==="survey")   clickByIndex(2);
  },[]);
  return <AdminAutomations/>;
}