// pages/Inventory.jsx
import React from "react";
import NavBar from "../components/NavBar";
import { getCtx } from "../components/lib/ctx";
import { depleteForDate, replenishCompleted } from "../components/lib/inventory";

function NumBox({ value }) {
  return <div style={{ fontFamily: "tabular-nums, ui-monospace, monospace" }}>{Number(value ?? 0)}</div>;
}

export default function Inventory() {
  const [rows, setRows] = React.useState([]);
  const [date, setDate] = React.useState(() => new Date().toISOString().slice(0,10));
  const [parkId, setParkId] = React.useState("");
  const [parks, setParks] = React.useState([]);
  const [q, setQ] = React.useState("");
  const [note, setNote] = React.useState("");

  React.useEffect(() => { (async () => {
    try {
      const { entities } = await getCtx();
      setParks(await entities.Parks.list() || []);
      await load();
    } catch (e) { setNote(e?.message || "Init failed"); }
  })(); }, []);

  async function load() {
    const { entities } = await getCtx();
    const list = await entities.Equipment.list() || [];
    setRows(list.sort((a,b)=> String(a.type).localeCompare(String(b.type)) || String(a.name).localeCompare(String(b.name))));
  }

  async function bump(row, field, by) {
    try {
      const nv = Math.max(0, Number(row[field] ?? 0) + by);
      const patch = { id: row.id, [field]: nv };
      const { entities } = await getCtx();
      await entities.Equipment.update(patch);
      setRows(prev => prev.map(r => r.id === row.id ? { ...r, ...patch } : r));
    } catch (e) { alert(e?.message || "Update failed"); }
  }

  async function applyDeplete() {
    try {
      await depleteForDate({ date, parkId: parkId || null });
      await load(); alert("Inventory depleted from bookings.");
    } catch (e) { alert(e?.message || "Deplete failed"); }
  }
  async function applyReplenish() {
    try {
      await replenishCompleted({ date, parkId: parkId || null });
      await load(); alert("Inventory replenished from completed bookings.");
    } catch (e) { alert(e?.message || "Replenish failed"); }
  }

  const filtered = rows.filter(r => {
    const s = (q || "").trim().toLowerCase();
    if (!s) return true;
    return String(r.name).toLowerCase().includes(s) || String(r.type).toLowerCase().includes(s);
  });

  return (
    <>
      <NavBar />
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: 16, display: "grid", gap: 16 }}>
        <h2>Inventory</h2>

        <section style={{ background: "white", border: "1px solid #e2e8f0", borderRadius: 16, padding: 16 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr auto auto", gap: 8 }}>
            <div>
              <label style={{ fontSize: 12, color: "#64748b" }}>Date</label>
              <input type="date" value={date} onChange={(e)=>setDate(e.target.value)}
                style={{ width: "100%", padding: "10px 12px", border: "1px solid #e2e8f0", borderRadius: 10 }} />
            </div>
            <div>
              <label style={{ fontSize: 12, color: "#64748b" }}>Park (optional)</label>
              <select value={parkId} onChange={(e)=>setParkId(e.target.value)}
                style={{ width: "100%", padding: "10px 12px", border: "1px solid #e2e8f0", borderRadius: 10 }}>
                <option value="">All parks</option>
                {parks.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 12, color: "#64748b" }}>Search</label>
              <input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="tent, chair, cooler…"
                style={{ width: "100%", padding: "10px 12px", border: "1px solid #e2e8f0", borderRadius: 10 }} />
            </div>
            <div style={{ display: "flex", alignItems: "end" }}>
              <button onClick={applyDeplete} style={{ padding: "10px 14px", borderRadius: 10, border: "1px solid #0ea5e9", background: "#0ea5e9", color: "white", fontWeight: 800 }}>
                Deplete from Bookings
              </button>
            </div>
            <div style={{ display: "flex", alignItems: "end" }}>
              <button onClick={applyReplenish} style={{ padding: "10px 14px", borderRadius: 10, border: "1px solid #10b981", background: "#10b981", color: "white", fontWeight: 800 }}>
                Replenish Completed
              </button>
            </div>
          </div>
        </section>

        <section style={{ background: "white", border: "1px solid #e2e8f0", borderRadius: 16, padding: 0 }}>
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  <th style={{ textAlign: "left", padding: 10, borderBottom: "1px solid #e2e8f0" }}>Type</th>
                  <th style={{ textAlign: "left", padding: 10, borderBottom: "1px solid #e2e8f0" }}>Name</th>
                  <th style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>Total</th>
                  <th style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>Available</th>
                  <th style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>Rented</th>
                  <th style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>Maint.</th>
                  <th style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>Damaged</th>
                  <th style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(r => (
                  <tr key={r.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                    <td style={{ padding: 10 }}>{r.type}</td>
                    <td style={{ padding: 10 }}>{r.name}</td>
                    <td style={{ textAlign: "center", padding: 10 }}><NumBox value={r.totalQty} /></td>
                    <td style={{ textAlign: "center", padding: 10 }}><NumBox value={r.availableQty} /></td>
                    <td style={{ textAlign: "center", padding: 10 }}><NumBox value={r.rentedQty} /></td>
                    <td style={{ textAlign: "center", padding: 10 }}><NumBox value={r.maintenanceQty} /></td>
                    <td style={{ textAlign: "center", padding: 10 }}><NumBox value={r.damagedQty} /></td>
                    <td style={{ padding: 10 }}>
                      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                        <button onClick={()=>bump(r, "availableQty", 1)}  title="Add to available">+Avail</button>
                        <button onClick={()=>bump(r, "availableQty", -1)} title="Remove from available">-Avail</button>
                        <button onClick={()=>bump(r, "rentedQty", 1)}     title="Add to rented">+Rent</button>
                        <button onClick={()=>bump(r, "rentedQty", -1)}    title="Remove from rented">-Rent</button>
                        <button onClick={()=>bump(r, "maintenanceQty", 1)}>+Maint</button>
                        <button onClick={()=>bump(r, "maintenanceQty", -1)}>-Maint</button>
                        <button onClick={()=>bump(r, "damagedQty", 1)}>+Damg</button>
                        <button onClick={()=>bump(r, "damagedQty", -1)}>-Damg</button>
                      </div>
                    </td>
                  </tr>
                ))}
                {!filtered.length && (
                  <tr><td colSpan={8} style={{ padding: 16, color: "#94a3b8" }}>No equipment found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        {!!note && <div style={{ color: "#ef4444" }}>{note}</div>}
      </div>
    </>
  );
}