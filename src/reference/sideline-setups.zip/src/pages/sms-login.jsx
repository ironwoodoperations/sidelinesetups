import SmsLogin from "./SmsLogin";

export default SmsLogin;