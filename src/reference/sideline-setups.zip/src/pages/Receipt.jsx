// pages/Receipt.jsx
import React from "react";
import { getCtx } from "../components/lib/ctx";

function Row({label,children}) {
  return (
    <tr>
      <td style={{padding:"6px 8px", color:"#475569", width:160}}><b>{label}</b></td>
      <td style={{padding:"6px 8px"}}>{children}</td>
    </tr>
  );
}

export default function Receipt(){
  const [booking,setBooking] = React.useState(null);
  const [brand,setBrand] = React.useState("Sideline Setups");

  React.useEffect(()=>{
    (async()=>{
      const sp = new URLSearchParams(location.search);
      const id = sp.get("b") || sp.get("booking");
      const { entities, settings } = await getCtx();
      setBrand(settings?.brandName || "Sideline Setups");
      if (!id) return;
      const b = await entities.Bookings.get({ id });
      setBooking(b || null);
    })();
  },[]);

  function onPrint(){ window.print(); }

  if (!booking) {
    return <div className="container section"><p>Loading…</p></div>;
  }

  const total = Number(booking?.totals?.amount ?? 0);

  return (
    <div className="container section" style={{maxWidth:800, margin:"0 auto"}}>
      <div style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
        <h1 style={{marginBottom:0}}>{brand} — Receipt</h1>
        <button onClick={onPrint}
                style={{padding:"8px 12px", borderRadius:8, border:"1px solid #cbd5e1"}}>
          Print
        </button>
      </div>
      <p style={{color:"#64748b", marginTop:6}}>Booking ID: <b>{booking.id}</b></p>

      <table style={{width:"100%", borderCollapse:"collapse", marginTop:8}}>
        <tbody>
          <Row label="Customer">{booking.fullName || booking.teamName || "—"}</Row>
          <Row label="Email">{booking.contactEmail || "—"}</Row>
          <Row label="Phone">{booking.phone || "—"}</Row>
          <Row label="Event Type">{booking.eventType || "—"}</Row>
          <Row label="Sport">{booking.sport || "—"}</Row>
          <Row label="Date">{booking.date || "—"}</Row>
          <Row label="Times">{(booking.gameTimes || []).join(", ") || "—"}</Row>
          <Row label="Package">{booking.packageName || booking.packageId || "—"}</Row>
          <Row label="Add-ons">{(booking.addOns || []).map(a=>a?.label||a?.equipmentId).join(", ") || "—"}</Row>
          <Row label="Spot">{booking.spotId || "—"}</Row>
          <Row label="Status">{booking.status || "pending"}</Row>
          <Row label="Total Paid">${total.toFixed(2)}</Row>
        </tbody>
      </table>

      <p style={{marginTop:16, fontSize:12, color:"#64748b"}}>Thank you for choosing {brand}. See you on game day!</p>
    </div>
  );
}