
import React from "react";
import SEO from "../components/SEO";

export default function OurStory() {
  const [settings, setSettings] = React.useState(null);

  React.useEffect(() => {
    (async () => {
      const { getCtx } = await import("../components/lib/ctx");
      const { settings } = await getCtx();
      setSettings(settings || {});
    })();
  }, []);

  return (
    <div 
      className="min-h-screen py-12"
      style={{
        backgroundImage: settings?.pageBackgroundPatternUrl 
          ? `linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.92)), url('${settings.pageBackgroundPatternUrl}')`
          : undefined,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
        backgroundColor: '#f8fafc'
      }}
    >
      <SEO 
        title="Our Story | Sideline Setups - Youth Sports Setup Rentals"
        description="Learn how Sideline Setups started from a simple observation: parents struggling with heavy equipment at youth sports tournaments. Now we serve travel ball families across East Texas."
        keywords="sideline setups story, youth sports rental company, travel ball services, tournament setup history, East Texas sports business"
        canonicalUrl="https://sideline-setups.com/ourstory"
      />
      
      <div className="max-w-4xl mx-auto px-4">
        <div className="card card-pad">
          <h1 className="text-4xl font-bold mb-6" style={{color: '#003f5c'}}>Our Story: Making Youth Sports Tournaments Easier for Parents</h1>
          
          <div className="space-y-6 text-gray-700 leading-relaxed">
            <p className="text-lg">
              Sideline Setups was born from a simple observation: parents spending hours at youth sports tournaments, 
              standing in the sun, juggling chairs, coolers, and equipment while trying to cheer for their kids.
            </p>

            <p>
              As a parent of three athletes myself, I've been there. The early morning scramble to pack the car, 
              the struggle to find a good spot at the field, and the constant worry about whether we brought everything. 
              Game day should be about watching your kids play, not stressing about logistics.
            </p>

            <p>
              That's why we created Sideline Setups. We handle all the heavy lifting so you can focus on what matters most – 
              supporting your athlete. Our team arrives early, sets up your comfortable shaded area with chairs and coolers, 
              and returns after the games to pack it all up.
            </p>

            <p>
              What started as a solution for our own family has grown into a service helping hundreds of sports families 
              across multiple tournaments. Every weekend, we see the relief on parents' faces when they arrive at the field 
              and their setup is already waiting for them.
            </p>

            <p>
              We're not just a rental company – we're sports parents who understand what you need because we've lived it. 
              Our mission is simple: make your tournament weekends easier, more comfortable, and more enjoyable.
            </p>

            <p className="text-lg font-semibold" style={{color: '#003f5c'}}>
              Welcome to the Sideline Setups family. We'll see you at the field!
            </p>
          </div>

          <div className="mt-8 text-center">
            <a href="/events" className="btn" style={{
              background: 'linear-gradient(to right, #003f5c, #00507a)',
              color: 'white',
              border: 'none',
              padding: '12px 32px',
              borderRadius: '9999px',
              fontWeight: '600',
              textDecoration: 'none',
              display: 'inline-block'
            }}>
              Book Your Setup Today
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
