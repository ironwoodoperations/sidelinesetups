import { useEffect, useState } from 'react';
import { Lock, Mail, Smartphone, Shield } from 'lucide-react';

export default function StaffLoginPage() {
  const [redirectTo, setRedirectTo] = useState('/StaffDashboard');
  const [tab, setTab] = useState('pin');
  const [pin, setPin] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const r = new URLSearchParams(window.location.search).get('redirect');
    if (r) setRedirectTo(r);
  }, []);

  async function handlePinLogin(e) {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    
    try {
      const res = await fetch('/functions/employeePinLogin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });
      
      const data = await res.json();
      
      if (res.ok && data.ok) {
        sessionStorage.setItem('ss.session', JSON.stringify({
          kind: 'employee',
          employee: data.employee
        }));
        window.location.href = redirectTo;
      } else {
        setMessage(data.error || 'Invalid PIN');
      }
    } catch (err) {
      setMessage('Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  async function handleEmailLink(e) {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    
    try {
      const res = await fetch('/functions/requestMagicLink', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind: 'employee', email })
      });
      
      if (res.ok) {
        setMessage('✅ Check your email for the login link!');
      } else {
        setMessage('Failed to send email. Please try again.');
      }
    } catch (err) {
      setMessage('Failed to send email. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  async function handleSmsCode(e) {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    
    try {
      const res = await fetch('/functions/auth/requestSmsOtp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind: 'employee_sms', phone })
      });
      
      if (res.ok) {
        setMessage('✅ Check your phone for the login code!');
        setTimeout(() => {
          window.location.href = `/staff-sms?phone=${encodeURIComponent(phone)}&redirect=${encodeURIComponent(redirectTo)}`;
        }, 1500);
      } else {
        setMessage('Failed to send SMS. Please try again.');
      }
    } catch (err) {
      setMessage('Failed to send SMS. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  const tabData = [
    { id: 'pin', label: 'PIN', icon: Lock },
    { id: 'email', label: 'Email', icon: Mail },
    { id: 'phone', label: 'SMS', icon: Smartphone }
  ];

  return (
    <div style={{ 
      minHeight: "calc(100vh - 400px)", 
      display: "flex", 
      alignItems: "center", 
      justifyContent: "center",
      padding: "40px 20px"
    }}>
      <div style={{ 
        maxWidth: "480px", 
        width: "100%",
        background: "white",
        borderRadius: "16px",
        boxShadow: "0 8px 32px rgba(0, 63, 92, 0.12)",
        overflow: "hidden"
      }}>
        {/* Header Section */}
        <div style={{
          background: "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
          padding: "32px 32px 24px 32px",
          textAlign: "center",
          color: "white"
        }}>
          <div style={{
            width: "64px",
            height: "64px",
            background: "rgba(255,255,255,0.15)",
            borderRadius: "50%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            margin: "0 auto 16px auto"
          }}>
            <Shield size={32} />
          </div>
          <h1 style={{ 
            margin: "0 0 8px 0", 
            fontSize: "24px", 
            fontWeight: "700"
          }}>
            Staff Access
          </h1>
          <p style={{ 
            margin: 0, 
            opacity: 0.9,
            fontSize: "14px"
          }}>
            Choose your preferred login method
          </p>
        </div>

        {/* Message Area */}
        {message && (
          <div style={{
            margin: "20px 32px 0 32px",
            padding: '14px 16px',
            borderRadius: '10px',
            background: message.includes('✅') ? '#d1fae5' : '#fee2e2',
            color: message.includes('✅') ? '#065f46' : '#991b1b',
            fontSize: "14px",
            fontWeight: "500",
            display: "flex",
            alignItems: "center",
            gap: "8px"
          }}>
            <span>{message}</span>
          </div>
        )}

        {/* Tab Navigation */}
        <div style={{
          display: "flex",
          borderBottom: "2px solid #f1f5f9",
          background: "#f8fafc",
          padding: "0 32px"
        }}>
          {tabData.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              style={{
                flex: 1,
                padding: "16px 12px",
                background: "transparent",
                border: "none",
                borderBottom: tab === id ? "3px solid #003f5c" : "3px solid transparent",
                color: tab === id ? "#003f5c" : "#64748b",
                fontWeight: tab === id ? "600" : "500",
                fontSize: "14px",
                cursor: "pointer",
                transition: "all 0.2s",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "8px",
                marginBottom: "-2px"
              }}
            >
              <Icon size={18} />
              {label}
            </button>
          ))}
        </div>

        {/* Form Content */}
        <div style={{ padding: "32px" }}>
          {tab === 'pin' && (
            <form onSubmit={handlePinLogin} style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
              <div>
                <label style={{ 
                  display: "block", 
                  fontSize: "14px", 
                  fontWeight: "600",
                  color: "#334155",
                  marginBottom: "8px"
                }}>
                  Enter Your PIN
                </label>
                <input
                  type="password"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  style={{
                    width: "100%",
                    padding: "14px 16px",
                    border: "2px solid #e2e8f0",
                    borderRadius: "10px",
                    fontSize: "16px",
                    transition: "all 0.2s",
                    fontFamily: "inherit"
                  }}
                  placeholder="••••"
                  required
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  onFocus={(e) => e.target.style.borderColor = "#003f5c"}
                  onBlur={(e) => e.target.style.borderColor = "#e2e8f0"}
                />
              </div>
              <button 
                type="submit"
                disabled={loading}
                style={{
                  width: "100%",
                  padding: "14px",
                  background: loading ? "#94a3b8" : "linear-gradient(135deg, #003f5c 0%, #005a7d 100%)",
                  color: "white",
                  border: "none",
                  borderRadius: "10px",
                  fontSize: "16px",
                  fontWeight: "600",
                  cursor: loading ? "not-allowed" : "pointer",
                  transition: "all 0.2s",
                  boxShadow: loading ? "none" : "0 4px 12px rgba(0, 63, 92, 0.2)"
                }}
                onMouseEnter={(e) => {
                  if (!loading) {
                    e.target.style.transform = "translateY(-2px)";
                    e.target.style.boxShadow = "0 6px 16px rgba(0, 63, 92, 0.3)";
                  }
                }}
                onMouseLeave={(e) => {
                  if (!loading) {
                    e.target.style.transform = "translateY(0)";
                    e.target.style.boxShadow = "0 4px 12px rgba(0, 63, 92, 0.2)";
                  }
                }}
              >
                {loading ? 'Signing in...' : 'Sign In'}
              </button>
            </form>
          )}

          {tab === 'email' && (
            <form onSubmit={handleEmailLink} style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
              <div>
                <label style={{ 
                  display: "block", 
                  fontSize: "14px", 
                  fontWeight: "600",
                  color: "#334155",
                  marginBottom: "8px"
                }}>
                  Work Email
                </label>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={{
                    width: "100%",
                    padding: "14px 16px",
                    border: "2px solid #e2e8f0",
                    borderRadius: "10px",
                    fontSize: "16px",
                    transition: "all 0.2s",
                    fontFamily: "inherit"
                  }}
                  placeholder="name@company.com" 
                  required
                  onFocus={(e) => e.target.style.borderColor = "#003f5c"}
                  onBlur={(e) => e.target.style.borderColor = "#e2e8f0"}
                />
                <p style={{ 
                  margin: "8px 0 0 0", 
                  fontSize: "12px", 
                  color: "#64748b"
                }}>
                  We'll send you a secure login link
                </p>
              </div>
              <button 
                type="submit"
                disabled={loading}
                style={{
                  width: "100%",
                  padding: "14px",
                  background: "white",
                  color: "#003f5c",
                  border: "2px solid #003f5c",
                  borderRadius: "10px",
                  fontSize: "16px",
                  fontWeight: "600",
                  cursor: loading ? "not-allowed" : "pointer",
                  transition: "all 0.2s",
                  opacity: loading ? 0.6 : 1
                }}
                onMouseEnter={(e) => {
                  if (!loading) {
                    e.target.style.background = "#f8fafc";
                  }
                }}
                onMouseLeave={(e) => {
                  if (!loading) {
                    e.target.style.background = "white";
                  }
                }}
              >
                {loading ? 'Sending...' : 'Send Magic Link'}
              </button>
            </form>
          )}

          {tab === 'phone' && (
            <form onSubmit={handleSmsCode} style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
              <div>
                <label style={{ 
                  display: "block", 
                  fontSize: "14px", 
                  fontWeight: "600",
                  color: "#334155",
                  marginBottom: "8px"
                }}>
                  Mobile Number
                </label>
                <input 
                  type="tel" 
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  style={{
                    width: "100%",
                    padding: "14px 16px",
                    border: "2px solid #e2e8f0",
                    borderRadius: "10px",
                    fontSize: "16px",
                    transition: "all 0.2s",
                    fontFamily: "inherit"
                  }}
                  placeholder="+1 555 123 4567" 
                  required
                  onFocus={(e) => e.target.style.borderColor = "#003f5c"}
                  onBlur={(e) => e.target.style.borderColor = "#e2e8f0"}
                />
                <p style={{ 
                  margin: "8px 0 0 0", 
                  fontSize: "12px", 
                  color: "#64748b"
                }}>
                  We'll text you a verification code
                </p>
              </div>
              <button 
                type="submit"
                disabled={loading}
                style={{
                  width: "100%",
                  padding: "14px",
                  background: "white",
                  color: "#003f5c",
                  border: "2px solid #003f5c",
                  borderRadius: "10px",
                  fontSize: "16px",
                  fontWeight: "600",
                  cursor: loading ? "not-allowed" : "pointer",
                  transition: "all 0.2s",
                  opacity: loading ? 0.6 : 1
                }}
                onMouseEnter={(e) => {
                  if (!loading) {
                    e.target.style.background = "#f8fafc";
                  }
                }}
                onMouseLeave={(e) => {
                  if (!loading) {
                    e.target.style.background = "white";
                  }
                }}
              >
                {loading ? 'Sending...' : 'Text Me a Code'}
              </button>
            </form>
          )}
        </div>

        {/* Footer Info */}
        <div style={{
          padding: "20px 32px",
          background: "#f8fafc",
          borderTop: "1px solid #e2e8f0",
          textAlign: "center"
        }}>
          <p style={{ 
            margin: 0, 
            fontSize: "12px", 
            color: "#64748b"
          }}>
            🔒 Secure staff authentication • After login, you'll be redirected to: <strong>{redirectTo}</strong>
          </p>
        </div>
      </div>
    </div>
  );
}