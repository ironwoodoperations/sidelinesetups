import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';

export default function SignIn() {
  const [status, setStatus] = useState('Verifying...');

  useEffect(() => {
    async function verifyToken() {
      const params = new URLSearchParams(window.location.search);
      const token = params.get('token');
      const kind = params.get('kind') || 'customer';
      const redirectTo = params.get('redirect') || (kind === 'customer' ? '/mybookings' : '/StaffDashboard');

      console.log('=== SignIn: Starting verification ===');
      console.log('Token:', token);
      console.log('Kind:', kind);

      if (!token) {
        setStatus('Missing token');
        alert('Missing token for sign-in. Please ensure the link is complete and try again.');
        setTimeout(() => {
          window.location.href = (kind === 'customer' ? '/customer-login' : '/staff-login');
        }, 1000);
        return;
      }

      try {
        setStatus('Verifying your login...');
        const result = await base44.functions.invoke('verifyMagicLink', { token, kind });
        
        console.log('=== SignIn: Verify result ===', result.data);
        
        if (result.data.ok) {
          const sessionData = result.data.session;
          console.log('=== SignIn: Session data to store ===', sessionData);
          
          if (kind === 'customer') {
            // Make sure we have the email
            if (!sessionData.customerEmail) {
              console.error('=== SignIn: Session missing customerEmail! ===', sessionData);
              alert('Login succeeded but session data is incomplete. Please try again.');
              window.location.href = '/customer-login';
              return;
            }

            sessionStorage.setItem('customer.session', JSON.stringify(sessionData));
            console.log('=== SignIn: Stored customer session ===');
            console.log('Stored value:', sessionStorage.getItem('customer.session'));
            
            setStatus('Success! Redirecting...');
            
            // Add delay to ensure storage completes
            setTimeout(() => {
              console.log('=== SignIn: Redirecting to:', redirectTo);
              window.location.href = redirectTo;
            }, 500);
          } else if (kind === 'employee') {
            sessionStorage.setItem('ss.session', JSON.stringify(sessionData));
            setStatus('Success! Redirecting...');
            setTimeout(() => {
              window.location.href = redirectTo;
            }, 500);
          } else {
            console.error('Unknown session kind:', kind);
            alert('Unknown session kind. Please try again.');
            window.location.href = '/';
          }
        } else {
          setStatus('Verification failed');
          alert(result.data.error || 'Failed to verify token.');
          setTimeout(() => {
            window.location.href = (kind === 'customer' ? '/customer-login' : '/staff-login');
          }, 1000);
        }
      } catch (err) {
        console.error('Verification error:', err);
        setStatus('Error: ' + err.message);
        alert(err.message || 'An error occurred during verification.');
        setTimeout(() => {
          window.location.href = (kind === 'customer' ? '/customer-login' : '/staff-login');
        }, 1000);
      }
    }
    verifyToken();
  }, []);

  return (
    <div style={{ padding: "40px", textAlign: "center" }}>
      <div className="spinner"></div>
      <p style={{ marginTop: "16px", fontSize: "1.1em", color: "#333" }}>
        {status}
      </p>
    </div>
  );
}