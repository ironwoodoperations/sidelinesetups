
import React, { useState, useEffect } from "react";
import { Calendar, ExternalLink, LogOut } from "lucide-react";
import { base44 } from "../api/base44Client";
import SmsContactBox from "../components/SmsContactBox";
import SEO from "../components/SEO";
import LoyaltyPointsBalance from "../components/loyalty/LoyaltyPointsBalance";
import LoyaltyTransactionHistory from "../components/loyalty/LoyaltyTransactionHistory";
import { format } from 'date-fns'; // Added date-fns import

export default function MyBookings() {
  const [customerSession, setCustomerSession] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  // Removed: const [expandedBooking, setExpandedBooking] = useState(null);

  useEffect(() => {
    console.log('[MyBookings] useEffect running');
    
    // Load customer session from sessionStorage
    try {
      const rawSession = sessionStorage.getItem("customer.session");
      console.log('[MyBookings] Raw session from storage:', rawSession);
      
      const session = JSON.parse(rawSession || "null");
      console.log('[MyBookings] Parsed session:', session);
      
      setCustomerSession(session);
      
      if (session) {
        loadBookings(session);
      } else {
        console.log('[MyBookings] No session found, showing login prompt');
        setLoading(false);
      }
    } catch (e) {
      console.error("[MyBookings] Error loading customer session:", e);
      setLoading(false);
    }
  }, []);

  async function loadBookings(session) {
    console.log('[MyBookings] loadBookings called with session:', session);
    
    if (!session?.customerEmail) {
      console.log('[MyBookings] No customerEmail in session:', session);
      setLoading(false);
      return;
    }

    try {
      console.log('[MyBookings] Fetching bookings for:', session.customerEmail);
      const result = await base44.functions.invoke('customer/my-bookings', {
        email: session.customerEmail
      });

      console.log('[MyBookings] Bookings result:', result.data);

      if (result.data.ok) {
        setBookings(result.data.bookings || []);
        console.log('[MyBookings] Loaded bookings:', result.data.bookings?.length || 0);
      }
    } catch (error) {
      console.error("[MyBookings] Failed to load bookings:", error);
    } finally {
      setLoading(false);
    }
  }

  function handleLogout() {
    console.log('[MyBookings] Logging out');
    sessionStorage.removeItem("customer.session");
    window.location.href = "/";
  }

  // Removed: function formatDate(dateStr) { ... }

  function formatMoney(cents) {
    return `$${(cents / 100).toFixed(2)}`;
  }

  // Removed: const statusColors = { ... }; (old statusColors for tailwind classes)

  console.log('[MyBookings] Render - loading:', loading, 'customerSession:', customerSession, 'bookings:', bookings.length);

  if (loading) {
    return (
      <div style={{ minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div className="spinner"></div>
        <p style={{ marginLeft: "16px", color: "#64748b" }}>Loading your bookings...</p>
      </div>
    );
  }

  if (!customerSession) {
    console.log('[MyBookings] Rendering login prompt because customerSession is:', customerSession);
    return (
      <div style={{ minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}>
        <div style={{ textAlign: "center" }}>
          <h2>Please Log In</h2>
          <p>You need to be logged in to view your bookings.</p>
          <a href="/customer-login" className="btn" style={{ marginTop: "16px" }}>
            Login
          </a>
        </div>
      </div>
    );
  }

  // New status color and label definitions, moved outside the map for efficiency
  const bookingStatusColors = {
    'pending': '#fbbf24',
    'paid': '#10b981',
    'photo_uploaded': '#3b82f6',
    'setup': '#06b6d4',
    'checked_in': '#8b5cf6',
    'leaving': '#64748b',
    'picked_up': '#a855f7',
    'closed': '#6b7280',
    'cancelled': '#ef4444'
  };

  const bookingStatusLabels = {
    'pending': 'Pending',
    'paid': 'Paid',
    'photo_uploaded': 'ID Uploaded',
    'setup': 'Setup Complete',
    'checked_in': 'Checked In',
    'leaving': 'Customer Leaving',
    'picked_up': 'Equipment Picked Up',
    'closed': 'Closed',
    'cancelled': 'Cancelled'
  };

  return (
    <div style={{ minHeight: "100vh", background: "#f8fafc" }}>
      <SEO 
        title="My Bookings | Sideline Setups"
        description="View and manage your Sideline Setups youth sports tournament bookings. Check your upcoming game day setups and past reservations."
        keywords="my bookings, sideline setups account, tournament reservations, game day setup bookings"
        canonicalUrl="https://sideline-setups.com/mybookings"
      />
      <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "24px" }}>
        {/* Header */}
        <div style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "32px",
          flexWrap: "wrap",
          gap: "16px"
        }}>
          <div>
            <h1 style={{ margin: 0, fontSize: "28px", fontWeight: "700", color: "#003f5c" }}>
              My Bookings
            </h1>
            <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>
              Logged in as {customerSession.customerEmail}
            </p>
          </div>
          <button
            onClick={handleLogout}
            style={{
              background: "white",
              border: "1px solid #e2e8f0",
              color: "#64748b",
              padding: "10px 20px",
              borderRadius: "8px",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: "8px",
              fontSize: "14px"
            }}
          >
            <LogOut size={16} />
            Logout
          </button>
        </div>

        {/* Loyalty Points Section - NEW */}
        {customerSession?.customerEmail && (
          <div style={{
            background: "white",
            borderRadius: "12px",
            padding: "24px",
            marginBottom: "24px",
            boxShadow: "0 2px 8px rgba(0,0,0,0.1)"
          }}>
            <h2 style={{ margin: "0 0 20px 0", fontSize: "24px", fontWeight: "700", color: "#003f5c" }}>
              Loyalty Rewards
            </h2>
            <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: "24px" }}> {/* Adjusted grid-template-columns */}
              <LoyaltyPointsBalance customerEmail={customerSession.customerEmail} showDetails={true} />
              <LoyaltyTransactionHistory customerEmail={customerSession.customerEmail} />
            </div>
          </div>
        )}

        {/* Bookings List */}
        {bookings.length === 0 ? (
          <div style={{
            background: "white",
            borderRadius: "12px",
            padding: "60px 20px",
            textAlign: "center",
            boxShadow: "0 2px 8px rgba(0,0,0,0.1)"
          }}>
            <Calendar size={48} style={{ margin: "0 auto 16px", color: "#cbd5e1" }} />
            <h3 style={{ margin: "0 0 8px 0", color: "#64748b" }}>No Bookings Yet</h3>
            <p style={{ margin: "0 0 24px 0", color: "#94a3b8", fontSize: "14px" }}>
              You haven't made any bookings yet. Ready to reserve your setup?
            </p>
            <a href="/events" className="btn">
              Browse Events
            </a>
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "24px" }}>
            {bookings.map((booking) => {
              const dateStr = booking.date 
                ? format(new Date(booking.date), 'MMM d, yyyy')
                : 'Date TBD';
              
              return (
                <div 
                  key={booking.id}
                  style={{
                    background: 'white',
                    borderRadius: '12px',
                    padding: '24px',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                    transition: 'all 0.2s',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.boxShadow = '0 4px 16px rgba(0,0,0,0.15)';
                    e.currentTarget.style.transform = 'translateY(-2px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '16px' }}>
                    <div>
                      <div style={{ 
                        fontSize: '12px', 
                        color: '#64748b', 
                        marginBottom: '4px',
                        fontFamily: 'monospace'
                      }}>
                        #{booking.id.substring(0, 8)}
                      </div>
                      <h3 style={{ margin: '0 0 8px 0', fontSize: '20px', fontWeight: '600', color: '#003f5c' }}>
                        {booking.teamName || booking.event?.name || 'Booking'}
                      </h3>
                    </div>
                    <div style={{
                      padding: '6px 12px',
                      borderRadius: '20px',
                      fontSize: '12px',
                      fontWeight: '600',
                      background: bookingStatusColors[booking.status] || '#94a3b8',
                      color: 'white',
                      whiteSpace: 'nowrap'
                    }}>
                      {bookingStatusLabels[booking.status] || booking.status}
                    </div>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '24px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#64748b' }}>
                      <Calendar size={16} />
                      <span>{dateStr}</span>
                    </div>
                    {booking.eventId && (
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#64748b', fontSize: '14px' }}>
                        <ExternalLink size={16} /> {/* Using ExternalLink icon for Event ID to imply it might link externally or be a reference */}
                        <span>Event ID: {booking.eventId.substring(0, 12)}...</span>
                      </div>
                    )}
                  </div>

                  <a 
                    href={`/thankyou?b=${booking.id}&from=mybookings`}
                    style={{
                      display: 'inline-block',
                      padding: '10px 20px',
                      background: 'linear-gradient(135deg, #003f5c 0%, #005a7d 100%)',
                      color: 'white',
                      borderRadius: '8px',
                      textDecoration: 'none',
                      fontSize: '14px',
                      fontWeight: '600',
                      textAlign: 'center',
                      transition: 'all 0.2s',
                      marginTop: 'auto' // Pushes the button to the bottom
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.transform = 'translateY(-1px)';
                      e.target.style.boxShadow = '0 4px 12px rgba(0,63,92,0.3)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.transform = 'translateY(0)';
                      e.target.style.boxShadow = 'none';
                    }}
                  >
                    View Details →
                  </a>
                </div>
              );
            })}
          </div>
        )}
        
        {/* SMS Contact Form */}
        <SmsContactBox 
          bookingId={bookings?.[0]?.id}
          customerName={customerSession?.customerEmail}
          customerPhone={bookings?.[0]?.phone}
        />
      </div>
    </div>
  );
}
