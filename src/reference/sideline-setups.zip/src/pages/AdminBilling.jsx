// pages/AdminBilling.jsx
import React from "react";
import NavBar from "../components/NavBar";
import { getCtx } from "../components/lib/ctx";
// Removed non-existent imports - functionality needs backend implementation

function Row({ label, children }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "160px 1fr", gap: 10, marginBottom: 8 }}>
      <div style={{ color: "#64748b", fontSize: 13 }}>{label}</div>
      <div>{children}</div>
    </div>
  );
}

export default function AdminBilling() {
  const [q, setQ] = React.useState("");
  const [bookings, setBookings] = React.useState([]);
  const [sel, setSel] = React.useState(null);
  const [note, setNote] = React.useState("");

  const [creditAmt, setCreditAmt] = React.useState("");
  const [creditReason, setCreditReason] = React.useState("");
  const [refundAmt, setRefundAmt] = React.useState("");
  const [refundReason, setRefundReason] = React.useState("");

  React.useEffect(() => { (async () => {
    const { entities } = await getCtx();
    const list = await entities.Bookings.list() || [];
    setBookings(list.sort((a,b) => new Date(b.created_date || 0) - new Date(a.created_date || 0)));
  })().catch(e => setNote(e?.message || "Init failed")); }, []);

  const filtered = bookings.filter(b => {
    const s = q.trim().toLowerCase();
    if (!s) return true;
    return String(b.id).toLowerCase().includes(s)
      || String(b.contactEmail).toLowerCase().includes(s)
      || String(b.teamName || "").toLowerCase().includes(s);
  });

  async function genInvoice() {
    alert("Invoice functionality coming soon - needs backend implementation");
  }

  async function giveCredit() {
    alert("Store credit functionality coming soon - needs backend implementation");
  }

  async function refund() {
    alert("Refund functionality coming soon - needs backend implementation");
  }

  return (
    <>
      <NavBar />
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: 16, display: "grid", gap: 16 }}>
        <h2>Admin — Invoicing / Credits & Refunds</h2>

        <section style={{ background: "white", border: "1px solid #e2e8f0", borderRadius: 16, padding: 16 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 8 }}>
            <input placeholder="Search bookings by id, email, team…" value={q} onChange={(e)=>setQ(e.target.value)}
              style={{ padding: "10px 12px", border: "1px solid #e2e8f0", borderRadius: 10 }} />
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 12, color: "#64748b" }}>{filtered.length} results</span>
            </div>
          </div>
          <div style={{ marginTop: 10, maxHeight: 320, overflow: "auto", border: "1px solid #e2e8f0", borderRadius: 12 }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  <th style={{ textAlign: "left", padding: 10, borderBottom: "1px solid #e2e8f0" }}>ID</th>
                  <th style={{ textAlign: "left", padding: 10, borderBottom: "1px solid #e2e8f0" }}>Email</th>
                  <th style={{ textAlign: "left", padding: 10, borderBottom: "1px solid #e2e8f0" }}>Team</th>
                  <th style={{ textAlign: "left", padding: 10, borderBottom: "1px solid #e2e8f0" }}>Date</th>
                  <th style={{ textAlign: "left", padding: 10, borderBottom: "1px solid #e2e8f0" }}>Total</th>
                  <th style={{ textAlign: "left", padding: 10, borderBottom: "1px solid #e2e8f0" }}>Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(b => (
                  <tr key={b.id}
                      onClick={()=>setSel(b)}
                      style={{ borderBottom: "1px solid #f1f5f9", cursor: "pointer", background: sel?.id===b.id ? "#f0f9ff" : "transparent" }}>
                    <td style={{ padding: 10 }}>{b.id}</td>
                    <td style={{ padding: 10 }}>{b.contactEmail}</td>
                    <td style={{ padding: 10 }}>{b.teamName || ""}</td>
                    <td style={{ padding: 10 }}>{b.date}</td>
                    <td style={{ padding: 10 }}>${(b?.totals?.amount || 0).toFixed(2)}</td>
                    <td style={{ padding: 10 }}>{b.status}</td>
                  </tr>
                ))}
                {!filtered.length && <tr><td colSpan={6} style={{ padding: 12, color: "#94a3b8" }}>No bookings.</td></tr>}
              </tbody>
            </table>
          </div>
        </section>

        {sel && (
          <section style={{ background: "white", border: "1px solid #e2e8f0", borderRadius: 16, padding: 16 }}>
            <h3 style={{ marginTop: 0 }}>Selected Booking</h3>
            <Row label="Booking">{sel.id}</Row>
            <Row label="Customer">{sel.fullName} — {sel.contactEmail}</Row>
            <Row label="Team">{sel.teamName || "—"}</Row>
            <Row label="Total">${(sel?.totals?.amount || 0).toFixed(2)}</Row>
            <Row label="Actions">
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <button onClick={genInvoice} style={{ padding: "10px 14px", borderRadius: 10, border: "1px solid #0ea5e9", background: "#0ea5e9", color: "white", fontWeight: 800 }}>
                  Create & Email Invoice
                </button>
              </div>
            </Row>

            <hr style={{ border: 0, borderTop: "1px solid #e2e8f0", margin: "12px 0" }} />

            <h4 style={{ margin: "8px 0" }}>Apply Store Credit (and loyalty points)</h4>
            <Row label="Amount (USD)">
              <input type="number" value={creditAmt} onChange={(e)=>setCreditAmt(e.target.value)} style={{ padding: 8, border: "1px solid #e2e8f0", borderRadius: 8 }} />
            </Row>
            <Row label="Reason">
              <input value={creditReason} onChange={(e)=>setCreditReason(e.target.value)} placeholder="Goodwill, weather delay, etc."
                style={{ width: "100%", padding: 8, border: "1px solid #e2e8f0", borderRadius: 8 }} />
            </Row>
            <Row label="">
              <button onClick={giveCredit} style={{ padding: "8px 12px", borderRadius: 10, border: "1px solid #10b981", background: "#10b981", color: "white", fontWeight: 800 }}>
                Apply Credit
              </button>
            </Row>

            <hr style={{ border: 0, borderTop: "1px solid #e2e8f0", margin: "12px 0" }} />

            <h4 style={{ margin: "8px 0" }}>Record Refund (note-only)</h4>
            <Row label="Amount (USD)">
              <input type="number" value={refundAmt} onChange={(e)=>setRefundAmt(e.target.value)} style={{ padding: 8, border: "1px solid #e2e8f0", borderRadius: 8 }} />
            </Row>
            <Row label="Reason">
              <input value={refundReason} onChange={(e)=>setRefundReason(e.target.value)} placeholder="Partial rainout, cancellation, etc."
                style={{ width: "100%", padding: 8, border: "1px solid #e2e8f0", borderRadius: 8 }} />
            </Row>
            <Row label="">
              <button onClick={refund} style={{ padding: "8px 12px", borderRadius: 10, border: "1px solid #ef4444", background: "#ef4444", color: "white", fontWeight: 800 }}>
                Record Refund
              </button>
            </Row>
          </section>
        )}

        {!!note && <div style={{ color: "#ef4444" }}>{note}</div>}
      </div>
    </>
  );
}