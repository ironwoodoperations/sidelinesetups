// pages/AdminAnalytics.jsx
import React from "react";
import NavBar from "../components/NavBar";
import { getCtx } from "../components/lib/ctx";

function sum(arr) { return arr.reduce((a,b) => a + (Number(b)||0), 0); }

export default function AdminAnalytics() {
  const [rows, setRows] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    (async () => {
      const { entities } = await getCtx();
      const bookings = await entities.Bookings.list();
      setRows(bookings || []);
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return (
      <>
        <NavBar/>
        <div className="container section"><h2>Loading…</h2></div>
      </>
    );
  }

  // KPIs
  const revenue = sum(rows.map(r => r?.totals?.amount ?? 0));
  const count = rows.length;
  const avg = count ? (revenue / count) : 0;

  // Mini bar chart: revenue per day
  const byDay = {};
  rows.forEach(r => {
    const d = (r?.date || "").slice(0,10); // YYYY-MM-DD
    const amt = Number(r?.totals?.amount ?? 0);
    if (!d) return;
    byDay[d] = (byDay[d] || 0) + amt;
  });
  const labels = Object.keys(byDay).sort();
  const values = labels.map(l => byDay[l]);

  const max = Math.max(1, ...values);
  const bars = values.map(v => Math.round((v / max) * 100));

  return (
    <>
      <NavBar/>
      <div className="container section" style={{ maxWidth: 960 }}>
        <h1>Admin • Analytics</h1>
        <div className="kpis" style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginTop: 12 }}>
          <div className="card" style={{ padding: 16 }}>
            <div style={{ fontSize: 12, opacity: .6 }}>Total Revenue</div>
            <div style={{ fontSize: 28, fontWeight: 700 }}>${revenue.toFixed(2)}</div>
          </div>
          <div className="card" style={{ padding: 16 }}>
            <div style={{ fontSize: 12, opacity: .6 }}>Bookings</div>
            <div style={{ fontSize: 28, fontWeight: 700 }}>{count}</div>
          </div>
          <div className="card" style={{ padding: 16 }}>
            <div style={{ fontSize: 12, opacity: .6 }}>Avg Order Value</div>
            <div style={{ fontSize: 28, fontWeight: 700 }}>${avg.toFixed(2)}</div>
          </div>
        </div>

        <div className="card" style={{ padding: 16, marginTop: 16 }}>
          <h3>Revenue by Day</h3>
          <div style={{ display: "flex", gap: 8, alignItems: "flex-end", height: 160, borderBottom: "1px solid #eee", paddingBottom: 8 }}>
            {bars.map((h, i) => (
              <div key={labels[i]} title={`${labels[i]} — $${values[i].toFixed(2)}`} style={{ width: 22, background: "#2d6cdf", height: `${h}%` }} />
            ))}
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 6 }}>
            {labels.map(l => <div key={l} style={{ width: 22, fontSize: 10, writingMode: "vertical-rl", transform: "rotate(180deg)" }}>{l.slice(5)}</div>)}
          </div>
        </div>
      </div>
    </>
  );
}