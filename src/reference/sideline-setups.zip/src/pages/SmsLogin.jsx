import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import useSession from "@/components/auth/SessionProvider";
import { Phone, Loader2, AlertCircle, Hash } from "lucide-react";

export default function SmsLogin() {
  const { setSession } = useSession();
  const [step, setStep] = useState("request"); // request | verify
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const sendOtp = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    
    try {
      await base44.functions.invoke('auth/requestSmsOtp', {
        kind: "customer_sms",
        phone
      });
      setStep("verify");
    } catch (err) {
      console.error("Send OTP error:", err);
      setError(err.response?.data?.error || "Could not send code. Check your number.");
    } finally {
      setLoading(false);
    }
  };

  const verify = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    
    try {
      const response = await base44.functions.invoke('auth/verifySmsOtp', {
        kind: "customer_sms",
        phone,
        code
      });

      if (response.data?.ok && response.data?.session) {
        setSession({ type: "customer", ...response.data.session });
        window.location.href = "/mybookings";
      } else {
        setError("Invalid code.");
      }
    } catch (err) {
      console.error("Verify error:", err);
      setError(err.response?.data?.error || "Invalid or expired code.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="card card-pad" style={{ maxWidth: "420px", width: "100%" }}>
        <div className="text-center mb-6">
          <Phone size={48} className="mx-auto mb-4" style={{ color: "#003f5c" }} />
          <h1 className="text-2xl font-bold mb-2" style={{ color: "#003f5c" }}>
            Access Your Bookings
          </h1>
          <p style={{ color: "var(--muted)" }}>
            {step === "request" 
              ? "Enter your phone number to receive a code"
              : "Enter the 6-digit code we sent you"}
          </p>
        </div>

        {step === "request" ? (
          <form onSubmit={sendOtp}>
            <div className="form-group">
              <label className="label">Mobile Number</label>
              <div style={{ position: "relative" }}>
                <input
                  type="tel"
                  className="input"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="(409) 555-1234"
                  required
                  style={{ paddingRight: "40px" }}
                />
                <Phone 
                  size={20} 
                  style={{ 
                    position: "absolute", 
                    right: "12px", 
                    top: "50%", 
                    transform: "translateY(-50%)",
                    color: "#64748b",
                    pointerEvents: "none"
                  }} 
                />
              </div>
            </div>

            {error && (
              <div style={{
                background: "#fee2e2",
                border: "1px solid #ef4444",
                borderRadius: "8px",
                padding: "12px",
                marginBottom: "16px",
                display: "flex",
                alignItems: "center",
                gap: "8px"
              }}>
                <AlertCircle size={20} style={{ color: "#ef4444", flexShrink: 0 }} />
                <span style={{ color: "#991b1b", fontSize: "14px" }}>{error}</span>
              </div>
            )}

            <button
              type="submit"
              className="btn"
              disabled={!phone || loading}
              style={{
                width: "100%",
                background: "linear-gradient(to right, #003f5c, #00507a)",
                color: "white",
                border: "none"
              }}
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <Loader2 className="animate-spin" size={20} />
                  Sending...
                </span>
              ) : (
                "Text me a code"
              )}
            </button>
          </form>
        ) : (
          <form onSubmit={verify}>
            <div className="form-group">
              <label className="label">Enter 6-Digit Code</label>
              <div style={{ position: "relative" }}>
                <input
                  type="text"
                  className="input"
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  placeholder="123456"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={6}
                  required
                  style={{ paddingRight: "40px", letterSpacing: "0.5em", fontSize: "18px", textAlign: "center" }}
                />
                <Hash 
                  size={20} 
                  style={{ 
                    position: "absolute", 
                    right: "12px", 
                    top: "50%", 
                    transform: "translateY(-50%)",
                    color: "#64748b",
                    pointerEvents: "none"
                  }} 
                />
              </div>
            </div>

            {error && (
              <div style={{
                background: "#fee2e2",
                border: "1px solid #ef4444",
                borderRadius: "8px",
                padding: "12px",
                marginBottom: "16px",
                display: "flex",
                alignItems: "center",
                gap: "8px"
              }}>
                <AlertCircle size={20} style={{ color: "#ef4444", flexShrink: 0 }} />
                <span style={{ color: "#991b1b", fontSize: "14px" }}>{error}</span>
              </div>
            )}

            <button
              type="submit"
              className="btn"
              disabled={code.length !== 6 || loading}
              style={{
                width: "100%",
                background: "linear-gradient(to right, #003f5c, #00507a)",
                color: "white",
                border: "none"
              }}
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <Loader2 className="animate-spin" size={20} />
                  Verifying...
                </span>
              ) : (
                "Verify & Continue"
              )}
            </button>

            <button
              type="button"
              onClick={() => {
                setStep("request");
                setCode("");
                setError("");
              }}
              className="btn-outline"
              style={{ 
                width: "100%", 
                marginTop: "12px",
                color: "#003f5c",
                borderColor: "#003f5c"
              }}
            >
              Resend Code
            </button>
          </form>
        )}

        <div style={{
          marginTop: "24px",
          paddingTop: "24px",
          borderTop: "1px solid #e2e8f0",
          textAlign: "center"
        }}>
          <p style={{ fontSize: "14px", color: "var(--muted)" }}>
            Prefer email? <a href="/signin" style={{ color: "#003f5c", textDecoration: "underline" }}>Use a magic link</a>
          </p>
        </div>
      </div>
    </div>
  );
}