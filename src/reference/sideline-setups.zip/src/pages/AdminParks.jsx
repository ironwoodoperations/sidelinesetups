// pages/AdminParks.jsx
import React from "react";
import NavBar from "../components/NavBar";
import { getCtx } from "../components/lib/ctx";

export default function AdminParks(){
  const [parks,setParks]=React.useState([]);const [fields,setFields]=React.useState([]);
  const [spots,setSpots]=React.useState([]);
  const [parkName,setParkName]=React.useState("");
  const [fieldForm,setFieldForm]=React.useState({name:"",parkId:"",imageUrl:""});
  const [selectedField,setSelectedField]=React.useState("");

  async function load(){
    const {entities}=await getCtx();
    setParks(await entities.Parks.list());
    setFields(await entities.Fields.list());
    setSpots(await entities.Spots.list());
  }
  React.useEffect(()=>{load();},[]);

  async function addPark(){
    const {entities}=await getCtx();
    await entities.Parks.create({name:parkName});
    setParkName("");load();
  }
  async function addField(){
    const {entities}=await getCtx();
    await entities.Fields.create(fieldForm);
    setFieldForm({name:"",parkId:"",imageUrl:""});load();
  }

  async function autoSpots(){
    if(!selectedField)return;
    const {entities}=await getCtx();
    for(let i=0;i<12;i++){
      await entities.Spots.create({
        fieldId:selectedField,label:"Spot "+(i+1),
        x:10+(i%4)*20,y:10+Math.floor(i/4)*20
      });
    }
    load();
  }

  return(
    <>
      <NavBar/>
      <div style={{padding:"24px 20px",maxWidth:1100,margin:"0 auto"}}>
        <h1>Parks & Fields</h1>
        <h3>Add Park</h3>
        <input value={parkName} onChange={e=>setParkName(e.target.value)} placeholder="Park name"/>
        <button onClick={addPark}>Add</button>

        <h3 style={{marginTop:24}}>Add Field</h3>
        <select value={fieldForm.parkId} onChange={e=>setFieldForm(f=>({...f,parkId:e.target.value}))}>
          <option value="">Select park…</option>
          {parks.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <input placeholder="Field name" value={fieldForm.name} onChange={e=>setFieldForm(f=>({...f,name:e.target.value}))}/>
        <input placeholder="Image URL" value={fieldForm.imageUrl} onChange={e=>setFieldForm(f=>({...f,imageUrl:e.target.value}))}/>
        <button onClick={addField}>Add Field</button>

        <h3 style={{marginTop:24}}>Auto-Generate Spots</h3>
        <select value={selectedField} onChange={e=>setSelectedField(e.target.value)}>
          <option value="">Select field…</option>
          {fields.map(f=><option key={f.id} value={f.id}>{f.name}</option>)}
        </select>
        <button onClick={autoSpots}>Generate 12 spots</button>

        <h3 style={{marginTop:24}}>Existing Parks</h3>
        <ul>{parks.map(p=><li key={p.id}>{p.name}</li>)}</ul>
      </div>
    </>
  );
}