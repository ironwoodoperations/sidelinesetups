// pages/StaffMobile.jsx
import React from "react";
import { getCtx } from "../components/lib/ctx";
import { punch, markSetupReady } from "../components/lib/staff";

function Row({ label, value }) {
  return (
    <div style={{display:"flex",justifyContent:"space-between",gap:12,alignItems:"center"}}>
      <div className="kicker">{label}</div>
      <div>{value}</div>
    </div>
  );
}

export default function StaffMobile() {
  const [staffId, setStaffId] = React.useState("");
  const [parkId, setParkId] = React.useState("");
  const [parks, setParks] = React.useState([]);
  const [bookings, setBookings] = React.useState([]);
  const [filter, setFilter] = React.useState("today");
  const [busy, setBusy] = React.useState(false);
  const [settings, setSettings] = React.useState(null);

  React.useEffect(() => {
    (async () => {
      const { entities, settings } = await getCtx();
      setSettings(settings || {});
      setParks(await entities.Parks.list() || []);
      await refresh();
    })();
  }, []);

  async function refresh() {
    const { entities } = await getCtx();
    const all = await entities.Bookings.list();
    const todayISO = new Date().toISOString().slice(0,10);
    let rows = all || [];
    if (filter === "today") rows = rows.filter(b => b.date === todayISO);
    if (parkId) rows = rows.filter(b => b.parkId === parkId);
    // sort by first game time
    rows = rows.sort((a,b)=> {
      const ta = (a.gameTimes?.[0] || "00:00");
      const tb = (b.gameTimes?.[0] || "00:00");
      return ta.localeCompare(tb);
    });
    setBookings(rows);
  }

  async function doPunch(action) {
    if (!staffId) { alert("Enter staff ID"); return; }
    setBusy(true);
    try { await punch(staffId, action, parkId || null); }
    finally { setBusy(false); }
  }

  async function ready(b) {
    setBusy(true);
    try { await markSetupReady(b.id, staffId || "staff", "Setup ready"); await refresh(); }
    finally { setBusy(false); }
  }

  return (
    <>
      <div className="nav">
        <div className="container nav-inner">
          <a className="brand" href="/">
            <span className="badge">SS</span>
            <span>{settings?.brandName || "Sideline Setups"}</span>
          </a>
          <div className="nav-links">
            <a className="btn-ghost" href="/events">Events</a>
            <a className="btn-ghost" href="/mybookings">My Bookings</a>
            <a className="btn-ghost" href="/admindashboard">Admin</a>
          </div>
        </div>
      </div>

      <main>
        <div className="container section" style={{maxWidth:640}}>
          <div className="card card-pad">
            <div className="kicker">Staff</div>
            <h1 style={{marginTop:6}}>On-site tools</h1>

            <div className="mt-12" style={{display:"grid", gap:12}}>
              <input className="input" placeholder="Your Staff ID"
                value={staffId} onChange={e=>setStaffId(e.target.value)} />
              <select className="select" value={parkId} onChange={e=>setParkId(e.target.value)}>
                <option value="">All parks</option>
                {(parks||[]).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>

              <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                <button className="btn-outline" onClick={()=>doPunch("in")} disabled={busy}>Punch in</button>
                <button className="btn-outline" onClick={()=>doPunch("out")} disabled={busy}>Punch out</button>
                <button className="btn" onClick={refresh} disabled={busy}>Refresh</button>
              </div>

              <div className="badge" style={{gap:4}}>
                <button className="btn-ghost" onClick={()=>{setFilter("today"); setTimeout(refresh,0);}}>Today</button>
                <button className="btn-ghost" onClick={()=>{setFilter("all"); setTimeout(refresh,0);}}>All</button>
              </div>
            </div>
          </div>

          <div className="mt-16" style={{display:"grid", gap:12}}>
            {(bookings||[]).map(b => (
              <div className="card card-pad" key={b.id}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:12}}>
                  <div>
                    <div className="kicker">{b.eventType} • {b.sport}</div>
                    <h3 style={{margin:"4px 0 0 0"}}>{b.fullName || "Booking"}</h3>
                  </div>
                  <span className={`badge ${b.status==="setup"?"badge-success":""}`}>{b.status}</span>
                </div>

                <div className="mt-12" style={{display:"grid",gap:8}}>
                  <Row label="Date" value={b.date || "-"} />
                  <Row label="Times" value={(b.gameTimes||[]).join(", ") || "-"} />
                  <Row label="Park/Field" value={`${b.parkId || "-"} / ${b.fieldId || "-"}`} />
                  <Row label="Spot" value={b.spotId || "-"} />
                  <Row label="Total" value={`$${(b.totals?.amount||0).toFixed(2)}`} />
                </div>

                <div className="mt-12" style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                  <a className="btn-outline" href={`/checkin?b=${encodeURIComponent(b.id)}`} target="_blank" rel="noreferrer">Check-in</a>
                  <button className="btn" onClick={()=>ready(b)} disabled={busy}>Mark ready → SMS</button>
                </div>
              </div>
            ))}

            {(!bookings || bookings.length===0) && (
              <div className="card card-pad" style={{textAlign:"center", color:"var(--muted)"}}>
                No bookings match your filters.
              </div>
            )}
          </div>
        </div>
      </main>

      <footer className="footer">
        <div className="container">
          © {new Date().getFullYear()} {settings?.brandName || "Sideline Setups"} — All rights reserved.
        </div>
      </footer>
    </>
  );
}