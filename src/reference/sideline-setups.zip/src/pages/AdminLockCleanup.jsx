// pages/AdminLockCleanup.jsx
import React from "react";
import NavBar from "../components/NavBar";
import { getCtx } from "../components/lib/ctx";

export default function AdminLockCleanup() {
  const [loading, setLoading] = React.useState(false);
  const [result, setResult] = React.useState(null);

  async function cleanupExpiredLocks() {
    setLoading(true);
    setResult(null);
    try {
      const { entities } = await getCtx();
      const allLocks = await entities.Locks.list();
      const now = new Date();
      
      let expiredCount = 0;
      
      for (const lock of allLocks || []) {
        if (lock.status !== "active") continue;
        
        const expiresAt = lock.expiresAt ? new Date(lock.expiresAt) : null;
        if (expiresAt && expiresAt < now) {
          await entities.Locks.update({ id: lock.id, status: "expired" });
          expiredCount++;
        }
      }
      
      setResult({ success: true, count: expiredCount });
    } catch (error) {
      setResult({ success: false, error: error.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <NavBar/>
      <div className="container section" style={{ maxWidth: 720 }}>
        <h1>Admin • Lock Cleanup</h1>
        <p>This utility marks expired "active" locks as "expired" to keep your holds list tidy.</p>

        <div className="card" style={{ padding: 16, marginTop: 16 }}>
          <h3>Expired Lock Cleanup</h3>
          <p style={{ color: "var(--muted)", marginBottom: 16 }}>
            Locks with status="active" that have passed their expiresAt timestamp will be marked as "expired".
            This helps keep your booking flow clean and prevents stale holds from blocking spots.
          </p>

          <button 
            className="btn" 
            onClick={cleanupExpiredLocks}
            disabled={loading}
          >
            {loading ? "Cleaning up..." : "Run Cleanup"}
          </button>

          {result && (
            <div style={{ 
              marginTop: 16, 
              padding: 12, 
              borderRadius: 8,
              background: result.success ? "#d1fae5" : "#fee2e2",
              color: result.success ? "#065f46" : "#991b1b"
            }}>
              {result.success ? (
                <>✅ Cleanup complete! Marked {result.count} lock(s) as expired.</>
              ) : (
                <>❌ Error: {result.error}</>
              )}
            </div>
          )}
        </div>

        <div className="card" style={{ padding: 16, marginTop: 16 }}>
          <h3>How Locks Work</h3>
          <ul style={{ lineHeight: 1.8 }}>
            <li><b>Active:</b> Spot is held during checkout (usually 10-15 min)</li>
            <li><b>Released:</b> User completed checkout or manually released</li>
            <li><b>Expired:</b> Time limit passed without completion</li>
          </ul>
          <p style={{ marginTop: 12, fontSize: 14, color: "var(--muted)" }}>
            Run this cleanup periodically (daily or weekly) to keep your system tidy.
          </p>
        </div>
      </div>
    </>
  );
}