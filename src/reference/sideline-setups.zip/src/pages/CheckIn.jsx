
import React, { useState, useEffect, useRef } from "react";
import { base44 } from "../api/base44Client";

export default function CheckIn() {
  const [msg, setMsg] = useState("Working…");
  const [bookingId, setBookingId] = useState("");
  const [booking, setBooking] = useState(null);
  const [showIdCapture, setShowIdCapture] = useState(false);
  const [showIdVerification, setShowIdVerification] = useState(false);
  const [idImageUrl, setIdImageUrl] = useState(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [capturedImage, setCapturedImage] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [checkinComplete, setCheckinComplete] = useState(false);
  const [isStaffMember, setIsStaffMember] = useState(false);
  const [cameraError, setCameraError] = useState("");
  
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);

  useEffect(() => {
    (async () => {
      const sp = new URLSearchParams(location.search);
      const id = sp.get("b") || sp.get("booking");
      
      if (!id) { 
        setMsg("Missing booking id. Please scan a valid QR code or use a check-in link from your email."); 
        return; 
      }
      
      setBookingId(id);

      // ONLY check for STAFF session (not base44 admin)
      try {
        const staffSession = JSON.parse(sessionStorage.getItem("ss.session") || "null");
        if (staffSession && staffSession.employee) {
          setIsStaffMember(true);
          console.log('Staff member detected:', staffSession.employee.fullName);
        }
      } catch (e) {
        setIsStaffMember(false);
      }

      try {
        const bookingData = await base44.entities.Bookings.get(id);
        
        if (!bookingData) {
          setMsg("Booking not found.");
          return;
        }
        
        setBooking(bookingData);

        const hasIdPhoto = !!bookingData.idPhotoUri;
        const idVerified = !!bookingData.idVerifiedBy;
        const skipApproved = !!bookingData.idSkipApprovedBy;

        if (bookingData.status === "pending" || bookingData.status === "paid") {
          if (!hasIdPhoto && !skipApproved) {
            setShowIdCapture(true);
            setMsg("ID Verification Required");
          } else if (hasIdPhoto && !idVerified) {
            setShowIdVerification(true);
            setMsg("ID Photo Ready for Verification");
            await loadIdPhoto(id);
          } else {
            setMsg(`✅ ID verification complete. Booking status: ${bookingData.status}`);
            setCheckinComplete(true);
          }
        } else if (bookingData.status === "photo_uploaded") {
          setShowIdVerification(true);
          setMsg("ID Photo Ready for Verification");
          await loadIdPhoto(id);
        } else if (bookingData.status === "setup") {
          if (hasIdPhoto && idVerified) {
            await completeCheckin(id);
          } else if (skipApproved) {
            await completeCheckin(id);
          } else {
            setMsg("Equipment setup complete. Please verify with staff.");
            setCheckinComplete(true);
          }
        } else if (bookingData.status === "checked_in") {
          setMsg(`✅ Already checked in! Enjoy your event.`);
          setCheckinComplete(true);
        } else if (bookingData.status === "leaving" || bookingData.status === "picked_up" || bookingData.status === "closed") {
          setMsg(`ℹ️ Booking status: ${bookingData.status.replace('_', ' ')}`);
          setCheckinComplete(true);
        } else {
          setMsg(`ℹ️ Current status: ${bookingData.status.replace('_', ' ')}`);
          setCheckinComplete(true);
        }
      } catch (e) {
        setMsg(`Error: ${e.message}`);
      }
    })();
  }, []);

  async function loadIdPhoto(bookingId) {
    try {
      const response = await base44.functions.invoke('viewIdPhoto', { bookingId });
      if (response.data && response.data.signed_url) {
        setIdImageUrl(response.data.signed_url);
      }
    } catch (error) {
      console.error('Failed to load ID photo:', error);
      setMsg("ID photo exists but couldn't be loaded. Please contact staff.");
    }
  }

  async function completeCheckin(bookingId) {
    try {
      await base44.entities.Bookings.update(bookingId, { 
        status: "checked_in"
      });
      setMsg(`✅ Check-in complete! You're all set. Enjoy your event!`);
      setCheckinComplete(true);
    } catch (error) {
      console.error('Failed to complete check-in:', error);
      setMsg("Failed to complete check-in. Please contact staff.");
    }
  }

  async function handleVerifyId(approved) {
    if (processing) return;
    setProcessing(true);

    try {
      if (approved) {
        await base44.functions.invoke('verifyIdPhoto', { 
          bookingId,
          approved: true
        });
        await completeCheckin(bookingId);
      } else {
        setShowIdVerification(false);
        setShowIdCapture(true);
        setMsg("Please retake photo of ID");
      }
    } catch (error) {
      console.error('Verification error:', error);
      alert('Failed to verify ID. Please try again or contact support.');
    } finally {
      setProcessing(false);
    }
  }

  async function handleSkipId() {
    if (processing) return;
    setProcessing(true);

    try {
      await base44.functions.invoke('verifyIdPhoto', { 
        bookingId,
        skipWithWarning: true
      });
      await completeCheckin(bookingId);
    } catch (error) {
      console.error('Skip ID error:', error);
      alert('Failed to process check-in. Please try again or contact support.');
    } finally {
      setProcessing(false);
    }
  }

  const startCamera = async () => {
    setCameraError("");
    
    try {
      console.log('[Camera] Step 1: Checking for camera support...');
      
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera is not supported on this device/browser');
      }

      console.log('[Camera] Step 2: Setting camera active to render video element...');
      
      // Set camera active FIRST to render the video element
      setCameraActive(true);
      
      // Wait a bit for React to render the video element
      await new Promise(resolve => setTimeout(resolve, 100));
      
      console.log('[Camera] Step 3: Requesting camera access...');
      
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      });
      
      console.log('[Camera] Step 4: Camera access granted, stream ID:', stream.id);
      
      if (!videoRef.current) {
        console.error('[Camera] Video element not found after render!');
        stream.getTracks().forEach(track => track.stop());
        setCameraActive(false); // Ensure cameraActive is false if element not found
        throw new Error('Video element not ready');
      }
      
      console.log('[Camera] Step 5: Setting up video element...');
      
      // Store stream reference immediately
      streamRef.current = stream;
      
      // Set video properties
      videoRef.current.setAttribute('playsinline', 'true');
      videoRef.current.setAttribute('autoplay', 'true');
      videoRef.current.setAttribute('muted', 'true');
      videoRef.current.muted = true;
      
      // Assign stream to video element
      videoRef.current.srcObject = stream;
      
      console.log('[Camera] Step 6: Waiting for video to load...');
      
      // Wait for video to load with timeout
      await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error('Video loading timed out'));
        }, 10000);
        
        videoRef.current.onloadedmetadata = () => {
          clearTimeout(timeout);
          console.log('[Camera] Video metadata loaded');
          resolve();
        };
        
        videoRef.current.onerror = (e) => {
          clearTimeout(timeout);
          console.error('[Camera] Video error:', e);
          reject(new Error('Video element error'));
        };
      });
      
      console.log('[Camera] Step 7: Attempting to play video...');
      
      await videoRef.current.play();
      
      console.log('[Camera] Step 8: Video playing successfully!');
      
    } catch (error) {
      console.error('[Camera] Error:', error);
      stopCamera(); // This will also set cameraActive to false
      
      let errorMessage = 'Unable to start camera. ';
      
      if (error.name === 'NotAllowedError') {
        errorMessage += 'Please allow camera access when prompted, then try again.';
      } else if (error.name === 'NotFoundError') {
        errorMessage += 'No camera found on this device.';
      } else if (error.name === 'NotReadableError') {
        errorMessage += 'Camera is in use by another app. Please close other camera apps and try again.';
      } else if (error.name === 'OverconstrainedError') {
        errorMessage += 'Camera specifications not met. Trying basic camera...';
        setTimeout(() => tryBasicCamera(), 1000);
        return;
      } else {
        errorMessage += error.message || 'Please check permissions and try again.';
      }
      
      setCameraError(errorMessage);
    }
  };

  const tryBasicCamera = async () => {
    try {
      console.log('[Camera] Trying basic camera constraints...');
      
      // Make sure camera is active to render the video element
      setCameraActive(true);
      await new Promise(resolve => setTimeout(resolve, 100)); // Wait for render
      
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true // Basic constraints only
      });
      
      if (!videoRef.current) {
        stream.getTracks().forEach(track => track.stop());
        setCameraActive(false); // Ensure cameraActive is false if element not found
        throw new Error('Video element not ready');
      }
      
      streamRef.current = stream;
      videoRef.current.srcObject = stream;
      
      await new Promise((resolve) => {
        videoRef.current.onloadedmetadata = resolve;
      });
      
      await videoRef.current.play();
      setCameraError("");
      
    } catch (error) {
      console.error('[Camera] Basic camera also failed:', error);
      setCameraActive(false); // Ensure cameraActive is false on error
      setCameraError('Camera could not be started. Please try again or contact staff for assistance.');
    }
  };

  const stopCamera = () => {
    console.log('[Camera] Stopping camera...');
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => {
        track.stop();
        console.log('[Camera] Stopped track:', track.label);
      });
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  const capturePhoto = () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    
    console.log('[Camera] Capturing photo...');
    
    if (!canvas || !video) {
      alert('Camera not ready. Please try again.');
      return;
    }
    
    if (video.readyState !== video.HAVE_ENOUGH_DATA) {
      console.warn('[Camera] Video not ready, readyState:', video.readyState);
      alert('Camera is still loading. Please wait a moment and try again.');
      return;
    }
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    console.log('[Camera] Canvas size:', canvas.width, 'x', canvas.height);
    
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0);
    
    canvas.toBlob((blob) => {
      if (blob) {
        console.log('[Camera] Photo captured successfully, size:', blob.size);
        setCapturedImage(URL.createObjectURL(blob));
        stopCamera();
      } else {
        console.error('[Camera] Failed to create blob');
        alert('Failed to capture photo. Please try again.');
      }
    }, 'image/jpeg', 0.9);
  };

  const retakePhoto = () => {
    if (capturedImage) {
      URL.revokeObjectURL(capturedImage);
    }
    setCapturedImage(null);
    setCameraError("");
    startCamera();
  };

  const uploadPhoto = async () => {
    if (!canvasRef.current) {
      alert('No image to upload. Please try again.');
      return;
    }
    
    setUploading(true);
    setCameraError(""); // Clear any previous errors
    console.log('[Upload] Starting upload for booking:', bookingId);
    
    try {
      // Convert canvas to blob
      const blob = await new Promise((resolve) => {
        canvasRef.current.toBlob((b) => resolve(b), 'image/jpeg', 0.9);
      });
      
      if (!blob) {
        throw new Error('Failed to create image blob');
      }
      
      console.log('[Upload] Created blob, size:', blob.size);
      
      // Create file from blob
      const file = new File([blob], 'id-photo.jpg', { type: 'image/jpeg' });
      console.log('[Upload] Created file:', file.name, file.size, file.type);
      
      // Step 1: Upload file to private storage
      console.log('[Upload] Uploading to private storage...');
      const uploadResult = await base44.integrations.Core.UploadPrivateFile({ file });
      console.log('[Upload] Upload result:', uploadResult);
      
      if (!uploadResult.file_uri) {
        throw new Error('No file_uri returned from upload');
      }
      
      // Step 2: Update booking with the file URI
      console.log('[Upload] Updating booking with file URI...');
      const response = await base44.functions.invoke('uploadIdPhoto', {
        bookingId: bookingId,
        fileUri: uploadResult.file_uri
      });
      
      console.log('[Upload] Function response:', response);
      
      if (response.data && response.data.success) {
        console.log('[Upload] Upload successful, updating booking status...');
        
        // Update booking status
        await base44.entities.Bookings.update(bookingId, {
          status: 'photo_uploaded'
        });
        
        console.log('[Upload] Booking status updated to photo_uploaded');
        
        setMsg("✅ ID Photo Uploaded! Status updated to 'Photo Uploaded'. Staff will verify when you arrive.");
        setShowIdCapture(false);
        setCheckinComplete(true);
      } else {
        const errorMsg = response.data?.error || response.data?.message || 'Unknown error';
        console.error('[Upload] Upload failed:', errorMsg);
        
        // Show detailed error on screen
        setCameraError(`Upload failed: ${errorMsg}\n\nFull response: ${JSON.stringify(response.data, null, 2)}`);
      }
    } catch (error) {
      console.error('[Upload] Error:', error);
      
      // Show detailed error on screen
      let errorDetails = `Error: ${error.message}\n\n`;
      if (error.response) {
        errorDetails += `Response status: ${error.response.status}\n`;
        errorDetails += `Response data: ${JSON.stringify(error.response.data, null, 2)}\n`;
      }
      errorDetails += `\nStack: ${error.stack}`;
      
      setCameraError(errorDetails);
    } finally {
      setUploading(false);
    }
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  return (
    <div style={{ padding: "32px 20px", maxWidth: 600, margin: "0 auto", textAlign: "center" }}>
      <h2>{msg}</h2>
      {bookingId && (
        <div style={{ marginTop: 16, padding: 12, background: "#f8fafc", borderRadius: 8, fontSize: 12, color: "#64748b" }}>
          Booking ID: {bookingId.substring(0, 8)}...
        </div>
      )}

      {/* ID VERIFICATION SCREEN */}
      {showIdVerification && !checkinComplete && (
        <div style={{ 
          marginTop: 24, 
          padding: 24, 
          background: "white", 
          borderRadius: 12, 
          boxShadow: "0 2px 8px rgba(0,0,0,0.1)" 
        }}>
          <h3 style={{ margin: "0 0 12px 0", fontSize: 20, fontWeight: 600, color: "#003f5c" }}>
            Verify ID Photo & Check In
          </h3>
          <p style={{ margin: "0 0 20px 0", color: "#64748b", fontSize: 14 }}>
            Staff: Verify the ID photo matches the customer, then check them in.
          </p>

          {idImageUrl ? (
            <div>
              <img 
                src={idImageUrl} 
                alt="Customer ID" 
                style={{ 
                  width: '100%', 
                  maxHeight: 400,
                  borderRadius: 8,
                  marginBottom: 20,
                  border: "2px solid #e2e8f0"
                }} 
              />
              <div style={{ display: "flex", gap: 12, marginBottom: 12 }}>
                <button 
                  onClick={() => handleVerifyId(false)}
                  disabled={processing}
                  style={{
                    flex: 1,
                    padding: "14px",
                    background: "#ef4444",
                    color: "white",
                    border: "none",
                    borderRadius: "10px",
                    fontSize: "16px",
                    fontWeight: "600",
                    cursor: processing ? "not-allowed" : "pointer",
                    opacity: processing ? 0.6 : 1
                  }}
                >
                  ❌ Reject & Retake
                </button>
                <button 
                  onClick={() => handleVerifyId(true)}
                  disabled={processing}
                  className="btn"
                  style={{ 
                    flex: 1, 
                    fontSize: "16px", 
                    padding: "14px",
                    opacity: processing ? 0.6 : 1,
                    cursor: processing ? "not-allowed" : "pointer"
                  }}
                >
                  ✓ Verify & Check In
                </button>
              </div>
            </div>
          ) : (
            <div style={{ padding: 20 }}>
              <div className="spinner" style={{ margin: "0 auto" }}></div>
              <p style={{ marginTop: 12, color: "#64748b" }}>Loading ID photo...</p>
            </div>
          )}
        </div>
      )}

      {/* ID CAPTURE SCREEN */}
      {showIdCapture && !checkinComplete && (
        <div style={{ 
          marginTop: 24, 
          padding: 24, 
          background: "white", 
          borderRadius: 12, 
          boxShadow: "0 2px 8px rgba(0,0,0,0.1)" 
        }}>
          <h3 style={{ margin: "0 0 12px 0", fontSize: 20, fontWeight: 600, color: "#003f5c" }}>
            ID Verification Required
          </h3>
          <p style={{ margin: "0 0 20px 0", color: "#64748b", fontSize: 14, lineHeight: 1.6 }}>
            For security, please take a clear photo of a government-issued ID. 
            Your image will be securely stored and automatically deleted 48 hours after your booking is completed.
          </p>

          {cameraError && (
            <div style={{
              padding: "12px",
              background: "#fee2e2",
              border: "1px solid #ef4444",
              borderRadius: "8px",
              marginBottom: "16px",
              color: "#991b1b",
              fontSize: "14px",
              whiteSpace: "pre-wrap", // Preserve whitespace and newlines for detailed errors
              textAlign: "left",
              wordBreak: "break-word"
            }}>
              {cameraError}
            </div>
          )}

          {!cameraActive && !capturedImage && (
            <>
              <button 
                onClick={startCamera}
                className="btn"
                style={{ width: "100%", fontSize: "16px", padding: "14px", marginBottom: "12px" }}
              >
                📸 Take Photo of ID
              </button>
              
              {isStaffMember && (
                <button 
                  onClick={handleSkipId}
                  disabled={processing}
                  style={{
                    width: "100%",
                    padding: "14px",
                    background: "#f59e0b",
                    color: "white",
                    border: "none",
                    borderRadius: "10px",
                    fontSize: "14px",
                    fontWeight: "600",
                    cursor: processing ? "not-allowed" : "pointer",
                    opacity: processing ? 0.6 : 1
                  }}
                >
                  ⚠️ Staff: Check In Without ID (Needs Review)
                </button>
              )}
            </>
          )}

          {cameraActive && !capturedImage && (
            <div>
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline
                muted
                style={{ 
                  width: '100%', 
                  maxHeight: 400, 
                  borderRadius: 8, 
                  background: "#000",
                  marginBottom: 16,
                  display: 'block'
                }} 
              />
              <button 
                onClick={capturePhoto}
                className="btn"
                style={{ width: "100%", fontSize: "16px", padding: "14px" }}
              >
                📷 Capture Photo
              </button>
            </div>
          )}

          {capturedImage && !uploading && (
            <div>
              <img 
                src={capturedImage} 
                alt="ID Preview" 
                style={{ 
                  width: '100%', 
                  maxHeight: 400,
                  borderRadius: 8,
                  marginBottom: 16,
                  border: "2px solid #e2e8f0"
                }} 
              />
              <div style={{ display: "flex", gap: 12 }}>
                <button 
                  onClick={retakePhoto}
                  className="btn-outline"
                  style={{ flex: 1, fontSize: "14px", padding: "12px" }}
                >
                  ↺ Retake
                </button>
                <button 
                  onClick={uploadPhoto}
                  className="btn"
                  style={{ flex: 1, fontSize: "14px", padding: "12px" }}
                >
                  ✓ Upload & Continue
                </button>
              </div>
            </div>
          )}

          {uploading && (
            <div style={{ padding: 20 }}>
              <div className="spinner" style={{ margin: "0 auto 12px auto" }}></div>
              <p style={{ color: "#64748b", fontSize: 14 }}>Uploading ID photo...</p>
            </div>
          )}

          <canvas ref={canvasRef} style={{ display: 'none' }} />

          <p style={{ 
            marginTop: 20, 
            fontSize: 12, 
            color: "#94a3b8",
            fontStyle: "italic"
          }}>
            Need assistance? Please ask a staff member.
          </p>
        </div>
      )}

      {checkinComplete && (
        <div style={{ marginTop: 20 }}>
          <a href="/" className="btn">Return Home</a>
        </div>
      )}
    </div>
  );
}
