
import React from "react";
import { getCtx } from "../components/lib/ctx";

export default function Home() {
  const [settings, setSettings] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    (async () => {
      try {
        const { settings } = await getCtx();
        setSettings(settings || {});
      } catch (e) {
        console.error("Failed to load SiteSettings:", e);
        setSettings({});
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return (
      <div className="container section">
        <div className="spinner"></div>
        <p style={{ textAlign: "center", marginTop: 16 }}>Loading...</p>
      </div>
    );
  }

  const fallbackImages = {
    softball: "https://images.unsplash.com/photo-1566577739114-d8c3ece82bc0?w=1200&h=400&fit=crop",
    baseball: "https://images.unsplash.com/photo-1566577739114-d8c3ece82bc0?w=1200&h=400&fit-crop",
    soccer: "https://images.unsplash.com/photo-1566577739114-d8c3ece82bc0?w=1200&h=400&fit-crop",
  };

  const sport = settings?.defaultSport || "softball";
  const heroImage = 
    sport === "soccer" ? (settings?.heroSoccerUrl || fallbackImages.soccer) :
    sport === "baseball" ? (settings?.heroBaseballUrl || fallbackImages.baseball) :
    (settings?.heroSoftballUrl || fallbackImages.softball);

  return (
    <div className="container section">
      <div className="hero" style={{ marginTop: 16 }}>
        <div className="hero-body">
          <h1>Your shade, chairs, and cooler—ready when you arrive.</h1>
          <p>Skip the packing, skip the sweat.<br/>Just show up, watch, and go home.</p>
          <div className="cta-row">
            <a className="btn" href="/events">Find an Event</a>
            <a className="btn-outline" href="/admin" style={{ background: "rgba(255,255,255,0.9)", color: "#0f172a" }}>
              Admin Dashboard
            </a>
          </div>
        </div>
        <style>{`.hero::before{background-image:url('${heroImage}');}`}</style>
      </div>

      <div className="section">
        <h2 style={{ marginBottom: 16 }}>How it works</h2>
        <div className="grid grid-3">
          <div className="card card-pad">
            <div className="kicker">TURN-KEY</div>
            <h3 style={{ marginTop: 8 }}>We set up & tear down</h3>
            <p className="mt-8" style={{ color: "var(--muted)" }}>
              Show up and cheer — we handle logistics so your family can focus on the game.
            </p>
          </div>
          <div className="card card-pad">
            <div className="kicker">QUALITY GEAR</div>
            <h3 style={{ marginTop: 8 }}>Pro tents, chairs, coolers</h3>
            <p className="mt-8" style={{ color: "var(--muted)" }}>
              Clean, sturdy equipment — with optional sidewalls, fans, lighting and more.
            </p>
          </div>
          <div className="card card-pad">
            <div className="kicker">FLEXIBLE</div>
            <h3 style={{ marginTop: 8 }}>Per game, day, or weekend</h3>
            <p className="mt-8" style={{ color: "var(--muted)" }}>
              Pick what you need — from a single game to the full weekend.
            </p>
          </div>
        </div>
      </div>

      <div className="card card-pad mt-16">
        <div style={{ textAlign: "center" }}>
          <h3>Ready to book?</h3>
          <p style={{ color: "var(--muted)", marginTop: 8 }}>
            Browse upcoming events and reserve your spot today.
          </p>
          <div style={{ marginTop: 16, display: "flex", gap: 12, justifyContent: "center" }}>
            <a className="btn" href="/events">Browse Events</a>
            <a className="btn-outline" href="/mybookings">My Bookings</a>
          </div>
        </div>
      </div>
    </div>
  );
}
