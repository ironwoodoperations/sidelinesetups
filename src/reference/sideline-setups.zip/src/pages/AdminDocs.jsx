import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import { FileText, Download, ChevronRight } from "lucide-react";

const DOC_CONTENT = `# Sideline Setups — Complete Application Documentation

> **Generated:** March 2026 | **Platform:** Base44 (React + Vite + Tailwind CSS)

---

## 1. Project Overview

**Sideline Setups** is a sports equipment rental and setup service for youth sports families in East Texas. Tournament and league weekends are long, hot, and exhausting — Sideline Setups solves this by delivering, setting up, and breaking down tents, chairs, coolers, fans, and other comfort equipment at the ballfield so families can simply show up and enjoy the game.

### Target Users

| User Type | Description |
|---|---|
| **Sports Parents / Customers** | Families attending youth baseball, softball, and soccer tournaments or leagues |
| **Staff / Field Crew** | Employees who physically set up and break down equipment at fields |
| **Managers** | Supervisors overseeing field operations and daily logistics |
| **Admins** | Back-office operators managing events, inventory, bookings, and reports |

### Core Value Proposition
- Book online in 2 minutes
- Arrive to find your setup ready
- Leave when you want — crew handles teardown

---

## 2. App Structure & Routes

### Public Pages

| Route | Description |
|---|---|
| \`/\` | Landing page — hero, benefits, how-it-works, testimonials, CTA |
| \`/events\` | Browse active tournaments & leagues, filter by sport/type |
| \`/packages\` | Browse all available packages |
| \`/book-new\` | **Primary** booking flow (full multi-step form with PayPal) |
| \`/book\` | Legacy booking flow (links from events page) |
| \`/thankyou\` | Post-payment confirmation with QR code and receipt |
| \`/faq\` | Frequently Asked Questions |
| \`/ourstory\` | Our Story page |
| \`/privacy-policy\` | Privacy Policy (legal) |
| \`/terms-and-conditions\` | Terms & Conditions (legal) |
| \`/mybookings\` | Customer's booking list (requires SMS auth) |
| \`/customer-login\` | Customer SMS OTP login |

### Staff Pages (requires staff session PIN login)

| Route | Description |
|---|---|
| \`/staff-login\` | Staff login via PIN or magic link |
| \`/StaffDashboard\` | Main staff dashboard |
| \`/EmployeeQuickActions\` | Quick action buttons for field crew |
| \`/CheckIn\` | Customer check-in flow |
| \`/Kiosk\` | On-site kiosk interface |
| \`/PullSheets\` | Equipment pull sheets |
| \`/ManagerDailyOverview\` | Manager daily summary |
| \`/Inventory\` | Inventory management |

### Admin Pages (requires Base44 admin auth)

| Route | Description |
|---|---|
| \`/Admin\` | Central admin dashboard hub with sidebar navigation |
| \`/AdminBookings\` | Manage all bookings |
| \`/AdminEvents\` | Manage events (tournaments/leagues) |
| \`/AdminPackages\` | Manage packages & pricing |
| \`/AdminParks\` | Manage parks, fields, and spots |
| \`/AdminStaff\` | Manage staff/employees |
| \`/AdminSettings\` | Site-wide settings |
| \`/AdminCRM\` | CRM & marketing contacts |
| \`/AdminDiscountCodes\` | Discount / coupon codes |
| \`/AdminAnalytics\` | Website traffic analytics |
| \`/AdminReports\` | Financial and operational reports |
| \`/AdminCOGS\` | Cost of goods tracking |
| \`/AdminSpend\` | Expense / spend tracking |
| \`/AdminXero\` | Xero accounting integration |
| \`/AdminRunSheets\` | Operational run sheets |
| \`/AdminPullSheets\` | Equipment pull sheets admin view |
| \`/AdminGoLive\` | Pre-launch go-live checklist |
| \`/AdminLockCleanup\` | Clean up stale booking locks |
| \`/AdminDocs\` | This documentation page |

---

## 3. Data Models / Entities

### Bookings (central entity)

| Field | Type | Description |
|---|---|---|
| \`fullName\` | string | Customer full name |
| \`contactEmail\` | string | Customer email |
| \`phone\` | string | Customer phone |
| \`teamName\` | string | Sports team name |
| \`eventId\` | string | FK → Events |
| \`eventType\` | enum | \`tournament\` or \`league\` |
| \`sport\` | enum | \`softball\`, \`baseball\`, \`soccer\` |
| \`date\` | date | Booking date |
| \`gameTimes\` | array | Game time slots |
| \`parkId / fieldId / spotId\` | string | Location references |
| \`packageId\` | string | FK → Packages |
| \`packageMode\` | enum | \`per_game\`, \`day\`, \`weekend\`, \`hourly\` |
| \`addOns\` | array | Selected add-ons with quantity & duration |
| \`lineItemsJson\` | array | Detailed line items with cents pricing |
| \`baseCents / addOnCents / totalCents\` | integer | Pricing in cents |
| \`discountCodeId\` | string | FK → DiscountCodes |
| \`discountAmountCents\` | integer | Amount discounted |
| \`loyaltyPointsEarned/Redeemed\` | integer | Loyalty point tracking |
| \`status\` | enum | See status flow below |
| \`agreedToTerms / smsConsentGiven\` | boolean | Legal consent |
| \`idPhotoUri\` | string | Private file URI for ID photo |
| \`equipmentSetupChecklist\` | object | Per-item setup tracking |
| \`xeroInvoiceId\` | string | Xero invoice reference |
| \`archived\` | boolean | Soft-delete flag |

**Booking Status Flow:**
\`\`\`
pending → paid → photo_uploaded → setup → checked_in → leaving → picked_up → closed
                                                                           ↘ cancelled
\`\`\`

---

### Events

| Field | Type | Description |
|---|---|---|
| \`name\` | string | Event name |
| \`eventType\` | enum | \`tournament\` or \`league\` |
| \`sport\` | enum | \`softball\`, \`baseball\`, \`soccer\` |
| \`startDate / endDate\` | date | Event dates |
| \`parkIds / fieldIds / packageIds\` | array | Associated location/package IDs |
| \`leagueEnabled\` | boolean | Enables league inventory/slot features |
| \`leagueDates\` | array | Available league dates |
| \`leagueStartTime / leagueEndTime\` | string | HH:mm slot range |
| \`leagueBufferMinutes\` | number | Slot duration including buffer |
| \`isActive / archived\` | boolean | Visibility flags |

---

### Packages

| Field | Type | Description |
|---|---|---|
| \`name\` | string | Package name |
| \`perGameUSD / perDayUSD / fullWeekendUSD\` | number | Pricing tiers |
| \`baseItems\` | array | Equipment included \`{equipmentId, qty}\` |
| \`addOnIds\` | array | Available upgrade add-ons |
| \`features\` | array | Feature bullet points |
| \`showForTournament / showForLeague\` | boolean | Event type visibility |
| \`displayOrder\` | number | Sort order (drag-and-drop reorderable) |

---

### Parks / Fields / Spots

- **Parks** — Physical ballpark locations (name, address, type)
- **Fields** — Fields within a park; have an \`imageUrl\` for visual spot picker
- **Spots** — Individual setup positions; stored with \`x/y\` % coordinates on the field image

---

### Equipment

| Field | Type | Description |
|---|---|---|
| \`type\` | enum | \`tent\`, \`chair\`, \`cooler\`, \`sidewall\`, \`fan\`, \`lighting\`, \`audio\`, \`misc\` |
| \`totalQty / availableQty / rentedQty\` | number | Inventory counts |
| \`maintenanceQty / damagedQty\` | number | Non-available units |
| \`cogsPerUseUSD\` | number | Cost per deployment |
| \`version\` | number | Optimistic concurrency control |

---

### Other Key Entities

| Entity | Purpose |
|---|---|
| \`AddOns\` | Optional upsell items with per-game/day/weekend pricing |
| \`Customers\` | Customer records linked to bookings |
| \`Locks\` | Temporary checkout holds to prevent double-booking |
| \`SiteSettings\` | Singleton global config (branding, PayPal mode, Twilio mode, etc.) |
| \`LeagueSpotInventory\` | Per-time-slot capacity for league bookings (CAS versioned) |
| \`DiscountCodes\` | Coupon codes (% or fixed, usage limits, expiry) |
| \`LoyaltyCredits / LoyaltyTransactions\` | Customer points balance and history |
| \`Employees\` | Staff records with PIN auth |
| \`Timeclock\` | Staff punch in/out records |
| \`CRMContacts / Campaigns / Sends\` | Marketing CRM system |
| \`PageVisit\` | Analytics — page view tracking |
| \`PaymentEvents\` | PayPal webhook audit log |
| \`COGS / Purchases / Vendors\` | Cost and spend tracking |
| \`FAQ\` | Public FAQ items |
| \`MagicTokens\` | Email magic link tokens for staff auth |
| \`SpotTemplate\` | Reusable field spot layout templates |

---

## 4. Features & Functionality

### 4.1 Booking Flow (/book-new)

Multi-step form — all on one scrollable page:

1. **Package Selection** — Cards with inventory indicators; AI "Best Deal" check
2. **Duration Selection** — Per-game, full-day (Sat/Sun), or full weekend
3. **Add-Ons** — Upsell items with per-game or weekend pricing + quantity selector
4. **Schedule** — Date + game times; league events show inventory-aware slot picker
5. **Location** — Park → Field → Visual spot picker (clickable map overlay)
6. **Customer Info** — Name, email, phone, team, coach, notes
7. **Consent** — T&C checkbox + SMS consent checkbox (TCPA compliant)
8. **Discount Code** — Optional coupon validation
9. **Order Summary** — Live-calculated pricing in cents
10. **PayPal Payment** — On success: booking created, inventory allocated, notifications sent

### 4.2 Visual Spot Picker

When a field has an \`imageUrl\`, spots render as circular buttons overlaid on the photo. Spots have \`x/y\` percentage coordinates. Customers click to select their preferred setup location.

### 4.3 Best Deal AI Check

The \`checkBestDeal\` backend function compares the customer's current selection (package + add-ons + duration) against all other packages and surfaces a cheaper or better-value alternative if one exists.

### 4.4 League Spot Reservation (CAS)

League time slots use Compare-And-Swap (optimistic concurrency) via \`leagueReserveSlotCAS\`. If a slot is taken between when the customer views it and when payment completes, they see an error and must choose again — preventing double-booking without pessimistic locks.

### 4.5 Admin Dashboard

Sidebar-navigated hub with lazy-loaded modules:
Bookings · Events · Packages · Parks & Fields · Equipment · Add-Ons · Employees · Shifts · League Inventory · Discount Codes · Analytics · Settings · Xero · Pull Sheets · CRM · Reports · COGS · Spend · Upload · Docs

### 4.6 Staff Operations

- PIN-based login → staff session JWT in \`sessionStorage\`
- Mark booking setup ready / customer checked in / equipment returned
- ID photo capture (uploaded to private storage) + verification
- Supervisor can approve check-in without ID (flagged in \`needsIdReview\`)
- Timeclock punch in/out per park
- Equipment setup/return checklists per booking

### 4.7 Customer Portal (/mybookings)

- SMS OTP authentication
- View upcoming and past bookings
- Re-send confirmation, view receipt

---

## 5. Business Logic & Workflows

### Pricing Engine
\`\`\`
baseCents      = package_price × duration_multiplier
addOnCents     = sum(addon_price × qty × duration) per add-on
subtotal       = baseCents + addOnCents
discount       = coupon (% or fixed) + loyalty points
total          = subtotal - discount + tax + service_fee
\`\`\`
All amounts computed in integer cents to avoid float errors.

### Inventory Flow
1. Booking created → \`inventoryAllocate\` decrements \`availableQty\`, increments \`rentedQty\`
2. Equipment returned → \`inventoryRelease\` reverses allocation
3. Package availability = \`floor(equipment.availableQty / item.qty)\` across all base items

### Post-Booking Notifications
On payment success: customer confirmation email (Resend) + SMS (Twilio) + internal admin copy + Xero invoice + loyalty points awarded

### Event Auto-Archiving
Events with \`endDate\` more than 1 day in the past auto-set to \`archived: true\` — hidden from public pages.

### CRM Sync
\`crmUpsertContactsFromBookings\` syncs booking data into \`CRMContacts\` with tags. Email and SMS campaigns can then be targeted to segments.

---

## 6. Integrations

| Service | Purpose | Key Secrets |
|---|---|---|
| **PayPal** | Payment processing | \`PAYPAL_CLIENT_ID\`, \`PAYPAL_CLIENT_SECRET\`, \`PAYPAL_MODE\` |
| **Twilio** | SMS notifications + OTP auth | \`TWILIO_ACCOUNT_SID\`, \`TWILIO_AUTH_TOKEN\`, \`TWILIO_MESSAGING_SERVICE_SID\` |
| **Resend** | Transactional email | \`RESEND_API_KEY\`, \`EMAIL_FROM_ADDRESS\` |
| **Xero** | Accounting — invoices | \`XERO_CLIENT_ID\`, \`XERO_CLIENT_SECRET\`, \`XERO_ACCOUNT_CODE\` |
| **Base44** | Platform (auth, DB, file storage, functions) | \`BASE44_SERVICE_API_KEY\` |

---

## 7. User Roles & Permissions

| Feature | Public | Customer | Staff | Admin |
|---|---|---|---|---|
| View/book events | ✅ | ✅ | ✅ | ✅ |
| My Bookings | ❌ | ✅ | ❌ | ✅ |
| Staff Dashboard / Check-in | ❌ | ❌ | ✅ | ✅ |
| Timeclock | ❌ | ❌ | ✅ | ✅ |
| Admin Dashboard | ❌ | ❌ | ❌ | ✅ |
| Manage Events / Packages / Inventory | ❌ | ❌ | ❌ | ✅ |
| Financial Reports / Xero | ❌ | ❌ | ❌ | ✅ |
| CRM / Campaigns | ❌ | ❌ | ❌ | ✅ |

**Auth Methods:**
- Admin → Base44 native auth (email/password)
- Staff → Numeric PIN via \`employeePinLogin\` or email magic link
- Customer → SMS OTP via Twilio
- Public → No auth required

**Session Storage:**
- Staff: \`sessionStorage["ss.session"]\` — signed JWT
- Customer: \`sessionStorage["customer.session"]\` — object with email, customerId
- Admin: Base44 platform JWT (managed automatically)

---

## 8. Backend Functions (Key)

| Category | Functions |
|---|---|
| **Auth** | \`auth/requestSmsOtp\`, \`auth/verifySmsOtp\`, \`employeePinLogin\`, \`requestMagicLink\`, \`verifyMagicLink\` |
| **Payments** | \`paypalCreateOrder\`, \`paypalCaptureOrder\`, \`getPayPalClientId\`, \`validateDiscountCode\` |
| **Inventory** | \`inventoryAllocate\`, \`inventoryRelease\`, \`inventoryReconcile\`, \`leagueReserveSlotCAS\` |
| **Notifications** | \`notifyBookingConfirmed\`, \`notifyBookingSetupReady\`, \`notifyBookingReturned\` |
| **Staff Ops** | \`markBookingSetup\`, \`markBookingReturned\`, \`uploadIdPhoto\`, \`verifyIdPhoto\`, \`approveIdSkip\` |
| **Timeclock** | \`timeClockIn\`, \`timeClockOut\`, \`timeClockStatus\`, \`listClockedInNow\` |
| **Reports** | \`generateBookingReceipt\`, \`generatePullSheetData\`, \`reports/revenueByDay\`, \`reports/packageMix\`, etc. |
| **CRM** | \`crmUpsertContactsFromBookings\`, \`crmSendEmailCampaign\`, \`crmSendSmsCampaign\` |
| **Xero** | \`xeroPush\`, \`xeroExportCsv\` |
| **Analytics** | \`recordPageVisit\` |
| **AI** | \`checkBestDeal\` — AI package comparison |

---

## 9. Environment Variables / Secrets

| Secret | Purpose |
|---|---|
| \`PAYPAL_CLIENT_ID / CLIENT_SECRET / MODE\` | PayPal |
| \`TWILIO_ACCOUNT_SID / AUTH_TOKEN / MESSAGING_SERVICE_SID\` | SMS |
| \`RESEND_API_KEY / EMAIL_FROM_ADDRESS / EMAIL_FROM_NAME\` | Email |
| \`XERO_CLIENT_ID / CLIENT_SECRET / ACCOUNT_CODE / TAX_TYPE\` | Xero |
| \`CUSTOMER_SESSION_SECRET\` | Sign customer session JWTs |
| \`STAFF_SESSION_SECRET\` | Sign staff session JWTs |
| \`BASE44_SERVICE_API_KEY\` | Base44 service-role API access |
| \`BRAND_NAME / SUPPORT_EMAIL / SITE_DOMAIN\` | Branding fallbacks |

---

## 10. Known Limitations & TODOs

### Limitations
- **Duplicate routes:** Pages exist in both PascalCase (\`/Events\`) and kebab-case (\`/events\`). Canonical public URLs use lowercase.
- **Legacy booking page:** \`/book\` (old) still exists alongside \`/book-new\` (current). Events page still links to old flow.
- **No real-time staff updates:** Staff dashboard requires manual refresh to see new bookings.
- **Loyalty redemption UI:** Points earning/redemption backend exists but customer checkout UI in \`/book-new\` is not fully surfaced.
- **Wallet passes:** Entity and helper code exist but Apple/Google Wallet pass generation is not production-ready.
- **Survey system:** \`SurveyResponse\` entity exists but survey sending/collection flow is incomplete.

### Suggested TODOs
- [ ] Redirect \`/book\` → \`/book-new\` to consolidate booking flows
- [ ] Add real-time booking updates on Staff Dashboard via entity subscriptions
- [ ] Surface loyalty points redemption widget in \`/book-new\` checkout
- [ ] Complete Apple/Google Wallet pass generation
- [ ] Add automated event archiving scheduled automation
- [ ] Build customer-facing receipt PDF download from \`/mybookings\`
- [ ] Refund/credit issuance admin workflow

---

*Full raw documentation: \`docs/APP_DOCUMENTATION.md\` in the project root.*
`;

export default function AdminDocs() {
  const [activeSection, setActiveSection] = useState(null);

  const sections = [
    { id: "1-project-overview", label: "1. Project Overview" },
    { id: "2-app-structure--routes", label: "2. App Structure & Routes" },
    { id: "3-data-models--entities", label: "3. Data Models / Entities" },
    { id: "4-features--functionality", label: "4. Features & Functionality" },
    { id: "5-business-logic--workflows", label: "5. Business Logic" },
    { id: "6-integrations", label: "6. Integrations" },
    { id: "7-user-roles--permissions", label: "7. Roles & Permissions" },
    { id: "8-backend-functions-key", label: "8. Backend Functions" },
    { id: "9-environment-variables--secrets", label: "9. Secrets / Env Vars" },
    { id: "10-known-limitations--todos", label: "10. Limitations & TODOs" },
  ];

  const scrollTo = (id) => {
    setActiveSection(id);
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const handleDownload = () => {
    const blob = new Blob([DOC_CONTENT], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "Sideline_Setups_Documentation.md";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#f8fafc", margin: "-24px" }}>
      {/* Sidebar */}
      <aside style={{
        width: "240px",
        flexShrink: 0,
        background: "white",
        borderRight: "1px solid #e2e8f0",
        padding: "24px 0",
        position: "sticky",
        top: 0,
        height: "100vh",
        overflowY: "auto"
      }}>
        <div style={{ padding: "0 16px 20px", borderBottom: "1px solid #e2e8f0" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "16px" }}>
            <div style={{
              background: "linear-gradient(135deg, #003f5c, #005a7d)",
              borderRadius: "8px",
              width: "36px",
              height: "36px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0
            }}>
              <FileText size={18} color="white" />
            </div>
            <div>
              <div style={{ fontWeight: "700", color: "#003f5c", fontSize: "13px" }}>App Documentation</div>
              <div style={{ fontSize: "11px", color: "#94a3b8" }}>Sideline Setups</div>
            </div>
          </div>
          <button
            onClick={handleDownload}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              width: "100%",
              padding: "8px 12px",
              background: "#f0f9ff",
              border: "1px solid #bae6fd",
              borderRadius: "8px",
              color: "#0369a1",
              fontSize: "12px",
              fontWeight: "600",
              cursor: "pointer"
            }}
          >
            <Download size={13} />
            Download .md file
          </button>
        </div>

        <nav style={{ padding: "12px 0" }}>
          {sections.map((s) => (
            <button
              key={s.id}
              onClick={() => scrollTo(s.id)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "6px",
                width: "100%",
                padding: "8px 16px",
                background: activeSection === s.id ? "#f0f9ff" : "transparent",
                border: "none",
                borderLeft: activeSection === s.id ? "3px solid #003f5c" : "3px solid transparent",
                color: activeSection === s.id ? "#003f5c" : "#475569",
                fontSize: "12px",
                fontWeight: activeSection === s.id ? "600" : "400",
                cursor: "pointer",
                textAlign: "left",
              }}
            >
              <ChevronRight size={11} style={{ flexShrink: 0 }} />
              {s.label}
            </button>
          ))}
        </nav>
      </aside>

      {/* Main content */}
      <main style={{ flex: 1, padding: "40px 48px", overflowY: "auto", maxWidth: "860px" }}>
        <div className="prose-doc">
          <style>{`
            .prose-doc h1 {
              font-size: 1.875rem;
              font-weight: 800;
              color: #003f5c;
              margin-bottom: 8px;
              padding-bottom: 16px;
              border-bottom: 3px solid #003f5c;
            }
            .prose-doc h2 {
              font-size: 1.375rem;
              font-weight: 700;
              color: #003f5c;
              margin-top: 48px;
              margin-bottom: 16px;
              padding-bottom: 8px;
              border-bottom: 1px solid #e2e8f0;
              scroll-margin-top: 20px;
            }
            .prose-doc h3 {
              font-size: 1.05rem;
              font-weight: 700;
              color: #0f172a;
              margin-top: 28px;
              margin-bottom: 10px;
            }
            .prose-doc h4 {
              font-size: 0.95rem;
              font-weight: 600;
              color: #334155;
              margin-top: 20px;
              margin-bottom: 8px;
            }
            .prose-doc p {
              color: #475569;
              line-height: 1.75;
              margin-bottom: 12px;
              font-size: 14px;
            }
            .prose-doc ul {
              padding-left: 24px;
              margin-bottom: 16px;
            }
            .prose-doc ul li {
              color: #475569;
              margin-bottom: 4px;
              line-height: 1.7;
              font-size: 14px;
            }
            .prose-doc ol {
              padding-left: 24px;
              margin-bottom: 16px;
            }
            .prose-doc ol li {
              color: #475569;
              margin-bottom: 6px;
              line-height: 1.7;
              font-size: 14px;
            }
            .prose-doc table {
              width: 100%;
              border-collapse: collapse;
              margin: 16px 0 24px;
              font-size: 13px;
            }
            .prose-doc th {
              background: #f1f5f9;
              color: #003f5c;
              font-weight: 700;
              padding: 10px 14px;
              text-align: left;
              border: 1px solid #e2e8f0;
            }
            .prose-doc td {
              padding: 9px 14px;
              border: 1px solid #e2e8f0;
              color: #334155;
              vertical-align: top;
              font-size: 13px;
            }
            .prose-doc tr:nth-child(even) td {
              background: #f8fafc;
            }
            .prose-doc code {
              background: #f1f5f9;
              border: 1px solid #e2e8f0;
              border-radius: 4px;
              padding: 2px 6px;
              font-size: 12px;
              color: #003f5c;
              font-family: 'Courier New', monospace;
            }
            .prose-doc pre {
              background: #0f172a;
              border-radius: 10px;
              padding: 20px;
              overflow-x: auto;
              margin: 16px 0;
            }
            .prose-doc pre code {
              background: transparent;
              border: none;
              color: #e2e8f0;
              font-size: 13px;
              padding: 0;
            }
            .prose-doc blockquote {
              border-left: 4px solid #003f5c;
              background: #f0f9ff;
              padding: 12px 20px;
              border-radius: 0 8px 8px 0;
              margin: 16px 0;
            }
            .prose-doc blockquote p {
              margin: 0;
              color: #0369a1;
            }
            .prose-doc hr {
              border: none;
              border-top: 1px solid #e2e8f0;
              margin: 32px 0;
            }
            .prose-doc a {
              color: #003f5c;
              text-decoration: underline;
            }
          `}</style>
          <ReactMarkdown
            components={{
              h2: ({ children, ...props }) => {
                const id = String(children)
                  .toLowerCase()
                  .replace(/[^a-z0-9\s-]/g, "")
                  .trim()
                  .replace(/\s+/g, "-");
                return <h2 id={id} {...props}>{children}</h2>;
              },
            }}
          >
            {DOC_CONTENT}
          </ReactMarkdown>
        </div>
      </main>
    </div>
  );
}