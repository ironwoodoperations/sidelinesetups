import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { bookingId } = await req.json();
    
    if (!bookingId) {
      return Response.json({ error: 'bookingId required' }, { status: 400 });
    }

    // Fetch booking
    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }

    // Fetch related data
    let event = null;
    let park = null;
    let field = null;
    let spot = null;
    let packageData = null;
    let packageEquipment = [];

    // Fetch event
    if (booking.eventId) {
      try {
        event = await base44.asServiceRole.entities.Events.get(booking.eventId);
      } catch (e) {
        console.warn('[getBookingDetails] Could not load event:', e);
      }
    }

    // Fetch park
    if (booking.parkId) {
      try {
        park = await base44.asServiceRole.entities.Parks.get(booking.parkId);
      } catch (e) {
        console.warn('[getBookingDetails] Could not load park:', e);
      }
    }

    // Fetch field
    if (booking.fieldId) {
      try {
        field = await base44.asServiceRole.entities.Fields.get(booking.fieldId);
      } catch (e) {
        console.warn('[getBookingDetails] Could not load field:', e);
      }
    }

    // Fetch spot
    if (booking.spotId) {
      try {
        spot = await base44.asServiceRole.entities.Spots.get(booking.spotId);
      } catch (e) {
        console.warn('[getBookingDetails] Could not load spot:', e);
      }
    }

    // Fetch package and its equipment
    if (booking.packageId) {
      try {
        packageData = await base44.asServiceRole.entities.Packages.get(booking.packageId);

        // Load equipment for package base items
        if (packageData?.baseItems && packageData.baseItems.length > 0) {
          const equipmentPromises = packageData.baseItems.map(async (item) => {
            try {
              const equipment = await base44.asServiceRole.entities.Equipment.get(item.equipmentId);
              return { ...equipment, qty: item.qty };
            } catch (e) {
              console.error('[getBookingDetails] Failed to load equipment:', e);
              return null;
            }
          });
          packageEquipment = (await Promise.all(equipmentPromises)).filter(Boolean);
        }
      } catch (e) {
        console.warn('[getBookingDetails] Could not load package:', e);
      }
    }

    return Response.json({
      success: true,
      booking,
      event,
      park,
      field,
      spot,
      packageData,
      packageEquipment
    });

  } catch (error) {
    console.error('[getBookingDetails] Error:', error);
    return Response.json({ 
      error: error.message || 'Failed to fetch booking details' 
    }, { status: 500 });
  }
});