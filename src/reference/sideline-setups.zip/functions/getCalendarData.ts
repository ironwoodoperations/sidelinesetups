import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { startDate, endDate, parkId, eventType, status } = await req.json();

    // Build filter for bookings
    const filter = {};
    
    if (parkId && parkId !== 'all') {
      filter.parkId = parkId;
    }
    
    if (eventType && eventType !== 'all') {
      filter.eventType = eventType;
    }
    
    if (status && status !== 'all') {
      filter.status = status;
    }

    // Fetch all bookings (will filter by date in memory)
    const allBookings = await base44.asServiceRole.entities.Bookings.list();
    
    // Filter by date range if provided
    let bookings = allBookings || [];
    if (startDate || endDate) {
      bookings = bookings.filter(booking => {
        if (!booking.date) return false;
        const bookingDate = booking.date;
        if (startDate && bookingDate < startDate) return false;
        if (endDate && bookingDate > endDate) return false;
        return true;
      });
    }
    
    // Apply other filters
    if (filter.parkId) {
      bookings = bookings.filter(b => b.parkId === filter.parkId);
    }
    if (filter.eventType) {
      bookings = bookings.filter(b => b.eventType === filter.eventType);
    }
    if (filter.status) {
      bookings = bookings.filter(b => b.status === filter.status);
    }

    // Fetch related data for enrichment
    const [parks, fields, events, packages] = await Promise.all([
      base44.asServiceRole.entities.Parks.list(),
      base44.asServiceRole.entities.Fields.list(),
      base44.asServiceRole.entities.Events.list(),
      base44.asServiceRole.entities.Packages.list()
    ]);

    // Create lookup maps
    const parkMap = {};
    parks.forEach(p => parkMap[p.id] = p);
    
    const fieldMap = {};
    fields.forEach(f => fieldMap[f.id] = f);
    
    const eventMap = {};
    events.forEach(e => eventMap[e.id] = e);
    
    const packageMap = {};
    packages.forEach(p => packageMap[p.id] = p);

    // Enrich bookings with related data
    const enrichedBookings = bookings.map(booking => ({
      ...booking,
      parkName: parkMap[booking.parkId]?.name || 'Unknown Park',
      fieldName: fieldMap[booking.fieldId]?.name || 'Unknown Field',
      eventName: eventMap[booking.eventId]?.name || 'Unknown Event',
      packageName: packageMap[booking.packageId]?.name || 'Unknown Package'
    }));

    // Calculate availability by date and park
    const availabilityByDate = {};
    
    // Group bookings by date
    const bookingsByDate = {};
    enrichedBookings.forEach(booking => {
      if (!booking.date) return;
      if (!bookingsByDate[booking.date]) {
        bookingsByDate[booking.date] = [];
      }
      bookingsByDate[booking.date].push(booking);
    });

    // For each date, calculate capacity
    for (const date in bookingsByDate) {
      const dateBookings = bookingsByDate[date];
      const parkCapacity = {};
      
      // Count bookings per park on this date
      dateBookings.forEach(booking => {
        const parkId = booking.parkId || 'unknown';
        if (!parkCapacity[parkId]) {
          parkCapacity[parkId] = {
            parkId,
            parkName: booking.parkName,
            booked: 0,
            total: 0
          };
        }
        
        // Only count confirmed/setup/completed bookings
        if (['confirmed', 'setup', 'completed'].includes(booking.status)) {
          parkCapacity[parkId].booked++;
        }
      });
      
      // Calculate total capacity per park (fields * avg spots per field)
      for (const parkId in parkCapacity) {
        const parkFields = fields.filter(f => f.parkId === parkId);
        const totalSpots = parkFields.length * 2; // Assume 2 spots per field on average
        parkCapacity[parkId].total = totalSpots;
        parkCapacity[parkId].available = Math.max(0, totalSpots - parkCapacity[parkId].booked);
      }
      
      availabilityByDate[date] = parkCapacity;
    }

    return Response.json({
      bookings: enrichedBookings,
      availability: availabilityByDate,
      parks,
      events
    });

  } catch (error) {
    console.error('Error in getCalendarData:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});