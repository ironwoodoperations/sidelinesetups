
import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import { Resend } from 'npm:resend@4.0.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { bookingId } = await req.json();

    if (!bookingId) {
      return Response.json({ error: 'bookingId required' }, { status: 400 });
    }

    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }

    let event = null;
    let park = null;
    let field = null;
    let packageData = null;

    if (booking.eventId) {
      event = await base44.asServiceRole.entities.Events.get(booking.eventId).catch(() => null);
    }
    if (booking.parkId) {
      park = await base44.asServiceRole.entities.Parks.get(booking.parkId).catch(() => null);
    }
    if (booking.fieldId) {
      field = await base44.asServiceRole.entities.Fields.get(booking.fieldId).catch(() => null);
    }
    if (booking.packageId) {
      packageData = await base44.asServiceRole.entities.Packages.get(booking.packageId).catch(() => null);
    }

    const settings = (await base44.asServiceRole.entities.SiteSettings.list())[0] || {};
    const brandName = settings.brandName || "Sideline Setups";
    const supportEmail = settings.supportEmail || "support@sideline-setups.com";
    const supportPhone = settings.supportPhone || "+1-903-541-9287";
    const logoUrl = settings.logoUrl || "";
    const siteDomain = settings.siteDomain || Deno.env.get('SITE_DOMAIN') || 'https://sideline-setups.com';

    const formatDate = (dateStr) => {
      if (!dateStr) return 'TBD';
      const d = new Date(dateStr);
      return d.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
    };

    const formatTime = (timeStr) => {
      if (!timeStr || timeStr === 'Waiting on Schedule') return timeStr;
      const [hh, mm] = timeStr.split(':').map(n => parseInt(n, 10));
      const ampm = hh >= 12 ? 'PM' : 'AM';
      const hour = ((hh + 11) % 12) + 1;
      return `${hour}:${mm.toString().padStart(2, '0')} ${ampm}`;
    };

    const formatMoney = (cents) => `$${Number(cents / 100 || 0).toFixed(2)}`;

    const dateStr = booking.date ? formatDate(booking.date) : 'TBD';
    const gameTimesStr = (booking.gameTimes && booking.gameTimes.length > 0)
      ? booking.gameTimes.map(t => formatTime(t)).join(', ')
      : 'TBD';
    const totalAmount = formatMoney(booking.totalCents || 0);

    const cleanPhone = supportPhone.replace(/^\+1/, '').replace(/[^\d]/g, '');
    const formattedPhone = cleanPhone.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');

    const qrUrl = `${siteDomain}/checkin?b=${booking.id}`;
    const viewBookingUrl = `${siteDomain}/customer-login?booking=${booking.id}`;

    // Build line items
    let lineItemsHTML = '';
    if (booking.lineItemsJson && Array.isArray(booking.lineItemsJson)) {
      booking.lineItemsJson.forEach(item => {
        lineItemsHTML += `
          <tr style="border-bottom: 1px solid #f1f5f9;">
            <td style="padding: 12px 0;">
              <div style="font-weight: 600; color: #0f172a;">${item.label || 'Item'}</div>
              ${item.meta?.description ? `<div style="font-size: 13px; color: #64748b;">${item.meta.description}</div>` : ''}
            </td>
            <td style="padding: 12px 0; text-align: right; font-weight: 600; color: #0f172a;">
              ${formatMoney(item.totalCents || 0)}
            </td>
          </tr>
        `;
      });
    }

    // Build package features
    let featuresHTML = '';
    if (packageData?.features && packageData.features.length > 0) {
      packageData.features.forEach(feature => {
        featuresHTML += `
          <div style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; color: #166534; font-size: 15px;">
            <span style="color: #10b981; font-size: 18px; margin-right: 8px;">✓</span>
            ${feature}
          </div>
        `;
      });
    }

    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f8fafc;">
  <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #f8fafc; padding: 20px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" border="0" style="max-width: 600px; background-color: #ffffff;">
          
          <!-- NAVY HEADER -->
          <tr>
            <td bgcolor="#003f5c" style="padding: 40px; text-align: center; background-color: #003f5c;">
              ${logoUrl ? `<img src="${logoUrl}" alt="${brandName}" width="150" style="display: block; margin: 0 auto 16px auto;">` : ''}
              <h1 style="margin: 0; color: #ffffff; font-size: 32px; font-weight: bold;">Booking Confirmed!</h1>
              <p style="margin: 12px 0 0 0; color: #ffffff; font-size: 18px;">We can't wait to set you up!</p>
            </td>
          </tr>

          <!-- Booking Details BOX -->
          <tr>
            <td style="padding: 32px;">
              <table width="100%" cellpadding="0" cellspacing="0" border="0">
                <tr>
                  <td bgcolor="#003f5c" style="padding: 16px 20px; background-color: #003f5c;">
                    <h2 style="margin: 0; color: #ffffff; font-size: 18px; font-weight: bold;">Booking Details</h2>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#ffffff" style="padding: 20px; background-color: #ffffff;">
                    <table width="100%" cellpadding="0" cellspacing="0" border="0">
                      <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 12px 0; color: #64748b; width: 40%;">Booking ID:</td>
                        <td style="padding: 12px 0; color: #0f172a; font-weight: 600;">${booking.id.substring(0, 8)}...</td>
                      </tr>
                      ${event?.name ? `
                      <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 12px 0; color: #64748b;">Event:</td>
                        <td style="padding: 12px 0; color: #0f172a; font-weight: 600;">${event.name}</td>
                      </tr>
                      ` : ''}
                      <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 12px 0; color: #64748b;">Date:</td>
                        <td style="padding: 12px 0; color: #0f172a; font-weight: 600;">${dateStr}</td>
                      </tr>
                      ${booking.teamName ? `
                      <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 12px 0; color: #64748b;">Team:</td>
                        <td style="padding: 12px 0; color: #0f172a; font-weight: 600;">${booking.teamName}</td>
                      </tr>
                      ` : ''}
                      <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 12px 0; color: #64748b;">Game Times:</td>
                        <td style="padding: 12px 0; color: #0f172a; font-weight: 600;">${gameTimesStr}</td>
                      </tr>
                      ${packageData?.name ? `
                      <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 12px 0; color: #64748b;">Package:</td>
                        <td style="padding: 12px 0; color: #0f172a; font-weight: 600;">${packageData.name}</td>
                      </tr>
                      ` : ''}
                      ${park?.name ? `
                      <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 12px 0; color: #64748b;">Park:</td>
                        <td style="padding: 12px 0; color: #0f172a; font-weight: 600;">${park.name}</td>
                      </tr>
                      ` : ''}
                      ${field?.name ? `
                      <tr>
                        <td style="padding: 12px 0; color: #64748b;">Field:</td>
                        <td style="padding: 12px 0; color: #0f172a; font-weight: 600;">${field.name}</td>
                      </tr>
                      ` : ''}
                    </table>

                    <!-- View Setup Location Link -->
                    <div style="margin-top: 20px; padding: 16px; background: #f0f9ff; border-left: 4px solid #003f5c; border-radius: 4px;">
                      <p style="margin: 0 0 8px 0; color: #0f172a; font-size: 14px; font-weight: 600;">📍 Want to see exactly where you'll be set up?</p>
                      <a href="${viewBookingUrl}" style="display: inline-block; margin-top: 8px; padding: 10px 20px; background: #003f5c; color: #ffffff; text-decoration: none; border-radius: 6px; font-size: 14px; font-weight: 600;">View My Setup Location</a>
                    </div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Package Features BOX -->
          ${featuresHTML ? `
          <tr>
            <td style="padding: 0 32px 32px 32px;">
              <table width="100%" cellpadding="0" cellspacing="0" border="0">
                <tr>
                  <td bgcolor="#003f5c" style="padding: 16px 20px; background-color: #003f5c;">
                    <h2 style="margin: 0; color: #ffffff; font-size: 18px; font-weight: bold;">Included with ${packageData.name}</h2>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#ffffff" style="padding: 20px; background-color: #ffffff;">
                    ${featuresHTML}
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          ` : ''}

          <!-- Order Summary BOX -->
          ${lineItemsHTML ? `
          <tr>
            <td style="padding: 0 32px 32px 32px;">
              <table width="100%" cellpadding="0" cellspacing="0" border="0">
                <tr>
                  <td bgcolor="#003f5c" style="padding: 16px 20px; background-color: #003f5c;">
                    <h2 style="margin: 0; color: #ffffff; font-size: 18px; font-weight: bold;">Order Summary</h2>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#ffffff" style="padding: 20px; background-color: #ffffff;">
                    <table width="100%" cellpadding="0" cellspacing="0" border="0">
                      ${lineItemsHTML}
                      <tr>
                        <td style="padding: 16px 0 0 0; font-size: 18px; font-weight: bold; color: #003f5c;">Total Paid:</td>
                        <td style="padding: 16px 0 0 0; text-align: right; font-size: 20px; font-weight: bold; color: #10b981;">${totalAmount}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          ` : ''}

          <!-- What's Next BOX - ALL NAVY -->
          <tr>
            <td style="padding: 0 32px 32px 32px;">
              <table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#003f5c" style="background-color: #003f5c;">
                <tr>
                  <td style="padding: 24px;">
                    <h2 style="margin: 0 0 20px 0; color: #ffffff; font-size: 20px; font-weight: bold; text-align: center;">What's Next?</h2>
                    
                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 16px;">
                      <tr>
                        <td width="40" valign="top">
                          <div style="background-color: #ffffff; border-radius: 50%; width: 36px; height: 36px; text-align: center; font-weight: bold; font-size: 16px; color: #003f5c; line-height: 36px;">1</div>
                        </td>
                        <td style="padding-left: 12px;">
                          <h3 style="margin: 0 0 6px 0; font-size: 16px; font-weight: bold; color: #ffffff;">We'll Keep You Updated</h3>
                          <p style="margin: 0; color: #ffffff; line-height: 1.5; font-size: 14px;">You'll receive a reminder email 24 hours before your event with all the important details and setup information.</p>
                        </td>
                      </tr>
                    </table>

                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 16px;">
                      <tr>
                        <td width="40" valign="top">
                          <div style="background-color: #ffffff; border-radius: 50%; width: 36px; height: 36px; text-align: center; font-weight: bold; font-size: 16px; color: #003f5c; line-height: 36px;">2</div>
                        </td>
                        <td style="padding-left: 12px;">
                          <h3 style="margin: 0 0 6px 0; font-size: 16px; font-weight: bold; color: #ffffff;">Your Setup Will Be Ready</h3>
                          <p style="margin: 0; color: #ffffff; line-height: 1.5; font-size: 14px;">Our team will arrive early to set everything up. We'll send you a text message when your setup is complete and ready for you to use. Just show up and enjoy!</p>
                        </td>
                      </tr>
                    </table>

                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 16px;">
                      <tr>
                        <td width="40" valign="top">
                          <div style="background-color: #ffffff; border-radius: 50%; width: 36px; height: 36px; text-align: center; font-weight: bold; font-size: 16px; color: #003f5c; line-height: 36px;">3</div>
                        </td>
                        <td style="padding-left: 12px;">
                          <h3 style="margin: 0 0 6px 0; font-size: 16px; font-weight: bold; color: #ffffff;">When You're Heading Out</h3>
                          <p style="margin: 0; color: #ffffff; line-height: 1.5; font-size: 14px;">When you're finished and leaving, just send us a quick text at <a href="tel:${supportPhone}" style="color: #10b981; text-decoration: underline; font-weight: 600;">${formattedPhone}</a> so we can come break down your setup. Easy as that!</p>
                        </td>
                      </tr>
                    </table>

                    <table width="100%" cellpadding="0" cellspacing="0" border="0">
                      <tr>
                        <td width="40" valign="top">
                          <div style="background-color: #ffffff; border-radius: 50%; width: 36px; height: 36px; text-align: center; font-weight: bold; font-size: 16px; color: #003f5c; line-height: 36px;">4</div>
                        </td>
                        <td style="padding-left: 12px;">
                          <h3 style="margin: 0 0 6px 0; font-size: 16px; font-weight: bold; color: #ffffff;">Questions or Changes?</h3>
                          <p style="margin: 0; color: #ffffff; line-height: 1.5; font-size: 14px;">Need to update your booking or have questions? Call or text us at <a href="tel:${supportPhone}" style="color: #10b981; text-decoration: underline; font-weight: 600;">${formattedPhone}</a> or email <a href="mailto:${supportEmail}" style="color: #10b981; text-decoration: underline; font-weight: 600;">${supportEmail}</a>. We're here to help!</p>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- QR Code BOX -->
          <tr>
            <td style="padding: 0 32px 32px 32px;">
              <table width="100%" cellpadding="0" cellspacing="0" border="0">
                <tr>
                  <td bgcolor="#003f5c" style="padding: 16px 20px; background-color: #003f5c;">
                    <h2 style="margin: 0; color: #ffffff; font-size: 18px; font-weight: bold;">Check-In QR Code</h2>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#ffffff" style="padding: 24px; text-align: center; background-color: #ffffff;">
                    <p style="margin: 0 0 16px 0; color: #64748b;">Show this QR code to staff when you arrive for quick check-in</p>
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(qrUrl)}" alt="QR Code" width="200" style="display: block; margin: 0 auto; border: 2px solid #e2e8f0; padding: 12px;">
                    <p style="margin: 16px 0 0 0; color: #64748b; font-size: 13px;">Or visit: <span style="color: #003f5c; font-weight: 600;">sideline-setups.com/checkin</span></p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td bgcolor="#f8fafc" style="padding: 24px 32px; text-align: center; background-color: #f8fafc; border-top: 1px solid #e2e8f0;">
              <p style="margin: 0 0 8px 0; color: #64748b; font-size: 14px;">Questions? Contact us at <a href="mailto:${supportEmail}" style="color: #003f5c; font-weight: 600; text-decoration: none;">${supportEmail}</a> or <a href="tel:${supportPhone}" style="color: #003f5c; font-weight: 600; text-decoration: none;">${formattedPhone}</a></p>
              <p style="margin: 0; color: #64748b; font-size: 14px;">Thank you for choosing ${brandName}!</p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `;

    const resend = new Resend(Deno.env.get('RESEND_API_KEY'));
    
    await resend.emails.send({
      from: `${brandName} <${Deno.env.get('EMAIL_FROM_ADDRESS') || 'noreply@sideline-setups.com'}>`,
      to: booking.contactEmail,
      subject: `Booking Confirmed - ${event?.name || 'Your Event'}`,
      html,
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error('[notifyBookingConfirmed] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
