
import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

// Inline sendSms helper
function env(name) {
  const v = Deno.env.get(name);
  if (!v) return "";
  return v;
}

function getAuthHeader() {
  const apiKey = env("TWILIO_API_KEY");
  const apiSecret = env("TWILIO_API_SECRET");
  const sid = env("TWILIO_ACCOUNT_SID");
  const authToken = env("TWILIO_AUTH_TOKEN");

  if (apiKey && apiSecret) return "Basic " + btoa(`${apiKey}:${apiSecret}`);
  if (sid && authToken)  return "Basic " + btoa(`${sid}:${authToken}`);
  throw new Error("Missing Twilio credentials");
}

async function sendSms(to, body) {
  if (!to || !body) throw new Error("sendSms: missing parameters");

  const accountSid = env("TWILIO_ACCOUNT_SID");
  if (!accountSid) throw new Error("Missing TWILIO_ACCOUNT_SID");

  const mg = env("TWILIO_MESSAGING_SERVICE_SID");
  const legacyFrom = env("TWILIO_FROM");

  const form = new URLSearchParams();
  form.set("To", to);
  form.set("Body", body);
  if (mg) form.set("MessagingServiceSid", mg);
  else if (legacyFrom) form.set("From", legacyFrom);
  else throw new Error("No sender configured");

  const res = await fetch(
    `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
    {
      method: "POST",
      headers: { Authorization: getAuthHeader(), "Content-Type": "application/x-www-form-urlencoded" },
      body: form.toString(),
    }
  );

  if (!res.ok) throw new Error(`Twilio error ${res.status}`);
  return res.json();
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { bookingId, checklist } = await req.json();
    
    if (!bookingId) {
      return Response.json({ error: 'Booking ID required' }, { status: 400 });
    }

    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }

    // Update booking with checklist and status to "picked_up"
    await base44.asServiceRole.entities.Bookings.update(bookingId, {
      status: 'picked_up',
      equipmentReturnedChecklist: checklist || {} // Keeping this field name as per original outline, assuming it's a generic "equipment check" checklist.
    });

    // Send SMS notification
    if (booking.phone) {
      try {
        const BRAND_NAME = Deno.env.get("BRAND_NAME") || "Sideline Setups";
        const message = `All equipment has been successfully picked up! Thank you for using ${BRAND_NAME}. We hope to see you again soon!`;
        
        await sendSms(booking.phone, message);
        console.log(`SMS sent to ${booking.phone} for booking ${bookingId}`);
      } catch (smsError) {
        console.error("Error sending SMS:", smsError);
      }
    }

    // Send email notification (keeping the function name 'notifyBookingReturned' as per the outline)
    try {
      await base44.asServiceRole.functions.invoke('notifyBookingReturned', { bookingId });
    } catch (emailError) {
      console.error("Error sending email:", emailError);
    }

    // Release inventory (keeping the function name 'inventoryRelease' as per the outline)
    try {
      await base44.asServiceRole.functions.invoke('inventoryRelease', { bookingId });
    } catch (inventoryError) {
      console.error("Error releasing inventory:", inventoryError);
    }

    return Response.json({ 
      success: true,
      message: 'Equipment picked up and customer notified'
    });

  } catch (error) {
    console.error('Error in handleBookingPickup:', error); // Updated error message to reflect new function
    return Response.json({ 
      error: error.message,
      success: false
    }, { status: 500 });
  }
});
