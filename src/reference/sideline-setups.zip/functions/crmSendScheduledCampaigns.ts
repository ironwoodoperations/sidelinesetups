import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Verify authentication
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const now = new Date();
    const campaigns = await base44.asServiceRole.entities.Campaigns.list();
    
    let processed = 0;
    for (const c of campaigns || []) {
      if (c.status === "scheduled" && c.scheduledFor && new Date(c.scheduledFor) <= now) {
        // Extract segment info
        const isTag = c.segment?.startsWith("tag:");
        const segmentTag = isTag ? c.segment.split(":")[1] : "";

        // Send the campaign
        await base44.functions.invoke('crmSendEmailCampaign', {
          campaignId: c.id,
          subject: c.subject,
          bodyText: c.bodyText,
          bodyHtml: c.bodyHtml,
          segment: isTag ? "tag" : "all",
          segmentTag
        });
        
        processed++;
      }
    }

    return Response.json({ ok: true, processed });
  } catch (error) {
    console.error("Scheduled campaigns error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});