import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

const PAYPAL_BASE = 'https://api-m.sandbox.paypal.com';

// Token cache to reuse PayPal OAuth tokens
let cached = { token: null, expiresAt: 0 };

async function getPayPalAccessToken(clientId, clientSecret) {
  const now = Date.now();
  
  // Return cached token if still valid (with 5s safety margin)
  if (cached.token && cached.expiresAt - 5000 > now) {
    return cached.token;
  }

  // Request new token
  const auth = btoa(`${clientId}:${clientSecret}`);
  const res = await fetch('https://api-m.sandbox.paypal.com/v1/oauth2/token', {
    method: 'POST',
    headers: { 
      'Authorization': `Basic ${auth}`, 
      'Content-Type': 'application/x-www-form-urlencoded' 
    },
    body: 'grant_type=client_credentials'
  });

  if (!res.ok) {
    const errorText = await res.text();
    console.error('PayPal token error:', errorText);
    throw new Error('Failed to get PayPal access token');
  }

  const json = await res.json();
  const ttlMs = (json.expires_in || 300) * 1000;
  
  cached.token = json.access_token;
  cached.expiresAt = Date.now() + ttlMs;
  
  return cached.token;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { orderID } = await req.json();
    
    if (!orderID) {
      return Response.json({ error: 'Order ID required' }, { status: 400 });
    }

    const clientId = Deno.env.get('PAYPAL_CLIENT_ID');
    const clientSecret = Deno.env.get('PAYPAL_CLIENT_SECRET');

    if (!clientId || !clientSecret) {
      return Response.json({ error: 'PayPal credentials not configured' }, { status: 500 });
    }

    // Get cached or fresh access token
    const access_token = await getPayPalAccessToken(clientId, clientSecret);

    // Capture order
    const captureRes = await fetch(`${PAYPAL_BASE}/v2/checkout/orders/${orderID}/capture`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${access_token}`,
        'Content-Type': 'application/json',
      },
    });

    if (!captureRes.ok) {
      const errorText = await captureRes.text();
      console.error('PayPal capture error:', errorText);
      return Response.json({ error: 'Failed to capture PayPal payment' }, { status: 500 });
    }

    const capture = await captureRes.json();
    return Response.json(capture);

  } catch (error) {
    console.error('Error in paypalCaptureOrder:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});