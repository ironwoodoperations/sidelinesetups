import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { kind = "customer", token } = await req.json();
    
    if (!token) {
      return Response.json({ error: 'Token required' }, { status: 400 });
    }

    console.log('[verifyMagicLink] Verifying token for kind:', kind);

    // Find the token
    const tokens = await base44.asServiceRole.entities.MagicTokens.filter({
      code: token,
      kind
    });

    const row = tokens?.[0];
    
    if (!row) {
      console.log('[verifyMagicLink] Token not found');
      return Response.json({ error: 'Invalid or expired token' }, { status: 401 });
    }

    if (row.consumedAt) {
      console.log('[verifyMagicLink] Token already used');
      return Response.json({ error: 'This link has already been used' }, { status: 401 });
    }

    if (new Date(row.expiresAt).getTime() < Date.now()) {
      console.log('[verifyMagicLink] Token expired');
      return Response.json({ error: 'This link has expired. Please request a new one.' }, { status: 401 });
    }

    // Mark token as consumed
    await base44.asServiceRole.entities.MagicTokens.update(row.id, {
      consumedAt: new Date().toISOString()
    });

    // Handle different auth types
    if (kind === "employee") {
      const employees = await base44.asServiceRole.entities.Employees.filter({
        email: row.email.toLowerCase(),
        status: "active"
      });
      
      const emp = employees?.[0];
      if (!emp) {
        console.log('[verifyMagicLink] No active employee found');
        return Response.json({ error: 'No active employee account found' }, { status: 401 });
      }

      console.log('[verifyMagicLink] Employee authenticated:', emp.id);
      return Response.json({
        ok: true,
        session: {
          kind: "employee",
          employeeId: emp.id,
          role: emp.role,
          fullName: emp.fullName,
          email: emp.email
        }
      });
    } else {
      // Customer auth - just need email to filter bookings
      console.log('[verifyMagicLink] Customer authenticated:', row.email);
      return Response.json({
        ok: true,
        session: {
          kind: "customer",
          customerEmail: row.email.toLowerCase()
        }
      });
    }
  } catch (error) {
    console.error('[verifyMagicLink] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});