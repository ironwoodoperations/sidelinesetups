import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      start, end, employeeId,
      rounding = "nearest_15",
      dailyOvertimeHours = 8,
      weeklyOvertimeHours = 40
    } = await req.json();
    
    if (!start || !end) {
      return Response.json({ error: 'start/end required' }, { status: 400 });
    }

    let rows = await base44.asServiceRole.entities.TimeEntries.list();
    rows = (rows || []).filter(r => {
      const t = toISODate(r.clockInAt || r.created_date);
      return (t >= start && t <= end) && (!employeeId || r.employeeId === employeeId);
    });

    const emps = await base44.asServiceRole.entities.Employees.list();
    const byEmp = Object.fromEntries((emps || []).map(e => [e.id, e]));

    const lines = [];
    for (const r of rows) {
      const emp = byEmp[r.employeeId];
      const employee = emp ? emp.fullName : r.employeeId || "";
      const inAt = r.clockInAt;
      const outAt = r.clockOutAt;
      const hrsRaw = computeHours(inAt, outAt);
      const hrsRounded = computeRounded(inAt, outAt, rounding);
      const day = toISODate(inAt || outAt || "");
      const week = isoWeekKey(day);

      const regDaily = Math.min(hrsRounded, dailyOvertimeHours);
      const otDaily = Math.max(0, hrsRounded - dailyOvertimeHours);

      lines.push({
        employeeId: r.employeeId || "",
        employee,
        clockInAt: inAt || "",
        clockOutAt: outAt || "",
        hoursRaw: hrsRaw,
        hoursRounded: hrsRounded,
        hoursRegularDaily: regDaily,
        hoursOTDaily: otDaily,
        parkId: r.parkId || "",
        notes: r.notes || "",
        source: r.source || "",
        week
      });
    }

    const sorted = [...lines].sort((a, b) => 
      (a.employeeId > b.employeeId ? 1 : -1) || 
      (a.week > b.week ? 1 : -1) || 
      ((a.clockInAt || "") > (b.clockInAt || "") ? 1 : -1)
    );

    const header = [
      "Employee", "EmployeeId", "Week",
      "ClockInAt", "ClockOutAt",
      "HoursRaw", "HoursRounded",
      "RegularDaily", "OTDaily",
      "ParkId", "Notes", "Source"
    ];
    const out = [header.join(",")];

    for (const ln of sorted) {
      out.push([
        csv(ln.employee), csv(ln.employeeId), csv(ln.week),
        csv(ln.clockInAt), csv(ln.clockOutAt),
        csv(n2(ln.hoursRaw)), csv(n2(ln.hoursRounded)),
        csv(n2(ln.hoursRegularDaily)), csv(n2(ln.hoursOTDaily)),
        csv(ln.parkId), csv(ln.notes), csv(ln.source)
      ].join(","));
    }

    const content = out.join("\n");
    const filename = `timeentries_${start}_to_${end}.csv`;
    
    return new Response(content, {
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': `attachment; filename="${filename}"`
      }
    });
  } catch (error) {
    console.error('Error in timeEntriesCsv:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function csv(s) { 
  return `"${String(s).replace(/"/g, '""')}"`; 
}

function n2(n) { 
  return (Math.round(n * 100) / 100).toFixed(2); 
}

function toISODate(ts) { 
  return ts ? new Date(ts).toISOString().slice(0, 10) : ""; 
}

function computeHours(a, b) {
  if (!a || !b) return 0;
  const ms = new Date(b).getTime() - new Date(a).getTime();
  if (!isFinite(ms) || ms <= 0) return 0;
  return ms / (1000 * 60 * 60);
}

function computeRounded(a, b, mode = "none") {
  if (!a || !b) return 0;
  let start = new Date(a).getTime();
  let end = new Date(b).getTime();
  const inc = 15 * 60 * 1000;

  const round = (t, how) => {
    if (how === "none") return t;
    const r = t % inc;
    if (how === "nearest_15") return r < inc / 2 ? (t - r) : (t + (inc - r));
    if (how === "up_15") return r === 0 ? t : (t + (inc - r));
    if (how === "down_15") return t - r;
    return t;
  };

  start = round(start, mode);
  end = round(end, mode);
  const ms = Math.max(0, end - start);
  return ms / (1000 * 60 * 60);
}

function isoWeekKey(isoDate) {
  if (!isoDate) return "";
  const d = new Date(isoDate + "T00:00:00Z");
  const tmp = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const dayNum = (tmp.getUTCDay() + 6) % 7;
  tmp.setUTCDate(tmp.getUTCDate() - dayNum + 3);
  const firstThursday = new Date(Date.UTC(tmp.getUTCFullYear(), 0, 4));
  const week = 1 + Math.round(((tmp.getTime() - firstThursday.getTime()) / (1000 * 60 * 60 * 24) - 3 + ((firstThursday.getUTCDay() + 6) % 7)) / 7);
  const year = tmp.getUTCFullYear();
  return `${year}-W${String(week).padStart(2, "0")}`;
}