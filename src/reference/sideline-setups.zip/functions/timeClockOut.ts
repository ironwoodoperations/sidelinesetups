import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { employeeId, notes = "" } = await req.json();
    
    if (!employeeId) {
      return Response.json({ error: 'employeeId required' }, { status: 400 });
    }

    const entries = await base44.asServiceRole.entities.TimeEntries.filter({ 
      employeeId,
      clockOutAt: null 
    });
    
    if (!entries || entries.length === 0) {
      return Response.json({ error: 'No open entry' }, { status: 400 });
    }

    const open = entries[0];
    await base44.asServiceRole.entities.TimeEntries.update(open.id, {
      clockOutAt: new Date().toISOString(),
      notes: open.notes || notes
    });

    return Response.json({ ok: true, id: open.id });
  } catch (error) {
    console.error('Error in timeClockOut:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});