import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    // Admin only
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Unauthorized' }, { status: 403 });
    }
    
    const { bookingId } = await req.json();
    
    if (!bookingId) {
      return Response.json({ error: 'bookingId required' }, { status: 400 });
    }
    
    // Get booking
    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }
    
    if (!booking.idPhotoUri) {
      return Response.json({ error: 'No ID photo found for this booking' }, { status: 404 });
    }
    
    // Generate signed URL (expires in 5 minutes)
    const result = await base44.integrations.Core.CreateFileSignedUrl({
      file_uri: booking.idPhotoUri,
      expires_in: 300
    });
    
    return Response.json({ 
      signed_url: result.signed_url,
      expires_in: 300 
    });
  } catch (error) {
    console.error('[viewIdPhoto] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});