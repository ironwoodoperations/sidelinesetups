import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Verify authentication
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
    if (!RESEND_API_KEY) {
      return Response.json({ error: "Missing RESEND_API_KEY" }, { status: 500 });
    }

    const response = await fetch("https://api.resend.com/emails", {
      headers: {
        "Authorization": `Bearer ${RESEND_API_KEY}`
      }
    });

    if (!response.ok) {
      const error = await response.text();
      return Response.json({ error: "Resend API error: " + error }, { status: response.status });
    }

    const data = await response.json();
    return Response.json(data);
  } catch (error) {
    console.error("Metrics fetch error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});