import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const body = await req.json();
    const { 
      currentPackageId, 
      currentAddOns,
      eventId,
      selectionDetails
    } = body;

    console.log('[checkBestDeal] Starting analysis...');

    if (!currentPackageId) {
      return Response.json({ 
        hasAlternative: false,
        message: "Missing package information"
      }, { status: 400 });
    }

    // Fetch event and all data
    let event = null;
    if (eventId) {
      try {
        event = await base44.asServiceRole.entities.Events.get(eventId);
      } catch (e) {
        console.warn('[checkBestDeal] Could not load event:', e);
      }
    }

    const [currentPackage, allPackages, allAddOns, allEquipment] = await Promise.all([
      base44.asServiceRole.entities.Packages.get(currentPackageId).catch(() => null),
      base44.asServiceRole.entities.Packages.filter({ isActive: true }).catch(() => []),
      base44.asServiceRole.entities.AddOns.filter({ isActive: true }).catch(() => []),
      base44.asServiceRole.entities.Equipment.list().catch(() => [])
    ]);

    if (!currentPackage) {
      return Response.json({ 
        hasAlternative: false,
        message: "Package not found"
      }, { status: 404 });
    }

    // Filter eligible packages based on event
    let eligiblePackages = allPackages || [];
    if (event) {
      const eventType = String(event.eventType || "").toLowerCase();
      eligiblePackages = eligiblePackages.filter(pkg => {
        if (eventType === "tournament") {
          return pkg.showForTournament !== false;
        } else if (eventType === "league") {
          return pkg.showForLeague === true;
        }
        return true;
      });
      
      if (event.packageIds && event.packageIds.length > 0) {
        eligiblePackages = eligiblePackages.filter(pkg => event.packageIds.includes(pkg.id));
      }
    }

    // Build lookups
    const equipmentMap = {};
    (allEquipment || []).forEach(eq => {
      equipmentMap[eq.id] = eq;
    });

    const addOnMap = {};
    (allAddOns || []).forEach(addon => {
      addOnMap[addon.id] = addon;
    });

    // Calculate current selection's equipment BY TYPE
    const currentEquipmentByType = {}; // type => [{id, qty, name}]
    const currentEquipmentItems = {}; // Keep this for exact matching too
    
    // Add base package items
    (currentPackage.baseItems || []).forEach(item => {
      const eqId = item.equipmentId;
      const qty = item.qty || 1;
      const equipment = equipmentMap[eqId];
      
      if (equipment) {
        const type = equipment.type || 'misc';
        if (!currentEquipmentByType[type]) {
          currentEquipmentByType[type] = [];
        }
        currentEquipmentByType[type].push({
          id: eqId,
          qty: qty,
          name: equipment.name
        });
        
        currentEquipmentItems[eqId] = (currentEquipmentItems[eqId] || 0) + qty;
      }
    });

    // Add equipment from selected add-ons
    (currentAddOns || []).forEach(selectedAddon => {
      const addon = addOnMap[selectedAddon.id];
      if (addon && addon.equipmentId) {
        const eqId = addon.equipmentId;
        const qty = selectedAddon.quantity || 1;
        const equipment = equipmentMap[eqId];
        
        if (equipment) {
          const type = equipment.type || 'misc';
          if (!currentEquipmentByType[type]) {
            currentEquipmentByType[type] = [];
          }
          currentEquipmentByType[type].push({
            id: eqId,
            qty: qty,
            name: equipment.name
          });
          
          currentEquipmentItems[eqId] = (currentEquipmentItems[eqId] || 0) + qty;
        }
      }
    });

    if (Object.keys(currentEquipmentItems).length === 0) {
      return Response.json({
        hasAlternative: false,
        message: "Great choice! Your package looks perfect."
      });
    }

    console.log('[checkBestDeal] Current equipment by type:', currentEquipmentByType);

    // Find packages that match by TYPE and quantity
    const packageMatches = [];
    
    for (const pkg of eligiblePackages) {
      if (pkg.id === currentPackageId) continue;
      if (!pkg.isActive) continue;
      
      // Build this package's equipment by type
      const pkgEquipmentByType = {};
      const pkgEquipmentItems = {};
      
      (pkg.baseItems || []).forEach(item => {
        const eqId = item.equipmentId;
        const qty = item.qty || 1;
        const equipment = equipmentMap[eqId];
        
        if (equipment) {
          const type = equipment.type || 'misc';
          if (!pkgEquipmentByType[type]) {
            pkgEquipmentByType[type] = [];
          }
          pkgEquipmentByType[type].push({
            id: eqId,
            qty: qty,
            name: equipment.name
          });
          
          pkgEquipmentItems[eqId] = (pkgEquipmentItems[eqId] || 0) + qty;
        }
      });
      
      // Calculate type-based coverage
      let typeMatchScore = 0;
      let totalTypesNeeded = 0;
      const missingTypes = {};
      const upgradedItems = []; // Items in package that are "upgrades"
      const missingEquipment = {};
      
      // Check each type the customer selected
      for (const [type, customerItems] of Object.entries(currentEquipmentByType)) {
        const customerTotalQty = customerItems.reduce((sum, item) => sum + item.qty, 0);
        totalTypesNeeded++;
        
        const pkgItems = pkgEquipmentByType[type] || [];
        const pkgTotalQty = pkgItems.reduce((sum, item) => sum + item.qty, 0);
        
        if (pkgTotalQty >= customerTotalQty) {
          // Package has enough of this type
          typeMatchScore++;
          
          // Check if it's a different (potentially upgraded) item
          const customerItemIds = customerItems.map(i => i.id);
          const pkgItemIds = pkgItems.map(i => i.id);
          
          const hasDifferentItems = pkgItemIds.some(id => !customerItemIds.includes(id));
          if (hasDifferentItems && pkgTotalQty >= customerTotalQty) {
            // This is a different item of the same type - likely an upgrade
            pkgItems.forEach(pkgItem => {
              if (!customerItemIds.includes(pkgItem.id)) {
                upgradedItems.push({
                  type,
                  name: pkgItem.name,
                  qty: pkgItem.qty,
                  replacesName: customerItems[0]?.name || type
                });
              }
            });
          }
        } else if (pkgTotalQty > 0) {
          // Package has some, but not enough
          typeMatchScore += (pkgTotalQty / customerTotalQty);
          missingTypes[type] = customerTotalQty - pkgTotalQty;
        } else {
          // Package doesn't have this type at all
          missingTypes[type] = customerTotalQty;
        }
      }
      
      // For missing types, find if we can add them as add-ons
      for (const [type, qtyNeeded] of Object.entries(missingTypes)) {
        const customerItemsOfType = currentEquipmentByType[type];
        for (const customerItem of customerItemsOfType) {
          const matchingAddon = allAddOns.find(a => a.equipmentId === customerItem.id);
          if (matchingAddon) {
            missingEquipment[customerItem.id] = qtyNeeded;
          }
        }
      }
      
      const coveragePercent = totalTypesNeeded > 0 ? (typeMatchScore / totalTypesNeeded) * 100 : 0;
      
      // Lower threshold to 40% to catch more alternatives
      if (coveragePercent >= 40) {
        packageMatches.push({
          package: pkg,
          coveragePercent,
          missingEquipment,
          upgradedItems,
          pkgEquipmentItems
        });
      }
    }

    console.log('[checkBestDeal] Found', packageMatches.length, 'packages with 40%+ coverage');

    if (packageMatches.length === 0) {
      return Response.json({
        hasAlternative: false,
        message: "Great choice! Your custom selection is unique and perfectly tailored to your needs."
      });
    }

    // Calculate pricing
    const currentPrice = currentPackage.perGameUSD || currentPackage.perDayUSD || currentPackage.fullWeekendUSD || 0;
    let currentAddOnTotal = 0;
    (currentAddOns || []).forEach(selectedAddon => {
      const addon = addOnMap[selectedAddon.id];
      if (addon) {
        const addonPrice = addon.perGameUSD || addon.perDayUSD || addon.fullWeekendUSD || 0;
        currentAddOnTotal += addonPrice * (selectedAddon.quantity || 1);
      }
    });
    const currentTotal = currentPrice + currentAddOnTotal;

    // Evaluate alternatives
    const alternatives = [];
    
    for (const match of packageMatches) {
      const pkgPrice = match.package.perGameUSD || match.package.perDayUSD || match.package.fullWeekendUSD || 0;
      
      let missingItemsCost = 0;
      const missingItemsList = [];
      
      for (const [eqId, qty] of Object.entries(match.missingEquipment)) {
        const equipment = equipmentMap[eqId];
        if (!equipment) continue;
        
        const matchingAddon = allAddOns.find(a => a.equipmentId === eqId);
        if (matchingAddon) {
          const addonPrice = matchingAddon.perGameUSD || matchingAddon.perDayUSD || matchingAddon.fullWeekendUSD || 0;
          missingItemsCost += addonPrice * qty;
          missingItemsList.push({
            equipment: equipment.name,
            quantity: qty,
            addon: matchingAddon,
            cost: addonPrice * qty
          });
        } else {
          missingItemsCost = Infinity;
          break;
        }
      }
      
      if (missingItemsCost === Infinity) continue;
      
      const totalCost = pkgPrice + missingItemsCost;
      const savings = currentTotal - totalCost;
      
      // Show if it saves money OR if it's within $5 but has upgrades
      if (savings > 0 || (savings >= -5 && match.upgradedItems.length > 0)) {
        alternatives.push({
          package: match.package,
          packagePrice: pkgPrice,
          missingItemsCost,
          totalCost,
          savings,
          coveragePercent: match.coveragePercent,
          missingItemsList,
          upgradedItems: match.upgradedItems,
          pkgEquipmentItems: match.pkgEquipmentItems
        });
      }
    }

    alternatives.sort((a, b) => {
      // Prioritize packages with upgrades even if savings are minimal
      if (a.upgradedItems.length > 0 && b.upgradedItems.length === 0) return -1;
      if (a.upgradedItems.length === 0 && b.upgradedItems.length > 0) return 1;
      return b.savings - a.savings;
    });

    if (alternatives.length === 0) {
      return Response.json({
        hasAlternative: false,
        message: "You're already getting a great deal!"
      });
    }

    const bestAlternative = alternatives[0];

    // Build lists for display
    const equipmentList = Object.keys(currentEquipmentItems).map(eqId => {
      const eq = equipmentMap[eqId];
      const qty = currentEquipmentItems[eqId];
      return eq ? `${qty}x ${eq.name}` : null;
    }).filter(Boolean);

    const packageIncludesList = [];
    (bestAlternative.package.baseItems || []).forEach(item => {
      const eq = equipmentMap[item.equipmentId];
      if (eq) {
        packageIncludesList.push(`${item.qty}x ${eq.name}`);
      }
    });

    const bonusItemsList = [];
    bestAlternative.upgradedItems.forEach(upgrade => {
      bonusItemsList.push(`${upgrade.qty}x ${upgrade.name} (upgraded from ${upgrade.replacesName})`);
    });

    // Generate message highlighting upgrades
    let friendlyMessage = `Great news! The "${bestAlternative.package.name}" package `;
    
    if (bestAlternative.upgradedItems.length > 0) {
      const upgradeNames = bestAlternative.upgradedItems.map(u => u.name).join(' and ');
      friendlyMessage += `includes upgraded equipment (${upgradeNames}) `;
    } else {
      friendlyMessage += `covers ${Math.round(bestAlternative.coveragePercent)}% of what you selected `;
    }
    
    if (bestAlternative.missingItemsList.length > 0) {
      friendlyMessage += `and you can add the remaining items for $${bestAlternative.missingItemsCost.toFixed(2)}. `;
    }
    
    if (bestAlternative.savings > 0) {
      friendlyMessage += `This saves you $${bestAlternative.savings.toFixed(2)}!`;
    } else if (Math.abs(bestAlternative.savings) <= 1) {
      friendlyMessage += `Same great price, but with better equipment!`;
    } else {
      const extraCost = Math.abs(bestAlternative.savings);
      friendlyMessage += `For just $${extraCost.toFixed(2)} more, you get premium upgrades worth much more!`;
    }

    return Response.json({
      hasAlternative: true,
      recommendedPackage: {
        id: bestAlternative.package.id,
        name: bestAlternative.package.name,
        description: bestAlternative.package.description || "",
        price: bestAlternative.packagePrice,
        thumbnailUrl: bestAlternative.package.thumbnailUrl || ""
      },
      currentSelection: {
        packageName: currentPackage.name,
        totalPrice: currentTotal
      },
      packageIncludes: packageIncludesList,
      missingItems: bestAlternative.missingItemsList,
      bonusItems: bonusItemsList,
      upgradedItems: bestAlternative.upgradedItems,
      newTotal: bestAlternative.totalCost,
      savings: bestAlternative.savings,
      coveragePercent: Math.round(bestAlternative.coveragePercent),
      message: friendlyMessage,
      equipmentList: equipmentList,
      analysis: bestAlternative.upgradedItems.length > 0 
        ? `The "${bestAlternative.package.name}" includes premium upgrades at essentially the same price!`
        : `The "${bestAlternative.package.name}" covers your needs efficiently.`
    });

  } catch (error) {
    console.error('[checkBestDeal] Error:', error);
    return Response.json({ 
      hasAlternative: false,
      message: "We couldn't check for better deals right now, but your selection looks great!"
    }, { status: 200 });
  }
});