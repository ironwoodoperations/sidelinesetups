import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { employeeId } = await req.json();
    
    if (!employeeId) {
      return Response.json({ error: 'employeeId required' }, { status: 400 });
    }

    const entries = await base44.asServiceRole.entities.TimeEntries.filter({ 
      employeeId,
      clockOutAt: null 
    });
    
    const openEntry = entries && entries.length > 0 ? entries[0] : null;

    return Response.json({ openEntry });
  } catch (error) {
    console.error('Error in timeClockStatus:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});