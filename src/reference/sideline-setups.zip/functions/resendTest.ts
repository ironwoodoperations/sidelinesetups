// functions/resendTest.js — Diagnostic endpoint to verify Resend configuration
import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

function env(name) {
  const v = Deno.env.get(name);
  if (!v) return "";
  return v;
}

Deno.serve(async (req) => {
  try {
    // Check if API key exists
    const key = env("RESEND_API_KEY");
    if (!key) {
      return Response.json({
        ok: false,
        where: "env",
        message: "RESEND_API_KEY missing in environment variables",
        fix: "Go to Base44 Dashboard → Settings → Environment Variables → Add RESEND_API_KEY → Save → Redeploy"
      }, { status: 500 });
    }

    // Get test email from query params or use default
    const url = new URL(req.url);
    const to = url.searchParams.get('to') || 'csdevore@outlook.com';

    // Verify from domain is set correctly
    const defaultFrom = env("EMAIL_FROM_ADDRESS") || "support@orders.sideline-setups.com";

    // Try to send test email
    const payload = {
      from: `Sideline Setups <${defaultFrom}>`,
      to: [to],
      subject: "Resend Test ✅",
      html: `
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #003f5c;">✅ Resend Configuration Test</h2>
          <p>If you received this email, your Resend integration is working correctly!</p>
          <div style="background: #f8fafc; padding: 16px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 8px 0;"><strong>✅ API Key:</strong> Loaded successfully</p>
            <p style="margin: 8px 0;"><strong>✅ From Domain:</strong> ${defaultFrom}</p>
            <p style="margin: 8px 0;"><strong>✅ Email Delivery:</strong> Working</p>
          </div>
          <p style="font-size: 12px; color: #64748b; margin-top: 32px;">
            This is an automated test email from your Sideline Setups backend.
          </p>
        </div>
      `,
      reply_to: defaultFrom
    };

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${key}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      const errorText = await res.text();
      let errorData;
      try {
        errorData = JSON.parse(errorText);
      } catch {
        errorData = { message: errorText };
      }

      // Provide helpful error messages
      let fix = "Check the error details above";
      if (res.status === 401 || res.status === 403) {
        fix = "RESEND_API_KEY is invalid or expired. Get a new key from Resend dashboard and update it in Base44 Settings → Environment Variables";
      } else if (errorData.message?.includes("not allowed to send from")) {
        fix = `Your verified domain in Resend doesn't match ${defaultFrom}. Either verify this domain in Resend, or update EMAIL_FROM_ADDRESS to match your verified domain.`;
      }

      return Response.json({
        ok: false,
        where: "send",
        status: res.status,
        message: errorData.message || errorText,
        code: errorData.code || null,
        fix
      }, { status: res.status });
    }

    const result = await res.json();

    return Response.json({
      ok: true,
      message: `Test email sent successfully to ${to}`,
      emailId: result.id,
      from: defaultFrom,
      to: to,
      nextSteps: "Check your inbox (and spam folder). If you received the email, your Resend integration is fully configured!"
    });

  } catch (err) {
    return Response.json({
      ok: false,
      where: "exception",
      message: err?.message || "Unknown error",
      stack: err?.stack || null,
      fix: "Check the error message above for details"
    }, { status: 500 });
  }
});