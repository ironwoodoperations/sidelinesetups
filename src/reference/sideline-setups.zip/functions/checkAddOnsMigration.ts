// Data check script to verify add-ons migration
// Reports any packages still holding embedded objects

import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const packages = await base44.asServiceRole.entities.Packages.list();
    
    const results = {
      totalPackages: packages.length,
      fullyMigrated: 0,
      needsMigration: [],
      details: []
    };

    for (const pkg of packages) {
      const hasEmbeddedObjects = Array.isArray(pkg.addOns) && 
                                 pkg.addOns.some(a => typeof a === 'object' && a !== null);
      
      if (hasEmbeddedObjects) {
        results.needsMigration.push({
          id: pkg.id,
          name: pkg.name,
          addOnCount: pkg.addOns.length,
          embeddedCount: pkg.addOns.filter(a => typeof a === 'object').length
        });
      } else {
        results.fullyMigrated++;
      }

      results.details.push({
        id: pkg.id,
        name: pkg.name,
        addOnsType: Array.isArray(pkg.addOns) 
          ? pkg.addOns.every(a => typeof a === 'string') ? 'IDs' : 'Mixed/Objects'
          : 'None',
        addOnCount: Array.isArray(pkg.addOns) ? pkg.addOns.length : 0
      });
    }

    return Response.json({
      success: true,
      migrationComplete: results.needsMigration.length === 0,
      results
    });

  } catch (error) {
    console.error('Check error:', error);
    return Response.json({
      success: false,
      error: error.message
    }, { status: 500 });
  }
});