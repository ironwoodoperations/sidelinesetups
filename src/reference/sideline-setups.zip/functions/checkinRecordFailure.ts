import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { token = null, employeeId = null, reason = "Other", geo } = await req.json();
    
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0].trim() || "";
    const ua = req.headers.get("user-agent") || "";

    await base44.asServiceRole.entities.CheckinFailures.create({
      scannedAt: new Date().toISOString(),
      employeeId,
      token,
      reason,
      meta: { 
        ip, 
        ua, 
        geo: geo && geo.lat ? { 
          lat: geo.lat, 
          lng: geo.lng, 
          accuracy: geo.accuracy || null 
        } : null 
      }
    });

    return Response.json({ ok: true });
  } catch (error) {
    console.error('Error in checkinRecordFailure:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});