import { createClientFromRequest } from "npm:@base44/sdk@0.7.1";

// Inline SMS helper
function env(name) {
  const v = Deno.env.get(name);
  if (!v) return "";
  return v;
}

function getAuthHeader() {
  const apiKey = env("TWILIO_API_KEY");
  const apiSecret = env("TWILIO_API_SECRET");
  const sid = env("TWILIO_ACCOUNT_SID");
  const authToken = env("TWILIO_AUTH_TOKEN");

  if (apiKey && apiSecret) return "Basic " + btoa(`${apiKey}:${apiSecret}`);
  if (sid && authToken)  return "Basic " + btoa(`${sid}:${authToken}`);
  throw new Error("Missing Twilio credentials: set TWILIO_API_KEY & TWILIO_API_SECRET (preferred) or TWILIO_ACCOUNT_SID & TWILIO_AUTH_TOKEN.");
}

async function sendSms(to, body) {
  if (!to) throw new Error("sendSms: missing 'to' (+1XXXXXXXXXX)");
  if (!body) throw new Error("sendSms: missing 'body'");

  const accountSid = env("TWILIO_ACCOUNT_SID");
  if (!accountSid) throw new Error("Missing TWILIO_ACCOUNT_SID");

  const mg = env("TWILIO_MESSAGING_SERVICE_SID");
  const legacyFrom = env("TWILIO_FROM");

  const form = new URLSearchParams();
  form.set("To", to);
  form.set("Body", body);
  if (mg) form.set("MessagingServiceSid", mg);
  else if (legacyFrom) form.set("From", legacyFrom);
  else throw new Error("No sender: set TWILIO_MESSAGING_SERVICE_SID (recommended) or TWILIO_FROM.");

  const res = await fetch(
    `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
    {
      method: "POST",
      headers: { Authorization: getAuthHeader(), "Content-Type": "application/x-www-form-urlencoded" },
      body: form.toString(),
    }
  );

  if (!res.ok) throw new Error(`Twilio error ${res.status}: ${await res.text()}`);
  return res.json();
}

function fmtWhen(d, tz = "America/Chicago") {
  const dt = typeof d === "string" ? new Date(d) : d;
  return new Intl.DateTimeFormat("en-US", {
    timeZone: tz, month: "short", day: "numeric", weekday: "short",
  }).format(dt);
}

Deno.serve(async (req) => {
  try {
    console.log('[notifyBookingConfirmedSms] Function called');
    
    if (req.method !== "POST") {
      console.error('[notifyBookingConfirmedSms] Method not allowed:', req.method);
      return Response.json({ error: "Method Not Allowed" }, { status: 405 });
    }
    
    const body = await req.json();
    console.log('[notifyBookingConfirmedSms] Request body:', body);
    
    const { bookingId } = body;
    if (!bookingId) {
      console.error('[notifyBookingConfirmedSms] Missing bookingId');
      return Response.json({ error: "Missing bookingId" }, { status: 400 });
    }

    const client = createClientFromRequest(req);
    console.log('[notifyBookingConfirmedSms] Fetching booking:', bookingId);
    
    const booking = await client.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking) {
      console.error('[notifyBookingConfirmedSms] Booking not found:', bookingId);
      return Response.json({ error: "Not found" }, { status: 404 });
    }

    console.log('[notifyBookingConfirmedSms] Booking found:', {
      id: booking.id,
      phone: booking.phone,
      fullName: booking.fullName
    });

    const to = booking.phone;
    const name = booking.fullName || "there";
    const when = fmtWhen(booking.date);
    const park = booking.parkName || "your field";

    console.log('[notifyBookingConfirmedSms] Sending SMS to:', to);
    
    await sendSms(
      to,
      `Hi ${name}, your Sideline Setups booking is CONFIRMED for ${when} at ${park}. We'll set up before your first game. Reply STOP to opt out, HELP for help.`
    );

    console.log('[notifyBookingConfirmedSms] SMS sent successfully');
    return Response.json({ ok: true }, { status: 200 });
    
  } catch (e) {
    console.error("[notifyBookingConfirmedSms] Error:", e);
    console.error("[notifyBookingConfirmedSms] Error stack:", e.stack);
    return Response.json({ 
      error: String(e.message || e),
      stack: e.stack 
    }, { status: 500 });
  }
});