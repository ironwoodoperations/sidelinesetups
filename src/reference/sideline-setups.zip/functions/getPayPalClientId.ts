import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve((req) => {
  try {
    const clientId = Deno.env.get('PAYPAL_CLIENT_ID');
    
    if (!clientId) {
      return Response.json({ error: 'PayPal Client ID not configured' }, { status: 500 });
    }

    return Response.json({ clientId });

  } catch (error) {
    console.error('Error in getPayPalClientId:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});