import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    console.log('[uploadIdPhoto] Request received');
    
    const base44 = createClientFromRequest(req);
    
    // Parse the JSON body
    let body;
    try {
      body = await req.json();
      console.log('[uploadIdPhoto] Body keys:', Object.keys(body));
    } catch (e) {
      console.error('[uploadIdPhoto] Failed to parse JSON body:', e);
      return Response.json({ error: 'Invalid request body', details: e.message }, { status: 400 });
    }
    
    const { bookingId, fileUri } = body;
    
    console.log('[uploadIdPhoto] Received bookingId:', bookingId);
    console.log('[uploadIdPhoto] Received fileUri:', fileUri);
    
    if (!bookingId) {
      return Response.json({ error: 'Missing bookingId' }, { status: 400 });
    }
    
    if (!fileUri) {
      return Response.json({ error: 'Missing fileUri' }, { status: 400 });
    }

    // Validate booking exists
    console.log('[uploadIdPhoto] Validating booking...');
    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking) {
      console.error('[uploadIdPhoto] Booking not found:', bookingId);
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }
    
    console.log('[uploadIdPhoto] Booking validated, updating with idPhotoUri...');
    
    // Update booking with the file URI
    try {
      await base44.asServiceRole.entities.Bookings.update(bookingId, {
        idPhotoUri: fileUri,
        idPhotoUploadedAt: new Date().toISOString()
      });
      console.log('[uploadIdPhoto] Booking updated successfully');
    } catch (updateError) {
      console.error('[uploadIdPhoto] Failed to update booking:', updateError);
      return Response.json({ 
        error: 'Failed to update booking',
        details: updateError.message 
      }, { status: 500 });
    }
    
    console.log('[uploadIdPhoto] Process completed successfully');
    return Response.json({ 
      success: true,
      message: 'ID photo uploaded successfully' 
    });
    
  } catch (error) {
    console.error('[uploadIdPhoto] Unexpected error:', error);
    return Response.json({ 
      error: 'Internal server error',
      details: error.message 
    }, { status: 500 });
  }
});