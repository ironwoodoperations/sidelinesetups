import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import { Resend } from 'npm:resend@4.0.0';

// Inline sendSms helper
function env(name) {
  const v = Deno.env.get(name);
  if (!v) return "";
  return v;
}

function getAuthHeader() {
  const apiKey = env("TWILIO_API_KEY");
  const apiSecret = env("TWILIO_API_SECRET");
  const sid = env("TWILIO_ACCOUNT_SID");
  const authToken = env("TWILIO_AUTH_TOKEN");

  if (apiKey && apiSecret) return "Basic " + btoa(`${apiKey}:${apiSecret}`);
  if (sid && authToken)  return "Basic " + btoa(`${sid}:${authToken}`);
  throw new Error("Missing Twilio credentials");
}

async function sendSms(to, body) {
  if (!to || !body) throw new Error("sendSms: missing parameters");

  const accountSid = env("TWILIO_ACCOUNT_SID");
  if (!accountSid) throw new Error("Missing TWILIO_ACCOUNT_SID");

  const mg = env("TWILIO_MESSAGING_SERVICE_SID");
  const legacyFrom = env("TWILIO_FROM");

  const form = new URLSearchParams();
  form.set("To", to);
  form.set("Body", body);
  if (mg) form.set("MessagingServiceSid", mg);
  else if (legacyFrom) form.set("From", legacyFrom);
  else throw new Error("No sender configured");

  const res = await fetch(
    `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
    {
      method: "POST",
      headers: { Authorization: getAuthHeader(), "Content-Type": "application/x-www-form-urlencoded" },
      body: form.toString(),
    }
  );

  if (!res.ok) throw new Error(`Twilio error ${res.status}`);
  return res.json();
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { bookingId } = await req.json();

    if (!bookingId) {
      return Response.json({ error: 'bookingId required' }, { status: 400 });
    }

    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }

    const settings = (await base44.asServiceRole.entities.SiteSettings.list())[0] || {};
    const brandName = settings.brandName || "Sideline Setups";
    const supportEmail = settings.supportEmail || "support@sideline-setups.com";
    const supportPhone = settings.supportPhone || "+1-903-541-9287";
    const logoUrl = settings.logoUrl || "";

    // Get upcoming events for promotional content
    const today = new Date().toISOString().split('T')[0];
    const upcomingEvents = await base44.asServiceRole.entities.Events.filter({
      isActive: true,
      startDate: { $gte: today }
    });

    // Sort by start date and take top 3
    const sortedEvents = (upcomingEvents || [])
      .sort((a, b) => new Date(a.startDate) - new Date(b.startDate))
      .slice(0, 3);

    let eventsHtml = '';
    if (sortedEvents.length > 0) {
      eventsHtml = `
        <tr>
          <td style="padding: 32px; background: #f8fafc;">
            <h2 style="margin: 0 0 16px 0; font-size: 24px; color: #003f5c; text-align: center;">Upcoming Events</h2>
            <p style="margin: 0 0 20px 0; color: #64748b; text-align: center;">We'd love to see you at these upcoming events!</p>
            
            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 12px;">
              ${sortedEvents.map(event => `
                <tr>
                  <td style="padding: 16px; background: white; border-radius: 8px; margin-bottom: 12px; display: block; border: 1px solid #e2e8f0;">
                    <h3 style="margin: 0 0 8px 0; font-size: 18px; color: #003f5c;">${event.name}</h3>
                    <p style="margin: 0; color: #64748b; font-size: 14px;">
                      ${event.city ? `📍 ${event.city} • ` : ''}
                      ${event.startDate ? new Date(event.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'TBD'}
                    </p>
                    ${event.website ? `
                      <a href="${event.website}" style="display: inline-block; margin-top: 12px; padding: 8px 16px; background: #003f5c; color: white; text-decoration: none; border-radius: 6px; font-size: 14px; font-weight: 600;">Learn More</a>
                    ` : ''}
                  </td>
                </tr>
              `).join('')}
            </table>
            
            <div style="text-align: center; margin-top: 20px;">
              <a href="${Deno.env.get('SITE_DOMAIN') || 'https://sideline-setups.com'}/events" style="display: inline-block; padding: 12px 24px; background: linear-gradient(135deg, #003f5c 0%, #005a7d 100%); color: white; text-decoration: none; border-radius: 8px; font-size: 16px; font-weight: 600;">View All Events</a>
            </div>
          </td>
        </tr>
      `;
    }

    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f8fafc;">
  <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #f8fafc; padding: 20px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" border="0" style="max-width: 600px; background-color: #ffffff;">
          
          <!-- Header -->
          <tr>
            <td bgcolor="#003f5c" style="padding: 40px; text-align: center; background-color: #003f5c;">
              ${logoUrl ? `<img src="${logoUrl}" alt="${brandName}" width="150" style="display: block; margin: 0 auto 16px auto;">` : ''}
              <h1 style="margin: 0; color: #ffffff; font-size: 32px; font-weight: bold;">Thank You!</h1>
              <p style="margin: 12px 0 0 0; color: #ffffff; font-size: 18px;">We hope you had a great game</p>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding: 32px;">
              <p style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px; line-height: 1.6;">
                Hi ${booking.fullName},
              </p>
              <p style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px; line-height: 1.6;">
                Thank you for choosing ${brandName}! We hope your setup made your game day easier and more enjoyable. 
              </p>
              <p style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px; line-height: 1.6;">
                Our team will be coming by to pick up your equipment shortly. If you have any feedback or need anything else, please don't hesitate to reach out.
              </p>
              <p style="margin: 0; color: #0f172a; font-size: 16px; line-height: 1.6;">
                We'd love to see you again!<br>
                The ${brandName} Team
              </p>
            </td>
          </tr>

          ${eventsHtml}

          <!-- Footer -->
          <tr>
            <td bgcolor="#f8fafc" style="padding: 24px 32px; text-align: center; background-color: #f8fafc; border-top: 1px solid #e2e8f0;">
              <p style="margin: 0 0 8px 0; color: #64748b; font-size: 14px;">Questions? Contact us at <a href="mailto:${supportEmail}" style="color: #003f5c; font-weight: 600; text-decoration: none;">${supportEmail}</a></p>
              <p style="margin: 0; color: #64748b; font-size: 14px;">Thank you for choosing ${brandName}!</p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `;

    const resend = new Resend(Deno.env.get('RESEND_API_KEY'));
    
    await resend.emails.send({
      from: `${brandName} <${Deno.env.get('EMAIL_FROM_ADDRESS') || 'noreply@sideline-setups.com'}>`,
      to: booking.contactEmail,
      subject: `Thank You from ${brandName}!`,
      html,
    });

    // Send SMS
    if (booking.phone) {
      try {
        const message = `Thank you for choosing ${brandName}! We hope you had a great game. Check your email for upcoming events!`;
        await sendSms(booking.phone, message);
      } catch (smsError) {
        console.error("Error sending SMS:", smsError);
      }
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('[notifyBookingCompleted] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});