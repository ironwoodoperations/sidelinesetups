import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { date, eventId, parkId } = await req.json();

    if (!date) {
      return Response.json({ error: 'date required' }, { status: 400 });
    }

    // Build query for bookings - updated to include new status names
    const query = {
      date: date,
      status: ['paid', 'photo_uploaded', 'setup', 'checked_in']
    };

    if (eventId && eventId !== 'all') {
      query.eventId = eventId;
    }

    if (parkId && parkId !== 'all') {
      query.parkId = parkId;
    }

    // Fetch bookings
    const bookings = await base44.asServiceRole.entities.Bookings.filter(query);

    if (bookings.length === 0) {
      return Response.json([]);
    }

    // Fetch all related data
    const eventIds = [...new Set(bookings.map(b => b.eventId).filter(Boolean))];
    const parkIds = [...new Set(bookings.map(b => b.parkId).filter(Boolean))];
    const fieldIds = [...new Set(bookings.map(b => b.fieldId).filter(Boolean))];
    const packageIds = [...new Set(bookings.map(b => b.packageId).filter(Boolean))];

    const [events, parks, fields, packages] = await Promise.all([
      eventIds.length > 0 
        ? Promise.all(eventIds.map(id => base44.asServiceRole.entities.Events.get(id).catch(() => null)))
        : [],
      parkIds.length > 0
        ? Promise.all(parkIds.map(id => base44.asServiceRole.entities.Parks.get(id).catch(() => null)))
        : [],
      fieldIds.length > 0
        ? Promise.all(fieldIds.map(id => base44.asServiceRole.entities.Fields.get(id).catch(() => null)))
        : [],
      packageIds.length > 0
        ? Promise.all(packageIds.map(id => base44.asServiceRole.entities.Packages.get(id).catch(() => null)))
        : []
    ]);

    // Create lookup maps
    const eventMap = Object.fromEntries(events.filter(Boolean).map(e => [e.id, e]));
    const parkMap = Object.fromEntries(parks.filter(Boolean).map(p => [p.id, p]));
    const fieldMap = Object.fromEntries(fields.filter(Boolean).map(f => [f.id, f]));
    const packageMap = Object.fromEntries(packages.filter(Boolean).map(p => [p.id, p]));

    // Build pull sheet data
    const pullSheetData = bookings.map(booking => {
      const event = eventMap[booking.eventId];
      const park = parkMap[booking.parkId];
      const field = fieldMap[booking.fieldId];
      const pkg = packageMap[booking.packageId];

      return {
        bookingId: booking.id,
        customerName: booking.fullName,
        teamName: booking.teamName || '',
        phone: booking.phone || '',
        eventName: event?.name || 'N/A',
        parkName: park?.name || 'N/A',
        fieldName: field?.name || 'N/A',
        spotLabel: booking.setupSideLabel || '',
        packageName: pkg?.name || 'N/A',
        gameTimes: booking.gameTimes || [],
        addOns: booking.addOns || [],
        status: booking.status,
        equipmentSetupChecklist: booking.equipmentSetupChecklist || {},
        lineItemsJson: booking.lineItemsJson || []
      };
    });

    return Response.json(pullSheetData);

  } catch (error) {
    console.error('[generatePullSheetData] Error:', error);
    return Response.json({ 
      error: error.message 
    }, { status: 500 });
  }
});