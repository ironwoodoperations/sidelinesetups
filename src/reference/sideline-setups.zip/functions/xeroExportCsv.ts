import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

function dollarsFromCents(cents) {
  return ((cents || 0) / 100).toFixed(2);
}

function formatDate(dateStr) {
  if (!dateStr) return new Date().toISOString().slice(0, 10);
  return new Date(dateStr).toISOString().slice(0, 10);
}

function addDays(dateStr, days) {
  const d = dateStr ? new Date(dateStr) : new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(req.url);
    const bookingIds = url.searchParams.get('bookingIds')?.split(',') || [];

    if (bookingIds.length === 0) {
      return Response.json({ error: 'No booking IDs provided' }, { status: 400 });
    }

    // Load bookings
    const bookings = [];
    for (const id of bookingIds) {
      try {
        const booking = await base44.asServiceRole.entities.Bookings.get(id);
        bookings.push(booking);
      } catch (e) {
        console.error(`Failed to load booking ${id}:`, e);
      }
    }

    if (bookings.length === 0) {
      return Response.json({ error: 'No valid bookings found' }, { status: 400 });
    }

    // Build CSV
    const rows = [];
    
    // Header
    rows.push([
      'ContactName',
      'EmailAddress',
      'InvoiceNumber',
      'InvoiceDate',
      'DueDate',
      'Description',
      'Quantity',
      'UnitAmount',
      'AccountCode',
      'TaxType',
      'Reference'
    ].join(','));

    // Data rows
    for (const booking of bookings) {
      const contactName = booking.fullName || booking.teamName || booking.contactEmail || 'Customer';
      const email = booking.contactEmail || booking.email || '';
      const invoiceNumber = `BKG-${booking.id.slice(0, 8)}`;
      const invoiceDate = formatDate(booking.created_date);
      const dueDate = addDays(booking.created_date, 7);
      const reference = `Booking ${booking.id.slice(0, 8)}`;

      const lineItems = booking.lineItemsJson || [];
      
      if (lineItems.length === 0) {
        // Fallback to single line
        rows.push([
          `"${contactName}"`,
          `"${email}"`,
          invoiceNumber,
          invoiceDate,
          dueDate,
          `"${booking.packageName || 'Package'}"`,
          1,
          dollarsFromCents(booking.totalCents || booking.totals?.amount * 100),
          Deno.env.get("XERO_ACCOUNT_CODE") || "200",
          Deno.env.get("XERO_TAX_TYPE") || "TAX001",
          `"${reference}"`
        ].join(','));
      } else {
        // One row per line item
        for (const item of lineItems) {
          const description = `${item.itemName || item.label} - ${item.dayLabel || ''} ${item.durationLabel || ''}`.trim();
          
          rows.push([
            `"${contactName}"`,
            `"${email}"`,
            invoiceNumber,
            invoiceDate,
            dueDate,
            `"${description}"`,
            item.qty || 1,
            dollarsFromCents(item.unitCents),
            Deno.env.get("XERO_ACCOUNT_CODE") || "200",
            Deno.env.get("XERO_TAX_TYPE") || "TAX001",
            `"${reference}"`
          ].join(','));
        }
      }
    }

    const csv = rows.join('\n');
    
    return new Response(csv, {
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': `attachment; filename="xero-invoices-${new Date().toISOString().slice(0, 10)}.csv"`
      }
    });

  } catch (e) {
    console.error("CSV export error:", e);
    return Response.json({ error: String(e) }, { status: 500 });
  }
});