import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const open = await base44.asServiceRole.entities.TimeEntries.filter({ clockOutAt: null });
    const emps = await base44.asServiceRole.entities.Employees.list();
    
    const byId = Object.fromEntries((emps || []).map(e => [e.id, e]));
    
    const rows = (open || []).map(t => ({
      id: t.id,
      employeeId: t.employeeId,
      employee: byId[t.employeeId]?.fullName || t.employeeId,
      role: byId[t.employeeId]?.role || "",
      clockInAt: t.clockInAt,
      parkId: t.parkId || "",
      notes: t.notes || "",
      source: t.source || "kiosk"
    })).sort((a, b) => (a.employee > b.employee ? 1 : -1));

    return Response.json(rows);
  } catch (error) {
    console.error('Error in listClockedInNow:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});