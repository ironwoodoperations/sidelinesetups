import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

// Inline helper functions
function genTimeSlots(startHHmm, endHHmm, minutes) {
  if (!startHHmm || !endHHmm || !minutes) return [];
  
  const [sh, sm] = startHHmm.split(":").map(Number);
  const [eh, em] = endHHmm.split(":").map(Number);
  const end = eh * 60 + em;
  let cur = sh * 60 + sm;
  const out = [];
  
  while (cur <= end) {
    const hh = String(Math.floor(cur / 60)).padStart(2, "0");
    const mm = String(cur % 60).padStart(2, "0");
    out.push(`${hh}:${mm}`);
    cur += Number(minutes);
    if (cur + Number(minutes) > end + Number(minutes)) break;
  }
  
  return out;
}

function invId(eventId, date, parkId, fieldId, time) {
  return `${eventId}:${date}:${parkId}:${fieldId}:${time}`;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { eventId } = await req.json();
    
    if (!eventId) {
      return Response.json({ error: 'eventId required' }, { status: 400 });
    }

    const ev = await base44.asServiceRole.entities.Events.get(eventId);
    if (!ev) {
      return Response.json({ error: 'Event not found' }, { status: 404 });
    }
    
    if (!ev.leagueEnabled) {
      return Response.json({ error: 'Event is not in league mode' }, { status: 400 });
    }

    const dates = (ev.leagueDates || [])
      .map(s => String(s).trim())
      .filter(Boolean);

    if (!dates.length) {
      return Response.json({ 
        error: 'leagueDates required - Please add league dates in the event editor (comma-separated YYYY-MM-DD format)' 
      }, { status: 400 });
    }
    
    if (!ev.leagueStartTime || !ev.leagueEndTime || !ev.leagueBufferMinutes) {
      return Response.json({ 
        error: 'start/end/buffer times required - Please set league times in the event editor' 
      }, { status: 400 });
    }

    const fields = ev.fieldIds || [];
    if (!fields.length) {
      return Response.json({ 
        error: 'fieldIds required - Please select at least one field for this league in the event editor' 
      }, { status: 400 });
    }

    const parks = ev.parkIds || [];
    if (!parks.length) {
      return Response.json({ 
        error: 'parkIds required - Please select at least one park for this league in the event editor' 
      }, { status: 400 });
    }

    const slots = genTimeSlots(ev.leagueStartTime, ev.leagueEndTime, Number(ev.leagueBufferMinutes));
    const defaultSpots = Number(ev.leagueDefaultSpotsPerSlot || 2);

    let upserts = 0;
    for (const date of dates) {
      for (const parkId of parks) {
        for (const fieldId of fields) {
          for (const time of slots) {
            const id = invId(ev.id, date, parkId, fieldId, time);
            
            try {
              const row = await base44.asServiceRole.entities.LeagueSpotInventory.get(id);
              
              // Refresh: keep the max between current and default
              const next = Math.max(Number(row.availableSpots || 0), defaultSpots);
              await base44.asServiceRole.entities.LeagueSpotInventory.update(id, {
                availableSpots: next,
                version: Number(row.version || 0) + 1
              });
            } catch (e) {
              // Doesn't exist, create it
              await base44.asServiceRole.entities.LeagueSpotInventory.create({
                id,
                eventId: ev.id,
                date,
                parkId,
                fieldId,
                time,
                availableSpots: defaultSpots,
                version: 0
              });
            }
            upserts++;
          }
        }
      }
    }

    return Response.json({ ok: true, upserts, message: `Successfully generated/refreshed ${upserts} inventory slots` });

  } catch (error) {
    console.error('Error in leagueGenerateInventory:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});