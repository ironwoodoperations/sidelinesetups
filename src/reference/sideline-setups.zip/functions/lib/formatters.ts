// Shared formatting helpers

export function formatMoneyUSD(amount) {
  const n = Number(amount || 0);
  return n.toLocaleString("en-US", { style: "currency", currency: "USD" });
}

export function formatDate(dateLike, tz = "America/Chicago") {
  const d = new Date(dateLike);
  return new Intl.DateTimeFormat("en-US", {
    year: "numeric", month: "short", day: "2-digit", timeZone: tz,
  }).format(d);
}

export function formatTimeHHmmTo12h(t) {
  // Accepts "HH:mm" -> "h:mm a"
  if (!t || typeof t !== "string" || !/^\d{1,2}:\d{2}$/.test(t)) return t || "";
  const [H, m] = t.split(":").map(Number);
  const h = ((H + 11) % 12) + 1;
  const ampm = H >= 12 ? "PM" : "AM";
  return `${h}:${String(m).padStart(2, "0")} ${ampm}`;
}

export function joinTruthy(parts, sep = " • ") {
  return parts.filter(Boolean).join(sep);
}