// Centralized brand tokens for PDFs + Email
export const BRAND = {
  NAME: "Sideline Setups",
  TAGLINE: "GameDay Without The Haul",
  COLORS: {
    NAVY: "#1a2a49",
    SKY: "#3b82f6",
    LIGHT_GREY: "#f3f4f6",
    MID_GREY: "#e5e7eb",
    TEXT_DARK: "#0f172a",
    TEXT_LIGHT: "#ffffff",
  },
  // Optional; pass a URL at runtime if you prefer
  DEFAULT_LOGO_URL: "", // e.g. "https://your-cdn/logo-ss.png"
};