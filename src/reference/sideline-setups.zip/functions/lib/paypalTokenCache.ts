// Token cache to reuse PayPal OAuth tokens
let cached = { token: null, expiresAt: 0 };

export async function getPayPalAccessToken(clientId, clientSecret) {
  const now = Date.now();
  
  // Return cached token if still valid (with 5s safety margin)
  if (cached.token && cached.expiresAt - 5000 > now) {
    return cached.token;
  }

  // Request new token
  const auth = btoa(`${clientId}:${clientSecret}`);
  const res = await fetch('https://api-m.sandbox.paypal.com/v1/oauth2/token', {
    method: 'POST',
    headers: { 
      'Authorization': `Basic ${auth}`, 
      'Content-Type': 'application/x-www-form-urlencoded' 
    },
    body: 'grant_type=client_credentials'
  });

  if (!res.ok) {
    const errorText = await res.text();
    console.error('PayPal token error:', errorText);
    throw new Error('Failed to get PayPal access token');
  }

  const json = await res.json();
  const ttlMs = (json.expires_in || 300) * 1000;
  
  cached.token = json.access_token;
  cached.expiresAt = Date.now() + ttlMs;
  
  return cached.token;
}