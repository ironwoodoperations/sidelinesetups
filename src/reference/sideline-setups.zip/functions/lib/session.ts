// functions/lib/session
export const cookie = {
  parse(req) {
    const raw = req.headers.get('cookie') || '';
    if (!raw) return {};
    return Object.fromEntries(
      raw.split(';').map(v => v.trim()).filter(Boolean).map(kv => {
        const i = kv.indexOf('=');
        if (i < 0) return [kv, ''];
        return [decodeURIComponent(kv.slice(0, i)), decodeURIComponent(kv.slice(i + 1))];
      })
    );
  },
  set(headers, name, value, opts = {}) {
    const parts = [`${encodeURIComponent(name)}=${encodeURIComponent(value)}`];
    if (opts.maxAge) parts.push(`Max-Age=${opts.maxAge}`);
    if (opts.expires) parts.push(`Expires=${opts.expires.toUTCString()}`);
    parts.push(`Path=/`, `SameSite=Lax`, `HttpOnly`, `Secure`);
    headers.append('Set-Cookie', parts.join('; '));
  },
  clear(headers, name) {
    headers.append('Set-Cookie', `${encodeURIComponent(name)}=; Max-Age=0; Path=/; HttpOnly; Secure; SameSite=Lax`);
  }
};

async function hmac(secret, msg) {
  const key = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(msg));
  return btoa(String.fromCharCode(...new Uint8Array(sig))).replace(/=+$/,'');
}

function getEnv(name, fallback) {
  try { return Deno.env.get(name) || fallback; } catch { return fallback; }
}

export async function signSession(payload, kind = 'staff', maxAgeSeconds = 60 * 60 * 24 * 30) {
  const secret = kind === 'customer'
    ? getEnv('CUSTOMER_SESSION_SECRET', 'dev-customer-change-me')
    : getEnv('STAFF_SESSION_SECRET', 'dev-staff-change-me');
  const exp = Math.floor(Date.now() / 1000) + maxAgeSeconds;
  const data = JSON.stringify({ ...payload, exp });
  const sig = await hmac(secret, data);
  return `${btoa(data)}.${sig}`;
}

export async function verifySession(token, kind = 'staff') {
  if (!token) return null;
  const secret = kind === 'customer'
    ? getEnv('CUSTOMER_SESSION_SECRET', 'dev-customer-change-me')
    : getEnv('STAFF_SESSION_SECRET', 'dev-staff-change-me');
  const dot = token.lastIndexOf('.');
  if (dot <= 0) return null;
  let data;
  try { data = JSON.parse(atob(token.slice(0, dot))); } catch { return null; }
  const expected = await hmac(secret, JSON.stringify(data));
  if (expected !== token.slice(dot + 1)) return null;
  if (!data.exp || data.exp < Math.floor(Date.now() / 1000)) return null;
  return data;
}