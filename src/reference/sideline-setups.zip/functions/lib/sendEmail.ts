import Resend from 'npm:resend@4.0.1';

const resend = new Resend(Deno.env.get('RESEND_API_KEY'));

/**
 * Send an email using Resend
 * @param {Object} options
 * @param {string} options.from - From email address
 * @param {string} options.to - To email address
 * @param {string} options.subject - Email subject
 * @param {string} options.html - HTML email body
 * @returns {Promise<Object>} Resend response
 */
export async function sendEmail({ from, to, subject, html }) {
  try {
    const result = await resend.emails.send({
      from,
      to,
      subject,
      html
    });
    
    return result;
  } catch (error) {
    console.error('[sendEmail] Error:', error);
    throw error;
  }
}