// Pretty, branded PDF generator with QR code for Deno
import PDFDocument from 'npm:pdfkit@0.15.0';
import QRCode from 'npm:qrcode@1.5.3';
import { BRAND } from "./branding.js";
import { formatMoneyUSD, formatDate, formatTimeHHmmTo12h, joinTruthy } from "./formatters.js";

/**
 * renderBookingPdf
 * @param {Object} params
 * @param {Object} params.booking - booking object (id, status, contact info, event details, etc.)
 * @param {Object} params.totals - { subtotal, tax, fees, total }
 * @param {string} params.checkinUrl - full URL encoded in the QR
 * @param {Object} params.site - { logoUrl?, supportEmail?, websiteUrl? }
 * @returns {Promise<Uint8Array>} PDF bytes
 */
export async function renderBookingPdf({ booking, totals, checkinUrl, site = {} }) {
  const {
    NAME, TAGLINE, COLORS: C, DEFAULT_LOGO_URL
  } = BRAND;

  // Fetch image as buffer
  async function fetchImageBuffer(url) {
    if (!url) return null;
    try {
      const res = await fetch(url);
      if (!res.ok) return null;
      const arrayBuffer = await res.arrayBuffer();
      return new Uint8Array(arrayBuffer);
    } catch {
      return null;
    }
  }

  const logoBuf = await fetchImageBuffer(site.logoUrl || DEFAULT_LOGO_URL);
  const qrDataUrl = await QRCode.toDataURL(checkinUrl || `https://example.com/checkin?b=${booking?.id || ""}`, {
    margin: 1,
    width: 256,
  });

  // Create PDF
  const doc = new PDFDocument({
    size: "LETTER",
    margin: 40,
    info: {
      Title: `Booking ${booking?.id || ""}`,
      Author: NAME,
      Producer: NAME,
    },
  });

  const chunks = [];
  doc.on("data", (c) => chunks.push(c));
  const done = new Promise((resolve) => doc.on("end", () => resolve(Uint8Array.from(Buffer.concat(chunks)))));

  // Header band
  doc.save();
  doc.rect(0, 0, doc.page.width, 90).fill(C.NAVY);
  doc.restore();

  // Logo + Title
  const leftPad = 40;
  const topPad = 20;

  if (logoBuf) {
    try {
      doc.image(logoBuf, leftPad, topPad + 4, { width: 56 });
    } catch (e) {
      console.error("Failed to add logo:", e);
    }
  }

  doc.fillColor(C.TEXT_LIGHT).fontSize(18).font("Helvetica-Bold")
     .text(NAME, (logoBuf ? leftPad + 66 : leftPad), topPad, { continued: false });

  doc.fontSize(11).font("Helvetica")
     .text(TAGLINE, (logoBuf ? leftPad + 66 : leftPad), topPad + 24);

  const rightText = joinTruthy([
    site.websiteUrl || "",
    site.supportEmail ? `support: ${site.supportEmail}` : "",
  ], "   ·   ");

  if (rightText) {
    doc.fontSize(9).text(rightText, 0, topPad + 8, {
      align: "right",
      width: doc.page.width - leftPad,
    });
  }

  // Title banner (Receipt/Invoice)
  const isInvoice = String(booking?.docType || "").toLowerCase() === "invoice";
  const mainTitle = isInvoice ? "INVOICE" : "BOOKING RECEIPT";

  doc.moveDown(2);
  doc.fillColor(C.TEXT_DARK).fontSize(18).font("Helvetica-Bold");
  doc.text(mainTitle, leftPad, 110);

  doc.fontSize(10).font("Helvetica").fillColor(C.TEXT_DARK);
  doc.text(`Reference: ${booking?.id || "—"}`, leftPad, 132);
  doc.text(`Date: ${formatDate(booking?.createdAt || Date.now())}`, leftPad, 146);

  // Grey section header helper
  function sectionHeader(label, y) {
    doc.save();
    doc.rect(leftPad, y, doc.page.width - 2 * leftPad, 22).fill(C.LIGHT_GREY);
    doc.restore();
    doc.fillColor(C.NAVY).fontSize(12).font("Helvetica-Bold");
    doc.text(label, leftPad + 8, y + 6);
    doc.fillColor(C.TEXT_DARK).font("Helvetica");
  }

  let yPos = 180;

  // Contact Information
  sectionHeader("Contact Information", yPos);
  yPos += 30;
  doc.fontSize(10);
  doc.text(booking?.contactName || "—", leftPad, yPos);
  yPos += 14;
  if (booking?.contactEmail) {
    doc.text(booking.contactEmail, leftPad, yPos);
    yPos += 14;
  }
  if (booking?.contactPhone) {
    doc.text(booking.contactPhone, leftPad, yPos);
    yPos += 14;
  }
  yPos += 10;

  // Event Details
  sectionHeader("Event Details", yPos);
  yPos += 30;
  if (booking?.eventName) {
    doc.text(`Event: ${booking.eventName}`, leftPad, yPos);
    yPos += 14;
  }
  if (booking?.eventType) {
    doc.text(`Type: ${booking.eventType}`, leftPad, yPos);
    yPos += 14;
  }
  if (booking?.date) {
    doc.text(`Date: ${formatDate(booking.date)}`, leftPad, yPos);
    yPos += 14;
  }
  if (booking?.parkName) {
    doc.text(`Park: ${booking.parkName}`, leftPad, yPos);
    yPos += 14;
  }
  if (booking?.fieldName) {
    doc.text(`Field: ${booking.fieldName}`, leftPad, yPos);
    yPos += 14;
  }
  if (booking?.spot) {
    doc.text(`Spot: ${booking.spot}`, leftPad, yPos);
    yPos += 14;
  }
  if (booking?.startTime) {
    const timeStr = `${formatTimeHHmmTo12h(booking.startTime)}${booking?.endTime ? `–${formatTimeHHmmTo12h(booking.endTime)}` : ""}`;
    doc.text(`Time: ${timeStr}`, leftPad, yPos);
    yPos += 14;
  }
  yPos += 10;

  // Package
  sectionHeader("Package", yPos);
  yPos += 30;
  doc.fontSize(11).font("Helvetica-Bold");
  doc.text(booking?.packageName || "—", leftPad, yPos);
  doc.fontSize(10).font("Helvetica");
  yPos += 16;
  if (booking?.packageMode) {
    doc.text(`Mode: ${booking.packageMode}`, leftPad, yPos);
    yPos += 14;
  }
  if (booking?.packageLength) {
    doc.text(`Length: ${booking.packageLength}`, leftPad, yPos);
    yPos += 14;
  }
  if (booking?.gameCount) {
    doc.text(`Games: ${booking.gameCount}`, leftPad, yPos);
    yPos += 14;
  }

  if (Array.isArray(booking?.packageContents) && booking.packageContents.length) {
    yPos += 4;
    doc.fontSize(10).font("Helvetica-Bold");
    doc.text("Includes:", leftPad, yPos);
    yPos += 14;
    doc.font("Helvetica");
    booking.packageContents.forEach((item) => {
      doc.text(`• ${item}`, leftPad + 12, yPos);
      yPos += 14;
    });
  }

  if (Array.isArray(booking?.addons) && booking.addons.length) {
    yPos += 6;
    doc.fontSize(10).font("Helvetica-Bold");
    doc.text("Add-ons:", leftPad, yPos);
    yPos += 14;
    doc.font("Helvetica");
    booking.addons.forEach((addon) => {
      const addonLine = `• ${addon.name}${addon.mode ? ` (${addon.mode})` : ""}${addon.quantity ? ` x${addon.quantity}` : ""}${addon.price != null ? ` – ${formatMoneyUSD(addon.price)}` : ""}`;
      doc.text(addonLine, leftPad + 12, yPos);
      yPos += 14;
    });
  }

  yPos += 10;

  // Totals
  sectionHeader("Totals", yPos);
  yPos += 30;
  doc.fontSize(10);
  doc.text("Subtotal:", leftPad, yPos);
  doc.text(formatMoneyUSD(totals?.subtotal || 0), 0, yPos, { align: "right", width: doc.page.width - leftPad });
  yPos += 16;
  doc.text("Tax:", leftPad, yPos);
  doc.text(formatMoneyUSD(totals?.tax || 0), 0, yPos, { align: "right", width: doc.page.width - leftPad });
  yPos += 16;
  doc.text("Fees:", leftPad, yPos);
  doc.text(formatMoneyUSD(totals?.fees || 0), 0, yPos, { align: "right", width: doc.page.width - leftPad });
  yPos += 20;
  doc.fontSize(12).font("Helvetica-Bold");
  doc.text("TOTAL:", leftPad, yPos);
  doc.text(formatMoneyUSD(totals?.total || 0), 0, yPos, { align: "right", width: doc.page.width - leftPad });

  // QR Code
  if (qrDataUrl) {
    try {
      const qrY = 160;
      const qrX = doc.page.width - 220;
      doc.image(qrDataUrl, qrX, qrY, { width: 180, height: 180 });
      doc.fontSize(9).font("Helvetica-Bold").fillColor(C.TEXT_DARK);
      doc.text("Scan to Check In", qrX, qrY + 190, { width: 180, align: "center" });
      doc.fontSize(7).font("Helvetica");
      doc.text(checkinUrl || "", qrX, qrY + 205, { width: 180, align: "center" });
    } catch (e) {
      console.error("Failed to add QR code:", e);
    }
  }

  // Footer
  doc.fontSize(9).fillColor(C.TEXT_DARK);
  const footerY = doc.page.height - 60;
  const footerText = joinTruthy([NAME, site.websiteUrl, site.supportEmail], " • ");
  doc.text(footerText, leftPad, footerY, { align: "center", width: doc.page.width - 2 * leftPad });

  doc.end();
  return done;
}