Deno.serve(async (req) => {
  return new Response(JSON.stringify({ ok: true, where: '/functions/ping' }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' },
  });
});