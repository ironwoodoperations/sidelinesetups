import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

/**
 * Records a page visit for analytics
 * Automatically filters internal traffic based on IP addresses in SiteSettings
 */

function parseUserAgent(ua) {
  const isMobile = /Mobile|Android|iPhone|iPad|iPod/i.test(ua);
  const isTablet = /iPad|Android(?!.*Mobile)/i.test(ua);
  
  let device = 'desktop';
  if (isTablet) device = 'tablet';
  else if (isMobile) device = 'mobile';
  
  let browser = 'Unknown';
  if (ua.includes('Chrome') && !ua.includes('Edg')) browser = 'Chrome';
  else if (ua.includes('Safari') && !ua.includes('Chrome')) browser = 'Safari';
  else if (ua.includes('Firefox')) browser = 'Firefox';
  else if (ua.includes('Edg')) browser = 'Edge';
  
  return { device, browser };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const body = await req.json();
    const { url, path, referrer, visitorId, sessionId, customerEmail } = body;
    
    if (!url || !path) {
      return Response.json({ 
        error: 'Missing required fields: url, path' 
      }, { status: 400 });
    }
    
    // Get user agent and IP
    const userAgent = req.headers.get('user-agent') || 'Unknown';
    const ipAddress = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() 
                      || req.headers.get('x-real-ip') 
                      || 'Unknown';
    
    // Parse device and browser from user agent
    const { device, browser } = parseUserAgent(userAgent);
    
    // Get internal IP addresses from settings
    const settings = await base44.asServiceRole.entities.SiteSettings.list();
    const internalIps = settings[0]?.internalIpAddresses || [];
    
    // Check if this is an internal visit
    const isInternal = internalIps.includes(ipAddress);
    
    // Basic geolocation (just country/city detection)
    // In production, you might use a service like ipapi.co or MaxMind
    let country = null;
    let city = null;
    
    // Create the visit record
    await base44.asServiceRole.entities.PageVisit.create({
      url,
      path,
      referrer: referrer || null,
      userAgent,
      ipAddress,
      visitorId: visitorId || null,
      sessionId: sessionId || null,
      isInternal,
      country,
      city,
      device,
      browser,
      customerEmail: customerEmail || null
    });
    
    return Response.json({
      success: true,
      isInternal,
      message: isInternal ? 'Internal visit recorded (excluded from analytics)' : 'Visit recorded'
    });
    
  } catch (error) {
    console.error('Error recording page visit:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});