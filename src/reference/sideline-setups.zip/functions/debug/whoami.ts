// functions/debug/whoami.js

// ===== INLINED SESSION HELPER =====
const cookie = {
  parse(req) {
    const raw = req.headers.get('cookie') || '';
    if (!raw) return {};
    return Object.fromEntries(
      raw.split(';').map(v => v.trim()).filter(Boolean).map(kv => {
        const i = kv.indexOf('=');
        if (i < 0) return [kv, ''];
        return [decodeURIComponent(kv.slice(0, i)), decodeURIComponent(kv.slice(i + 1))];
      })
    );
  }
};

async function hmac(secret, msg) {
  const key = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(msg));
  return btoa(String.fromCharCode(...new Uint8Array(sig))).replace(/=+$/,'');
}

function getEnv(name, fallback) {
  try { return Deno.env.get(name) || fallback; } catch { return fallback; }
}

async function verifySession(token, kind = 'staff') {
  if (!token) return null;
  const secret = kind === 'customer'
    ? getEnv('CUSTOMER_SESSION_SECRET', 'dev-customer-change-me')
    : getEnv('STAFF_SESSION_SECRET', 'dev-staff-change-me');
  const dot = token.lastIndexOf('.');
  if (dot <= 0) return null;
  let data;
  try { data = JSON.parse(atob(token.slice(0, dot))); } catch { return null; }
  const expected = await hmac(secret, JSON.stringify(data));
  if (expected !== token.slice(dot + 1)) return null;
  if (!data.exp || data.exp < Math.floor(Date.now() / 1000)) return null;
  return data;
}
// ===== END INLINED SESSION HELPER =====

Deno.serve(async (req) => {
  const c = cookie.parse(req);
  const staffData = await verifySession(c['staff_session'], 'staff');
  const customerData = await verifySession(c['customer_session'], 'customer');

  return new Response(JSON.stringify({
    ok: true,
    staff: staffData ? true : false,
    staffData: staffData || null,
    customer: customerData ? true : false,
    customerData: customerData || null,
    cookies: Object.keys(c)
  }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  });
});