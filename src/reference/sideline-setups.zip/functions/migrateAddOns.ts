// Migration script to normalize add-ons
// This creates top-level AddOns entities from embedded package add-ons
// and updates Packages to reference them by ID

import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Use service role for migration
    const packages = await base44.asServiceRole.entities.Packages.list();
    
    const results = {
      packagesProcessed: 0,
      addOnsCreated: 0,
      packagesUpdated: 0,
      errors: []
    };

    for (const pkg of packages) {
      results.packagesProcessed++;
      
      // Skip if addOns is already an array of IDs (all strings)
      if (Array.isArray(pkg.addOns) && pkg.addOns.every(a => typeof a === 'string')) {
        continue;
      }

      // If addOns contains objects, migrate them
      if (Array.isArray(pkg.addOns) && pkg.addOns.some(a => typeof a === 'object')) {
        const newAddOnIds = [];

        for (const addon of pkg.addOns) {
          if (typeof addon === 'string') {
            // Already an ID, keep it
            newAddOnIds.push(addon);
            continue;
          }

          // Create new AddOns entity
          try {
            const newAddOn = await base44.asServiceRole.entities.AddOns.create({
              label: addon.label || addon.equipmentId || 'Unnamed Add-on',
              description: addon.description || '',
              perGameUSD: addon.perGameUSD || 0,
              perDayUSD: addon.perDayUSD || 0,
              fullWeekendUSD: addon.fullWeekendUSD || 0,
              inventory: addon.inventory || 0,
              isActive: true
            });

            newAddOnIds.push(newAddOn.id);
            results.addOnsCreated++;
          } catch (error) {
            results.errors.push({
              packageId: pkg.id,
              addon: addon.label || 'unknown',
              error: error.message
            });
          }
        }

        // Update package with new add-on IDs
        try {
          await base44.asServiceRole.entities.Packages.update(pkg.id, {
            addOns: newAddOnIds
          });
          results.packagesUpdated++;
        } catch (error) {
          results.errors.push({
            packageId: pkg.id,
            error: `Failed to update package: ${error.message}`
          });
        }
      }
    }

    return Response.json({
      success: true,
      message: 'Add-ons migration completed',
      results
    });

  } catch (error) {
    console.error('Migration error:', error);
    return Response.json({
      success: false,
      error: error.message
    }, { status: 500 });
  }
});