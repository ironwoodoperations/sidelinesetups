import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

function normalizeEmail(s) {
  return (s || "").trim().toLowerCase();
}

function normalizePhone(p) {
  if (!p) return "";
  const digits = (""+p).replace(/\D/g, "");
  if (digits.length === 10) return `+1${digits}`;
  if (digits.length === 11 && digits.startsWith("1")) return `+${digits}`;
  if (p.startsWith("+")) return p;
  return p;
}

function slugify(x) {
  return (x || "")
    .toLowerCase()
    .replace(/['"]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function safeTag(prefix, value) {
  const s = slugify(value || "");
  return s ? `${prefix}:${s}` : "";
}

function ym(dateIso) {
  try {
    const d = dateIso ? new Date(dateIso) : new Date();
    const y = d.getUTCFullYear();
    const m = String(d.getUTCMonth() + 1).padStart(2, "0");
    return `${y}-${m}`;
  } catch {
    return "";
  }
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Verify authentication
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const bookings = await base44.asServiceRole.entities.Bookings.list();

    // Optional lookups for parks/events
    const parks = await base44.asServiceRole.entities.Parks.list().catch(() => []);
    const events = await base44.asServiceRole.entities.Events.list().catch(() => []);
    
    const parkById = {};
    for (const p of parks || []) {
      parkById[p.id] = p;
    }
    
    const eventById = {};
    for (const e of events || []) {
      eventById[e.id] = e;
    }

    const mapByKey = {};

    for (const b of bookings || []) {
      const email = normalizeEmail(b.contactEmail || b.email);
      const phone = normalizePhone(b.phone || b.contactPhone);

      const key = email || phone;
      if (!key) continue;

      // Derive context
      const ev = b.eventId ? eventById[b.eventId] : null;
      const pk = b.parkId ? parkById[b.parkId] : null;
      
      const eventType = (ev?.eventType || b.eventType || "").toLowerCase();
      const sport = (ev?.sport || b.sport || "").toLowerCase();
      const eventName = ev?.name || b.eventName || "";
      const parkName = pk?.name || b.parkName || "";
      const city = pk?.city || b.city || "";
      const teamName = b.teamName || "";
      const monthTag = ym(b.created_date || b.date);

      // Build tags
      const ts = new Set();
      
      const tType = safeTag("type", eventType);
      if (tType) ts.add(tType); // e.g., "type:tournament"
      
      const tSport = safeTag("sport", sport);
      if (tSport) ts.add(tSport); // e.g., "sport:softball"
      
      const tEvent = safeTag("event", eventName);
      if (tEvent) ts.add(tEvent); // e.g., "event:texas-classic"
      
      const tPark = safeTag("park", parkName);
      if (tPark) ts.add(tPark); // e.g., "park:mcinnis-park"
      
      const tCity = safeTag("city", city);
      if (tCity) ts.add(tCity); // e.g., "city:allen"
      
      const tYm = safeTag("date", monthTag);
      if (tYm) ts.add(tYm); // e.g., "date:2025-01"
      
      const tTeam = safeTag("team", teamName);
      if (tTeam) ts.add(tTeam); // e.g., "team:wildcats"

      // Merge any preexisting tags on booking
      for (const x of b.tags || []) {
        if (x) ts.add(String(x));
      }

      // Accumulate into map (merge strategy)
      const prev = mapByKey[key] || {};
      mapByKey[key] = {
        id: prev.id,
        fullName: prev.fullName || b.fullName || b.customerName || "",
        email: email || prev.email || "",
        phone: phone || prev.phone || "",
        unsubscribedEmail: prev.unsubscribedEmail || false,
        unsubscribedSms: prev.unsubscribedSms || false,
        tags: Array.from(new Set([...(prev.tags || []), ...Array.from(ts)])),
        meta: {
          ...(prev.meta || {}),
          lastBookingId: b.id,
          lastEventId: b.eventId,
          lastEventName: eventName,
          lastParkId: b.parkId,
          lastParkName: parkName,
          lastTeamName: teamName
        }
      };
    }

    // Reconcile with existing Contacts
    const allContacts = await base44.asServiceRole.entities.Contacts.list();
    const byKey = {};
    for (const c of allContacts || []) {
      const e = normalizeEmail(c.email);
      const p = normalizePhone(c.phone);
      const k = e || p;
      if (k) byKey[k] = c;
    }

    const results = { created: 0, updated: 0 };
    for (const [k, row] of Object.entries(mapByKey)) {
      const found = byKey[k];
      if (found) {
        // Merge tags - don't overwrite, add to existing
        const mergedTags = Array.from(new Set([...(found.tags || []), ...(row.tags || [])]));
        await base44.asServiceRole.entities.Contacts.update(found.id, {
          ...row,
          id: found.id,
          tags: mergedTags,
          meta: { ...found.meta, ...row.meta }
        });
        results.updated++;
      } else {
        await base44.asServiceRole.entities.Contacts.create(row);
        results.created++;
      }
    }

    return Response.json(results);
  } catch (error) {
    console.error("CRM import error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});