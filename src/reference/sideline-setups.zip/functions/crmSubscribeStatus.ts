import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Verify authentication
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id, field, value } = await req.json();
    
    if (!id || !["email","sms"].includes(field)) {
      return Response.json({ error: "Invalid args" }, { status: 400 });
    }

    const row = await base44.asServiceRole.entities.Contacts.get(id);
    if (!row) {
      return Response.json({ error: "Not found" }, { status: 404 });
    }

    const updates = { ...row };
    if (field === "email") updates.unsubscribedEmail = !value ? true : false;
    if (field === "sms")   updates.unsubscribedSms   = !value ? true : false;

    await base44.asServiceRole.entities.Contacts.update(id, updates);
    
    return Response.json({ ok: true });
  } catch (error) {
    console.error("CRM subscribe status error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});