import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

/**
 * Release equipment inventory from a cancelled/refunded/deleted booking
 * This function now checks BOTH InventoryMovements AND the actual booking
 * to ensure all equipment is released, even if movement records are missing
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { bookingId } = await req.json();
    
    if (!bookingId) {
      return Response.json({ 
        error: 'Missing required field: bookingId' 
      }, { status: 400 });
    }

    console.log(`[inventoryRelease] Starting release for booking ${bookingId}`);

    // Get the booking to determine what equipment should be released
    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking) {
      return Response.json({
        error: 'Booking not found'
      }, { status: 404 });
    }

    console.log(`[inventoryRelease] Booking status: ${booking.status}`);

    // Build a map of equipment that SHOULD be released based on the booking
    const expectedEquipment = new Map(); // equipmentId => quantity

    // 1. Get equipment from package baseItems
    if (booking.packageId) {
      try {
        const pkg = await base44.asServiceRole.entities.Packages.get(booking.packageId);
        if (pkg && pkg.baseItems && Array.isArray(pkg.baseItems)) {
          console.log(`[inventoryRelease] Package ${pkg.name} has ${pkg.baseItems.length} base items`);
          for (const item of pkg.baseItems) {
            if (item.equipmentId && item.qty) {
              const current = expectedEquipment.get(item.equipmentId) || 0;
              expectedEquipment.set(item.equipmentId, current + Number(item.qty));
              console.log(`[inventoryRelease] Expected from package: ${item.equipmentId} qty ${item.qty}`);
            }
          }
        }
      } catch (err) {
        console.error('[inventoryRelease] Error loading package:', err);
      }
    }

    // 2. Get equipment from add-ons
    if (booking.addOns && Array.isArray(booking.addOns)) {
      console.log(`[inventoryRelease] Booking has ${booking.addOns.length} add-ons`);
      for (const addon of booking.addOns) {
        if (addon.id) {
          try {
            const addonRecord = await base44.asServiceRole.entities.AddOns.get(addon.id);
            if (addonRecord && addonRecord.equipmentId) {
              const quantity = Number(addon.quantity || 1);
              const current = expectedEquipment.get(addonRecord.equipmentId) || 0;
              expectedEquipment.set(addonRecord.equipmentId, current + quantity);
              console.log(`[inventoryRelease] Expected from addon: ${addonRecord.equipmentId} qty ${quantity}`);
            }
          } catch (err) {
            console.error('[inventoryRelease] Error loading addon:', err);
          }
        }
      }
    }

    console.log(`[inventoryRelease] Expected equipment to release:`, Array.from(expectedEquipment.entries()));

    // Now check what was actually allocated in InventoryMovements
    const movements = await base44.asServiceRole.entities.InventoryMovements.filter({
      bookingId,
      type: 'allocate'
    });
    
    console.log(`[inventoryRelease] Found ${movements.length} allocation movements`);

    // Build a map of what was actually allocated
    const allocatedEquipment = new Map(); // equipmentId => quantity
    for (const movement of movements) {
      const current = allocatedEquipment.get(movement.equipmentId) || 0;
      allocatedEquipment.set(movement.equipmentId, current + Number(movement.qty || 0));
    }

    console.log(`[inventoryRelease] Allocated equipment from movements:`, Array.from(allocatedEquipment.entries()));

    // Determine what to release: use the MAXIMUM of expected vs allocated for each equipment
    const toRelease = new Map();
    
    // Add all expected equipment
    for (const [equipmentId, qty] of expectedEquipment.entries()) {
      toRelease.set(equipmentId, qty);
    }
    
    // Check if allocated has more (shouldn't happen, but handle it)
    for (const [equipmentId, qty] of allocatedEquipment.entries()) {
      const expected = toRelease.get(equipmentId) || 0;
      if (qty > expected) {
        console.warn(`[inventoryRelease] Warning: Allocated ${qty} but expected ${expected} for equipment ${equipmentId}. Using allocated amount.`);
        toRelease.set(equipmentId, qty);
      }
    }

    console.log(`[inventoryRelease] Final equipment to release:`, Array.from(toRelease.entries()));

    if (toRelease.size === 0) {
      return Response.json({
        success: true,
        message: 'No equipment allocations found for this booking',
        releases: []
      });
    }

    const releases = [];
    
    for (const [equipmentId, quantity] of toRelease.entries()) {
      console.log(`[inventoryRelease] Releasing ${quantity} of equipment ${equipmentId}`);
      
      let success = false;
      let attempts = 0;
      const maxAttempts = 5;
      
      while (!success && attempts < maxAttempts) {
        attempts++;
        
        try {
          // Fetch current equipment state
          const equipment = await base44.asServiceRole.entities.Equipment.get(equipmentId);
          
          if (!equipment) {
            console.warn(`[inventoryRelease] Equipment ${equipmentId} not found, skipping`);
            break;
          }
          
          const availableQty = Number(equipment.availableQty || 0);
          const rentedQty = Number(equipment.rentedQty || 0);
          const currentVersion = Number(equipment.version || 0);
          
          console.log(`[inventoryRelease] ${equipment.name} - Attempt ${attempts}: available=${availableQty}, rented=${rentedQty}`);
          
          // Update inventory
          await base44.asServiceRole.entities.Equipment.update(equipmentId, {
            availableQty: availableQty + quantity,
            rentedQty: Math.max(0, rentedQty - quantity),
            version: currentVersion + 1
          });
          
          console.log(`[inventoryRelease] ${equipment.name} updated: available ${availableQty} → ${availableQty + quantity}, rented ${rentedQty} → ${Math.max(0, rentedQty - quantity)}`);
          
          // Log the release
          await base44.asServiceRole.entities.InventoryMovements.create({
            equipmentId,
            type: 'return',
            qty: quantity,
            unitCostUSD: equipment.cogsPerUseUSD || 0,
            bookingId,
            note: `Released from ${booking.status === 'cancelled' ? 'cancelled' : 'deleted'} booking ${bookingId}`,
            whenAt: new Date().toISOString()
          });
          
          releases.push({
            equipmentId,
            equipmentName: equipment.name,
            quantity,
            previousAvailable: availableQty,
            newAvailable: availableQty + quantity,
            previousRented: rentedQty,
            newRented: Math.max(0, rentedQty - quantity)
          });
          
          success = true;
          
        } catch (updateError) {
          console.error(`[inventoryRelease] Error on attempt ${attempts} for equipment ${equipmentId}:`, updateError);
          
          if (attempts >= maxAttempts) {
            console.error('[inventoryRelease] Max retries reached for', equipmentId, updateError);
            return Response.json({
              error: 'Failed to release inventory after multiple attempts',
              details: updateError.message,
              equipmentId
            }, { status: 500 });
          }
          
          // Wait before retry (exponential backoff)
          await new Promise(resolve => setTimeout(resolve, 100 * attempts));
        }
      }
    }

    console.log(`[inventoryRelease] Successfully released ${releases.length} equipment items`);

    return Response.json({
      success: true,
      releases,
      message: `Successfully released equipment for booking ${bookingId}`
    });

  } catch (error) {
    console.error('[inventoryRelease] Unexpected error:', error);
    return Response.json({
      error: error.message || 'Failed to release inventory'
    }, { status: 500 });
  }
});