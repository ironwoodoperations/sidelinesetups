// functions/emailSend.js — HTTP endpoint for sending emails
import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

// Inline sendEmail helper
function env(name) {
  const v = Deno.env.get(name);
  if (!v) return "";
  return v;
}

async function sendEmail({ from, to, subject, html, text }) {
  const apiKey = env("RESEND_API_KEY");
  if (!apiKey) {
    throw new Error("Missing RESEND_API_KEY environment variable");
  }

  const defaultFrom = env("EMAIL_FROM_ADDRESS") || "support@orders.sideline-setups.com";
  const fromAddress = from || defaultFrom;

  if (!to) throw new Error("sendEmail: missing 'to' address");
  if (!subject) throw new Error("sendEmail: missing 'subject'");
  if (!html && !text) throw new Error("sendEmail: missing 'html' or 'text' content");

  const payload = {
    from: fromAddress,
    to: Array.isArray(to) ? to : [to],
    subject,
    ...(html && { html }),
    ...(text && { text })
  };

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  if (!res.ok) {
    const errorText = await res.text();
    console.error("[Resend] sendEmail failed", res.status, errorText);
    throw new Error(`Resend error ${res.status}: ${errorText}`);
  }

  const data = await res.json();
  console.log("[Resend] Email sent", data.id);
  return data;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (req.method !== "POST") {
      return new Response("Method Not Allowed", { status: 405 });
    }

    const { from, to, subject, html, text } = await req.json();
    const data = await sendEmail({ from, to, subject, html, text });
    
    return Response.json({ 
      ok: true, 
      id: data.id 
    });
  } catch (err) {
    console.error("Email send error:", err);
    return Response.json({ 
      ok: false, 
      error: String(err) 
    }, { status: 500 });
  }
});