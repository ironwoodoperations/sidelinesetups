import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

// ---------- Config ----------
const API_BASE = "https://api.xero.com/api.xro/2.0";
const TOKEN_URL = "https://identity.xero.com/connect/token";

const DEFAULT_ACCOUNT_CODE = Deno.env.get("XERO_ACCOUNT_CODE") || "200"; // Sales
const DEFAULT_TAX_TYPE = Deno.env.get("XERO_TAX_TYPE") || "TAX001";

// ---------- OAuth (Custom Connection: client_credentials) ----------
async function getAccessToken() {
  const clientId = Deno.env.get("XERO_CLIENT_ID");
  const clientSecret = Deno.env.get("XERO_CLIENT_SECRET");
  
  if (!clientId || !clientSecret) {
    throw new Error("Missing XERO_CLIENT_ID or XERO_CLIENT_SECRET environment variables");
  }
  
  const body = new URLSearchParams();
  body.set("grant_type", "client_credentials");
  body.set("scope", "accounting.transactions accounting.contacts offline_access");

  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Authorization": "Basic " + btoa(`${clientId}:${clientSecret}`),
    },
    body,
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Xero token error ${res.status}: ${text}`);
  }
  
  const json = await res.json();
  return json.access_token;
}

// ---------- Helpers ----------
function dollarsFromCents(cents) {
  return Number(((cents || 0) / 100).toFixed(2));
}

function firstNonEmpty(...xs) {
  for (const x of xs) {
    const s = String(x || "").trim();
    if (s) return s;
  }
  return "";
}

// Build Xero "LineItems" from our line_items_json
function buildXeroLineItems(booking, accountMapping = {}) {
  const items = booking.lineItemsJson || [];
  
  return items.map((item) => {
    // Try to get account code from mapping, otherwise use default
    const accountCode = accountMapping[item.meta?.packageId || item.meta?.addOnId] || DEFAULT_ACCOUNT_CODE;
    
    return {
      Description: `${item.itemName || item.label} - ${item.dayLabel || ''} ${item.durationLabel || ''}`.trim(),
      Quantity: item.qty || 1,
      UnitAmount: dollarsFromCents(item.unitCents),
      AccountCode: accountCode,
      TaxType: DEFAULT_TAX_TYPE,
    };
  });
}

// ---------- Contact upsert ----------
async function getOrCreateContact(accessToken, email, name, phone) {
  const body = {
    Contacts: [
      {
        Name: name || email,
        EmailAddress: email,
        Phones: phone ? [{ PhoneType: "MOBILE", PhoneNumber: phone }] : [],
      },
    ],
  };

  const res = await fetch(`${API_BASE}/Contacts`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${accessToken}`,
      "Accept": "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Xero Contacts error ${res.status}: ${text}`);
  }

  const json = await res.json();
  const contact = json?.Contacts?.[0];
  
  return { 
    ContactID: contact?.ContactID, 
    Name: contact?.Name, 
    EmailAddress: contact?.EmailAddress 
  };
}

// ---------- Invoice create (one or many) ----------
async function createInvoices(accessToken, invoices) {
  const batches = [];
  const MAX_PER_BATCH = 40;
  
  for (let i = 0; i < invoices.length; i += MAX_PER_BATCH) {
    batches.push(invoices.slice(i, i + MAX_PER_BATCH));
  }

  const results = [];
  
  for (const chunk of batches) {
    const payload = { Invoices: chunk };
    
    let retries = 0;
    let success = false;
    
    while (!success && retries < 3) {
      const res = await fetch(`${API_BASE}/Invoices`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "Accept": "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (res.status === 429) {
        // Rate limit hit
        const retryAfter = Number(res.headers.get("Retry-After") || "2");
        console.log(`Rate limited, waiting ${retryAfter}s...`);
        await new Promise(r => setTimeout(r, (retryAfter + 1) * 1000));
        retries++;
        continue;
      }

      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Xero Invoices error ${res.status}: ${text}`);
      }

      const json = await res.json();
      results.push(...(json?.Invoices || []));
      success = true;
    }
    
    if (!success) {
      throw new Error("Failed to create invoices after 3 retries");
    }
  }
  
  return results;
}

// ---------- HTTP handler ----------
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (req.method !== "POST") {
      return Response.json({ ok: false, error: "POST only" }, { status: 405 });
    }

    const { bookingIds, accountMapping } = await req.json();
    
    if (!Array.isArray(bookingIds) || bookingIds.length === 0) {
      return Response.json({ ok: false, error: "Missing bookingIds[]" }, { status: 400 });
    }

    // Load bookings
    const bookings = [];
    for (const id of bookingIds) {
      try {
        const booking = await base44.asServiceRole.entities.Bookings.get(id);
        bookings.push(booking);
      } catch (e) {
        console.error(`Failed to load booking ${id}:`, e);
      }
    }

    if (bookings.length === 0) {
      return Response.json({ ok: false, error: "No valid bookings found" }, { status: 400 });
    }

    const token = await getAccessToken();

    // Build invoices
    const invoices = [];
    const bookingInvoiceMap = {}; // Track which booking gets which invoice
    
    for (const booking of bookings) {
      const email = firstNonEmpty(booking.contactEmail, booking.email);
      const name = firstNonEmpty(booking.fullName, booking.teamName, email, "Sideline Customer");
      const phone = booking.phone || "";

      if (!email) {
        console.warn(`Skipping booking ${booking.id} - no email`);
        continue;
      }

      const contact = await getOrCreateContact(token, email, name, phone);
      const lineItems = buildXeroLineItems(booking, accountMapping || {});

      if (lineItems.length === 0) {
        console.warn(`Skipping booking ${booking.id} - no line items`);
        continue;
      }

      const invoice = {
        Type: "ACCREC", // Sales invoice
        Contact: { ContactID: contact.ContactID },
        Date: new Date().toISOString().slice(0, 10),
        DueDate: new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
        LineAmountTypes: "Exclusive",
        LineItems: lineItems,
        Reference: `Booking ${booking.id.slice(0, 8)}`,
        Status: "DRAFT",
      };

      invoices.push(invoice);
      bookingInvoiceMap[invoices.length - 1] = booking.id;
    }

    if (invoices.length === 0) {
      return Response.json({ ok: false, error: "No valid invoices to create" }, { status: 400 });
    }

    const created = await createInvoices(token, invoices);
    
    // Store invoice IDs back on bookings
    for (let i = 0; i < created.length; i++) {
      const xeroInvoice = created[i];
      const bookingId = bookingInvoiceMap[i];
      
      if (xeroInvoice?.InvoiceID && bookingId) {
        try {
          await base44.asServiceRole.entities.Bookings.update(bookingId, {
            xeroInvoiceId: xeroInvoice.InvoiceID,
            xeroInvoiceNumber: xeroInvoice.InvoiceNumber,
            xeroInvoiceUrl: `https://go.xero.com/AccountsReceivable/View.aspx?InvoiceID=${xeroInvoice.InvoiceID}`
          });
        } catch (e) {
          console.error(`Failed to update booking ${bookingId} with invoice ID:`, e);
        }
      }
    }

    return Response.json({ 
      ok: true, 
      count: created.length, 
      invoices: created.map(inv => ({
        InvoiceID: inv.InvoiceID,
        InvoiceNumber: inv.InvoiceNumber,
        Status: inv.Status,
        Total: inv.Total
      }))
    });

  } catch (e) {
    console.error("Xero push error:", e);
    return Response.json({ ok: false, error: String(e) }, { status: 500 });
  }
});