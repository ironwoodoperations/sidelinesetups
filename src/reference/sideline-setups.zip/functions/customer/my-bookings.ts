import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { email } = await req.json();
    
    if (!email) {
      return Response.json({ ok: false, error: 'Email required' }, { status: 400 });
    }

    console.log('[customer/my-bookings] Fetching bookings for:', email);

    // Fetch bookings for this customer email
    const bookings = await base44.asServiceRole.entities.Bookings.filter({
      contactEmail: email.toLowerCase()
    });

    // Sort by date descending
    bookings.sort((a, b) => {
      const dateA = new Date(a.date || a.created_date || 0);
      const dateB = new Date(b.date || b.created_date || 0);
      return dateB - dateA;
    });

    console.log('[customer/my-bookings] Found bookings:', bookings.length);

    return Response.json({ 
      ok: true, 
      bookings: bookings || [] 
    });
  } catch (error) {
    console.error('[customer/my-bookings] Error:', error);
    return Response.json({ 
      ok: false, 
      error: error.message 
    }, { status: 500 });
  }
});