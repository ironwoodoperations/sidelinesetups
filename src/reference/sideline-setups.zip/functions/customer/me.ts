import { cookie, verifySession } from '../lib/session';

Deno.serve(async (req) => {
  const c = cookie.parse(req);
  const data = await verifySession(c['customer_session'], 'customer');
  
  if (!data?.email) {
    return new Response(JSON.stringify({ ok:false }), { status:401 });
  }
  
  return new Response(JSON.stringify({ 
    ok:true, 
    customer: { email: data.email, name: data.name || '' } 
  }), { 
    status:200, 
    headers:{ 'Content-Type':'application/json' }
  });
});