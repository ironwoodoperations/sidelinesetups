import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

/**
 * Redeems loyalty points for a discount on a booking
 * 
 * Conversion rate: 100 points = $10 off (10 points per dollar)
 * 
 * Returns updated pricing with loyalty discount applied
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const { customerEmail, pointsToRedeem, currentTotalCents } = await req.json();
    
    if (!customerEmail || !pointsToRedeem || !currentTotalCents) {
      return Response.json({ 
        error: 'Missing required fields: customerEmail, pointsToRedeem, currentTotalCents' 
      }, { status: 400 });
    }
    
    if (pointsToRedeem <= 0) {
      return Response.json({ 
        error: 'Points to redeem must be greater than 0' 
      }, { status: 400 });
    }
    
    // Configuration
    const pointsPerDollar = 10; // 100 points = $10 off
    const minRedemptionPoints = 100; // Minimum points to redeem
    
    if (pointsToRedeem < minRedemptionPoints) {
      return Response.json({ 
        error: `Minimum redemption is ${minRedemptionPoints} points` 
      }, { status: 400 });
    }
    
    // Get customer's current balance
    const existingCredits = await base44.asServiceRole.entities.LoyaltyCredits.filter({
      customerId: customerEmail
    });
    
    if (!existingCredits || existingCredits.length === 0) {
      return Response.json({ 
        error: 'No loyalty account found for this customer' 
      }, { status: 404 });
    }
    
    const loyaltyRecord = existingCredits[0];
    const currentBalance = loyaltyRecord.points || 0;
    
    if (currentBalance < pointsToRedeem) {
      return Response.json({ 
        error: `Insufficient points. You have ${currentBalance} points.` 
      }, { status: 400 });
    }
    
    // Calculate discount
    const discountDollars = pointsToRedeem / pointsPerDollar;
    const discountCents = Math.floor(discountDollars * 100);
    
    // Can't discount more than the total
    const actualDiscountCents = Math.min(discountCents, currentTotalCents);
    const actualPointsUsed = Math.floor((actualDiscountCents / 100) * pointsPerDollar);
    
    const newTotalCents = currentTotalCents - actualDiscountCents;
    const newBalance = currentBalance - actualPointsUsed;
    
    // Validate redemption is worth it
    if (actualDiscountCents === 0) {
      return Response.json({ 
        error: 'Redemption amount too small or total is already $0' 
      }, { status: 400 });
    }
    
    return Response.json({
      success: true,
      pointsRedeemed: actualPointsUsed,
      discountCents: actualDiscountCents,
      discountDollars: (actualDiscountCents / 100).toFixed(2),
      newTotalCents,
      newBalance,
      pointsPerDollar,
      minRedemptionPoints,
      message: `${actualPointsUsed} points applied! You saved $${(actualDiscountCents / 100).toFixed(2)}`
    });
    
  } catch (error) {
    console.error('Error redeeming loyalty points:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});