import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

// Inline sendSms helper
function env(name) {
  const v = Deno.env.get(name);
  if (!v) return "";
  return v;
}

function getAuthHeader() {
  const apiKey = env("TWILIO_API_KEY");
  const apiSecret = env("TWILIO_API_SECRET");
  const sid = env("TWILIO_ACCOUNT_SID");
  const authToken = env("TWILIO_AUTH_TOKEN");

  if (apiKey && apiSecret) return "Basic " + btoa(`${apiKey}:${apiSecret}`);
  if (sid && authToken)  return "Basic " + btoa(`${sid}:${authToken}`);
  throw new Error("Missing Twilio credentials");
}

async function sendSms(to, body) {
  if (!to || !body) throw new Error("sendSms: missing 'to' or 'body'");

  const accountSid = env("TWILIO_ACCOUNT_SID");
  if (!accountSid) throw new Error("Missing TWILIO_ACCOUNT_SID");

  const mg = env("TWILIO_MESSAGING_SERVICE_SID");
  const legacyFrom = env("TWILIO_FROM");

  const form = new URLSearchParams();
  form.set("To", to);
  form.set("Body", body);
  if (mg) form.set("MessagingServiceSid", mg);
  else if (legacyFrom) form.set("From", legacyFrom);
  else throw new Error("No sender configured");

  const res = await fetch(
    `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
    {
      method: "POST",
      headers: { Authorization: getAuthHeader(), "Content-Type": "application/x-www-form-urlencoded" },
      body: form.toString(),
    }
  );

  if (!res.ok) throw new Error(`Twilio error ${res.status}`);
  return res.json();
}

function normalizePhone(p) {
  if (!p) return "";
  const digits = (""+p).replace(/\D/g, "");
  if (digits.length === 10) return `+1${digits}`;
  if (digits.length === 11 && digits.startsWith("1")) return `+${digits}`;
  if (p.startsWith("+")) return p;
  return p;
}

function sleep(ms) { 
  return new Promise(r => setTimeout(r, ms)); 
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      bodyText = "",
      testTo,
      previewOnly = false,
      segment = "all",
      segmentTag = ""
    } = await req.json();

    let recipients = [];
    if (testTo) {
      recipients = [{ phone: normalizePhone(testTo), unsubscribedSms: false }];
    } else {
      let rows = await base44.asServiceRole.entities.Contacts.list();
      rows = (rows || []).filter((c) => c.phone && !c.unsubscribedSms);
      if (segment === "tag" && segmentTag) {
        rows = rows.filter((c) => (c.tags||[]).includes(segmentTag));
      }
      recipients = rows;
    }

    const BATCH = 100;
    for (let i=0; i<recipients.length; i+=BATCH) {
      const batch = recipients.slice(i, i+BATCH);
      if (previewOnly) break;

      for (const r of batch) {
        const to = normalizePhone(r.phone);
        
        try {
          await sendSms(to, bodyText);
          console.log(`SMS sent to ${to}`);
        } catch (smsError) {
          console.warn(`Failed to send SMS to ${to}:`, smsError);
        }

        await sleep(150);
      }
      await sleep(600);
    }

    return Response.json({ ok: true, count: recipients.length });
  } catch (error) {
    console.error("SMS campaign error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});