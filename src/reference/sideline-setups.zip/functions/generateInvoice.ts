import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import { jsPDF } from 'npm:jspdf@2.5.1';

function money(n) {
  const v = Number(n || 0);
  return `$${v.toFixed(2)}`;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { bookingId } = await req.json();
    
    if (!bookingId) {
      return Response.json({ error: 'Booking ID required' }, { status: 400 });
    }

    // Get booking data
    const booking = await base44.entities.Bookings.get(bookingId);
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }

    // Get settings
    const settingsRows = await base44.asServiceRole.entities.SiteSettings.list();
    const settings = settingsRows?.[0] || {};

    const doc = new jsPDF({ unit: 'pt', format: 'letter' });
    const brand = settings?.brandName || "Sideline Setups";
    
    // Header
    doc.setFont(undefined, 'bold');
    doc.setFontSize(20);
    doc.text(brand, 40, 60);
    
    doc.setFontSize(16);
    doc.text("INVOICE", 40, 80);
    
    // Invoice details
    doc.setFont(undefined, 'normal');
    doc.setFontSize(11);
    doc.text(`Invoice #: ${booking?.id || "-"}`, 40, 120);
    doc.text(`Date: ${new Date(booking?.created_date || Date.now()).toLocaleDateString()}`, 40, 138);
    
    // Customer info
    doc.setFont(undefined, 'bold');
    doc.setFontSize(12);
    doc.text("Bill To:", 40, 180);
    
    doc.setFont(undefined, 'normal');
    doc.setFontSize(11);
    doc.text(booking?.fullName || "-", 40, 200);
    doc.text(booking?.contactEmail || "-", 40, 218);
    doc.text(booking?.phone || "-", 40, 236);
    
    // Booking details
    doc.setFont(undefined, 'bold');
    doc.setFontSize(12);
    doc.text("Booking Details:", 40, 280);
    
    doc.setFont(undefined, 'normal');
    doc.setFontSize(11);
    doc.text(`Event: ${booking?.eventType || "-"} • ${booking?.sport || "-"}`, 40, 300);
    doc.text(`Date: ${booking?.date || "-"}`, 40, 318);
    doc.text(`Package: ${booking?.packageName || booking?.packageId || "-"}`, 40, 336);
    
    // Amount
    doc.setFont(undefined, 'bold');
    doc.setFontSize(13);
    doc.text("Amount Due:", 40, 380);
    
    doc.setFontSize(16);
    doc.text(money(booking?.totals?.amount || 0), 40, 404);
    
    // Footer
    doc.setFont(undefined, 'normal');
    doc.setFontSize(11);
    doc.text("Thank you for your business!", 40, 720);

    const pdfBytes = doc.output('arraybuffer');

    return new Response(pdfBytes, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename=Invoice-${bookingId}.pdf`
      }
    });

  } catch (error) {
    console.error('Error in generateInvoice:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});