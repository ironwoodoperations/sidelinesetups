
import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import { Resend } from 'npm:resend@4.0.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { bookingId } = await req.json();

    if (!bookingId) {
      return Response.json({ error: 'bookingId required' }, { status: 400 });
    }

    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }

    // Fetch event, park, field details
    let event = null;
    let park = null;
    let field = null;

    if (booking.eventId) {
      try {
        event = await base44.asServiceRole.entities.Events.get(booking.eventId);
      } catch (e) {
        console.warn('Could not load event:', e);
      }
    }

    if (booking.parkId) {
      try {
        park = await base44.asServiceRole.entities.Parks.get(booking.parkId);
      } catch (e) {
        console.warn('Could not load park:', e);
      }
    }

    if (booking.fieldId) {
      try {
        field = await base44.asServiceRole.entities.Fields.get(booking.fieldId);
      } catch (e) {
        console.warn('Could not load field:', e);
      }
    }

    const settings = (await base44.asServiceRole.entities.SiteSettings.list())[0] || {};
    const brandName = settings.brandName || "Sideline Setups";
    const supportEmail = settings.supportEmail || "support@sideline-setups.com";
    const supportPhone = settings.supportPhone || "+1-903-541-9287";
    const logoUrl = settings.logoUrl || "";
    const siteDomain = settings.siteDomain || Deno.env.get('SITE_DOMAIN') || 'https://sideline-setups.com';

    const eventName = event?.name || 'your event';
    const parkName = park?.name || 'your park';
    const fieldName = field?.name || 'your field';
    const viewBookingUrl = `${siteDomain}/customer-login?booking=${booking.id}`;

    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f8fafc;">
  <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #f8fafc; padding: 20px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" border="0" style="max-width: 600px; background-color: #ffffff;">
          
          <!-- Header -->
          <tr>
            <td bgcolor="#003f5c" style="padding: 40px; text-align: center; background-color: #003f5c;">
              ${logoUrl ? `<img src="${logoUrl}" alt="${brandName}" width="150" style="display: block; margin: 0 auto 16px auto;">` : ''}
              <h1 style="margin: 0; color: #ffffff; font-size: 32px; font-weight: bold;">Your Setup is Ready!</h1>
              <p style="margin: 12px 0 0 0; color: #ffffff; font-size: 18px;">Come enjoy your GameDay!</p>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding: 32px;">
              <p style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px; line-height: 1.6;">
                Hi ${booking.fullName},
              </p>
              <p style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px; line-height: 1.6;">
                Great news! Your setup is complete and ready for you at <strong>${eventName}</strong> at <strong>${parkName}</strong> on <strong>${fieldName}</strong>. Everything is in place for you to have an amazing GameDay!
              </p>

              <!-- View Setup Location Link -->
              <div style="margin: 20px 0; padding: 16px; background: #f0f9ff; border-left: 4px solid #003f5c; border-radius: 4px;">
                <p style="margin: 0 0 8px 0; color: #0f172a; font-size: 14px; font-weight: 600;">📍 View your exact setup location:</p>
                <a href="${viewBookingUrl}" style="display: inline-block; margin-top: 8px; padding: 10px 20px; background: #003f5c; color: #ffffff; text-decoration: none; border-radius: 6px; font-size: 14px; font-weight: 600;">View My Setup</a>
              </div>

              <p style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px; line-height: 1.6;">
                When you're finished and leaving, please send us a quick text at <strong>${supportPhone}</strong> so we can come Haul it off for you.
              </p>
              <p style="margin: 0; color: #0f172a; font-size: 16px; line-height: 1.6;">
                Have a great game!<br>
                The ${brandName} Team
              </p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td bgcolor="#f8fafc" style="padding: 24px 32px; text-align: center; background-color: #f8fafc; border-top: 1px solid #e2e8f0;">
              <p style="margin: 0; color: #64748b; font-size: 14px;">Questions? Contact us at <a href="mailto:${supportEmail}" style="color: #003f5c; font-weight: 600; text-decoration: none;">${supportEmail}</a></p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `;

    const resend = new Resend(Deno.env.get('RESEND_API_KEY'));
    
    await resend.emails.send({
      from: `${brandName} <${Deno.env.get('EMAIL_FROM_ADDRESS') || 'noreply@sideline-setups.com'}>`,
      to: booking.contactEmail,
      subject: `Your Setup is Ready!`,
      html,
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error('[notifyBookingSetupReady] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
