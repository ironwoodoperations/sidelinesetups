import twilio from "npm:twilio";

const client = twilio(
  Deno.env.get("TWILIO_ACCOUNT_SID"),
  Deno.env.get("TWILIO_AUTH_TOKEN"),
  { accountSid: Deno.env.get("TWILIO_ACCOUNT_SID") }
);

export async function sendSms(to, body) {
  return client.messages.create({
    to,
    body,
    messagingServiceSid: Deno.env.get("TWILIO_MESSAGING_SERVICE_SID"),
  });
}