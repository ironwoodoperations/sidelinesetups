import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

// Inline helper function
function genTimeSlots(startHHmm, endHHmm, minutes) {
  if (!startHHmm || !endHHmm || !minutes) return [];
  
  const [sh, sm] = startHHmm.split(":").map(Number);
  const [eh, em] = endHHmm.split(":").map(Number);
  const end = eh * 60 + em;
  let cur = sh * 60 + sm;
  const out = [];
  
  while (cur <= end) {
    const hh = String(Math.floor(cur / 60)).padStart(2, "0");
    const mm = String(cur % 60).padStart(2, "0");
    out.push(`${hh}:${mm}`);
    cur += Number(minutes);
    if (cur + Number(minutes) > end + Number(minutes)) break;
  }
  
  return out;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { eventId, date, parkId } = await req.json();
    
    if (!eventId) {
      return Response.json({ error: 'eventId required' }, { status: 400 });
    }

    const ev = await base44.asServiceRole.entities.Events.get(eventId);
    if (!ev) {
      return Response.json({ error: 'Event not found' }, { status: 404 });
    }
    
    if (!ev.leagueEnabled) {
      return Response.json({ error: 'Not a league event' }, { status: 400 });
    }

    const times = (ev.leagueStartTime && ev.leagueEndTime && ev.leagueBufferMinutes)
      ? genTimeSlots(ev.leagueStartTime, ev.leagueEndTime, Number(ev.leagueBufferMinutes))
      : [];

    // Load parks/fields lists
    const allParks = await base44.asServiceRole.entities.Parks.list();
    const allFields = await base44.asServiceRole.entities.Fields.list();
    
    const eventParks = new Set(ev.parkIds || []);
    const eventFields = new Set(ev.fieldIds || []);

    const parks = (allParks || []).filter(p => eventParks.has(p.id));
    const fields = (allFields || []).filter(f => eventFields.has(f.id));

    // Load inventory with filters
    let inv = await base44.asServiceRole.entities.LeagueSpotInventory.filter({ eventId });
    inv = (inv || []).filter(r =>
      (!date || r.date === date) &&
      (!parkId || r.parkId === parkId)
    );

    return Response.json({
      rows: inv,
      parks,
      fields,
      times
    });

  } catch (error) {
    console.error('Error in leagueListInventory:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});