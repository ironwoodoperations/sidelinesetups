import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import { Resend } from 'npm:resend@4.0.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { bookingId } = await req.json();

    if (!bookingId) {
      return Response.json({ error: 'bookingId required' }, { status: 400 });
    }

    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }

    const settings = (await base44.asServiceRole.entities.SiteSettings.list())[0] || {};
    const brandName = settings.brandName || "Sideline Setups";
    const supportEmail = settings.supportEmail || "support@sideline-setups.com";
    const logoUrl = settings.logoUrl || "";

    // Get upcoming events for promotional content
    const today = new Date().toISOString().split('T')[0];
    const upcomingEvents = await base44.asServiceRole.entities.Events.filter({
      isActive: true,
      startDate: { $gte: today }
    });

    // Sort by start date and take top 3
    const sortedEvents = (upcomingEvents || [])
      .sort((a, b) => new Date(a.startDate) - new Date(b.startDate))
      .slice(0, 3);

    let eventsHtml = '';
    if (sortedEvents.length > 0) {
      eventsHtml = `
        <tr>
          <td style="padding: 32px; background: #f8fafc;">
            <h2 style="margin: 0 0 16px 0; font-size: 24px; color: #003f5c; text-align: center;">Upcoming Events</h2>
            <p style="margin: 0 0 20px 0; color: #64748b; text-align: center;">We'd love to see you at these upcoming events!</p>
            
            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 12px;">
              ${sortedEvents.map(event => `
                <tr>
                  <td style="padding: 16px; background: white; border-radius: 8px; margin-bottom: 12px; display: block; border: 1px solid #e2e8f0;">
                    <h3 style="margin: 0 0 8px 0; font-size: 18px; color: #003f5c;">${event.name}</h3>
                    <p style="margin: 0; color: #64748b; font-size: 14px;">
                      ${event.eventType === 'tournament' ? '🏆 Tournament' : '🏅 League'} • 
                      ${event.sport ? event.sport.charAt(0).toUpperCase() + event.sport.slice(1) : ''}
                      ${event.city ? ` • 📍 ${event.city}` : ''}
                      ${event.startDate ? ` • ${new Date(event.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}` : ' • TBD'}
                    </p>
                    ${event.website ? `
                      <a href="${event.website}" style="display: inline-block; margin-top: 12px; padding: 8px 16px; background: #003f5c; color: white; text-decoration: none; border-radius: 6px; font-size: 14px; font-weight: 600;">Learn More</a>
                    ` : ''}
                  </td>
                </tr>
              `).join('')}
            </table>
            
            <div style="text-align: center; margin-top: 20px;">
              <a href="${Deno.env.get('SITE_DOMAIN') || 'https://sideline-setups.com'}/events" style="display: inline-block; padding: 12px 24px; background: linear-gradient(135deg, #003f5c 0%, #005a7d 100%); color: white; text-decoration: none; border-radius: 8px; font-size: 16px; font-weight: 600;">View All Events</a>
            </div>
          </td>
        </tr>
      `;
    }

    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f8fafc;">
  <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #f8fafc; padding: 20px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" border="0" style="max-width: 600px; background-color: #ffffff;">
          
          <!-- Header -->
          <tr>
            <td bgcolor="#003f5c" style="padding: 40px; text-align: center; background-color: #003f5c;">
              ${logoUrl ? `<img src="${logoUrl}" alt="${brandName}" width="150" style="display: block; margin: 0 auto 16px auto;">` : ''}
              <h1 style="margin: 0; color: #ffffff; font-size: 32px; font-weight: bold;">All Set!</h1>
              <p style="margin: 12px 0 0 0; color: #ffffff; font-size: 18px;">Equipment successfully returned</p>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding: 32px;">
              <p style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px; line-height: 1.6;">
                Hi ${booking.fullName},
              </p>
              <p style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px; line-height: 1.6;">
                Great news! All of your equipment has been successfully returned. Your booking is now complete.
              </p>
              <p style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px; line-height: 1.6;">
                We truly appreciate your business and hope we made your game day special. We'd love to work with you again at future events!
              </p>
              <p style="margin: 0; color: #0f172a; font-size: 16px; line-height: 1.6;">
                Thanks again,<br>
                The ${brandName} Team
              </p>
            </td>
          </tr>

          ${eventsHtml}

          <!-- Footer -->
          <tr>
            <td bgcolor="#f8fafc" style="padding: 24px 32px; text-align: center; background-color: #f8fafc; border-top: 1px solid #e2e8f0;">
              <p style="margin: 0; color: #64748b; font-size: 14px;">Questions? Contact us at <a href="mailto:${supportEmail}" style="color: #003f5c; font-weight: 600; text-decoration: none;">${supportEmail}</a></p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `;

    const resend = new Resend(Deno.env.get('RESEND_API_KEY'));
    
    await resend.emails.send({
      from: `${brandName} <${Deno.env.get('EMAIL_FROM_ADDRESS') || 'noreply@sideline-setups.com'}>`,
      to: booking.contactEmail,
      subject: `Equipment Returned Successfully`,
      html,
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error('[notifyBookingReturned] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});