
import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

// Inline sendSms helper
function env(name) {
  const v = Deno.env.get(name);
  if (!v) return "";
  return v;
}

function getAuthHeader() {
  const apiKey = env("TWILIO_API_KEY");
  const apiSecret = env("TWILIO_API_SECRET");
  const sid = env("TWILIO_ACCOUNT_SID");
  const authToken = env("TWILIO_AUTH_TOKEN");

  if (apiKey && apiSecret) return "Basic " + btoa(`${apiKey}:${apiSecret}`);
  if (sid && authToken)  return "Basic " + btoa(`${sid}:${authToken}`);
  throw new Error("Missing Twilio credentials");
}

async function sendSms(to, body) {
  if (!to || !body) throw new Error("sendSms: missing parameters");

  const accountSid = env("TWILIO_ACCOUNT_SID");
  if (!accountSid) throw new Error("Missing TWILIO_ACCOUNT_SID");

  const mg = env("TWILIO_MESSAGING_SERVICE_SID");
  const legacyFrom = env("TWILIO_FROM");

  const form = new URLSearchParams();
  form.set("To", to);
  form.set("Body", body);
  if (mg) form.set("MessagingServiceSid", mg);
  else if (legacyFrom) form.set("From", legacyFrom);
  else throw new Error("No sender configured");

  const res = await fetch(
    `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
    {
      method: "POST",
      headers: { Authorization: getAuthHeader(), "Content-Type": "application/x-www-form-urlencoded" },
      body: form.toString(),
    }
  );

  if (!res.ok) throw new Error(`Twilio error ${res.status}`);
  return res.json();
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { bookingId, checklist } = await req.json();
    
    if (!bookingId) {
      return Response.json({ error: 'Booking ID required' }, { status: 400 });
    }

    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }

    // Fetch event, park, field details for SMS
    let event = null;
    let park = null;
    let field = null;

    if (booking.eventId) {
      try {
        event = await base44.asServiceRole.entities.Events.get(booking.eventId);
      } catch (e) {
        console.warn('Could not load event:', e);
      }
    }

    if (booking.parkId) {
      try {
        park = await base44.asServiceRole.entities.Parks.get(booking.parkId);
      } catch (e) {
        console.warn('Could not load park:', e);
      }
    }

    if (booking.fieldId) {
      try {
        field = await base44.asServiceRole.entities.Fields.get(booking.fieldId);
      } catch (e) {
        console.warn('Could not load field:', e);
      }
    }

    // Update booking with checklist and status
    await base44.asServiceRole.entities.Bookings.update(bookingId, {
      status: 'setup',
      equipmentSetupChecklist: checklist || {}
    });

    // Send SMS notification
    if (booking.phone) {
      try {
        const BRAND_NAME = Deno.env.get("BRAND_NAME") || "Sideline Setups";
        const eventName = event?.name || "your event";
        const parkName = park?.name || "your park";
        const fieldName = field?.name || "your field";
        const message = `Your ${BRAND_NAME} Setup is ready at ${eventName} at ${parkName} on ${fieldName} – Enjoy your GameDay!`;
        
        await sendSms(booking.phone, message);
        console.log(`SMS sent to ${booking.phone} for booking ${bookingId}`);
      } catch (smsError) {
        console.error("Error sending SMS:", smsError);
      }
    }

    // Send email notification
    try {
      await base44.asServiceRole.functions.invoke('notifyBookingSetupReady', { bookingId });
    } catch (emailError) {
      console.error("Error sending email:", emailError);
    }

    return Response.json({ 
      success: true,
      message: 'Booking marked as setup and customer notified'
    });

  } catch (error) {
    console.error('Error in markBookingSetup:', error);
    return Response.json({ 
      error: error.message,
      success: false
    }, { status: 500 });
  }
});
