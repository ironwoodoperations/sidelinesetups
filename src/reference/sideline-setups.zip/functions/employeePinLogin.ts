import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { pin } = await req.json();
    
    if (!pin) {
      return Response.json({ error: 'PIN required' }, { status: 400 });
    }

    const matches = await base44.asServiceRole.entities.Employees.filter({ pin });
    const emp = (matches || [])[0];
    
    if (!emp || emp.status === "inactive") {
      return Response.json({ error: 'Invalid PIN' }, { status: 401 });
    }

    return Response.json({ 
      ok: true, 
      employee: { 
        id: emp.id, 
        fullName: emp.fullName, 
        role: emp.role 
      } 
    });
  } catch (error) {
    console.error('Error in employeePinLogin:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});