import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

// Inline helper function
function invId(eventId, date, parkId, fieldId, time) {
  return `${eventId}:${date}:${parkId}:${fieldId}:${time}`;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      console.error('[leagueReserveSlotCAS] Unauthorized - no user');
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { eventId, date, parkId, fieldId, time } = body;
    
    console.log('[leagueReserveSlotCAS] Request body:', body);
    
    if (!eventId || !date || !parkId || !fieldId || !time) {
      console.error('[leagueReserveSlotCAS] Missing fields:', { eventId, date, parkId, fieldId, time });
      return Response.json({ 
        error: 'Missing required fields: eventId, date, parkId, fieldId, time' 
      }, { status: 400 });
    }

    const id = invId(eventId, date, parkId, fieldId, time);
    console.log('[leagueReserveSlotCAS] Attempting to reserve slot:', id);

    // CAS retry loop
    for (let attempt = 0; attempt < 5; attempt++) {
      try {
        console.log(`[leagueReserveSlotCAS] Attempt ${attempt + 1} - Fetching inventory record`);
        
        let row;
        try {
          row = await base44.asServiceRole.entities.LeagueSpotInventory.get(id);
        } catch (getError) {
          console.error('[leagueReserveSlotCAS] Error fetching inventory:', getError);
          
          // If record doesn't exist, try to find it by filter
          console.log('[leagueReserveSlotCAS] Trying to find record by filter...');
          const filtered = await base44.asServiceRole.entities.LeagueSpotInventory.filter({
            eventId,
            date,
            parkId,
            fieldId,
            time
          });
          
          if (filtered && filtered.length > 0) {
            row = filtered[0];
            console.log('[leagueReserveSlotCAS] Found record via filter:', row.id);
          } else {
            console.error('[leagueReserveSlotCAS] No inventory record found');
            return Response.json({ 
              error: 'Inventory slot not found. Please ask an admin to generate inventory for this event.' 
            }, { status: 404 });
          }
        }
        
        if (!row) {
          console.error('[leagueReserveSlotCAS] Inventory row not found:', id);
          return Response.json({ 
            error: 'Inventory slot not found. Please ask an admin to generate inventory for this event.' 
          }, { status: 404 });
        }
        
        const current = Number(row.availableSpots || 0);
        console.log('[leagueReserveSlotCAS] Current available spots:', current, 'for record ID:', row.id);
        
        if (current <= 0) {
          console.warn('[leagueReserveSlotCAS] No spots left for:', id);
          return Response.json({ error: 'No spots left' }, { status: 400 });
        }

        const expectedVersion = Number(row.version || 0);
        console.log('[leagueReserveSlotCAS] Attempting update with version:', expectedVersion);

        try {
          // Use the actual record ID, not the composite ID
          await base44.asServiceRole.entities.LeagueSpotInventory.update(row.id, {
            availableSpots: current - 1,
            version: expectedVersion + 1
          });

          console.log('[leagueReserveSlotCAS] Successfully reserved slot, new count:', current - 1);
          return Response.json({
            ok: true,
            remaining: current - 1,
            version: expectedVersion + 1
          });
        } catch (updateError) {
          console.error('[leagueReserveSlotCAS] Update failed on attempt', attempt + 1, ':', updateError.message);
          console.error('[leagueReserveSlotCAS] Update error details:', updateError);
          
          // Version conflict or update failed, retry
          if (attempt === 4) {
            console.error('[leagueReserveSlotCAS] Max retries reached');
            return Response.json({ 
              error: 'This slot was just booked by someone else - please select another time or refresh the page' 
            }, { status: 409 });
          }
          
          // Wait briefly before retry
          await new Promise(resolve => setTimeout(resolve, 100 * (attempt + 1)));
          continue; // Retry the loop
        }
      } catch (fetchError) {
        console.error('[leagueReserveSlotCAS] Error in attempt', attempt + 1, ':', fetchError.message);
        console.error('[leagueReserveSlotCAS] Fetch error details:', fetchError);
        
        // If it's the last attempt, return error
        if (attempt === 4) {
          return Response.json({ 
            error: `Failed to reserve slot: ${fetchError.message}. Please contact support.` 
          }, { status: 500 });
        }
        
        // Wait and retry
        await new Promise(resolve => setTimeout(resolve, 100 * (attempt + 1)));
        continue;
      }
    }

    return Response.json({ error: 'Reservation failed after multiple attempts' }, { status: 500 });

  } catch (error) {
    console.error('[leagueReserveSlotCAS] Fatal error:', error.message);
    console.error('[leagueReserveSlotCAS] Fatal error stack:', error.stack);
    return Response.json({ 
      error: `Reservation failed: ${error.message}` 
    }, { status: 500 });
  }
});