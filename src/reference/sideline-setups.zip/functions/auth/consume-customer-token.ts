import { cookie, signSession, redirect } from '../lib/session';

Deno.serve(async (req) => {
  const url = new URL(req.url);
  const email = url.searchParams.get('email') || '';
  const name = url.searchParams.get('name') || '';
  const to = url.searchParams.get('redirect') || '/mybookings';
  
  if (!email) return redirect('/signin');
  
  const headers = new Headers();
  const session = await signSession({ email, name }, 'customer');
  cookie.set(headers, 'customer_session', session, { maxAge: 60*60*24*30 });
  
  return redirect(to, headers);
});