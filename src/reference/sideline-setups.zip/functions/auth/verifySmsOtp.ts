import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

function normalizeE164(p) {
  if (!p) return "";
  const d = ("" + p).replace(/\D/g, "");
  if (d.length === 10) return `+1${d}`;
  if (d.length === 11 && d.startsWith("1")) return `+${d}`;
  if (p.startsWith("+")) return p;
  return "";
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { kind = "customer_sms", phone, code } = await req.json();
    
    const to = normalizeE164(phone);
    if (!to || !code) {
      return Response.json({ error: "Phone and code required" }, { status: 400 });
    }

    console.log('[verifySmsOtp] Verifying OTP for:', to, 'kind:', kind);

    // Find the token
    const tokens = await base44.asServiceRole.entities.MagicTokens.filter({
      kind,
      email: to,
      code
    });

    const row = tokens?.[0];
    
    if (!row) {
      console.log('[verifySmsOtp] Token not found');
      return Response.json({ error: "Invalid code" }, { status: 401 });
    }

    if (row.consumedAt) {
      console.log('[verifySmsOtp] Token already used');
      return Response.json({ error: "Code already used" }, { status: 401 });
    }

    if (new Date(row.expiresAt).getTime() < Date.now()) {
      console.log('[verifySmsOtp] Token expired');
      return Response.json({ error: "Code expired" }, { status: 401 });
    }

    // Mark token as consumed
    await base44.asServiceRole.entities.MagicTokens.update(row.id, {
      consumedAt: new Date().toISOString()
    });

    // Handle different auth types
    if (kind === "employee_sms") {
      const employees = await base44.asServiceRole.entities.Employees.filter({
        phone: to,
        status: "active"
      });
      
      const emp = employees?.[0];
      if (!emp) {
        console.log('[verifySmsOtp] No active employee found');
        return Response.json({ error: "No active employee account found" }, { status: 401 });
      }

      console.log('[verifySmsOtp] Employee authenticated:', emp.id);
      return Response.json({
        ok: true,
        session: {
          kind: "employee",
          employeeId: emp.id,
          role: emp.role,
          fullName: emp.fullName,
          phone: emp.phone
        }
      });
    } else {
      // Customer auth by phone
      console.log('[verifySmsOtp] Customer authenticated:', to);
      return Response.json({
        ok: true,
        session: {
          kind: "customer",
          customerPhone: to
        }
      });
    }
  } catch (error) {
    console.error('[verifySmsOtp] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});