import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

// Inline sendSms helper
function env(name) {
  const v = Deno.env.get(name);
  if (!v) return "";
  return v;
}

function getAuthHeader() {
  const apiKey = env("TWILIO_API_KEY");
  const apiSecret = env("TWILIO_API_SECRET");
  const sid = env("TWILIO_ACCOUNT_SID");
  const authToken = env("TWILIO_AUTH_TOKEN");

  if (apiKey && apiSecret) return "Basic " + btoa(`${apiKey}:${apiSecret}`);
  if (sid && authToken)  return "Basic " + btoa(`${sid}:${authToken}`);
  throw new Error("Missing Twilio credentials");
}

async function sendSms(to, body) {
  if (!to || !body) throw new Error("sendSms: missing parameters");

  const accountSid = env("TWILIO_ACCOUNT_SID");
  if (!accountSid) throw new Error("Missing TWILIO_ACCOUNT_SID");

  const mg = env("TWILIO_MESSAGING_SERVICE_SID");
  const legacyFrom = env("TWILIO_FROM");

  const form = new URLSearchParams();
  form.set("To", to);
  form.set("Body", body);
  if (mg) form.set("MessagingServiceSid", mg);
  else if (legacyFrom) form.set("From", legacyFrom);
  else throw new Error("No sender configured");

  const res = await fetch(
    `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
    {
      method: "POST",
      headers: { Authorization: getAuthHeader(), "Content-Type": "application/x-www-form-urlencoded" },
      body: form.toString(),
    }
  );

  if (!res.ok) throw new Error(`Twilio error ${res.status}`);
  return res.json();
}

function normalizeE164(p) {
  if (!p) return "";
  const d = ("" + p).replace(/\D/g, "");
  if (d.length === 10) return `+1${d}`;
  if (d.length === 11 && d.startsWith("1")) return `+${d}`;
  if (p.startsWith("+")) return p;
  return "";
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { kind = "customer_sms", phone } = await req.json();
    
    const to = normalizeE164(phone);
    if (!to) {
      return Response.json({ error: "Invalid phone number" }, { status: 400 });
    }

    console.log('[requestSmsOtp] Sending OTP to:', to, 'kind:', kind);

    const code = String(Math.floor(100000 + Math.random() * 900000));
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

    await base44.asServiceRole.entities.MagicTokens.create({
      kind,
      email: to,
      code,
      expiresAt,
      consumedAt: null,
      meta: {}
    });

    try {
      await sendSms(to, `Your Sideline Setups login code is ${code}. It expires in 10 minutes.`);
      console.log('[requestSmsOtp] SMS sent successfully');
    } catch (smsError) {
      console.error('[requestSmsOtp] SMS send failed:', smsError);
      return Response.json({ error: "Failed to send SMS" }, { status: 500 });
    }

    return Response.json({ ok: true });
  } catch (error) {
    console.error('[requestSmsOtp] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});