import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  console.log('[bulkCreateFieldsWithTemplate] Starting function');
  
  try {
    const base44 = createClientFromRequest(req);
    
    // Check authentication
    const user = await base44.auth.me();
    if (!user) {
      console.error('[bulkCreateFieldsWithTemplate] Unauthorized - no user');
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    console.log('[bulkCreateFieldsWithTemplate] User authenticated:', user.email);

    // Parse request body
    const body = await req.json();
    console.log('[bulkCreateFieldsWithTemplate] Request body:', body);
    
    const { templateId, parkId, count, baseName, imageUrl } = body;
    
    // Validate required fields
    if (!parkId || !count) {
      console.error('[bulkCreateFieldsWithTemplate] Missing required fields');
      return Response.json({ 
        success: false,
        error: 'parkId and count are required' 
      }, { status: 400 });
    }

    if (count < 1 || count > 50) {
      console.error('[bulkCreateFieldsWithTemplate] Invalid count:', count);
      return Response.json({ 
        success: false,
        error: 'Count must be between 1 and 50' 
      }, { status: 400 });
    }

    // Check if park exists
    const park = await base44.asServiceRole.entities.Parks.get(parkId);
    if (!park) {
      console.error('[bulkCreateFieldsWithTemplate] Park not found:', parkId);
      return Response.json({ 
        success: false,
        error: 'Park not found' 
      }, { status: 404 });
    }
    
    console.log('[bulkCreateFieldsWithTemplate] Park found:', park.name);

    // Get template if provided
    let template = null;
    if (templateId) {
      template = await base44.asServiceRole.entities.SpotTemplate.get(templateId);
      if (!template) {
        console.error('[bulkCreateFieldsWithTemplate] Template not found:', templateId);
        return Response.json({ 
          success: false,
          error: 'Template not found' 
        }, { status: 404 });
      }
      console.log('[bulkCreateFieldsWithTemplate] Template found:', template.name);
    }

    const fieldBaseName = baseName || "Field";
    const createdFields = [];

    console.log('[bulkCreateFieldsWithTemplate] Creating', count, 'fields with base name:', fieldBaseName);

    // Create fields
    for (let i = 1; i <= count; i++) {
      const fieldName = `${fieldBaseName} ${i}`;
      
      console.log('[bulkCreateFieldsWithTemplate] Creating field:', fieldName);
      
      const newField = await base44.asServiceRole.entities.Fields.create({
        parkId: park.id,
        name: fieldName,
        imageUrl: imageUrl || "",
        maxLeagueSpots: 2
      });

      console.log('[bulkCreateFieldsWithTemplate] Field created with ID:', newField.id);

      // Apply template spots if provided
      let createdSpots = [];
      if (template && template.spots && template.spots.length > 0) {
        console.log('[bulkCreateFieldsWithTemplate] Applying', template.spots.length, 'spots to field');
        
        for (const spotData of template.spots) {
          const spotLabel = spotData.label;

          const newSpot = await base44.asServiceRole.entities.Spots.create({
            fieldId: newField.id,
            label: spotLabel,
            x: spotData.x || 50,
            y: spotData.y || 50,
            isActive: true
          });
          
          createdSpots.push(newSpot);
        }
        
        console.log('[bulkCreateFieldsWithTemplate] Created', createdSpots.length, 'spots');
      }

      createdFields.push({
        field: newField,
        spotsCreated: createdSpots.length
      });
    }

    console.log('[bulkCreateFieldsWithTemplate] Success! Created', createdFields.length, 'fields');

    return Response.json({ 
      success: true, 
      fieldsCreated: createdFields.length,
      fields: createdFields,
      message: `Successfully created ${createdFields.length} field${createdFields.length !== 1 ? 's' : ''}${template ? ` with ${template.spots?.length || 0} spots each` : ''}`
    });

  } catch (error) {
    console.error('[bulkCreateFieldsWithTemplate] Error:', error);
    console.error('[bulkCreateFieldsWithTemplate] Error stack:', error.stack);
    
    return Response.json({ 
      success: false,
      error: error.message || 'Failed to create fields' 
    }, { status: 500 });
  }
});