export function genTimeSlots(startHHmm, endHHmm, minutes) {
  if (!startHHmm || !endHHmm || !minutes) return [];
  
  const [sh, sm] = startHHmm.split(":").map(Number);
  const [eh, em] = endHHmm.split(":").map(Number);
  const end = eh * 60 + em;
  let cur = sh * 60 + sm;
  const out = [];
  
  while (cur <= end) {
    const hh = String(Math.floor(cur / 60)).padStart(2, "0");
    const mm = String(cur % 60).padStart(2, "0");
    out.push(`${hh}:${mm}`);
    cur += Number(minutes);
    if (cur + Number(minutes) > end + Number(minutes)) break;
  }
  
  return out;
}

export function invId(eventId, date, parkId, fieldId, time) {
  return `${eventId}:${date}:${parkId}:${fieldId}:${time}`;
}