import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

const PAYPAL_BASE = 'https://api-m.sandbox.paypal.com';

// Token cache to reuse PayPal OAuth tokens
let cached = { token: null, expiresAt: 0 };

async function getPayPalAccessToken(clientId, clientSecret) {
  const now = Date.now();
  
  // Return cached token if still valid (with 5s safety margin)
  if (cached.token && cached.expiresAt - 5000 > now) {
    return cached.token;
  }

  // Request new token
  const auth = btoa(`${clientId}:${clientSecret}`);
  const res = await fetch('https://api-m.sandbox.paypal.com/v1/oauth2/token', {
    method: 'POST',
    headers: { 
      'Authorization': `Basic ${auth}`, 
      'Content-Type': 'application/x-www-form-urlencoded' 
    },
    body: 'grant_type=client_credentials'
  });

  if (!res.ok) {
    const errorText = await res.text();
    console.error('PayPal token error:', errorText);
    throw new Error('Failed to get PayPal access token');
  }

  const json = await res.json();
  const ttlMs = (json.expires_in || 300) * 1000;
  
  cached.token = json.access_token;
  cached.expiresAt = Date.now() + ttlMs;
  
  return cached.token;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { total, currency } = await req.json();
    
    if (!total || total <= 0) {
      return Response.json({ error: 'Invalid total amount' }, { status: 400 });
    }

    const clientId = Deno.env.get('PAYPAL_CLIENT_ID');
    const clientSecret = Deno.env.get('PAYPAL_CLIENT_SECRET');

    if (!clientId || !clientSecret) {
      return Response.json({ error: 'PayPal credentials not configured' }, { status: 500 });
    }

    // Get cached or fresh access token
    const access_token = await getPayPalAccessToken(clientId, clientSecret);

    // Create order
    const orderRes = await fetch(`${PAYPAL_BASE}/v2/checkout/orders`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${access_token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        intent: 'CAPTURE',
        purchase_units: [
          {
            amount: {
              currency_code: currency || 'USD',
              value: total.toFixed(2)
            },
          },
        ],
      }),
    });

    if (!orderRes.ok) {
      const errorText = await orderRes.text();
      console.error('PayPal order creation error:', errorText);
      return Response.json({ error: 'Failed to create PayPal order' }, { status: 500 });
    }

    const order = await orderRes.json();
    return Response.json(order);

  } catch (error) {
    console.error('Error in paypalCreateOrder:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});