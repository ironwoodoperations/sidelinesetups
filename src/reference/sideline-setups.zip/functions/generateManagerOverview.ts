import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { date } = await req.json();

    if (!date) {
      return Response.json({ error: 'date parameter required' }, { status: 400 });
    }

    // Fetch bookings for the date
    const bookings = await base44.asServiceRole.entities.Bookings.filter({
      date: date,
      status: ['confirmed', 'setup', 'completed']
    });

    // Fetch related data
    const [events, parks, fields] = await Promise.all([
      base44.asServiceRole.entities.Events.list(),
      base44.asServiceRole.entities.Parks.list(),
      base44.asServiceRole.entities.Fields.list()
    ]);

    // Create lookup maps
    const eventMap = {};
    events.forEach(e => eventMap[e.id] = e);

    const parkMap = {};
    parks.forEach(p => parkMap[p.id] = p);

    const fieldMap = {};
    fields.forEach(f => fieldMap[f.id] = f);

    // Build overview data
    const overview = bookings.map(booking => ({
      bookingId: booking.id,
      customerName: booking.fullName || 'Unknown',
      eventName: eventMap[booking.eventId]?.name || 'Unknown Event',
      parkName: parkMap[booking.parkId]?.name || 'Unknown Park',
      fieldName: fieldMap[booking.fieldId]?.name || 'Unknown Field',
      status: booking.status,
      gameTimes: booking.gameTimes || []
    }));

    // Sort by Event > Park > Field
    overview.sort((a, b) => {
      const eventCompare = a.eventName.localeCompare(b.eventName);
      if (eventCompare !== 0) return eventCompare;

      const parkCompare = a.parkName.localeCompare(b.parkName);
      if (parkCompare !== 0) return parkCompare;

      return a.fieldName.localeCompare(b.fieldName);
    });

    return Response.json(overview);

  } catch (error) {
    console.error('Error generating manager overview:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});