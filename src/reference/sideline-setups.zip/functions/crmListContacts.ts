import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

function normalizeEmail(s) {
  return (s || "").trim().toLowerCase();
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Verify authentication
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { q = "", tag = "" } = await req.json().catch(() => ({}));
    
    const rows = await base44.asServiceRole.entities.Contacts.list();
    const qq = (q || "").toLowerCase();

    const filtered = (rows || []).filter((r) => {
      const tagOk = tag ? (r.tags || []).includes(tag) : true;
      const searchOk = !qq ? true :
        (r.fullName || "").toLowerCase().includes(qq) ||
        normalizeEmail(r.email).includes(qq) ||
        (r.phone || "").includes(qq);
      return tagOk && searchOk;
    });

    return Response.json(filtered);
  } catch (error) {
    console.error("CRM list error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});