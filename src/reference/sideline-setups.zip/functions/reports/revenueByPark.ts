import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(req.url);
    const from = url.searchParams.get('from');
    const to = url.searchParams.get('to');

    // Fetch bookings and parks
    const [bookings, parks] = await Promise.all([
      base44.asServiceRole.entities.Bookings.filter({
        status: ['confirmed', 'setup', 'completed']
      }),
      base44.asServiceRole.entities.Parks.list()
    ]);

    // Create park lookup
    const parkMap = {};
    parks.forEach(p => {
      parkMap[p.id] = p.name;
    });

    // Group by park
    const grouped = {};
    
    for (const booking of bookings) {
      const createdDate = new Date(booking.created_date);
      const saleDate = createdDate.toISOString().split('T')[0];
      
      // Apply date filters
      if (from && saleDate < from) continue;
      if (to && saleDate > to) continue;

      const parkId = booking.parkId || 'unknown';
      const parkName = parkMap[parkId] || 'Unknown Park';

      if (!grouped[parkId]) {
        grouped[parkId] = {
          park_id: parkId,
          park_name: parkName,
          gross_cents: 0,
          tax_cents: 0,
          fee_cents: 0,
          net_cents: 0
        };
      }

      const totalCents = booking.totalCents || 0;
      const taxCents = booking.taxCents || 0;
      const feeCents = booking.feeCents || 0;

      grouped[parkId].gross_cents += totalCents;
      grouped[parkId].tax_cents += taxCents;
      grouped[parkId].fee_cents += feeCents;
      grouped[parkId].net_cents += (totalCents - taxCents - feeCents);
    }

    // Convert to array and sort by net revenue
    const result = Object.values(grouped).sort((a, b) => 
      b.net_cents - a.net_cents
    );

    return Response.json(result);
  } catch (error) {
    console.error('Error in revenueByPark:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});