import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(req.url);
    const from = url.searchParams.get('from');
    const to = url.searchParams.get('to');

    // Fetch bookings, parks, and fields
    const [bookings, parks, fields] = await Promise.all([
      base44.asServiceRole.entities.Bookings.list(),
      base44.asServiceRole.entities.Parks.list(),
      base44.asServiceRole.entities.Fields.list()
    ]);

    // Create lookups
    const parkMap = {};
    parks.forEach(p => parkMap[p.id] = p.name);
    
    // Calculate field capacity per park
    const parkCapacity = {};
    fields.forEach(f => {
      if (!parkCapacity[f.parkId]) parkCapacity[f.parkId] = 0;
      parkCapacity[f.parkId] += 2; // Assume 2 spots per field
    });

    // Group by park and day
    const grouped = {};
    
    for (const booking of bookings) {
      const serviceDate = booking.date || new Date(booking.created_date).toISOString().split('T')[0];
      
      // Apply date filters
      if (from && serviceDate < from) continue;
      if (to && serviceDate > to) continue;

      const parkId = booking.parkId || 'unknown';
      const key = `${parkId}-${serviceDate}`;

      if (!grouped[key]) {
        grouped[key] = {
          park_id: parkId,
          park_name: parkMap[parkId] || 'Unknown',
          day: serviceDate,
          bookings_count: 0,
          capacity_estimate: parkCapacity[parkId] || 0
        };
      }

      if (['confirmed', 'setup', 'completed'].includes(booking.status)) {
        grouped[key].bookings_count += 1;
      }
    }

    // Convert to array and sort
    const result = Object.values(grouped).sort((a, b) => {
      const dateCompare = b.day.localeCompare(a.day);
      if (dateCompare !== 0) return dateCompare;
      return a.park_name.localeCompare(b.park_name);
    });

    return Response.json(result);
  } catch (error) {
    console.error('Error in utilizationByParkDay:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});