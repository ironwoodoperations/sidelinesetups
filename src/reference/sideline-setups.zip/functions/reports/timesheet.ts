import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(req.url);
    const from = url.searchParams.get('from');
    const to = url.searchParams.get('to');

    // Fetch time entries and employees
    const [timeEntries, employees] = await Promise.all([
      base44.asServiceRole.entities.TimeEntries.list(),
      base44.asServiceRole.entities.Employees.list()
    ]);

    // Create employee lookup
    const employeeMap = {};
    employees.forEach(e => {
      employeeMap[e.id] = {
        name: e.fullName,
        rateCents: e.rateCents || 0
      };
    });

    // Process time entries
    const result = [];
    
    for (const entry of timeEntries) {
      if (!entry.clockOutAt) continue; // Skip open shifts

      const clockIn = new Date(entry.clockInAt);
      const clockOut = new Date(entry.clockOutAt);
      const entryDate = clockIn.toISOString().split('T')[0];
      
      // Apply date filters
      if (from && entryDate < from) continue;
      if (to && entryDate > to) continue;

      const hours = (clockOut - clockIn) / (1000 * 60 * 60);
      const employee = employeeMap[entry.employeeId] || { name: 'Unknown', rateCents: 0 };
      const rateCents = employee.rateCents;
      const payCents = hours * rateCents;

      result.push({
        time_id: entry.id,
        employee_id: entry.employeeId,
        employee_name: employee.name,
        start_local: entry.clockInAt,
        end_local: entry.clockOutAt,
        hours: Math.round(hours * 100) / 100,
        rate_cents: rateCents,
        pay_cents: Math.round(payCents)
      });
    }

    // Sort by start time descending
    result.sort((a, b) => 
      new Date(b.start_local) - new Date(a.start_local)
    );

    return Response.json(result);
  } catch (error) {
    console.error('Error in timesheet:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});