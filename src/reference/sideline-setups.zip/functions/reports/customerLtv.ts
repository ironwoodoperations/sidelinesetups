import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(req.url);
    const from = url.searchParams.get('from');
    const to = url.searchParams.get('to');

    // Fetch all bookings
    const bookings = await base44.asServiceRole.entities.Bookings.list();

    // Group by customer email
    const grouped = {};
    
    for (const booking of bookings) {
      const createdDate = new Date(booking.created_date);
      const saleDate = createdDate.toISOString().split('T')[0];
      
      // Apply date filters
      if (from && saleDate < from) continue;
      if (to && saleDate > to) continue;

      const email = booking.contactEmail || 'unknown';

      if (!grouped[email]) {
        grouped[email] = {
          customer_email: email,
          first_seen: booking.created_date,
          orders: 0,
          gross_cents: 0
        };
      }

      // Update first seen
      if (booking.created_date < grouped[email].first_seen) {
        grouped[email].first_seen = booking.created_date;
      }

      // Count orders and revenue for confirmed/setup/complete only
      if (['confirmed', 'setup', 'completed'].includes(booking.status)) {
        grouped[email].orders += 1;
        grouped[email].gross_cents += (booking.totalCents || 0);
      }
    }

    // Convert to array and sort by gross revenue
    const result = Object.values(grouped)
      .filter(c => c.orders > 0) // Only customers with completed orders
      .sort((a, b) => b.gross_cents - a.gross_cents);

    return Response.json(result);
  } catch (error) {
    console.error('Error in customerLtv:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});