import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(req.url);
    const from = url.searchParams.get('from');
    const to = url.searchParams.get('to');

    // Fetch bookings and packages
    const [bookings, packages] = await Promise.all([
      base44.asServiceRole.entities.Bookings.filter({
        status: ['confirmed', 'setup', 'completed']
      }),
      base44.asServiceRole.entities.Packages.list()
    ]);

    // Create package lookup
    const packageMap = {};
    packages.forEach(p => {
      packageMap[p.id] = p.name;
    });

    // Group by package
    const grouped = {};
    
    for (const booking of bookings) {
      const createdDate = new Date(booking.created_date);
      const saleDate = createdDate.toISOString().split('T')[0];
      
      // Apply date filters
      if (from && saleDate < from) continue;
      if (to && saleDate > to) continue;

      const packageId = booking.packageId || 'unknown';
      const packageName = packageMap[packageId] || 'Unknown Package';

      if (!grouped[packageId]) {
        grouped[packageId] = {
          package_name: packageName,
          orders: 0,
          gross_cents: 0
        };
      }

      grouped[packageId].orders += 1;
      grouped[packageId].gross_cents += (booking.totalCents || 0);
    }

    // Convert to array and sort by order count
    const result = Object.values(grouped).sort((a, b) => 
      b.orders - a.orders
    );

    return Response.json(result);
  } catch (error) {
    console.error('Error in packageMix:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});