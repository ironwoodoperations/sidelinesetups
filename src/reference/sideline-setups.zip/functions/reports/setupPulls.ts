import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(req.url);
    const from = url.searchParams.get('from');
    const to = url.searchParams.get('to');

    // Fetch bookings, parks, fields, and packages
    const [bookings, parks, fields, packages] = await Promise.all([
      base44.asServiceRole.entities.Bookings.filter({
        status: ['confirmed', 'setup']
      }),
      base44.asServiceRole.entities.Parks.list(),
      base44.asServiceRole.entities.Fields.list(),
      base44.asServiceRole.entities.Packages.list()
    ]);

    // Create lookups
    const parkMap = {};
    parks.forEach(p => parkMap[p.id] = p.name);
    
    const fieldMap = {};
    fields.forEach(f => fieldMap[f.id] = f.name);
    
    const packageMap = {};
    packages.forEach(p => packageMap[p.id] = p.name);

    // Format results
    const result = [];
    
    for (const booking of bookings) {
      const serviceDate = booking.date || new Date(booking.created_date).toISOString().split('T')[0];
      
      // Apply date filters
      if (from && serviceDate < from) continue;
      if (to && serviceDate > to) continue;

      result.push({
        booking_id: booking.id,
        event_id: booking.eventId,
        park_id: booking.parkId,
        park_name: parkMap[booking.parkId] || 'Unknown',
        field_id: booking.fieldId,
        field_name: fieldMap[booking.fieldId] || 'Unknown',
        service_date: serviceDate,
        customer_name: booking.fullName || booking.contactEmail,
        package_name: packageMap[booking.packageId] || 'Unknown',
        spot: booking.spotId || booking.setupSideLabel || 'TBD',
        status: booking.status
      });
    }

    // Sort by date and park
    result.sort((a, b) => {
      const dateCompare = a.service_date.localeCompare(b.service_date);
      if (dateCompare !== 0) return dateCompare;
      return a.park_name.localeCompare(b.park_name);
    });

    return Response.json(result);
  } catch (error) {
    console.error('Error in setupPulls:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});