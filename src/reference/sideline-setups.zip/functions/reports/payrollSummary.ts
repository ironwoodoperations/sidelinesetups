import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(req.url);
    const from = url.searchParams.get('from');
    const to = url.searchParams.get('to');

    // Fetch time entries and employees
    const [timeEntries, employees] = await Promise.all([
      base44.asServiceRole.entities.TimeEntries.list(),
      base44.asServiceRole.entities.Employees.list()
    ]);

    // Create employee lookup
    const employeeMap = {};
    employees.forEach(e => {
      employeeMap[e.id] = {
        name: e.fullName,
        rateCents: e.rateCents || 0
      };
    });

    // Group by employee and week
    const grouped = {};
    
    for (const entry of timeEntries) {
      if (!entry.clockOutAt) continue;

      const clockIn = new Date(entry.clockInAt);
      const clockOut = new Date(entry.clockOutAt);
      const entryDate = clockIn.toISOString().split('T')[0];
      
      // Apply date filters
      if (from && entryDate < from) continue;
      if (to && entryDate > to) continue;

      // Calculate week start (Sunday)
      const weekStart = new Date(clockIn);
      weekStart.setDate(clockIn.getDate() - clockIn.getDay());
      const weekKey = weekStart.toISOString().split('T')[0];

      const hours = (clockOut - clockIn) / (1000 * 60 * 60);
      const employee = employeeMap[entry.employeeId] || { name: 'Unknown', rateCents: 0 };
      const rateCents = employee.rateCents;
      const payCents = hours * rateCents;

      const key = `${entry.employeeId}-${weekKey}`;
      
      if (!grouped[key]) {
        grouped[key] = {
          employee_id: entry.employeeId,
          employee_name: employee.name,
          week_start: weekKey,
          hours: 0,
          total_rate_cents: 0,
          count: 0,
          pay_cents: 0
        };
      }

      grouped[key].hours += hours;
      grouped[key].total_rate_cents += rateCents;
      grouped[key].count += 1;
      grouped[key].pay_cents += payCents;
    }

    // Calculate averages and format result
    const result = Object.values(grouped).map(g => ({
      employee_id: g.employee_id,
      employee_name: g.employee_name,
      week_start: g.week_start,
      hours: Math.round(g.hours * 100) / 100,
      avg_rate_cents: Math.round(g.total_rate_cents / g.count),
      pay_cents: Math.round(g.pay_cents)
    }));

    // Sort by week descending, then employee name
    result.sort((a, b) => {
      const weekCompare = b.week_start.localeCompare(a.week_start);
      if (weekCompare !== 0) return weekCompare;
      return a.employee_name.localeCompare(b.employee_name);
    });

    return Response.json(result);
  } catch (error) {
    console.error('Error in payrollSummary:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});