import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(req.url);
    const from = url.searchParams.get('from');
    const to = url.searchParams.get('to');

    // Fetch all confirmed/setup/complete bookings
    const bookings = await base44.asServiceRole.entities.Bookings.filter({
      status: ['confirmed', 'setup', 'completed']
    });

    // Extract add-ons from line items
    const grouped = {};
    
    for (const booking of bookings) {
      const createdDate = new Date(booking.created_date);
      const saleDate = createdDate.toISOString().split('T')[0];
      
      // Apply date filters
      if (from && saleDate < from) continue;
      if (to && saleDate > to) continue;

      const lineItems = booking.lineItemsJson || [];
      
      for (const item of lineItems) {
        // Check if it's an add-on (has type: "ADDON" in meta)
        if (item.meta && item.meta.type === 'ADDON') {
          const label = item.itemName || 'Unknown Add-on';
          
          if (!grouped[label]) {
            grouped[label] = {
              label,
              qty: 0,
              total_cents: 0
            };
          }

          grouped[label].qty += (item.qty || 0);
          grouped[label].total_cents += (item.totalCents || 0);
        }
      }
    }

    // Convert to array and sort by total revenue
    const result = Object.values(grouped).sort((a, b) => 
      b.total_cents - a.total_cents
    );

    return Response.json(result);
  } catch (error) {
    console.error('Error in addonSales:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});