import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(req.url);
    const from = url.searchParams.get('from');
    const to = url.searchParams.get('to');

    // Fetch all confirmed/setup/complete bookings
    const bookings = await base44.asServiceRole.entities.Bookings.filter({
      status: ['confirmed', 'setup', 'completed']
    });

    // Group by date and aggregate
    const grouped = {};
    
    for (const booking of bookings) {
      const createdDate = new Date(booking.created_date);
      const saleDate = createdDate.toISOString().split('T')[0]; // YYYY-MM-DD
      
      // Apply date filters
      if (from && saleDate < from) continue;
      if (to && saleDate > to) continue;

      if (!grouped[saleDate]) {
        grouped[saleDate] = {
          sale_date: saleDate,
          gross_cents: 0,
          tax_cents: 0,
          fee_cents: 0,
          net_cents: 0
        };
      }

      const totalCents = booking.totalCents || 0;
      const taxCents = booking.taxCents || 0;
      const feeCents = booking.feeCents || 0;

      grouped[saleDate].gross_cents += totalCents;
      grouped[saleDate].tax_cents += taxCents;
      grouped[saleDate].fee_cents += feeCents;
      grouped[saleDate].net_cents += (totalCents - taxCents - feeCents);
    }

    // Convert to array and sort
    const result = Object.values(grouped).sort((a, b) => 
      b.sale_date.localeCompare(a.sale_date)
    );

    return Response.json(result);
  } catch (error) {
    console.error('Error in revenueByDay:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});