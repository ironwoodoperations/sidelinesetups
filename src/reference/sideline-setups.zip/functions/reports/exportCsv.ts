import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

function toCSV(rows) {
  if (!rows || rows.length === 0) return "";
  
  const headers = Object.keys(rows[0]);
  const csvHeaders = headers.join(",");
  
  const csvRows = rows.map(row => {
    return headers.map(header => {
      const value = row[header];
      // Escape quotes and wrap in quotes if contains comma or quote
      if (value === null || value === undefined) return "";
      const stringValue = String(value);
      if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
        return `"${stringValue.replace(/"/g, '""')}"`;
      }
      return stringValue;
    }).join(",");
  });
  
  return [csvHeaders, ...csvRows].join("\n");
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(req.url);
    const report = url.searchParams.get('report') || 'revenueByDay';
    const from = url.searchParams.get('from') || '';
    const to = url.searchParams.get('to') || '';

    // Build query params for the report function
    const params = new URLSearchParams();
    if (from) params.set('from', from);
    if (to) params.set('to', to);

    // Call the appropriate report function
    const reportResponse = await base44.functions.invoke(
      `reports/${report}`,
      Object.fromEntries(params)
    );

    if (!reportResponse.data) {
      return Response.json({ error: 'No data returned from report' }, { status: 500 });
    }

    const csv = toCSV(reportResponse.data);
    
    return new Response(csv, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="${report}-${from || 'all'}-${to || 'all'}.csv"`
      }
    });
  } catch (error) {
    console.error('Error in exportCsv:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});