import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    // Admin/staff only
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Unauthorized' }, { status: 403 });
    }
    
    const { bookingId } = await req.json();
    
    if (!bookingId) {
      return Response.json({ error: 'bookingId required' }, { status: 400 });
    }
    
    // Get booking
    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }
    
    // Approve skip
    await base44.asServiceRole.entities.Bookings.update(bookingId, {
      idSkipApprovedBy: user.email,
      idSkipApprovedAt: new Date().toISOString()
    });
    
    return Response.json({ 
      success: true,
      message: 'ID requirement waived by staff' 
    });
  } catch (error) {
    console.error('[approveIdSkip] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});