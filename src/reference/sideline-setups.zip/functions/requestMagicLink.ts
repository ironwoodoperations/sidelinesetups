import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { kind = "customer", email } = await req.json();
    
    if (!email) {
      return Response.json({ error: 'Email required' }, { status: 400 });
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    console.log('[requestMagicLink] Request for:', kind, normalizedEmail);

    const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
    const MAIL_FROM = Deno.env.get("MAIL_FROM") || Deno.env.get("EMAIL_FROM_ADDRESS") || "no-reply@sidelinesetups.com";
    const PUBLIC_BASE_URL = Deno.env.get("SITE_DOMAIN") || "https://fieldflex.rentals";
    
    if (!RESEND_API_KEY) {
      console.error('[requestMagicLink] Missing RESEND_API_KEY');
      return Response.json({ error: "Email service not configured" }, { status: 500 });
    }

    // Generate token
    const code = Math.random().toString(36).slice(2, 12);
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();

    // Store token
    await base44.asServiceRole.entities.MagicTokens.create({
      kind,
      email: normalizedEmail,
      code,
      expiresAt,
      consumedAt: null,
      meta: {}
    });

    // Send email - USE CAPITAL S in SignIn
    const link = `${PUBLIC_BASE_URL}/SignIn?token=${encodeURIComponent(code)}&kind=${kind}`;
    const brandName = Deno.env.get("BRAND_NAME") || "Sideline Setups";

    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: MAIL_FROM,
        to: [normalizedEmail],
        subject: `${brandName} - Your Sign-In Link`,
        html: `
          <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h2 style="color: #003f5c; margin-bottom: 20px;">Sign in to ${brandName}</h2>
            <p style="font-size: 16px; line-height: 1.6; color: #333; margin-bottom: 24px;">
              Click the button below to sign in to your account. This link will expire in 15 minutes.
            </p>
            <div style="text-align: center; margin: 32px 0;">
              <a href="${link}" 
                 style="background: linear-gradient(to right, #003f5c, #00507a); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block;">
                Sign In Now
              </a>
            </div>
            <p style="font-size: 14px; color: #666; margin-top: 24px;">
              Or copy and paste this link into your browser:<br>
              <a href="${link}" style="color: #003f5c; word-break: break-all;">${link}</a>
            </p>
            <p style="font-size: 12px; color: #999; margin-top: 32px; padding-top: 20px; border-top: 1px solid #eee;">
              If you didn't request this email, you can safely ignore it.
            </p>
          </div>
        `
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[requestMagicLink] Resend error:', errorText);
      return Response.json({ error: "Failed to send email" }, { status: 500 });
    }

    console.log('[requestMagicLink] Magic link sent to:', normalizedEmail);
    return Response.json({ ok: true });
  } catch (error) {
    console.error('[requestMagicLink] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});