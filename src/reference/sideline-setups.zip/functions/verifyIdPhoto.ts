import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const { bookingId, approved, skipWithWarning } = await req.json();
    
    if (!bookingId) {
      return Response.json({ error: 'bookingId required' }, { status: 400 });
    }
    
    // Get booking
    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }
    
    // Try to get staff email (might be customer doing this)
    let staffEmail = 'customer';
    try {
      const user = await base44.auth.me();
      if (user) staffEmail = user.email;
    } catch (e) {
      // Customer flow - no user
    }
    
    if (skipWithWarning) {
      // Staff chose to check in without ID - mark for review
      await base44.asServiceRole.entities.Bookings.update(bookingId, {
        idSkipApprovedBy: staffEmail,
        idSkipApprovedAt: new Date().toISOString(),
        needsIdReview: true
      });
      
      return Response.json({ 
        success: true,
        message: 'Checked in without ID - marked for admin review' 
      });
    }
    
    if (approved) {
      // ID verified - mark as verified
      await base44.asServiceRole.entities.Bookings.update(bookingId, {
        idVerifiedBy: staffEmail,
        idVerifiedAt: new Date().toISOString(),
        needsIdReview: false
      });
      
      return Response.json({ 
        success: true,
        message: 'ID verified successfully' 
      });
    } else {
      // ID rejected - clear the photo so they can retake
      await base44.asServiceRole.entities.Bookings.update(bookingId, {
        idPhotoUri: null,
        idPhotoUploadedAt: null,
        idVerifiedBy: null,
        idVerifiedAt: null
      });
      
      return Response.json({ 
        success: true,
        message: 'ID rejected - please retake photo' 
      });
    }
    
  } catch (error) {
    console.error('[verifyIdPhoto] Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});