import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

// Inline sendSms helper to avoid import issues
function env(name) {
  const v = Deno.env.get(name);
  if (!v) return "";
  return v;
}

function getAuthHeader() {
  const apiKey = env("TWILIO_API_KEY");
  const apiSecret = env("TWILIO_API_SECRET");
  const sid = env("TWILIO_ACCOUNT_SID");
  const authToken = env("TWILIO_AUTH_TOKEN");

  if (apiKey && apiSecret) return "Basic " + btoa(`${apiKey}:${apiSecret}`);
  if (sid && authToken)  return "Basic " + btoa(`${sid}:${authToken}`);
  throw new Error("Missing Twilio credentials: set TWILIO_API_KEY & TWILIO_API_SECRET (preferred) or TWILIO_ACCOUNT_SID & TWILIO_AUTH_TOKEN.");
}

async function sendSms(to, body) {
  if (!to) throw new Error("sendSms: missing 'to' (+1XXXXXXXXXX)");
  if (!body) throw new Error("sendSms: missing 'body'");

  const accountSid = env("TWILIO_ACCOUNT_SID");
  if (!accountSid) throw new Error("Missing TWILIO_ACCOUNT_SID");

  const mg = env("TWILIO_MESSAGING_SERVICE_SID");
  const legacyFrom = env("TWILIO_FROM");

  const form = new URLSearchParams();
  form.set("To", to);
  form.set("Body", body);
  if (mg) form.set("MessagingServiceSid", mg);
  else if (legacyFrom) form.set("From", legacyFrom);
  else throw new Error("No sender: set TWILIO_MESSAGING_SERVICE_SID (recommended) or TWILIO_FROM.");

  const res = await fetch(
    `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
    {
      method: "POST",
      headers: { Authorization: getAuthHeader(), "Content-Type": "application/x-www-form-urlencoded" },
      body: form.toString(),
    }
  );

  if (!res.ok) throw new Error(`Twilio error ${res.status}: ${await res.text()}`);
  return res.json();
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (req.method !== "POST") {
      return new Response("Method Not Allowed", { status: 405 });
    }

    const { to, body } = await req.json();
    const data = await sendSms(to, body);
    
    return Response.json({ 
      ok: true, 
      sid: data.sid, 
      status: data.status 
    });
  } catch (err) {
    console.error("SMS send error:", err);
    return Response.json({ 
      ok: false, 
      error: String(err) 
    }, { status: 500 });
  }
});