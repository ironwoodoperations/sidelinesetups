import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

/**
 * Reconcile equipment inventory against active bookings
 * This is a periodic audit function to catch discrepancies
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get all equipment
    const allEquipment = await base44.asServiceRole.entities.Equipment.list();
    
    // Get all confirmed bookings that haven't been completed
    const activeBookings = await base44.asServiceRole.entities.Bookings.filter({
      status: 'confirmed'
    });
    
    const discrepancies = [];
    
    for (const equipment of allEquipment) {
      // Calculate expected rented quantity from active bookings
      let expectedRentedQty = 0;
      
      // Find all allocations for this equipment
      const allocations = await base44.asServiceRole.entities.InventoryMovements.filter({
        equipmentId: equipment.id,
        type: 'allocate'
      });
      
      for (const allocation of allocations) {
        // Check if booking is still active
        const booking = activeBookings.find(b => b.id === allocation.bookingId);
        if (booking) {
          expectedRentedQty += Number(allocation.qty || 0);
        }
      }
      
      const currentRentedQty = Number(equipment.rentedQty || 0);
      
      if (currentRentedQty !== expectedRentedQty) {
        discrepancies.push({
          equipmentId: equipment.id,
          equipmentName: equipment.name,
          currentRentedQty,
          expectedRentedQty,
          difference: currentRentedQty - expectedRentedQty
        });
        
        // Auto-fix the discrepancy
        const totalQty = Number(equipment.totalQty || 0);
        await base44.asServiceRole.entities.Equipment.update(equipment.id, {
          rentedQty: expectedRentedQty,
          availableQty: totalQty - expectedRentedQty - Number(equipment.maintenanceQty || 0) - Number(equipment.damagedQty || 0),
          version: Number(equipment.version || 0) + 1
        });
      }
    }

    return Response.json({
      success: true,
      totalEquipment: allEquipment.length,
      discrepanciesFound: discrepancies.length,
      discrepancies,
      message: discrepancies.length > 0 
        ? `Found and fixed ${discrepancies.length} inventory discrepancies`
        : 'All equipment inventory is accurate'
    });

  } catch (error) {
    console.error('[inventoryReconcile] Error:', error);
    return Response.json({
      error: error.message || 'Failed to reconcile inventory'
    }, { status: 500 });
  }
});