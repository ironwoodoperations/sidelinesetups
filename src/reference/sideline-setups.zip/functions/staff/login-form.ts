// GET /functions/staff/login-form?redirect=/Admin
// Simple server-rendered form that POSTs to /functions/staff/login

function esc(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

Deno.serve((req) => {
  const url = new URL(req.url);
  const redirectTo = url.searchParams.get('redirect') || '/Admin';

  const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Staff Login</title>
<style>
  body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif; margin:0; padding:2rem; background:#f8f8f8; }
  .card { max-width: 420px; margin: 0 auto; background:#fff; border:1px solid #e5e7eb; border-radius: 12px; padding: 24px; box-shadow: 0 1px 2px rgba(0,0,0,0.06); }
  h1 { font-size: 1.5rem; margin: 0 0 1rem; }
  label { display:block; font-size: 0.875rem; margin: 0 0 0.25rem; }
  input { width: 100%; padding: 10px 12px; border:1px solid #d1d5db; border-radius: 8px; font-size: 1rem; }
  button { width: 100%; margin-top: 12px; background: #111; color:#fff; border:0; padding: 10px 14px; border-radius: 9999px; font-weight:600; cursor:pointer; }
  .muted { margin-top: 8px; color:#6b7280; font-size: 12px; text-align:center; }
</style>
</head>
<body>
  <div class="card">
    <h1>Staff Login (PIN)</h1>
    <form action="/functions/staff/login" method="post">
      <input type="hidden" name="redirect" value="${esc(redirectTo)}" />
      <label for="pin">PIN</label>
      <input id="pin" name="pin" type="password" autocomplete="one-time-code" inputmode="numeric" placeholder="Enter PIN" required />
      <button type="submit">Sign in</button>
      <div class="muted">After sign-in you'll go to: ${esc(redirectTo)}</div>
    </form>
  </div>
</body>
</html>`;

  return new Response(html, { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8' } });
});