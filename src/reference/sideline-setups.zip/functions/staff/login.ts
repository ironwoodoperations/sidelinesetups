// functions/staff/login.js
import { createClient } from 'npm:@base44/sdk@0.7.1';

// ===== INLINED SESSION HELPER (to avoid Base44 import rewrites) =====
const cookie = {
  parse(req) {
    const raw = req.headers.get('cookie') || '';
    if (!raw) return {};
    return Object.fromEntries(
      raw.split(';').map(v => v.trim()).filter(Boolean).map(kv => {
        const i = kv.indexOf('=');
        if (i < 0) return [kv, ''];
        return [decodeURIComponent(kv.slice(0, i)), decodeURIComponent(kv.slice(i + 1))];
      })
    );
  },
  set(headers, name, value, opts = {}) {
    const parts = [`${encodeURIComponent(name)}=${encodeURIComponent(value)}`];
    if (opts.maxAge) parts.push(`Max-Age=${opts.maxAge}`);
    if (opts.expires) parts.push(`Expires=${opts.expires.toUTCString()}`);
    parts.push(`Path=/`, `SameSite=Lax`, `HttpOnly`, `Secure`);
    headers.append('Set-Cookie', parts.join('; '));
  },
  clear(headers, name) {
    headers.append('Set-Cookie', `${encodeURIComponent(name)}=; Max-Age=0; Path=/; HttpOnly; Secure; SameSite=Lax`);
  }
};

async function hmac(secret, msg) {
  const key = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(msg));
  return btoa(String.fromCharCode(...new Uint8Array(sig))).replace(/=+$/,'');
}

function getEnv(name, fallback) {
  try { return Deno.env.get(name) || fallback; } catch { return fallback; }
}

async function signSession(payload, kind = 'staff', maxAgeSeconds = 60 * 60 * 24 * 30) {
  const secret = kind === 'customer'
    ? getEnv('CUSTOMER_SESSION_SECRET', 'dev-customer-change-me')
    : getEnv('STAFF_SESSION_SECRET', 'dev-staff-change-me');
  const exp = Math.floor(Date.now() / 1000) + maxAgeSeconds;
  const data = JSON.stringify({ ...payload, exp });
  const sig = await hmac(secret, data);
  return `${btoa(data)}.${sig}`;
}
// ===== END INLINED SESSION HELPER =====

async function handlePOST(req) {
  const ct = req.headers.get('content-type') || '';
  let pin = '';
  let to = '/Admin';

  try {
    if (ct.includes('application/json')) {
      const body = await req.json();
      pin = (body?.pin || '').toString().trim();
      to = (body?.redirect || '/Admin').toString();
    } else {
      const form = await req.formData();
      pin = (form.get('pin') || '').toString().trim();
      to = (form.get('redirect') || '/Admin').toString();
    }
  } catch {}

  if (!pin) return new Response('PIN required', { status: 400 });

  const apiKey = getEnv('BASE44_SERVICE_API_KEY', '');
  if (!apiKey) return new Response('Missing BASE44_SERVICE_API_KEY', { status: 500 });

  const base44 = createClient({ apiKey });
  const matches = await base44.entities.Employees.filter({ pin });
  if (!matches?.length) return new Response('Invalid PIN', { status: 401 });

  const emp = matches[0];
  const token = await signSession(
    { sid: emp.id, role: emp.role || 'staff', name: emp.fullName || '', email: emp.email || '' },
    'staff'
  );

  const headers = new Headers();
  cookie.set(headers, 'staff_session', token, { maxAge: 60*60*24*30 });

  const accept = req.headers.get('Accept') || '';
  if (accept.includes('application/json')) {
    headers.set('Content-Type', 'application/json');
    return new Response(JSON.stringify({ ok: true, redirect: to || '/Admin' }), { status: 200, headers });
  }
  
  headers.set('Location', to || '/Admin');
  return new Response(null, { status: 302, headers });
}

async function handleGET() {
  return new Response(JSON.stringify({ ok: true, hint: 'POST pin to this endpoint' }), {
    status: 200, headers: { 'Content-Type': 'application/json' }
  });
}

Deno.serve(async (req) => {
  const method = (req.method || 'GET').toUpperCase();
  if (method === 'POST') return handlePOST(req);
  return handleGET();
});