import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

/**
 * Gets the current loyalty point balance for a customer
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const { customerEmail } = await req.json();
    
    if (!customerEmail) {
      return Response.json({ 
        error: 'Missing required field: customerEmail' 
      }, { status: 400 });
    }
    
    // Get customer's loyalty credits
    const existingCredits = await base44.asServiceRole.entities.LoyaltyCredits.filter({
      customerId: customerEmail
    });
    
    let balance = 0;
    if (existingCredits && existingCredits.length > 0) {
      balance = existingCredits[0].points || 0;
    }
    
    // Get recent transactions
    const allTransactions = await base44.asServiceRole.entities.LoyaltyTransactions.filter({
      customerEmail: customerEmail
    });
    
    // Sort by date descending
    const transactions = (allTransactions || []).sort((a, b) => {
      const dateA = new Date(a.created_date);
      const dateB = new Date(b.created_date);
      return dateB - dateA;
    }).slice(0, 10); // Last 10 transactions
    
    return Response.json({
      success: true,
      balance,
      dollarValue: (balance / 10).toFixed(2), // 100 points = $10
      transactions,
      conversionRate: {
        pointsPerDollarSpent: 1,
        pointsPerDollarDiscount: 10
      }
    });
    
  } catch (error) {
    console.error('Error getting loyalty balance:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});