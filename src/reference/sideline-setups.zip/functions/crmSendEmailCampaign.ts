import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

function sleep(ms) { 
  return new Promise(r => setTimeout(r, ms)); 
}

function chunk(arr, n) {
  const out = [];
  for (let i = 0; i < arr.length; i += n) {
    out.push(arr.slice(i, i + n));
  }
  return out;
}

function escapeHtml(s) {
  return String(s || '').replace(/[&<>"]/g, c => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;'
  }[c]));
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Verify authentication
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      campaignId,
      subject = "",
      bodyText = "",
      bodyHtml = "",
      testTo,
      previewOnly = false,
      segment = "all",
      segmentTag = "",
      scheduleAt
    } = await req.json();

    const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
    const MAIL_FROM = Deno.env.get("MAIL_FROM") || Deno.env.get("EMAIL_FROM_ADDRESS") || "no-reply@sidelinesetups.com";
    const MAIL_REPLY_TO = Deno.env.get("MAIL_REPLY_TO") || MAIL_FROM;
    
    if (!RESEND_API_KEY) {
      console.error("[crmSendEmailCampaign] Missing RESEND_API_KEY");
      return Response.json({ error: "Missing RESEND_API_KEY - please set it in environment variables" }, { status: 500 });
    }

    console.log("[crmSendEmailCampaign] Starting campaign send with:", {
      testTo,
      previewOnly,
      segment,
      segmentTag,
      from: MAIL_FROM
    });

    // Handle scheduling
    if (scheduleAt && new Date(scheduleAt) > new Date()) {
      const row = await base44.asServiceRole.entities.Campaigns.create({
        type: "email",
        subject,
        bodyText,
        bodyHtml,
        segment: segmentTag ? `tag:${segmentTag}` : segment,
        scheduledFor: scheduleAt,
        status: "scheduled"
      });
      return Response.json({ ok: true, scheduled: true, campaign: row });
    }

    // Determine recipients
    let recipients = [];
    if (testTo) {
      recipients = [{ email: String(testTo).trim().toLowerCase(), fullName: "Test User", unsubscribedEmail: false }];
    } else {
      let rows = await base44.asServiceRole.entities.Contacts.list();
      rows = (rows || []).filter((c) => c.email && !c.unsubscribedEmail);
      if (segment === "tag" && segmentTag) {
        const t = String(segmentTag).trim().toLowerCase();
        rows = rows.filter((c) => (c.tags || []).some((x) => String(x).toLowerCase() === t));
      }
      recipients = rows.map(c => ({
        email: String(c.email).trim().toLowerCase(),
        fullName: c.fullName || "",
        unsubscribedEmail: c.unsubscribedEmail || false
      }));
    }

    console.log(`[crmSendEmailCampaign] Found ${recipients.length} recipients`);

    if (!recipients.length) {
      return Response.json({ ok: true, count: 0, message: "No recipients found" });
    }

    if (previewOnly) {
      return Response.json({ ok: true, previewOnly: true, count: recipients.length });
    }

    // Create or update Campaign record
    const campaign = campaignId
      ? await base44.asServiceRole.entities.Campaigns.update(campaignId, { status: "sending" })
      : await base44.asServiceRole.entities.Campaigns.create({
          type: "email",
          subject,
          bodyText,
          bodyHtml,
          segment: segmentTag ? `tag:${segmentTag}` : segment,
          status: "sending"
        });

    let sent = 0;
    let errors = 0;
    const templateRe = /\{\{(.*?)\}\}/g;

    const personalize = (text, row) => {
      return String(text || '').replace(templateRe, (_, key) => {
        const trimmed = key.trim();
        return String(row[trimmed] || "");
      });
    };

    // Send in batches (Resend allows up to 50 recipients per call in batch mode)
    const batches = chunk(recipients, 50);
    
    for (const batch of batches) {
      for (const r of batch) {
        const personalizedSubject = personalize(subject, r);
        const personalizedText = personalize(bodyText, r);
        const personalizedHtml = bodyHtml 
          ? personalize(bodyHtml, r)
          : `<pre style="font:14px/1.4 -apple-system,Segoe UI,Arial">${escapeHtml(personalizedText)}</pre>`;

        const payload = {
          from: MAIL_FROM,
          to: [r.email],
          subject: personalizedSubject,
          text: personalizedText || undefined,
          html: personalizedHtml,
          reply_to: MAIL_REPLY_TO,
          tags: [
            { name: "campaign", value: campaign.id },
            { name: "type", value: "crm_campaign" }
          ]
        };

        try {
          const response = await fetch("https://api.resend.com/emails", {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${RESEND_API_KEY}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
          });

          if (!response.ok) {
            const errorText = await response.text();
            console.error("[crmSendEmailCampaign] Resend error:", errorText);
            errors++;
          } else {
            const result = await response.json();
            console.log("[crmSendEmailCampaign] Email sent successfully:", result.id);
            sent++;
          }

          // Rate limiting - ~8-10 emails/second is safe
          await sleep(120);
        } catch (err) {
          console.error("[crmSendEmailCampaign] Send failed:", err);
          errors++;
        }
      }
      
      // Pause between batches
      await sleep(500);
    }

    // Update campaign status
    await base44.asServiceRole.entities.Campaigns.update(campaign.id, {
      status: "sent",
      stats: { sent, errors },
      sentAt: new Date().toISOString()
    });

    console.log(`[crmSendEmailCampaign] Campaign complete: ${sent} sent, ${errors} errors`);

    return Response.json({ ok: true, count: sent, errors, campaignId: campaign.id });
  } catch (error) {
    console.error("[crmSendEmailCampaign] Error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});