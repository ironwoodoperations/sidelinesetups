
import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import { jsPDF } from 'npm:jspdf@2.5.2';

// 12-hour time formatter - FIXED to handle PM times correctly
function fmt12h(timeStr) {
  if (!timeStr) return "";
  const [hh, mm] = timeStr.split(":").map(n => parseInt(n, 10));
  const ampm = hh >= 12 ? "PM" : "AM";
  const hour = hh === 0 ? 12 : (hh > 12 ? hh - 12 : hh);
  return `${hour}:${mm.toString().padStart(2, "0")} ${ampm}`;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { bookingId } = await req.json();
    
    if (!bookingId) {
      return Response.json({ error: 'Missing bookingId' }, { status: 400 });
    }

    // Fetch booking
    const booking = await base44.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }

    // Fetch event
    let event = null;
    if (booking.eventId) {
      try {
        event = await base44.asServiceRole.entities.Events.get(booking.eventId);
      } catch (e) {
        console.warn('[generateBookingReceipt] Could not load event:', e);
      }
    }

    // Fetch package
    let packageData = null;
    // packageEquipment and its loading logic are removed as package features are used instead.
    if (booking.packageId) {
      try {
        packageData = await base44.asServiceRole.entities.Packages.get(booking.packageId);
      } catch (e) {
        console.warn('[generateBookingReceipt] Could not load package:', e);
      }
    }

    // Fetch park, field, spot
    let park = null;
    let field = null;
    let spot = null;
    
    if (booking.parkId) {
      try {
        park = await base44.asServiceRole.entities.Parks.get(booking.parkId);
      } catch (e) {
        console.warn('[generateBookingReceipt] Could not load park:', e);
      }
    }
    
    if (booking.fieldId) {
      try {
        field = await base44.asServiceRole.entities.Fields.get(booking.fieldId);
      } catch (e) {
        console.warn('[generateBookingReceipt] Could not load field:', e);
      }
    }
    
    if (booking.spotId) {
      try {
        spot = await base44.asServiceRole.entities.Spots.get(booking.spotId);
      } catch (e) {
        console.warn('[generateBookingReceipt] Could not load spot:', e);
      }
    }

    // Fetch settings for branding and contact info
    const settingsList = await base44.asServiceRole.entities.SiteSettings.list();
    const settings = settingsList?.[0] || {};
    const brandName = settings.brandName || "Sideline Setups";
    const supportEmail = settings.supportEmail || 'support@sideline-setups.com';
    const supportPhone = settings.supportPhone || '(903) 541-9287';
    const siteDomain = settings.siteDomain || 'https://www.sideline-setups.com'; 

    // Create PDF
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    let yPos = 20;

    // Header with solid navy background
    doc.setFillColor(0, 63, 92);
    doc.rect(0, 0, pageWidth, 50, 'F');

    // Brand name and tagline - WHITE TEXT
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(28);
    doc.setFont(undefined, 'bold');
    doc.text(brandName, pageWidth / 2, 25, { align: 'center' });
    
    doc.setFontSize(12);
    doc.setFont(undefined, 'normal');
    doc.text('GameDay Without The Haul', pageWidth / 2, 35, { align: 'center' });

    yPos = 60;

    // Title
    doc.setTextColor(0, 0, 0); // Reset to black for body
    doc.setFontSize(20);
    doc.setFont(undefined, 'bold');
    doc.text('Booking Receipt', pageWidth / 2, yPos, { align: 'center' });
    
    yPos += 15;

    // Booking Details Section - Correct Order
    doc.setFontSize(14);
    doc.setFont(undefined, 'bold');
    doc.text('Booking Details', 20, yPos);
    yPos += 8;
    
    doc.setFontSize(10);
    doc.setFont(undefined, 'normal');
    
    // Booking ID
    doc.text(`Booking ID: ${booking.id}`, 20, yPos);
    yPos += 6;
    
    // Event
    doc.text(`Event: ${event?.name || 'TBD'}`, 20, yPos);
    yPos += 6;
    
    // Date
    const dateStr = booking.date 
      ? new Date(booking.date).toLocaleDateString('en-US', { 
          weekday: 'long', 
          month: 'long', 
          day: 'numeric', 
          year: 'numeric' 
        })
      : 'TBD';
    doc.text(`Date: ${dateStr}`, 20, yPos);
    yPos += 6;
    
    // Team Name
    if (booking.teamName) {
      doc.text(`Team Name: ${booking.teamName}`, 20, yPos);
      yPos += 6;
    }
    
    // Game Times
    if (booking.gameTimes && booking.gameTimes.length > 0) {
      const formattedTimes = booking.gameTimes.map(t => fmt12h(t)).join(', ');
      doc.text(`Game Times: ${formattedTimes}`, 20, yPos);
      yPos += 6;
    }
    
    // Package
    doc.text(`Package: ${packageData?.name || 'TBD'}`, 20, yPos); // Updated 'Package' to 'TBD'
    yPos += 6;
    
    // Park
    doc.text(`Park: ${park?.name || 'TBD'}`, 20, yPos);
    yPos += 6;
    
    // Field
    if (field) {
      doc.text(`Field: ${field.name}`, 20, yPos);
      yPos += 6;
    }
    
    // Spot
    if (spot) {
      doc.text(`Spot: ${spot.label}`, 20, yPos);
      yPos += 6;
    }

    yPos += 5;

    // Package Features Section (not equipment) - ONLY features
    if (packageData && packageData.features && packageData.features.length > 0) {
      doc.setFontSize(14);
      doc.setFont(undefined, 'bold');
      doc.text(`Included with ${packageData.name}:`, 20, yPos);
      yPos += 8;
      
      doc.setFontSize(10);
      doc.setFont(undefined, 'normal');
      
      packageData.features.forEach((feature) => {
        doc.text(`  • ${feature}`, 25, yPos);
        yPos += 5;
      });
      
      yPos += 5;
    }

    // Line Items Table
    if (booking.lineItemsJson && booking.lineItemsJson.length > 0) {
      if (yPos > 220) {
        doc.addPage();
        yPos = 20;
      }

      doc.setFontSize(14);
      doc.setFont(undefined, 'bold');
      doc.text('Order Summary', 20, yPos);
      yPos += 10;

      // Table headers
      doc.setFontSize(9);
      doc.setFont(undefined, 'bold');
      doc.text('Item', 20, yPos);
      doc.text('When', 75, yPos);
      doc.text('Duration', 105, yPos);
      doc.text('Qty', 135, yPos);
      doc.text('Unit Price', 150, yPos);
      doc.text('Total', 180, yPos);
      yPos += 5;

      // Draw line under headers
      doc.setDrawColor(200);
      doc.line(20, yPos, 190, yPos);
      yPos += 5;

      // Table rows
      doc.setFont(undefined, 'normal');
      booking.lineItemsJson.forEach((item) => {
        if (yPos > 270) {
          doc.addPage();
          yPos = 20;
        }

        const itemName = item.itemName || item.label || 'Item';
        const dayLabel = item.dayLabel || '-';
        const durationLabel = item.durationLabel || '-';
        const qty = item.qty || 1;
        const unitPrice = `$${((item.unitCents || 0) / 100).toFixed(2)}`;
        const total = `$${((item.totalCents || 0) / 100).toFixed(2)}`;

        doc.text(itemName, 20, yPos, { maxWidth: 50 });
        doc.text(dayLabel, 75, yPos, { maxWidth: 25 });
        doc.text(durationLabel, 105, yPos, { maxWidth: 25 });
        doc.text(String(qty), 135, yPos);
        doc.text(unitPrice, 150, yPos);
        doc.text(total, 180, yPos);
        yPos += 6;
      });

      yPos += 5;

      // Totals
      doc.setFont(undefined, 'bold');
      if (booking.baseCents !== undefined) {
        doc.text(`Package Subtotal: $${(booking.baseCents / 100).toFixed(2)}`, 20, yPos);
        yPos += 6;
      }
      if (booking.addOnCents !== undefined && booking.addOnCents > 0) {
        doc.text(`Add-Ons Subtotal: $${(booking.addOnCents / 100).toFixed(2)}`, 20, yPos);
        yPos += 6;
      }
      if (booking.totalCents !== undefined) {
        doc.setFontSize(12);
        doc.text(`Total: $${(booking.totalCents / 100).toFixed(2)}`, 20, yPos);
        yPos += 10;
      }
      doc.setFont(undefined, 'normal');
    }

    // What's Next section with enhanced messaging
    doc.addPage();
    yPos = 40;

    // What's Next header with navy background
    doc.setFillColor(0, 63, 92);
    doc.rect(20, yPos, pageWidth - 40, 12, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(16);
    doc.setFont(undefined, "bold");
    doc.text("What's Next?", 25, yPos + 8);
    
    yPos += 20;
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(10);

    // Step 1
    doc.setFont(undefined, "bold");
    doc.text("1. We'll Keep You Updated", 25, yPos);
    doc.setFont(undefined, "normal");
    yPos += 6;
    const step1Text = doc.splitTextToSize(
      "You'll receive a reminder email 24 hours before your event with all the important details and setup information.",
      pageWidth - 50
    );
    doc.text(step1Text, 25, yPos);
    yPos += step1Text.length * 5 + 8;

    // Step 2
    doc.setFont(undefined, "bold");
    doc.text("2. Your Setup Will Be Ready", 25, yPos);
    doc.setFont(undefined, "normal");
    yPos += 6;
    const step2Text = doc.splitTextToSize(
      "Our team will arrive early to set everything up. We'll send you a text message when your setup is complete and ready for you to use. Just show up and enjoy!",
      pageWidth - 50
    );
    doc.text(step2Text, 25, yPos);
    yPos += step2Text.length * 5 + 8;

    // Step 3
    doc.setFont(undefined, "bold");
    doc.text("3. When You're Heading Out", 25, yPos);
    doc.setFont(undefined, "normal");
    yPos += 6;
    const step3Text = doc.splitTextToSize(
      `When you're finished and leaving, just send us a quick text at ${supportPhone} so we can come break down your setup. Easy as that!`,
      pageWidth - 50
    );
    doc.text(step3Text, 25, yPos);
    yPos += step3Text.length * 5 + 8;

    // Step 4
    doc.setFont(undefined, "bold");
    doc.text("4. Questions or Changes?", 25, yPos);
    doc.setFont(undefined, "normal");
    yPos += 6;
    const step4Text = doc.splitTextToSize(
      `Need to update your booking or have questions? Call or text us at ${supportPhone} or email ${supportEmail}. We're here to help!`,
      pageWidth - 50
    );
    doc.text(step4Text, 25, yPos);
    yPos += step4Text.length * 5 + 8; // Adjust yPos for the last section's height

    // Footer
    doc.setTextColor(100);
    doc.setFontSize(8);
    doc.text(`Check-in URL: ${siteDomain}/checkin?b=${booking.id}`, pageWidth / 2, yPos, { align: 'center' });

    // Generate PDF
    const pdfBytes = doc.output('arraybuffer');

    return new Response(pdfBytes, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="booking-${booking.id}.pdf"`
      }
    });

  } catch (error) {
    console.error('[generateBookingReceipt] Error:', error);
    return Response.json({ 
      error: error.message || 'Failed to generate receipt',
      details: error.toString()
    }, { status: 500 });
  }
});
