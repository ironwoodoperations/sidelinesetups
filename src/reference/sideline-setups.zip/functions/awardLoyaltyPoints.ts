import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

/**
 * Awards loyalty points to a customer after booking completion
 * Call this function after payment is captured and booking is confirmed
 * 
 * Rules:
 * - 1 point per $1 spent (configurable via pointsPerDollar)
 * - Bonus points for first booking
 * - Updates LoyaltyCredits entity
 * - Creates LoyaltyTransactions record
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const { bookingId, amountCents, customerEmail, isFirstBooking = false } = await req.json();
    
    if (!bookingId || !amountCents || !customerEmail) {
      return Response.json({ 
        error: 'Missing required fields: bookingId, amountCents, customerEmail' 
      }, { status: 400 });
    }

    // Configuration (could move to SiteSettings later)
    const pointsPerDollar = 1;
    const firstBookingBonus = 100;
    
    // Calculate points earned
    const amountDollars = amountCents / 100;
    let pointsEarned = Math.floor(amountDollars * pointsPerDollar);
    
    // Add first booking bonus
    if (isFirstBooking) {
      pointsEarned += firstBookingBonus;
    }
    
    // Get or create customer loyalty record
    const existingCredits = await base44.asServiceRole.entities.LoyaltyCredits.filter({
      customerId: customerEmail // Using email as customerId for now
    });
    
    let currentBalance = 0;
    let loyaltyRecord = null;
    
    if (existingCredits && existingCredits.length > 0) {
      loyaltyRecord = existingCredits[0];
      currentBalance = loyaltyRecord.points || 0;
    }
    
    const newBalance = currentBalance + pointsEarned;
    
    // Update or create loyalty credits
    if (loyaltyRecord) {
      await base44.asServiceRole.entities.LoyaltyCredits.update(loyaltyRecord.id, {
        points: newBalance
      });
    } else {
      await base44.asServiceRole.entities.LoyaltyCredits.create({
        customerId: customerEmail,
        points: newBalance
      });
    }
    
    // Create transaction record
    await base44.asServiceRole.entities.LoyaltyTransactions.create({
      customerId: customerEmail,
      customerEmail: customerEmail,
      type: isFirstBooking ? 'earned_bonus' : 'earned_booking',
      pointsChange: pointsEarned,
      bookingId: bookingId,
      reason: isFirstBooking 
        ? `Booking #${bookingId.slice(0, 8)} + First Booking Bonus (${firstBookingBonus} pts)` 
        : `Booking #${bookingId.slice(0, 8)} completed`,
      balanceAfter: newBalance,
      metadata: {
        amountCents,
        amountDollars,
        pointsPerDollar,
        firstBookingBonus: isFirstBooking ? firstBookingBonus : 0
      }
    });
    
    // Update booking with points earned
    await base44.asServiceRole.entities.Bookings.update(bookingId, {
      loyaltyPointsEarned: pointsEarned
    });
    
    return Response.json({
      success: true,
      pointsEarned,
      newBalance,
      isFirstBooking,
      message: `Awarded ${pointsEarned} loyalty points!`
    });
    
  } catch (error) {
    console.error('Error awarding loyalty points:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});