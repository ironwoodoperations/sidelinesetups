import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const { 
      code, 
      subtotalCents, 
      customerEmail, 
      packageId, 
      eventId 
    } = await req.json();

    if (!code) {
      return Response.json({ 
        valid: false, 
        error: 'Please enter a discount code' 
      });
    }

    if (!subtotalCents || subtotalCents <= 0) {
      return Response.json({ 
        valid: false, 
        error: 'Invalid order total' 
      });
    }

    // Find the discount code (case-insensitive)
    const codes = await base44.asServiceRole.entities.DiscountCodes.filter({});
    const discountCode = codes.find(c => c.code.toUpperCase() === code.toUpperCase());

    if (!discountCode) {
      return Response.json({ 
        valid: false, 
        error: 'Invalid discount code' 
      });
    }

    // Check if code is active
    if (!discountCode.isActive) {
      return Response.json({ 
        valid: false, 
        error: 'This discount code is no longer active' 
      });
    }

    // Check expiration
    if (discountCode.expiryDate) {
      const expiryDate = new Date(discountCode.expiryDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (expiryDate < today) {
        return Response.json({ 
          valid: false, 
          error: 'This discount code has expired' 
        });
      }
    }

    // Check total usage limit
    if (discountCode.usageLimit && discountCode.usageCount >= discountCode.usageLimit) {
      return Response.json({ 
        valid: false, 
        error: 'This discount code has reached its usage limit' 
      });
    }

    // Check per-customer usage limit
    if (discountCode.perCustomerLimit && customerEmail) {
      const customerBookings = await base44.asServiceRole.entities.Bookings.filter({
        contactEmail: customerEmail,
        discountCodeId: discountCode.id
      });
      
      if (customerBookings.length >= discountCode.perCustomerLimit) {
        return Response.json({ 
          valid: false, 
          error: 'You have already used this discount code the maximum number of times' 
        });
      }
    }

    // Check minimum purchase requirement
    const subtotalUSD = subtotalCents / 100;
    if (discountCode.minimumPurchaseUSD && subtotalUSD < discountCode.minimumPurchaseUSD) {
      return Response.json({ 
        valid: false, 
        error: `This code requires a minimum purchase of $${discountCode.minimumPurchaseUSD.toFixed(2)}` 
      });
    }

    // Check applicability (packages/events)
    if (discountCode.applicableTo === 'packages' && discountCode.applicableIds.length > 0) {
      if (!packageId || !discountCode.applicableIds.includes(packageId)) {
        return Response.json({ 
          valid: false, 
          error: 'This code is not applicable to your selected package' 
        });
      }
    }

    if (discountCode.applicableTo === 'events' && discountCode.applicableIds.length > 0) {
      if (!eventId || !discountCode.applicableIds.includes(eventId)) {
        return Response.json({ 
          valid: false, 
          error: 'This code is not applicable to this event' 
        });
      }
    }

    // Calculate discount amount
    let discountCents = 0;
    if (discountCode.type === 'percentage') {
      discountCents = Math.round(subtotalCents * (discountCode.value / 100));
    } else if (discountCode.type === 'fixed_amount') {
      discountCents = Math.round(discountCode.value * 100);
    }

    // Don't let discount exceed subtotal
    if (discountCents > subtotalCents) {
      discountCents = subtotalCents;
    }

    // Return success
    return Response.json({
      valid: true,
      discountCode: {
        id: discountCode.id,
        code: discountCode.code,
        type: discountCode.type,
        value: discountCode.value,
        discountCents: discountCents,
        discountUSD: (discountCents / 100).toFixed(2)
      },
      message: discountCode.type === 'percentage' 
        ? `${discountCode.value}% discount applied!` 
        : `$${discountCode.value} discount applied!`
    });

  } catch (error) {
    console.error('Error validating discount code:', error);
    return Response.json({ 
      valid: false, 
      error: 'Failed to validate discount code. Please try again.' 
    }, { status: 500 });
  }
});