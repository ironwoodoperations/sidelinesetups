import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { employeeId, parkId = "", notes = "" } = await req.json();
    
    if (!employeeId) {
      return Response.json({ error: 'employeeId required' }, { status: 400 });
    }

    // Check if already clocked in
    const open = await base44.asServiceRole.entities.TimeEntries.filter({ 
      employeeId,
      clockOutAt: null 
    });
    
    if (open && open.length > 0) {
      return Response.json({ ok: true, alreadyOpen: true, id: open[0].id });
    }

    const row = await base44.asServiceRole.entities.TimeEntries.create({
      employeeId,
      clockInAt: new Date().toISOString(),
      clockOutAt: null,
      parkId,
      notes,
      source: "kiosk"
    });

    return Response.json({ ok: true, id: row.id });
  } catch (error) {
    console.error('Error in timeClockIn:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});