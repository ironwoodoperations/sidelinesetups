import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id, delta, expectVersion } = await req.json();
    
    if (!id || !delta || (delta !== 1 && delta !== -1)) {
      return Response.json({ error: 'Invalid args: id and delta (+1 or -1) required' }, { status: 400 });
    }

    const row = await base44.asServiceRole.entities.LeagueSpotInventory.get(id);
    if (!row) {
      return Response.json({ error: 'Not found' }, { status: 404 });
    }
    
    if (typeof expectVersion === 'number' && row.version !== expectVersion) {
      return Response.json({ error: 'VersionConflict' }, { status: 409 });
    }
    
    const current = Number(row.availableSpots || 0);
    const next = current + delta;
    
    if (next < 0) {
      return Response.json({ error: 'No spots left' }, { status: 400 });
    }

    await base44.asServiceRole.entities.LeagueSpotInventory.update(id, {
      availableSpots: next,
      version: Number(row.version || 0) + 1
    });

    return Response.json({
      ok: true,
      availableSpots: next,
      version: Number(row.version || 0) + 1
    });

  } catch (error) {
    console.error('Error in leagueAdjustInventory:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});