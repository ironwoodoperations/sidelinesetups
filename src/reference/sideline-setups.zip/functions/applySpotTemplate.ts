import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { templateId, fieldId } = await req.json();
    
    if (!templateId || !fieldId) {
      return Response.json({ 
        error: 'templateId and fieldId are required' 
      }, { status: 400 });
    }

    const template = await base44.asServiceRole.entities.SpotTemplate.get(templateId);
    if (!template) {
      return Response.json({ error: 'Template not found' }, { status: 404 });
    }

    const field = await base44.asServiceRole.entities.Fields.get(fieldId);
    if (!field) {
      return Response.json({ error: 'Field not found' }, { status: 404 });
    }

    const existingSpots = await base44.asServiceRole.entities.Spots.filter({ fieldId });
    for (const spot of existingSpots) {
      await base44.asServiceRole.entities.Spots.delete(spot.id);
    }

    const createdSpots = [];
    for (const spotData of template.spots || []) {
      // Just use the label from template without adding field name
      const newLabel = spotData.label;

      const newSpot = await base44.asServiceRole.entities.Spots.create({
        fieldId: field.id,
        label: newLabel,
        x: spotData.x || 50,
        y: spotData.y || 50,
        isActive: true
      });
      
      createdSpots.push(newSpot);
    }

    return Response.json({ 
      success: true, 
      spotsCreated: createdSpots.length,
      spots: createdSpots
    });

  } catch (error) {
    console.error('Error applying spot template:', error);
    return Response.json({ 
      error: error.message || 'Failed to apply template' 
    }, { status: 500 });
  }
});