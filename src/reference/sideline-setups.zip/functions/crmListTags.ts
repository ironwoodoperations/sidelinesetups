import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Verify authentication
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const rows = await base44.asServiceRole.entities.Contacts.list();
    const set = new Set();
    
    for (const c of rows || []) {
      for (const t of c.tags || []) {
        if (t) set.add(t);
      }
    }
    
    return Response.json({ data: Array.from(set).sort() });
  } catch (error) {
    console.error("List tags error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});