// functions/notify.bookingConfirmedEmail.js
import { createClientFromRequest } from "npm:@base44/sdk@0.7.1";

// Inline helpers
function env(name) {
  const v = Deno.env.get(name);
  if (!v) return "";
  return v;
}

async function sendEmail({ from, to, subject, html, text }) {
  const apiKey = env("RESEND_API_KEY");
  if (!apiKey) {
    throw new Error("Missing RESEND_API_KEY environment variable");
  }

  const defaultFrom = env("EMAIL_FROM_ADDRESS") || "support@orders.sideline-setups.com";
  const fromAddress = from || defaultFrom;

  if (!to) throw new Error("sendEmail: missing 'to' address");
  if (!subject) throw new Error("sendEmail: missing 'subject'");
  if (!html && !text) throw new Error("sendEmail: missing 'html' or 'text' content");

  const payload = {
    from: fromAddress,
    to: Array.isArray(to) ? to : [to],
    subject,
    ...(html && { html }),
    ...(text && { text })
  };

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  if (!res.ok) {
    const errorText = await res.text();
    console.error("[Resend] sendEmail failed", res.status, errorText);
    throw new Error(`Resend error ${res.status}: ${errorText}`);
  }

  const data = await res.json();
  console.log("[Resend] Email sent", data.id);
  return data;
}

function fmtWhen(d, tz = "America/Chicago") {
  const dt = typeof d === "string" ? new Date(d) : d;
  return new Intl.DateTimeFormat("en-US", {
    timeZone: tz, month: "short", day: "numeric", weekday: "short",
  }).format(dt);
}

Deno.serve(async (req) => {
  try {
    if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });
    const { bookingId } = await req.json();
    if (!bookingId) return new Response("Missing bookingId", { status: 400 });

    const client = createClientFromRequest(req);
    const booking = await client.asServiceRole.entities.Bookings.get(bookingId);
    if (!booking) return new Response("Not found", { status: 404 });

    const name = booking.fullName || "there";
    const when = fmtWhen(booking.date);
    const park = booking.parkName || "your field";
    const email = booking.contactEmail;

    if (!email) {
      return new Response("No email address for booking", { status: 400 });
    }

    const html = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #003f5c;">Booking Confirmed! 🎉</h2>
        <p>Hi ${name},</p>
        <p>Your Sideline Setups booking is <strong>CONFIRMED</strong> for:</p>
        <div style="background: #f8fafc; padding: 16px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 8px 0;"><strong>📅 When:</strong> ${when}</p>
          <p style="margin: 8px 0;"><strong>📍 Where:</strong> ${park}</p>
          <p style="margin: 8px 0;"><strong>🎫 Booking ID:</strong> ${booking.id}</p>
        </div>
        <p>We'll set up your equipment before your first game. Just show up and enjoy!</p>
        <p style="margin-top: 32px;">See you at the fields,<br><strong>The Sideline Setups Team</strong></p>
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 32px 0;">
        <p style="font-size: 12px; color: #64748b;">
          Questions? Reply to this email or call us at (903) 541-9287
        </p>
      </div>
    `;

    await sendEmail({
      to: email,
      subject: `Booking Confirmed - ${when} at ${park}`,
      html
    });

    return new Response(JSON.stringify({ ok: true }), { status: 200 });
  } catch (e) {
    console.error("Error in notify.bookingConfirmedEmail:", e);
    return new Response(JSON.stringify({ ok: false, error: String(e) }), { status: 500 });
  }
});