import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

/**
 * Allocate equipment inventory for a booking
 * Handles both package baseItems and add-ons
 * Uses optimistic concurrency control (CAS) to prevent race conditions
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      console.error('[inventoryAllocate] Unauthorized - no user');
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { bookingId, packageId, addOns } = await req.json();
    
    console.log('[inventoryAllocate] Request received:', {
      bookingId,
      packageId,
      addOns: JSON.stringify(addOns, null, 2)
    });
    
    if (!bookingId) {
      return Response.json({ 
        success: false,
        error: 'Missing required field: bookingId' 
      }, { status: 400 });
    }

    const allocations = [];
    const equipmentAllocations = new Map(); // equipmentId => total quantity needed

    // 1. Process package baseItems
    if (packageId) {
      console.log('[inventoryAllocate] Processing package:', packageId);
      
      try {
        const pkg = await base44.asServiceRole.entities.Packages.get(packageId);
        console.log('[inventoryAllocate] Package loaded:', {
          id: pkg?.id,
          name: pkg?.name,
          baseItemsCount: pkg?.baseItems?.length || 0
        });
        
        if (pkg && pkg.baseItems && Array.isArray(pkg.baseItems)) {
          console.log('[inventoryAllocate] Package baseItems:', pkg.baseItems);
          
          for (const item of pkg.baseItems) {
            if (!item.equipmentId || !item.qty) {
              console.warn('[inventoryAllocate] Skipping baseItem with missing equipmentId or qty:', item);
              continue;
            }
            
            const current = equipmentAllocations.get(item.equipmentId) || 0;
            const newQty = current + Number(item.qty);
            
            console.log('[inventoryAllocate] Adding package baseItem:', {
              equipmentId: item.equipmentId,
              qty: item.qty,
              previousTotal: current,
              newTotal: newQty
            });
            
            equipmentAllocations.set(item.equipmentId, newQty);
          }
        } else {
          console.warn('[inventoryAllocate] Package has no baseItems or baseItems is not an array');
        }
      } catch (err) {
        console.error('[inventoryAllocate] Error loading package:', err);
        return Response.json({
          success: false,
          error: `Failed to load package: ${err.message}`
        }, { status: 500 });
      }
    }

    // 2. Process add-ons
    if (Array.isArray(addOns) && addOns.length > 0) {
      console.log('[inventoryAllocate] Processing add-ons:', addOns.length);
      
      for (const addon of addOns) {
        console.log('[inventoryAllocate] Processing addon:', JSON.stringify(addon, null, 2));
        
        if (!addon.id) {
          console.warn('[inventoryAllocate] Skipping addon with no id:', addon);
          continue;
        }
        
        // Get add-on details to find equipment link
        let addonRecord;
        try {
          addonRecord = await base44.asServiceRole.entities.AddOns.get(addon.id);
        } catch (err) {
          console.error('[inventoryAllocate] Failed to load addon:', addon.id, err);
          continue;
        }
        
        if (!addonRecord) {
          console.warn('[inventoryAllocate] AddOn record not found:', addon.id);
          continue;
        }
        
        if (!addonRecord.equipmentId) {
          console.log('[inventoryAllocate] AddOn has no equipmentId, skipping:', addonRecord.label);
          continue;
        }
        
        // Get the physical quantity directly from the addon object
        const quantity = Number(addon.quantity || 1);
        
        console.log('[inventoryAllocate] Adding addon:', {
          addonId: addon.id,
          addonLabel: addonRecord.label,
          equipmentId: addonRecord.equipmentId,
          quantity
        });
        
        // Accumulate quantity by equipment ID
        const current = equipmentAllocations.get(addonRecord.equipmentId) || 0;
        equipmentAllocations.set(addonRecord.equipmentId, current + quantity);
      }
    }

    console.log('[inventoryAllocate] Total equipment to allocate:', Array.from(equipmentAllocations.entries()));

    // 3. Allocate equipment with CAS retry logic
    for (const [equipmentId, quantity] of equipmentAllocations.entries()) {
      console.log(`[inventoryAllocate] Allocating ${quantity} of equipment ${equipmentId}`);
      
      let success = false;
      let attempts = 0;
      const maxAttempts = 5;
      
      while (!success && attempts < maxAttempts) {
        attempts++;
        
        try {
          // Fetch current equipment state
          const equipment = await base44.asServiceRole.entities.Equipment.get(equipmentId);
          
          if (!equipment) {
            return Response.json({
              success: false,
              error: `Equipment ${equipmentId} not found`
            }, { status: 400 });
          }
          
          console.log(`[inventoryAllocate] Equipment ${equipment.name} - Attempt ${attempts}:`, {
            availableQty: equipment.availableQty,
            rentedQty: equipment.rentedQty,
            neededQty: quantity
          });
          
          const availableQty = Number(equipment.availableQty || 0);
          const rentedQty = Number(equipment.rentedQty || 0);
          const currentVersion = Number(equipment.version || 0);
          
          // Check if we have enough inventory
          if (availableQty < quantity) {
            console.error(`[inventoryAllocate] Insufficient inventory for ${equipment.name}`);
            
            // Rollback any successful allocations
            for (const allocation of allocations) {
              try {
                const eq = await base44.asServiceRole.entities.Equipment.get(allocation.equipmentId);
                await base44.asServiceRole.entities.Equipment.update(allocation.equipmentId, {
                  availableQty: Number(eq.availableQty || 0) + allocation.quantity,
                  rentedQty: Number(eq.rentedQty || 0) - allocation.quantity,
                  version: Number(eq.version || 0) + 1
                });
                console.log(`[inventoryAllocate] Rolled back allocation for ${eq.name}`);
              } catch (rollbackError) {
                console.error('[inventoryAllocate] Rollback failed for', allocation.equipmentId, rollbackError);
              }
            }
            
            return Response.json({
              success: false,
              error: `Not enough inventory for ${equipment.name}. Available: ${availableQty}, Needed: ${quantity}`,
              equipmentId,
              equipmentName: equipment.name,
              available: availableQty,
              needed: quantity
            }, { status: 400 });
          }
          
          // Update with version check (CAS)
          await base44.asServiceRole.entities.Equipment.update(equipmentId, {
            availableQty: availableQty - quantity,
            rentedQty: rentedQty + quantity,
            version: currentVersion + 1
          });
          
          console.log(`[inventoryAllocate] Successfully updated ${equipment.name}:`, {
            newAvailableQty: availableQty - quantity,
            newRentedQty: rentedQty + quantity
          });
          
          // Log the allocation
          await base44.asServiceRole.entities.InventoryMovements.create({
            equipmentId,
            type: 'allocate',
            qty: quantity,
            unitCostUSD: equipment.cogsPerUseUSD || 0,
            bookingId,
            note: `Allocated for booking ${bookingId}`,
            whenAt: new Date().toISOString()
          });
          
          allocations.push({
            equipmentId,
            equipmentName: equipment.name,
            quantity,
            previousAvailable: availableQty,
            newAvailable: availableQty - quantity
          });
          
          success = true;
          
        } catch (updateError) {
          console.error(`[inventoryAllocate] Update error on attempt ${attempts}:`, updateError);
          
          if (attempts >= maxAttempts) {
            console.error('[inventoryAllocate] Max retries reached for', equipmentId);
            
            // Rollback any successful allocations
            for (const allocation of allocations) {
              try {
                const eq = await base44.asServiceRole.entities.Equipment.get(allocation.equipmentId);
                await base44.asServiceRole.entities.Equipment.update(allocation.equipmentId, {
                  availableQty: Number(eq.availableQty || 0) + allocation.quantity,
                  rentedQty: Number(eq.rentedQty || 0) - allocation.quantity,
                  version: Number(eq.version || 0) + 1
                });
              } catch (rollbackError) {
                console.error('[inventoryAllocate] Rollback failed for', allocation.equipmentId, rollbackError);
              }
            }
            
            return Response.json({
              success: false,
              error: 'Failed to allocate inventory after multiple attempts. Please try again.',
              details: updateError.message
            }, { status: 500 });
          }
          
          // Wait before retry (exponential backoff)
          await new Promise(resolve => setTimeout(resolve, 100 * attempts));
        }
      }
    }

    console.log('[inventoryAllocate] All allocations successful:', allocations);

    return Response.json({
      success: true,
      allocations,
      message: `Successfully allocated equipment for booking ${bookingId}`
    });

  } catch (error) {
    console.error('[inventoryAllocate] Unexpected error:', error);
    console.error('[inventoryAllocate] Error stack:', error.stack);
    return Response.json({
      success: false,
      error: error.message || 'Failed to allocate inventory'
    }, { status: 500 });
  }
});